import pandas as pd
from saturn_server.helpers import safe_register_formula

#
#When to use this file?
#----------------------
#Some problems with the meta-data or corruption of a series

#
#Example of error
#UniqueViolation: duplicate key value violates unique constraint "oil.energy_aspects.russia.throughput.kbd.monthly_pkey"
#DETAIL:  Key (id)=(1044) already exist
#

#
#Example of error
#

#What does this Python do ?
#---------------------------
#Delete the series and then re-create and apply all the versions back 

#
#How to use this ?
#See snippet below. You will need to call the function try_the_fix with the name of the series
#
#
#
def try_the_fix(tsa,name):
    print("hello world fix----------------")
    print(name)
    history = tsa.history(name)
    if history is None:
        print(f"The series was not found: {name}")
        return
    history_items  = history.items()
    existing_meta_data = tsa.metadata(name)
    tsa.delete(name)
    print(f"The series {name} was deleted")
    for idate, ts in history_items:        
        print(idate)
        tsa.update(name, ts, author='whatever', insertion_date=idate)            
    print("Finsihed with revision history")
    tsa.update_metadata(name,existing_meta_data)
    print("Finsihed with meta-data")
    print("finished repair")
    print("-----------------------")


if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    try_the_fix(tsa,"oil.energy_aspects.russia.throughput.kbd.monthly")
    exit()
    #try_the_fix(tsa,"diesel.dtn.padd_2.rack_sales.kbd.daily_pkey")
    try_the_fix(tsa,"diesel.dtn.padd_1.rack_sales.kbd.daily")
    exit()
    try_the_fix(tsa,"jet.dtn.padd_1.rack_sales.kbd.daily")
    try_the_fix(tsa,"jet.dtn.padd_2.rack_sales.kbd.daily")
    try_the_fix(tsa,"jet.dtn.padd_3.rack_sales.kbd.daily")
    try_the_fix(tsa,"jet.dtn.padd_4.rack_sales.kbd.daily")
    try_the_fix(tsa,"jet.dtn.padd_5.rack_sales.kbd.daily")
    try_the_fix(tsa,"jet.dtn.total.rack_sales.kbd.daily")
    #"diesel.dtn.total.rack_sales.kbd.daily")
    #"diesel.dtn.padd_5.rack_sales.kbd.daily")
    #"diesel.dtn.padd_4.rack_sales.kbd.daily")
    #"diesel.dtn.padd_3.rack_sales.kbd.daily")

