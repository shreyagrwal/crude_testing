from tshistory.api import timeseries

#
#What does this script do?
#-------------------------
#Moves series data from one Saturn environment to another, along with revision history
#
#Any short comings ?
#--------------------
#No way to find Author information from source environment . This has to be hard coded while updating the destination (see below)
#
#
#

def move_individual_series(tsa_source: timeseries, tsa_dest: timeseries, series_name: str)->None:
    df_series_on_dest  =tsa_dest.get(series_name)
    if df_series_on_dest is not None:
        print(f"The series {series_name} already exists. Skipping")
        return
    history = tsa_source.history(series_name)
    if history is None:
        print(f"The series was not found: {series_name}")
        return
    history_items  = history.items()
    df_series = tsa_source.get(series_name)
    
    existing_meta_data = tsa_source.metadata(series_name)
    print(f"Got a series with length={len(df_series)} , name={series_name}")
    #tsa_dest.update(series_name, df_series, 'dong')
    count_of_revision_items=0
    for idate, ts in history_items:        
        print(idate)
        tsa_dest.update(series_name, ts, author='dong', insertion_date=idate)  #Author has to be hard coded          
        count_of_revision_items +=1
    print("Finsihed with revision history")
    tsa_dest.update_metadata(series_name,existing_meta_data)
    print(f"Finsihed with meta-data , revision items={count_of_revision_items}")
    print(f"Completed {series_name}")
    


def move_series_to_ap8(tsa_source:timeseries, tsa_dest: timeseries,series_list:list[str])->None:
    for series_name in series_list:
        print(f"Going to move the series {series_name}")
        move_individual_series(tsa_source=tsa_source,tsa_dest=tsa_dest,series_name=series_name)
        print("--------------")
    pass
    
def get_lng_series_from_ap9(tsa:timeseries)->list[str]:
    catalog = tsa.catalog()
    first_item_key=list(catalog.keys())[0]
    all_tuples = catalog[first_item_key]
    all_series_names = map(lambda x: x[0], all_tuples)
    all_lng_series = filter(lambda x: x.startswith("lng."),all_series_names )
    return list(all_lng_series)

if __name__ == '__main__':
    url_ap9='http://tst-qdev-ap9.petroineos.local/api'
    url_ap8='http://tst-qdev-ap8.petroineos.local/api'
    
    tsa_ap9 = timeseries(url_ap9)
    tsa_ap8 = timeseries(url_ap8)
    print(f"Created instances of TSA on ap9={url_ap9} and ap8={url_ap8}")
    lng_series = get_lng_series_from_ap9(tsa=tsa_ap9)
    print(f"Got {len(lng_series)} series from the environment at {url_ap9}")
    move_series_to_ap8(tsa_source=tsa_ap9, tsa_dest=tsa_ap8,series_list=lng_series)
    exit()
