from sqlalchemy import create_engine
from tshistory_formula.tsio import timeseries
import sys




def check_metadata(cn_string: str):
    engine=create_engine(cn_string)
    tsh=timeseries()
    with engine.begin() as cn:
        for name,metadata,text in cn.execute('select name,metadata,text from tsh.formula').fetchall():
            if not metadata:                
                print(name)
                print(metadata)
                print(text)
                #print(tsh.formula(cn,name))
                cn.execute("delete from tsh.formula where name=%(name)s",name=name)
                print("----------------------")



if __name__ =="__main__":
    print(sys.argv)
    cn_string=sys.argv[1]
    print(f"cn_string={cn_string}")
    check_metadata(cn_string=cn_string)
    print("Complete")
