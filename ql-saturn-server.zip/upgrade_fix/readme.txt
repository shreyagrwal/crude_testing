About
------
This is a Python file that was written by Aurelien to investigate the upgrade issues from the version runing on AP9 to latest


Which were the failing series?
------------------------------
(add (* -1 (add (series "diesel.vortexa.other_europe.oecd_europe.imports.kt.30mav"))) 
(series "diesel.vortexa.baltic_ports.oecd_europe.imports.kt.30mav") 
(series "diesel.vortexa.oecd_europe.other_europe.exports.kt.30mav"))


How to run the metadatacheck.py?
--------------------------------
$db="postgresql://postgres:Pass%40word123@TST-QDEV-AP12/07-nov-0321"
python .\metadatacheck.py $db
