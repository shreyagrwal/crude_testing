import pandas as pd
import pytest

from tshistory.testutil import assert_df


def test_bo(engine, tsh):
    sql = (
        'select pdate as date, mean(nwesimple) as value '
        'from dataengineering.oil_crude_euromargin '
        'where type=0 and ddate >= \'{from_value_date}\'' 
        'and ddate <= \'{to_value_date}\' '
        'and pdate <= \'{revision_date}\' '
        'group by date'
    )

    tsh.register_formula(
        engine,
        'test_bo',
        f'(blueocean "{sql}")'
    )

    ts = tsh.get(
        engine,
        'test_bo',
        from_value_date=pd.Timestamp('2021-1-1'),
        to_value_date=pd.Timestamp('2021-1-31')
    )
    assert_df("""
date
2021-01-04    0.03
2021-01-05   -0.29
2021-01-06   -1.14
2021-01-07   -0.90
2021-01-08   -1.15
2021-01-11   -0.70
2021-01-12   -0.70
2021-01-13   -0.52
2021-01-14   -0.29
2021-01-15   -0.17
2021-01-18   -0.20
2021-01-19   -0.50
2021-01-20   -0.88
2021-01-21   -1.06
2021-01-22   -1.29
2021-01-25   -1.03
2021-01-26   -1.11
2021-01-27   -0.89
2021-01-28   -0.87
2021-01-29   -0.67
""", ts)


    ts = tsh.get(
        engine,
        'test_bo',
        from_value_date=pd.Timestamp('2021-1-1'),
        to_value_date=pd.Timestamp('2021-1-31'),
        revision_date=pd.Timestamp('2022-1-1')
    )
    assert_df("""
date
2021-01-04    0.03
2021-01-05   -0.29
2021-01-06   -1.14
2021-01-07   -0.90
2021-01-08   -1.15
2021-01-11   -0.70
2021-01-12   -0.70
2021-01-13   -0.52
2021-01-14   -0.29
2021-01-15   -0.17
2021-01-18   -0.20
2021-01-19   -0.50
2021-01-20   -0.88
2021-01-21   -1.06
2021-01-22   -1.29
2021-01-25   -1.03
2021-01-26   -1.11
2021-01-27   -0.89
2021-01-28   -0.87
2021-01-29   -0.67
""", ts)


def test_monthly_dummies(engine, tsh):
    ts = pd.Series(
        [1, 2, 3],
        index=pd.date_range(
            pd.Timestamp('2023-1-1'),
            freq='D',
            periods=3
        )
    )
    tsh.update(engine, ts, 'for-dummies', 'Babar')
    tsh.register_formula(
        engine,
        'm-dummies',
        '(monthly_dummies (series "for-dummies")'
        '  1 2 3 4 5 6 7 8 9 10 11 12)'
    )

    with pytest.raises(ValueError):
        tsh.get(engine, 'm-dummies')
