import pandas as pd


def test_table_get_frame(engine, tsh, http):
    """Test the custom http API point with one series"""
    ts = pd.Series(
        [1, 2, 3],
        index=pd.date_range(
            pd.Timestamp('2023-1-1'),
            periods=3,
            freq='D'
        )
    )
    tsh.update(engine, ts, 'test1', 'Aurélien')

    # query that and see what we get
    res = http.get('/api/table/get_frame', params={
        'name': 'test1',
        'format': 'json'
    })

    assert res.json == {
        '0': {
            'date': '2023-01-01T00:00:00.000',
            'id': 'test1',
            'index_dtype': '<M8[ns]',
            'index_type': 'datetime64[ns]',
            'supervision_status': 'unsupervised',
            'tablename': 'test1',
            'tzaware': False,
            'value_dtype': '<f8',
            'value_type': 'float64',
            '0': 1.0
        },
        '1': {
            'date': '2023-01-02T00:00:00.000',
            'id': 'test1',
            'index_dtype': '<M8[ns]',
            'index_type': 'datetime64[ns]',
            'supervision_status': 'unsupervised',
            'tablename': 'test1',
            'tzaware': False,
            'value_dtype': '<f8',
            'value_type': 'float64',
            '0': 2.0
        },
        '2': {
            'date': '2023-01-03T00:00:00.000',
            'id': 'test1',
            'index_dtype': '<M8[ns]',
            'index_type': 'datetime64[ns]',
            'supervision_status': 'unsupervised',
            'tablename': 'test1',
            'tzaware': False,
            'value_dtype': '<f8',
            'value_type': 'float64',
            '0': 3.0
        }
    }
