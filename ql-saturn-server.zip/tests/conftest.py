from functools import partial
from pathlib import Path

import pytest
from sqlalchemy import create_engine
from pytest_sa_pg import db

from tshistory.api import timeseries
from tshistory.testutil import (
    WebTester,
)
from tshistory_refinery import (
    schema,
    tsio
)

from saturn_server import webapi


DATADIR = Path(__file__).parent / 'test' / 'data'


@pytest.fixture(scope='session')
def engine(request):
    port = 5433
    db.setup_local_pg_cluster(request, DATADIR, port)
    uri = f'postgresql://localhost:{port}/postgres'
    e = create_engine(uri)
    schema.refinery_schema('tsh').create(e, rework=True, reset=True)
    yield e


@pytest.fixture(scope='session')
def tsh(engine):
    return tsio.timeseries()


@pytest.fixture(scope='session')
def http(engine):
    uri = str(engine.url)
    app = webapi.make_app(
        {'db': {'uri': uri}},
        timeseries(
            uri,
            handler=tsio.timeseries,
            sources={}
        )
    )
    return WebTester(app)
