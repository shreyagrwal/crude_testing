[[_TOC_]]
# Saturn server

Cross team repository for the saturn time series management system.

# Setup

Install packages

We need elm + postgresql  + make + mercurial for installing the saturn suite.

```
conda install -c anaconda postgresql
conda install -c anaconda mercurial
conda install -c conda-forge elm
conda install -c conda-forge make
```

In the repository:

If you do not have a database follow this: https://gist.github.com/gwangjinkim/f13bf596fefa7db7d31c22efd1627c7a

```
pip install -e. --no-cache-dir
```

Then we will pull repos where we need to compile elm files

```
hg clone https://hg.sr.ht/~pythonian/tshistory_refinery
hg clone https://hg.sr.ht/~pythonian/tsview
```

Clinkhange the elm version in the `elm.json` so that it matches the current conda installation of elm 

then in each of the repository folders, use `make` to compile elm files. Then, install the packages locally with `pip install -e.`

Fork the `refinery.example.cfg` file by removing the `example` placeholder and put the postgresql route for the URI.

Set the following environmenet variables:

```
URI=<uri> # Postgresql URL for the saturn database
DGUSER=<username> # Datagenic user name
DGPASSWORD=<password> # Datagenic password
DGSERVER=<dgserver> # Datagenic upstream server
DGREST=<dgrest> # Datagenic REST server
ADISERVER=<adiserver> # ADI server url
WORKERS=<n_workers> # Number of rework workers
```

# Get the datagenic package:

```
pip install git+http://lon-build01:7990/scm/quan/ql-datagenic-rest-api.git
```

# Start

Starting the postgresql database:

```
pg_ctl -D <dbname> -l logfile start
```

Start the rework service (use the environement variables):

```
rework monitor <URI> --maxworkers <WORKERS>
```

Start the webserver

```
saturn webstart
```

## Project structure

```bash
├───saturn_server
│   ├───cross # cross crude and products folder
│   │   ├───data
│   ├───crude # crude oil specific saturn folder
│   │   ├───data
│   ├───products # oil products specific saturn folder
│   │   ├───data
│   │   ├───models
├───scripts # Ad-hoc upstream scrapers to injest in ADI it should be copy-pastable straight in AP3
│   ├───cross
│   ├───crude
│   └───products
├───tests # Unit tests
```

---

# How to import the custom funcs from ql-saturn-server into another vanilla instance of Saturn

[import_custom_funcs_into_vanilla_instance.md](docs/import_custom_funcs_into_vanilla_instance.md)

# How to restore a POSTGRES backup from PROD to DEV ?
See notes in the inner [readme.md](windows_server_deploy/readme.md)
