import pandas as pd
from vortexasdk import CargoTimeSeries, Products, Geographies
from tshistory.api import timeseries
from dotenv import load_dotenv



if __name__ == '__main__':
    load_dotenv()
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')

    diesel = [
        p.id
        for p in Products().search(term="Diesel/Gasoil").to_list()
        if p.name == "Diesel/Gasoil"
    ]
    russia = [
        p.id
        for p in Geographies().search(term="Russia").to_list()
        if p.name == "Russia"
    ]
    diesel_floating = CargoTimeSeries().search(
        # We're looking at daily storage levels
        timeseries_frequency="day",
        # We want 'b' for barrels here
        timeseries_unit="t",
        # We're only interested in storage of Medium-Sour Crude
        filter_products=diesel,
        # We're only included in cargo's that were in floating storage
        filter_activity="storing_state",
        # We're only interested in floating storage that lasted longer than 14 days
        timeseries_activity_time_span_min=1000 * 60 * 60 * 24 * 14,
        # Let's limit the search to January 2019 storage events
        filter_time_min=pd.Timestamp("2016-1-1"),
        filter_time_max=pd.Timestamp.now(),
    )
    diesel_floating_ex_russia = CargoTimeSeries().search(
        # We're looking at daily storage levels
        timeseries_frequency="day",
        # We want 'b' for barrels here
        timeseries_unit="t",
        # We're only interested in storage of Medium-Sour Crude
        filter_products=diesel,
        # We're only included in cargo's that were in floating storage
        filter_activity="storing_state",
        filter_origins=russia,
        # We're only interested in floating storage that lasted longer than 14 days
        timeseries_activity_time_span_min=1000 * 60 * 60 * 24 * 14,
        # Let's limit the search to January 2019 storage events
        filter_time_min=pd.Timestamp("2016-1-1"),
        filter_time_max=pd.Timestamp.now(),
    )

    dow = CargoTimeSeries().search(
        # We're looking at daily storage levels
        timeseries_frequency="day",
        # We want 'b' for barrels here
        timeseries_unit="t",
        # We're only interested in storage of Medium-Sour Crude
        filter_products=diesel,
        # We're only included in cargo's that were in floating storage
        filter_activity="oil_on_water_state",
        # We're only interested in floating storage that lasted longer than 14 days
        timeseries_activity_time_span_min=1000 * 60 * 60 * 24 * 14,
        # Let's limit the search to January 2019 storage events
        filter_time_min=pd.Timestamp("2016-1-1"),
        filter_time_max=pd.Timestamp.now(),
    )
    dow_ex_russia = CargoTimeSeries().search(
        # We're looking at daily storage levels
        timeseries_frequency="day",
        # We want 'b' for barrels here
        timeseries_unit="t",
        # We're only interested in storage of Medium-Sour Crude
        filter_products=diesel,
        # We're only included in cargo's that were in floating storage
        filter_activity="oil_on_water_state",
        filter_origins=russia,
        # We're only interested in floating storage that lasted longer than 14 days
        timeseries_activity_time_span_min=1000 * 60 * 60 * 24 * 14,
        # Let's limit the search to January 2019 storage events
        filter_time_min=pd.Timestamp("2016-1-1"),
        filter_time_max=pd.Timestamp.now(),
    )
    dow_suez = CargoTimeSeries().search(
        # We're looking at daily storage levels
        timeseries_frequency="day",
        # We want 'b' for barrels here
        timeseries_unit="t",
        # We're only interested in storage of Medium-Sour Crude
        filter_products=diesel,
        # We're only included in cargo's that were in floating storage
        filter_activity="oil_on_water_state",
        filter_waypoints = ['f5634597081459985237dc54fcbe518d4b0a4f4af618b7719abda334b95538d1'],
        # We're only interested in floating storage that lasted longer than 14 days
        timeseries_activity_time_span_min=1000 * 60 * 60 * 24 * 14,
        # Let's limit the search to January 2019 storage events
        filter_time_min=pd.Timestamp("2016-1-1"),
        filter_time_max=pd.Timestamp.now(),
    )

    df = diesel_floating.to_df().set_index('key')
    df.index = pd.to_datetime(df.index)
    df_r = diesel_floating_ex_russia.to_df().set_index('key')
    df_r.index = pd.to_datetime(df_r.index)
    df_dow = dow.to_df().set_index('key')
    df_dow.index = pd.to_datetime(df_dow.index)
    df_r_dow = dow_ex_russia.to_df().set_index('key')
    df_r_dow.index = pd.to_datetime(df_r_dow.index)
    df_r_dow_suez = dow_suez.to_df().set_index('key')
    df_r_dow_suez.index = pd.to_datetime(df_r_dow_suez.index)


    tsa.update("diesel.vortexa.world.floating_storage.kt.daily", df.value / 1000, author='loic')
    tsa.update("diesel.vortexa.world.floating_storage_ex_russia.kt.daily", (df.value - df_r.value) / 1000, author='loic')
    tsa.update("diesel.vortexa.world.diesel_on_water.kt.daily", df_dow.value / 1000, author='loic')
    tsa.update("diesel.vortexa.world.diesel_on_water_ex_russia.kt.daily", (df_dow.value - df_r_dow.value) / 1000, author='loic')
    tsa.update("diesel.vortexa.world.diesel_on_water_via_suez.kt.daily", (df_r_dow_suez.value) / 1000, author='loic')