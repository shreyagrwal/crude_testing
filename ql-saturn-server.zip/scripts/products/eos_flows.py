import pandas as pd
from tshistory.api import timeseries
import statsmodels.api as sm

if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    _tickers = [
        "price.pvm.10ppm_ew_spread.m01.usd_t.daily.forward",
        "price.pvm.10ppm_singapore.usd_t.spread.daily.forward",
        "diesel.vortexa.east_of_suez.oecd_europe.imports_ratio.pct.daily.30mav",
    ]
    tickers = [
        'ew', 
        'spread',
        'ratio',
    ]
    data = pd.concat(map(tsa.get, _tickers), axis=1).rename(columns=dict(zip(_tickers, tickers)))
    tdata = data.copy()
    tdata['ratio'] = tdata['ratio'].shift(-70)
    tdata = tdata.resample('W-FRI').mean()
    model = sm.formula.ols(
        f'ratio ~ ew + spread', 
        tdata[:'2020']).fit()
    model.summary()
    forecast_ew = model.predict(tdata).clip(lower = 0.7 * tdata['ratio'], upper= 1.3 * tdata['ratio']).ffill()['2016':].shift(2)
    forecast_ew = pd.concat((0.7 * forecast_ew, 0.3 * tdata['ratio']), axis=1).ffill().sum(axis=1)
    name = "diesel.petroineos.oecd_europe_from_east_arb_forecast.pct.weekly"
    tsa.update(name, forecast_ew, author='loic')