from tshistory.api import timeseries
from saturn_server.helpers import safe_register_formula
from saturn_server import HERE
import pandas as pd

def pi_runs_full(tsa):
    metadata = pd.read_csv(HERE / 'cross' / 'data' / 'petroineos_runs.csv')
    tput_data = metadata[metadata['economic_property']=='throughput'].copy()
    upload_count = []
    for c in tput_data['country']:
        formula = f'''(priority (series "crude.jodi.{c}.throughput.kbd.monthly") (series "oil.petroineos.{c}.throughput_forecast2.kbd.monthly"))'''
        name = f'crude.petroineos.{c}.throughput.kbd.monthly.full'
        try:
            safe_register_formula(tsa, name, formula)
            upload_count.append('y')
        except:
            pass
    print(f'{len(upload_count)} out of {len(tput_data.country)} series uploaded')

if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    pi_runs_full(tsa)
