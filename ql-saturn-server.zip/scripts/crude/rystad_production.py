import pandas as pd
from tshistory.api import timeseries
# from saturn_server.helpers import safe_register_formula

filepath = '//petroineos.local/dfs/Department Shared Folders/~Analysis Department/crude/production/RystadProduction.xlsx'
filepath_us = '//petroineos.local/dfs/Department Shared Folders/~Analysis Department/crude/production/RystadUSProduction.xlsx'
filepath_grades = '//petroineos.local/dfs/Department Shared Folders/~Analysis Department/crude/production/RystadProductionGrades.xlsx'

def safe_register_formula(tsa, name, formula):
    if tsa.exists(name):
        tsa.delete(name)
    tsa.register_formula(name, formula)

def rystad_datetime(df):
    df['date'] = pd.to_datetime(df['Year Month'])
    df.drop(columns = 'Year Month', inplace=True)
    df.set_index('date', inplace=True)
    return df

def clean_names(df):
    df[df.columns[0]] = df[df.columns[0]].replace("Cote d'Ivoire", 'ivory_coast', regex=True)
    df[df.columns[0]] = df[df.columns[0]].replace("Timor-Leste", 'timor_leste', regex=True)
    df[df.columns[0]] = df[df.columns[0]].replace("Democratic Republic of Congo", 'drc', regex=True)
    df[df.columns[0]] = df[df.columns[0]].replace("Malaysia/Thailand JDA", 'malaysia_thailand_jda', regex=True)
    df[df.columns[0]] = df[df.columns[0]].str.lower()
    df[df.columns[0]] = df[df.columns[0]].replace(' ', '_', regex=True)
    return df

def clean_grade_names(df):
    df['Crude Grade'] = df['Crude Grade'].str.lower()
    df['Crude Grade'] = df['Crude Grade'].replace(' ', '_', regex=True)
    return df


def loop_and_upload(tsa):
    df = clean_names(rystad_datetime(pd.read_excel(filepath)))

    country_list = df[df.columns[0]].unique()
    for c in country_list:
        name = f'crude.rystad.{c}.production.kbd.monthly'
        country_df = df[df[df.columns[0]]==c]
        country_production = country_df['Production (kbbl/d)']
        tsa.update(name, country_production, 'Syed Ahmad')
    return print(f'{len(country_list)} series uploaded')

def loop_and_upload_us(tsa):
    df = clean_names(rystad_datetime(pd.read_excel(filepath_us)))

    country_list = df['EIA PADD'].unique()
    for c in country_list:
        name = f'crude.rystad.{c}.production.kbd.monthly'
        country_df = df[df[df.columns[0]]==c]
        country_production = country_df['Production (kbbl/d)']
        tsa.update(name, country_production, 'Syed Ahmad')
    return print(f'{len(country_list)} series uploaded')

def loop_and_upload_grades(tsa):
    df = clean_grade_names(rystad_datetime(pd.read_excel(filepath_grades)))
    grade_list = df['Crude Grade'].unique()

    for g in grade_list:
        
        #uploading grades as daily series
        name = f'crude.rystad.{g}.production.kbd.daily'
        filter_df = df[df['Crude Grade']==g].copy()
        production = filter_df['Production (kbbl/d)'].resample('d').asfreq().fillna(method='ffill')
        tsa.update(name, production, 'Syed Ahmad')
        
        # #uploading analyst override series
        # override = f'crude.analyst.{g}.production.kbd.daily'
        # blank = production.head(2)
        # tsa.update(override, blank, 'Syed Ahmad')

        # #priority formula to combine analyst override and Rystad data
        # name_monthly = f'crude.petroineos.{g}.production.kbd.daily'
        # formula = f'(priority (series "crude.analyst.{g}.production.kbd.daily") (series "crude.rystad.{g}.production.kbd.daily"))'
        # safe_register_formula(tsa, name_monthly, formula)
        
        # #resampling to monthly using formula
        # name_monthly = f'crude.petroineos.{g}.production.kbd.monthly'
        # formula = f'(resample (series "crude.petroineos.{g}.production.kbd.daily") "MS")'
        # safe_register_formula(tsa, name_monthly, formula)
    
    return print(f'{len(grade_list)} grades uploaded')


if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    loop_and_upload_us(tsa)
    loop_and_upload(tsa)
    # loop_and_upload_grades(tsa)