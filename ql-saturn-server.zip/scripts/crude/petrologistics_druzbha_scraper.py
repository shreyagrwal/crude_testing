import pandas as pd
from tshistory.api import timeseries

filepath = '//petroineos.local/dfs/Department Shared Folders/~Analysis Department/crude/petrologistics_druzbha/petrologistics_druzbha_imports.xlsx'

def get_data(filepath):
    df = pd.read_excel(filepath)
    df.set_index('date', inplace=True)
    return df

def clean_country_names(df):
    df.columns = df.columns.str.lower()
    df.columns = df.columns.str.replace(' ', '_', regex=True)
    return df

def kbd(df):
    df = df/1000
    return df

def loop_and_upload(tsa):
    df = kbd(clean_country_names(get_data(filepath)))
    country_list = df.columns.to_list()
    for c in country_list:
        name = f'crude.petrologistics.{c}.druzbha_imports.kbd.monthly'
        country_df = df[c]
        tsa.delete(name)
        tsa.update(name, country_df, 'Syed Ahmad')
    return print(f'{len(country_list)} series uploaded')

if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    loop_and_upload(tsa)