from tshistory.api import timeseries
from saturn_server.helpers import safe_register_formula
import pandas as pd

from saturn_server import HERE

# took out ireland from PI runs as JODI does not publish irish runs data
oecd_europe_runs_countries = ('Austria','Poland','Turkey','Denmark','Norway','United Kingdom','Greece','Italy','Spain','France','Germany','Netherlands','czech_republic' )

def clean_names(str_list):
    new_list = []
    for i in range(len(str_list)):
        new_list.append(str_list[i].lower())
        new_list[i] = new_list[i].replace(' ','_')
    return new_list


def ea_net_length(tsa):
    mapping_file = pd.read_csv(HERE / 'crude' / 'data' / 'rystad_ea_mapping.csv')
    for a, b in zip(mapping_file.Rystad, mapping_file.EA):
        formula = f'''(add 
        (series "crude.rystad.{a}.production.kbd.monthly") 
        (*
        -1
        (series "oil.energy_aspects.{b}.throughput.kbd.monthly")))'''
        name = f'crude.petroineos.{a}.net_length.kbd.monthly'
        safe_register_formula(tsa, name, formula)
    print(f'{len(mapping_file)} formulas uploaded with EA')

def pi_net_length(tsa):
    oecd_eu_list = clean_names(list(oecd_europe_runs_countries))
    for c in oecd_eu_list:
        formula = f'''(add 
        (series "crude.rystad.{c}.production.kbd.monthly") 
        (*
        -1
        (series "crude.petroineos.{c}.throughput.kbd.monthly.full")))'''
        name = f'crude.petroineos.{c}.net_length.kbd.monthly'
        safe_register_formula(tsa, name, formula)
    print(f'{len(oecd_eu_list)} PI formulas uploaded for OECD europe')


if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    ea_net_length(tsa)
    pi_net_length(tsa)