import pandas as pd
from tshistory.api import timeseries
tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')

import eikon as ek

def get_eikon(tickers, start_date, field='VALUE'):
    fn = lambda x: ek.get_timeseries(
        x[1], 
        start_date=start_date.strftime('%Y-%m-%dT%H:%M:%S'), 
        interval='daily',
        )[field].rename(x[0])
    return pd.concat(map(fn, tickers.items()), axis=1)


if __name__ == '__main__':

    eikon_key = '31585902a9df4582b7998776552606db82634f6b'
    ek.set_app_key(eikon_key)

    cftc = {
        "price.cftc.ice_gasoil.managed_net_positioning.kt.weekly": "3ICELGOMNET",
        "price.cftc.ice_gasoil.producer_net_positioning.kt.weekly": "3ICELGOPNET",
        "price.cftc.ice_gasoil.open_interest.kt.weekly": "3ICELGOOI",
    }
    cftc = get_eikon(cftc, pd.Timestamp.now() - pd.DateOffset(years=10), field='CLOSE').astype(float) / 10
    for x in cftc:
        # tsa.delete(x)
        tsa.update(x, cftc[x], author='loic')

    cftc_b = {
        "price.cftc.ice_brent.managed_net_positioning.kt.weekly": "3ICELCOMNET",
    }
    cftc_b = get_eikon(cftc_b, pd.Timestamp.now() - pd.DateOffset(years=10), field='CLOSE').astype(float) / 7.33
    for x in cftc_b:
        # tsa.delete(x)
        tsa.update(x, cftc_b[x], author='loic')

    euroilstock = {
        "crude.euroilstock.eu16.throughput.kt.monthly": "CRI2-EU-EOIL",
        "diesel.euroilstock.eu16.refinery_production.kt.monthly": "DSTR-EU-EOIL",
        "gasoline.euroilstock.eu16.refinery_production.kt.monthly": "GLRI-EU-EOIL",
        "diesel.euroilstock.eu16.ending_stocks.kt.monthly": "DSTSL-EU-EOIL",
    }
    euroilstock = get_eikon(euroilstock, pd.Timestamp.now() - pd.DateOffset(years=20), field='CLOSE').resample('MS').mean().astype(float)
    for x in euroilstock:
        tsa.update(x, euroilstock[x], author='loic')