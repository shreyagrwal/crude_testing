# from saturn_server.cross.refinery import RefineryData, OECD_EU_COUNTRIES
import pandas as pd
import numpy as np
import statsmodels.api as sm
from pathlib import Path
import argparse
import time
from pandas.tseries.offsets import DateOffset
from refinery.refinery_bo import RefineryData, OECD_EU_COUNTRIES


# get the forecasted unknown unplanned Outages for OECD
def project_total_outage_by_country(oecd_unplanned, capacity, historic_date, startdate, forecast_date, trend, seasonal,
                                    autoregressive, forecast):
    input_df = oecd_unplanned[historic_date :startdate]
    input_df = input_df.groupby(level=0, axis=1).sum()
    input_df = input_df.stack().swaplevel().rename('outages')
    input_df = np.log(input_df.dropna().groupby(axis=0, level=1).sum() + 10)
    model = sm.tsa.UnobservedComponents(input_df, trend, freq='MS', autoregressive=autoregressive, seasonal=seasonal)
    fit = model.fit()
    log_forecast = fit.forecast(forecast)
    forecast_values = (np.exp(log_forecast) - 10)
    total_outage = oecd_unplanned.groupby(level=0, axis=1).sum().resample('A').mean().round(0).astype(int)[
                   historic_date :startdate].T.sum(axis=1).sort_values()
    table_forcast = pd.DataFrame(
        forecast_values.T.values[..., None] @ (total_outage / total_outage.sum()).values[None, ...],
        columns=total_outage.index, index=forecast_values.index)
    table_forcast = table_forcast.round(0).astype(int)[:forecast_date]
    table_forcast = table_forcast.stack().swaplevel()
    table_forcast = table_forcast.reset_index()
    table_forcast.columns = ['COUNTRY', 'FORECAST_DATE', 'UNKNOWN_UNPLANNED_OFF']
    table_forcast = table_forcast.sort_values(by=['COUNTRY', 'FORECAST_DATE'])
    table_forcast['PDate'] = startdate
    country_capacity = capacity.groupby(level=0, axis=1).sum().round(0).astype(int).T.stack().swaplevel().reset_index()
    country_capacity.columns = ['FORECAST_DATE', 'COUNTRY', 'CAPACITY']
    unplanned_forecast = pd.merge(table_forcast, country_capacity, on=["COUNTRY", "FORECAST_DATE"])
    return unplanned_forecast


def main(historic_years, forecast_years) :
    now = (pd.Timestamp.now()).floor('D')
    historic_date = pd.Timestamp.now() - DateOffset(years=historic_years)
    forecast_date = pd.Timestamp.now() + DateOffset(years=forecast_years)
    capacity = RefineryData().get_capacity(
        'COUNTRY',
        OECD_EU_COUNTRIES,
        unit_type='CDU',
    )
    oecd_unplanned = RefineryData().get_outage('COUNTRY', OECD_EU_COUNTRIES, 'CDU', outage_type='Unplanned',
                                               exclude_cause=['Economic']).resample('MS').mean()
    oecd_unplanned = oecd_unplanned.drop(axis='columns', columns=('FRANCE', 'Gonfreville Refinery (Normandie)'))
    oecd_unplanned.index.name = 'Date'
    oecd_unplanned['Datetime'] = pd.to_datetime(oecd_unplanned.index)
    oecd_unplanned = oecd_unplanned.set_index('Datetime')

    result = project_total_outage_by_country(oecd_unplanned, capacity, historic_date, now, forecast_date, 'rwalk', 12,
                                             2, 35)
    root = Path(
        r"\\petroineos.local\dfs\BlueOcean\central\jobs\incoming")
    batch_upload_path = f"Upload_OIL_UnplannedOutagesForecast-{now:%Y%m%d%H%M%S}.csv"
    result.to_csv(root / batch_upload_path, index=False)


if __name__ == '__main__' :
    parser = argparse.ArgumentParser(description='get unplanned forecast')
    parser.add_argument('-H', '--historic_years', type=int, metavar='', required=False, default= 8)
    parser.add_argument('-F', '--forecast_years', type=int, metavar='', required=False, default= 2)
    args = parser.parse_args()
    print("Example")
    try :
        start = time.time()
        main(args.historic_years, args.forecast_years)
        end = time.time()
        print('Task runs %0.2f seconds.' % (end - start))
    except KeyboardInterrupt :
        print("Ctrl+C pressed. Stopping...")
