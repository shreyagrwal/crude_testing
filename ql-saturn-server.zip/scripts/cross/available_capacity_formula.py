
shares = {
"austria":0.014,
"belgium":0.047,
"czech_republic":0.013,
"denmark":0.013,
"finland":0.015,
"france":0.086,
"germany":0.0156,
"greece":0.0379,
"hungary":0.0116,
"ireland":0.005,
"italy":0.135,
"lithuania":0.016,
"netherlands":0.07,
"norway":0.0149,
"poland":0.039,
"portugal":0.016,
"slovakia":0.008,
"spain":0.104,
"sweden":0.034,
"switzerland":0.005,
"turkey":0.061,
"united_kingdom":0.091,
}


if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    for country, share in shares.items():
        name = f"oil.petroineos.{country}.available_capacity_forecast.kbd.monthly"
        formula = f"""
        (add
        (series "oil.petroineos.{country}.cdu.capacity.kbd.monthly")
        (*
            -1
            (resample
                (priority
                    (slice
                        (series "oil.petroineos.{country}.cdu.total_outage_plus_economic.kbd.daily")
                        #:todate (shifted
                            (today)
                            #:days 30))
                    (add
                        (series "oil.petroineos.{country}.cdu.total_outage.kbd.daily")
                        (*
                            {share}
                            (series "oil.petroineos.oecd_europe.cdu.total_outage.kbd.daily.seasonality.provisioned"))))
                "MS")))
        """
        tsa.register_formula(name, formula)
        name = f"oil.petroineos.{country}.provisioned_outage_forecast.kbd.monthly"
        formula = f"""
        (*
            {share}
            (series "oil.petroineos.oecd_europe.cdu.total_outage.kbd.daily.seasonality.provisioned"))
        """
        tsa.register_formula(name, formula)
