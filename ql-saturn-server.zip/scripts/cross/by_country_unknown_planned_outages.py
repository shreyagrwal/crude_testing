from pathlib import Path
import argparse
import time
from pandas.tseries.offsets import DateOffset
# from saturn_server.cross.refinery import RefineryData, OECD_EU_COUNTRIES
from tqdm.contrib.concurrent import thread_map
import pandas as pd
import statsmodels.api as sm
from refinery.refinery_bo import RefineryData, OECD_EU_COUNTRIES
import numpy as np

ref_data = RefineryData()


def get_outage_by_pdate(pdate) :
    outages = ref_data.get_outage(
        'COUNTRY',
        OECD_EU_COUNTRIES,
        unit_type='CDU',
        outage_type='Planned',
        pdate=pdate
    )
    outages.index.name = 'date'
    flattened_outage = (
        outages
            .groupby(axis=1, level=0)
            .sum()
            .resample('MS')
            .mean()
            .stack()
            .rename('outage')
            .to_frame()
            .assign(pdate=lambda x : pdate)
            .set_index('pdate', append=True)
    )
    flattened_outage['ttm'] = (
            flattened_outage.index.get_level_values('date').to_period('M').astype('int') -
            flattened_outage.index.get_level_values('pdate').to_period('M').astype('int')
    )
    return flattened_outage.set_index('ttm', append=True)


def planned_outage_by_country(capacity, forecast_date, pdates, p_date) :
    mapped_tables = thread_map(get_outage_by_pdate, pdates, max_workers=10)
    planned_outage = pd.concat(mapped_tables, axis=0)
    planned_outage = planned_outage.groupby(axis=0, level=[0, 2, 3]).sum()
    outage_data = pd.concat(
        (planned_outage.reset_index(), pd.get_dummies(planned_outage.index.get_level_values('date').month, prefix='s')),
        axis=1).query('ttm > 0')
    outage_data['capacity'] = outage_data['date'].map(capacity.sum(axis=1))
    outage_data['pct_outage'] = 100 * (outage_data['outage'] / outage_data['capacity'])
    fitted_outage = sm.formula.ols(
        f"pct_outage ~ (np.exp(-0.145 * ttm)) : (s_1 + s_2 + s_3 + s_4 + s_5 + s_6 + s_7 + s_8 + s_9 + s_10 + s_11 + s_12) - 1",
        data=outage_data[outage_data['pdate'] < pd.Timestamp.now()]
    ).fit()
    outage_data['fitted_values'] = fitted_outage.fittedvalues
    outage_data['terminal_average_outage'] = fitted_outage.predict(outage_data.assign(ttm=0))
    outage_data['terminal_average_outage_kbd'] = (outage_data['pct_outage'] - outage_data['fitted_values'] +
                                                  outage_data[
                                                      'terminal_average_outage']) * outage_data['capacity'] / 100
    outage_data['unknown_outage'] = outage_data['terminal_average_outage_kbd'] - outage_data['outage']
    outage_data = outage_data.set_index(['date', 'pdate']).xs(p_date.strftime('%Y-%m-01'), level=1)
    total_capacity = capacity.groupby(level=0, axis=1).sum().round(0).astype(int).T[p_date.strftime('%Y-%m-01')]
    country_capacity = capacity.groupby(level=0, axis=1).sum().round(0).astype(int).T.stack().swaplevel().reset_index()
    planned_forecast = pd.DataFrame(
        outage_data['unknown_outage'].T.values[..., None] @ (total_capacity / total_capacity.sum()).values[None, ...],
        columns=total_capacity.index, index=outage_data.index)
    planned_forecast = planned_forecast[:forecast_date]
    planned_forecast = planned_forecast.round(0).astype(int)
    planned_forecast = planned_forecast.stack().swaplevel().reset_index()
    planned_forecast.columns = ['COUNTRY', 'FORECAST_DATE', 'UNKNOWN_PLANNED_OFF']
    planned_forecast['PDate'] = p_date
    country_capacity.columns = ['FORECAST_DATE', 'COUNTRY', 'CAPACITY']
    planned_forecast = pd.merge(planned_forecast, country_capacity, on=["COUNTRY", "FORECAST_DATE"])
    return planned_forecast


def main(forecast_years, historic_years) :
    historic_date = (pd.Timestamp.now() - DateOffset(years=historic_years)).strftime('%Y-%m-01')
    forecast_date = (pd.Timestamp.now() + DateOffset(years=forecast_years)).strftime('%Y-%m-01')
    p_dates = pd.date_range(start=historic_date, end=forecast_date, freq='MS')
    now = pd.Timestamp.now().floor('D')
    capacity = ref_data.get_capacity(
        'COUNTRY',
        OECD_EU_COUNTRIES,
        unit_type='CDU',
    )
    result = planned_outage_by_country(capacity, forecast_date, p_dates, now)
    root = Path(
        r"\\petroineos.local\dfs\BlueOcean\central\jobs\incoming")
    batch_upload_path = f"Upload_OIL_PlannedOutagesForecast-{now:%Y%m%d%H%M%S}.csv"
    result.to_csv(root / batch_upload_path, index=False)


if __name__ == '__main__' :
    parser = argparse.ArgumentParser(description='get unplanned forecast')
    parser.add_argument('-F', '--forecast_years', type=int, metavar='', required=True)
    parser.add_argument('-HY', '--historic_years', type=int, metavar='', required=True)
    args = parser.parse_args()
    start = time.time()
    main(args.forecast_years, args.historic_years)
    end = time.time()
    print('Task runs %0.2f seconds.' % (end - start))