from tshistory.api import timeseries
from BlueOcean import DataAccessApi
from saturn_server.helpers import safe_register_formula

def bo_get_data(query):
    data = DataAccessApi.GetDataframe(query)
    return data

def get_countries_list():

    def clean_country_names(data):
        df = data.copy()
        df['country'] = df['country'].str.lower()
        df['country'] = df['country'].replace(' ', '_', regex=True)
        return df

    ctry_qry = """select distinct country from hive_metastore.dataengineering.oil_refinery_outages_forecast
    where pdate = (select max(pdate) from hive_metastore.dataengineering.oil_refinery_outages_forecast)
    order by country desc"""
    countries = bo_get_data(ctry_qry)
    return countries['country'].to_list(), clean_country_names(countries)['country'].to_list()

def get_outage_forecasts(tsa, table_names, clean_names):
    # uploading planned outages
    for x, y in zip(table_names, clean_names):
        formula = f"""(blueocean "select FORECAST_DATE as date, UNKNOWN_OUTAGES_KBD as value from hive_metastore.dataengineering.oil_refinery_outages_forecast where pdate = (select max(pdate) from hive_metastore.dataengineering.oil_refinery_outages_forecast) and Country = '{x}' and type = 'Unknown_Planned' order by oil_refinery_outages_forecast.FORECAST_DATE asc")"""
        name = f'oil.petroineos.{y}.planned_outage_forecast.kbd.monthly'
        safe_register_formula(tsa, name, formula)
    print (f'uploaded {len(x)} planned formulas')

    # uploading unplanned outages
    for x, y in zip(table_names, clean_names):
        formula = f"""(blueocean "select FORECAST_DATE as date, UNKNOWN_OUTAGES_KBD as value from hive_metastore.dataengineering.oil_refinery_outages_forecast where pdate = (select max(pdate) from hive_metastore.dataengineering.oil_refinery_outages_forecast) and Country = '{x}' and type = 'Unknown_Unplanned' order by oil_refinery_outages_forecast.FORECAST_DATE asc")"""
        name = f'oil.petroineos.{y}.unplanned_outage_forecast.kbd.monthly'
        safe_register_formula(tsa, name, formula)
    print (f'uploaded {len(x)} unplanned formulas')

    # uploading total outages
    for x in clean_names:
        formula = f"""(add(series "oil.petroineos.{x}.unplanned_outage_forecast.kbd.monthly")(series "oil.petroineos.{x}.planned_outage_forecast.kbd.monthly"))"""
        name = f'oil.petroineos.{x}.total_outage_forecast.kbd.monthly'
        safe_register_formula(tsa, name, formula)
    print (f'uploaded {len(x)} total formulas')
    return print('all formulas uploaded')

if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    table_names, clean_names = get_countries_list()
    get_outage_forecasts(tsa, table_names, clean_names)