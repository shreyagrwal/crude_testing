from saturn_server.wsgi import app
try:
    from refinery_report.webapi import bp
    app.register_blueprint(bp)
except ImportError:
    pass
if __name__ == '__main__':
    app.run(debug=True)
