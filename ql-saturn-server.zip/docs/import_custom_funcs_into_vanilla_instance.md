[[_TOC_]]

# About

This is a short note on how to import all the custom functions implemented by Loic in ql-saturn-server into another vanilla instance of Saturn. 
**What is a vanilla instance of Saturn?** This is an instance which is out of box. No custom code of any sort has been added to it.

---

# What are funcs?

Saturn software provides a functionality to extend back end processing through a sytems of funcs and formulas. A func is a Python function that accepts an input series and emits a transformed series. **Example**: You could imagine a "smoothening" function that uses the Pandas rolling mean to create a smoothening effect.

---

# How does the import from ql-saturn-server into another vanilla instance work ?

```
        Vanilla instance on <strong>AP18:8080
        -------------------------------------
                        |
                        |
                        |
                        V
        Modify the app.py on AP12 to have the following import statement
        -----------------------------------------------------------------
            import saturn_server
                        |
                        |
                        |
                        V
        pip install -e [path to clone of the master branch of ql-saturn-server on AP12]
        -------------------------------------------------------------------------------
                        |
                        |
                        |
                        V
        The custom funcs from ql-saturn-server are now imported into app.py
        -------------------------------------------------------------------


```






---

# Example of a new formula Series

![formula.png](images/formula.png)

```
(mul_days_in_month
    (series "crude.kpler.ara.ending_stocks.mb.daily"))
```

---

# Steps to follow


1. Identify a folder to clone the ql-saturn-server (example: C:\saturn-demo\ql-saturn-server on AP12:8080)
2. Do the clone of the master branch here
3. Locate the VENV (example: C:\inetpub\wwwroot\saturn8080\.venv on AP12:8080)
4. Launch a CMD shell with **Administrative** rights and browse to this location. 
5. Activate the virtual environment
6. Run the command `pip install --editable C:\saturn-demo\ql-saturn-server` . This will link the vanilla installation to the code in `ql-saturn-server` repo
7. Install all other dependencies (blueocean, ql-pidas)
8. Copy the .ENV file from the running instance of AP9 (Unfortunately, some of the instantiations happen early in the __init__.py )
9.  Modify `app.py`  (See code below)
10. Restart the IIS web site (example: 8080)
11. Test with the formula (steps in the section below)

---

# How to validate?

## Create the following formula

Save as **my_formula**
```
(upsample
    (series "diesel.petroineos.regrade_cif_nwe_curve.usd_bbl")
    "D"
    "D"
    "bfill")
```

## Navigate to the Series catalog

You should see the formula **my_formula** listed 


# References

https://tshistory-refinery.readthedocs.io/en/latest/formula.html#declaring-a-new-operator

---


# Modified app.py
Refer the file [sample_app_with_funcs.md](sample_app_with_funcs)
