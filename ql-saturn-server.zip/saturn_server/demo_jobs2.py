from rework.api import task
import rework.io as rio
from rework import api, io
from BlueOcean import DataAccessApi
import sys

@api.task(domain='products',inputs=())
def demo_job_blueocean_003(task):
    with task.capturelogs(std=True):
        print(f"Hello world for blueocnean_001 start")
        print(f"Current interpreter is {sys.executable}")
        df=DataAccessApi.GetDataframe("SELECT 100,200")
        print(f"After querying df={df}")
        print(f"Hello world for blueocnean_001 end")
