import pandas as pd

from tshistory.api import timeseries
from BlueOcean import DataAccessApi

def last_pdate(field, schema_name):
    query = f"""
        SELECT max({field}) FROM {schema_name} where isactive is true
        """
    print(query)
    date = DataAccessApi.GetDataframe(query)
    return pd.Timestamp(date.values[0, 0]).tz_localize(None)

def reupdate_ordered_history(tsa, name, series, insertion_date):
    history = tsa.history(name)
    history[insertion_date] = series
    tsa.delete(name)
    for date in sorted(history):
        tsa.update(
            name, 
            history[date], 
            insertion_date=date, 
            author='uploader'
        )

def safe_update(tsa:timeseries, name, series, insertion_date):
    insertion_date = insertion_date.tz_localize('UTC')
    if tsa.exists(name):
        dates = tsa.insertion_dates(name)
        if dates:
            insertion_dates = pd.to_datetime(dates)
            if insertion_date <= max(insertion_dates):
                if tsa.supervision_status(name) == 'supervised':
                    reupdate_ordered_history(tsa, name, series, insertion_date)
                    return 
                else:
                    tsa.strip(name, insertion_date=insertion_date)
                if not tsa.insertion_dates(name):
                    tsa.delete(name)
        else:
            tsa.delete(name)
    return tsa.update(name, series, insertion_date=insertion_date, author='uploader')    

def safe_register_formula(tsa, name, formula):
    if tsa.exists(name):
        tsa.delete(name)
    tsa.register_formula(name, formula)

def series_id(meta, order):
    return ".".join([meta[x] for x in order])


def generate_formula(operator, serieslist):
    return "".join([f"({operator}", " ".join(serieslist), ")"])

def lowercase(value):
    return value.lower().replace('-', '_').replace(' ', '_').replace(r'[()]','')