import pandas as pd
import sys, os
import numpy as np
import shutil
import time
from datetime import datetime

from tshistory.api import timeseries
sys.path.append(os.getcwd())
from saturn_server import HERE
from saturn_server.helpers import (
    safe_update, 
    series_id, 
    generate_formula, 
    safe_register_formula, 
    last_pdate
)
from BlueOcean import DataAccessApi
from saturn_server.safe_metadata_update import safely_update_metadata

ORDER = ['product', 'source', 'region',
         'economic_property', 'unit', 'frequency']

temp_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\JODI'
saturn_datafeed = os.path.join(temp_path, "saturn_dirct_datafeed\JODI\\")

def get_direct_datafeed(df, meta):
    df['TIME_PERIOD'] = pd.to_datetime(df['TIME_PERIOD'])
    df = df[(df['REF_AREA']==meta['ref_area'])&(df['FLOW_BREAKDOWN']==meta['flow_breakdown'])
                        &(df['ENERGY_PRODUCT']==meta['energy_product'])&(df['UNIT_MEASURE']==meta['unit_measure'])]
    df =df[['TIME_PERIOD', 'OBS_VALUE']]
    df = df.rename(columns={'TIME_PERIOD': 'date', 'OBS_VALUE': 'value'})
    df['value'] = df['value'].astype(float).round(1)
    return df 
    

def get_jodi(meta, db, dfp, dfs):
    
    if 'crude' in db:
        data = get_direct_datafeed(dfp, meta)
    elif 'product' in db:
        data = get_direct_datafeed(dfs, meta)

    data.set_index('date', inplace=True)
    data = data.value.asfreq('MS').rename(meta['series_id'])
    if not data.empty:
        return pd.Series(np.where(data == 0, np.nan, data),index=data.index,name=data.name)

def jodi_last_publication(db):
    return last_pdate('PDate',db)

def register_jodi_formulas(tsa, metadata, aspect, region, product, unit, to_include):
    series = [m
              for m in metadata
              if m['economic_property'] == aspect and m['region'] == region and m['product'] == product and m['unit'] == unit
              ]
    serieslist = [f'(series "{s["""series_id"""]}" #:fill "ffill")' for s in series if s['series_id'] in to_include]
    name = series_id(series[-1], ORDER)
    formula = generate_formula('add ', serieslist)
    print(formula)
    # OECD Europe sum
    safe_register_formula(tsa, name, formula)
    growth_name = '.'.join([name, 'weighted_growth'])
    # OECD Europe weighted average growth
    growth_formula = generate_formula('row-geometric-growth ', serieslist)
    safe_register_formula(tsa, growth_name, growth_formula)


def upload_jodi_data(tsa, metadata, aspect, region, product, unit, db, pdate, df_primary, df_secondary):
    series = [m
              for m in metadata
              if m['economic_property'] == aspect and m['region'] == region and m['product'] == product and m['unit'] == unit
              ]
    dfs = list(map(lambda x: get_jodi(x, db, df_primary, df_secondary), series))
    data = pd.concat(dfs, axis=1)
    #print(data.tail(1).T)
    to_include = []
    for serie in series:
        serie_id = serie["series_id"]
        try:
            if data[serie_id].sum() != 0:
                to_include.append(serie_id)
                safe_update(
                    tsa,
                    serie_id,
                    data[serie_id].dropna(),
                    insertion_date=pdate
                )
                #safely_update_metadata(tsa, serie["series_id"], serie)
                temp_metadata = serie
                temp_metadata['hs_is_safe_update'] = 1
                temp_metadata['hs_data_ingestion_frequency'] = 31
                safely_update_metadata(tsa, serie["series_id"], temp_metadata)
        except:
            print(f'Data for series {serie_id} not exist')
            continue
    register_jodi_formulas(tsa, metadata, aspect, region, product, unit, to_include)

def upload_jodi_directfeed(tsa):

    loop_over = ["product", "economic_property", "region", "unit"]

    data = pd.read_csv(
        HERE / 'cross' / 'data' / 'jodi.csv')
    
    metadata = data.to_dict('records')

    data = data.drop_duplicates(loop_over)[loop_over]
    conditions = [data['product'].str.contains('crude')]
    values = ['dataengineering.oil_jodi_jodicrudelatest']
    data['db'] = np.select(conditions, values, default='dataengineering.oil_jodi_jodiproductlatest')

    if os.path.exists(saturn_datafeed + 'NewProcedure_Primary_CSV.csv') and os.path.exists(saturn_datafeed + 'NewProcedure_Secondary_CSV.csv'):
        df_primary = pd.read_csv(saturn_datafeed + 'NewProcedure_Primary_CSV.csv')
        df_secondary = pd.read_csv(saturn_datafeed + 'NewProcedure_Secondary_CSV.csv')
        # pdate = jodi_last_publication(db)
        pdate = pd.to_datetime(time.ctime(os.path.getmtime(saturn_datafeed + 'NewProcedure_Secondary_CSV.csv')))
        print(f'pdate is {pdate}')

        for prod, aspect, region, unit, db in data.values:
            if not df_primary.empty and not df_secondary.empty:
                upload_jodi_data(
                    tsa, metadata, aspect,
                    region, prod, unit, db, pdate, df_primary, df_secondary
                )
    else:
        print('No CSV files are found!!')

    if os.path.exists(saturn_datafeed + 'NewProcedure_Primary_CSV.csv'):
        print('moving NewProcedure_Primary_CSV to archive')
        shutil.move(os.path.join(saturn_datafeed, 'NewProcedure_Primary_CSV.csv'), os.path.join(saturn_datafeed, 'archive\\NewProcedure_Primary_CSV.csv'))
    if os.path.exists(saturn_datafeed + 'NewProcedure_Secondary_CSV.csv'):
        print('moving NewProcedure_Secondary_CSV to archive')
        shutil.move(os.path.join(saturn_datafeed, 'NewProcedure_Secondary_CSV.csv'), os.path.join(saturn_datafeed, 'archive\\NewProcedure_Secondary_CSV.csv'))

if __name__ == '__main__':
    from tshistory.api import timeseries
    print(datetime.now())
    tsa = timeseries('http://tst-qdev-ap12.petroineos.local/api/')
    upload_jodi_directfeed(tsa)
    print(datetime.now())