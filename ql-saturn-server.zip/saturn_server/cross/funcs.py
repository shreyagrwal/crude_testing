from typing import Optional, List
from datetime import datetime as dt
from numbers import Number

import pandas as pd
import numpy as np
from scipy.signal import lfilter
from numbers import Number
from tshistory.util import (
    ensuretz
)

from rework.io import moment

from tshistory_formula.registry import func, metadata, history, gfunc
from tshistory_formula.funcs import _group_series

from saturn_server import DG

from BlueOcean import DataAccessApi

def _time_arrow(
        values: np.ndarray,
        today: dt,
        freq: str,
        offset: int) -> pd.DatetimeIndex:

    length = values.shape[0] + offset
    date = pd.date_range(start=today, periods=length, freq=freq)
    return date[offset:]


def _concat_futures(futures, freq, offset):
    today = futures.index[-1]
    # The series are updated each day, with one value
    # and one date corresponding at the current day
    current = futures.iloc[-1, 1:].values
    date = _time_arrow(current, today, freq, offset)
    return pd.Series(
        data=current,
        index=date
    )


@func('concat_futures', auto=False)
def concat_futures(
        __interpreter__,
        *serieslist: pd.Series,
        freq: str = 'M',
        offset: int = 1) -> pd.Series:
    """
    Concatenate rolling contracts to create a forward curve
    """
    i = __interpreter__
    revision_date = i.getargs.get('revision_date')
    serieslist = list(map(lambda x: i.tsh.get(i.cn, x.name), serieslist))
    futures = pd.concat(serieslist, axis=1)[:revision_date]
    return _concat_futures(futures, freq, offset)


def _forward_curve(url: str, date: pd.Timestamp):
    proper_date = dt(date.year, date.month, date.day)
    proper = '/'.join(['model:/', url, 'CURVE', f'{proper_date:%d-%m-%Y}'])
    try:
        data = DG.get_curve(proper)
        if data is not None:
            data.index = data.index.tz_localize(None)
            idx = data.index.drop_duplicates(keep='last')
            return data.iloc[:, -1].reindex(idx)
        else:
            return _forward_curve(url, date + pd.DateOffset(days=-1))
    except:
        return _forward_curve(url, date + pd.DateOffset(days=-1))


@func('forward_curve')
def forward_curve(__interpreter__, url: str, date: pd.Timestamp = None) -> pd.Series:
    """
    Forward curve out of Datagenic, use the right URL, without 'model:/'' 
    """
    i = __interpreter__
    args = i.getargs.copy()
    date = args.get('revision_date') or date
    return _forward_curve(url, date)


@func('pct_change')
def pct_change(series: pd.Series) -> pd.Series:
    """
    Percentage change of the `series` between two observations
    """

    if not len(series):
        return series

    return series.pct_change().dropna()


@func('logarithm')
def logarithm(series: pd.Series) -> pd.Series:
    """
    Logarithm of the `series`
    """

    if not len(series):
        return series

    return series.apply(np.log).dropna()

@func('shift')
def shift(series: pd.Series, months: int, days:int, years:int) -> pd.Series:
    """
    Shift of the `series` between two observations
    """

    if not len(series):
        return series
    series.index = series.index + pd.DateOffset(months=months, days=days, years=years)
    return series.dropna()

@func('diff')
def diff(series: pd.Series, order: int) -> pd.Series:
    """
    1st order difference of the `series` between two observations
    """

    if not len(series):
        return series

    return series.diff(order).dropna()


@func('unrolling')
def unrolling(series: pd.Series, window: int) -> pd.Series:
    """
    unroll rolling formula
    """
    T = series.shape[0]
    A = (np.tril(np.ones((T, T)), -1) -
         np.tril(np.ones((T, T)), -(window + 1))) / window
    A = A[window:, :]
    pA = np.linalg.pinv(A)  # pseudo inverse
    return pd.Series(pA.T @ series.values, index=series.index[window:])


def __integrate(stock, flow, *args):
    last = stock.dropna(axis=0)
    last_date, last_value = last.index[-1], last.values[-1]
    cumflow = last_value + flow[flow.index > last_date].cumsum()
    return stock.combine_first(cumflow)


@func('log_exp_integrate')
def _log_integrate(*serieslist: pd.Series) -> pd.Series:
    """
    Cummulative product between the first series `stock` and the second `flow`. The `stock` data is extrapolated with the `flow` data.
    Mathematically, it is the exponential of the sum of log values.
    """
    return np.exp(__integrate(*list(map(np.log, serieslist))))


@func('integrate')
def _integrate(*serieslist: pd.Series) -> pd.Series:
    """
    Cummulative sum between the first series `stock` and the second `flow`. The `stock` data is extrapolated with the `flow` data.
    """
    return __integrate(*serieslist)


@func('div_days_in_month')
def div_days_in_month(series: pd.Series) -> pd.Series:
    """
    Series values divided by the number of days in the months.
    """

    if not len(series):
        return series

    return series / series.index.daysinmonth


@func('mul_days_in_month')
def mul_days_in_month(series: pd.Series) -> pd.Series:
    """
    Series values multiplied by the number of days in the months.
    """

    if not len(series):
        return series

    return series * series.index.daysinmonth


@func('upsample')
def upsample(series: pd.Series,
             native_freq: str,
             freq: str,
             fillna_method: str) -> pd.Series:
    """
    Increase the sample frequency of a series while maintaining average values unchanged
    at a higher frequency
    """
    if not len(series):
        return series

    resampled = series.resample(freq).mean().fillna(method=fillna_method)
    ratio = resampled.resample(native_freq).sum().div(series)
    ratio = ratio.resample(freq).mean().fillna(method=fillna_method)
    return resampled.div(ratio).dropna(axis=0)


def _row_geometric_growth(serieslist):
    data = pd.concat(serieslist, axis=1)
    result = data.pct_change().mul(data).sum(axis=1) / data.sum(axis=1)
    return result.apply(lambda x: np.nan_to_num(x, posinf=np.nan, neginf=np.nan)).dropna()


@func('row-geometric-growth')
def row_geometric_growth(*serieslist: pd.Series) -> pd.Series:
    """
    Weighted average growth of multiple series
    """
    return _row_geometric_growth(serieslist)
def monthly_dummies(series, seasonals):
    dummy_month = pd.get_dummies(series.index.month).values
    data = dummy_month @ seasonals
    return pd.Series(data, index=series.index)


@func('monthly_dummies')
def _monthly_dummies(__interpreter__, series: pd.Series,
                     jan: Number,
                     feb: Number,
                     mar: Number,
                     apr: Number,
                     may: Number,
                     jun: Number,
                     jul: Number,
                     aug: Number,
                     sep: Number,
                     oct: Number,
                     nov: Number,
                     dec: Number) -> pd.Series:
    """
    Monthly dummies generator
    """
    return monthly_dummies(series,
                           [jan,
                            feb,
                            mar,
                            apr,
                            may,
                            jun,
                            jul,
                            aug,
                            sep,
                            oct,
                            nov,
                            dec
                            ])

def _indicative(series: pd.Series, threshold: Number=0) -> pd.Series:
    if not len(series):
        return
    return pd.Series((series > threshold).astype(float), index=series.index)

@func('indicative')
def indicative(__interpreter__, series: pd.Series, threshold: Number=0) -> pd.Series:
    """
    Indicative function above threshold
    """
    return _indicative(series, threshold)

def _mtd(series:pd.Series) -> pd.Series:
    series = (series
              .asfreq('D')
              .fillna(0)
              .groupby([
                  series.index,
                  series.index.month,
                  series.index.year,
                  ])
              .last()
              .unstack([2,1])
              .cumsum()
    )
    series = series.sum(axis=1)
    return series

@func('mtd')
def mtd(__interpreter__, series: pd.Series) -> pd.Series:
    """
    Month to date accumulator
    """
    if not len(series):
        return
    return _mtd(series)

@func('power')
def power(__interpreter__,series: pd.Series, power: Number) -> pd.Series:
    """
    Power function
    """
    if not len(series):
        return
    return pd.Series(np.power(series.values, power), index=series.index)

def _blueocean(
    query: str,
    **query_kwargs) -> pd.Series:
    """
    return the query as (date, value), use the keyword revision_date in your query if needed
    use the from_value_date, to_value_date if needed to scope your query properly
    """
    proper_query = query.format(**query_kwargs)
    proper_query = " ".join(proper_query.splitlines()).rstrip().lstrip()
    print(proper_query)
    data = DataAccessApi.GetDataframe(query=proper_query)
    data.index = pd.to_datetime(data.date)
    return data.value.sort_index()


@func('blueocean')
def blueocean(
    __interpreter__,
    query: str,
    revision_date:pd.Timestamp=None,
    from_value_date:pd.Timestamp=None,
    to_value_date:pd.Timestamp=None) -> pd.Series:
    """
    return the query as (date, value), use the keyword revision_date in your query if needed
    use the from_value_date, to_value_date if needed to scope your query properly.
    example: 
            "
            select pdate as date, mean(nwesimple) as value from dataengineering.oil_crude_euromargin
            where type=0 
            and ddate >= '{from_value_date:%Y-%m-%d}' 
            and ddate <= '{to_value_date:%Y-%m-%d}'
            and pdate <= '{revision_date:%Y-%m-%d}'
            group by date
            "
            would be the query
    """
    defaults = {
        'revision_date': ensuretz(pd.Timestamp.now()),
        'from_value_date': ensuretz(pd.Timestamp('1900-1-1')),
        'to_value_date': ensuretz(pd.Timestamp('2070-1-1')),
    }
    
    args = __interpreter__.getargs.copy()
    query_revision_date = ensuretz(args.get('revision_date')) or defaults['revision_date']
    formula_revision_date = ensuretz(revision_date) or defaults['revision_date']

    query_from_value_date = ensuretz(args.get('from_value_date')) or defaults['from_value_date']
    formula_from_value_date = max(
        ensuretz(from_value_date) or defaults['from_value_date'], 
        defaults['from_value_date']
    )

    query_to_value_date = ensuretz(args.get('to_value_date')) or defaults['to_value_date']
    formula_to_value_date = min(
        ensuretz(to_value_date) or defaults['to_value_date'], 
        defaults['to_value_date']
    )

    args['revision_date'] = min(query_revision_date, formula_revision_date)
    args['from_value_date'] = max(query_from_value_date, formula_from_value_date)
    args['to_value_date'] = min(query_to_value_date, formula_to_value_date)
    return _blueocean(query, **args)

def _datagenic_rolling(
    model_id:str, 
    revision_date:pd.Timestamp,
    from_value_date:pd.Timestamp,
    to_value_date:pd.Timestamp,
    *args,
    **kwargs,
    ) -> pd.Series:
    data = DG.get_time_series(model_id, from_value_date, min(to_value_date, revision_date))
    if data is not None:
        data.index = data.index.tz_localize(None)
        return data.iloc[:, -1].dropna()
    else:
        return

@func('datagenic')
def datagenic(
    __interpreter__,
    model_id: str,
    revision_date:pd.Timestamp=None,
    from_value_date:pd.Timestamp=None,
    to_value_date:pd.Timestamp=None) -> pd.Series:
    """
    return the query as (date, value), use the keyword revision_date in your query if needed
    use the from_value_date, to_value_date if needed to scope your query properly.
    example: 
            "
            select pdate as date, mean(nwesimple) as value from dataengineering.oil_crude_euromargin
            where type=0 
            and ddate >= '{from_value_date:%Y-%m-%d}' 
            and ddate <= '{to_value_date:%Y-%m-%d}'
            and pdate <= '{revision_date:%Y-%m-%d}'
            group by date
            "
            would be the query
    """
    defaults = {
        'revision_date': ensuretz(pd.Timestamp.now()),
        'from_value_date': ensuretz(pd.Timestamp('1900-1-1')),
        'to_value_date': ensuretz(pd.Timestamp('2070-1-1')),
    }
    
    args = __interpreter__.getargs.copy()
    query_revision_date = ensuretz(args.get('revision_date')) or defaults['revision_date']
    formula_revision_date = ensuretz(revision_date) or defaults['revision_date']
    query_from_value_date = ensuretz(args.get('from_value_date')) or defaults['from_value_date']
    formula_from_value_date = max(
        ensuretz(from_value_date) or defaults['from_value_date'], 
        defaults['from_value_date']
    )

    query_to_value_date = ensuretz(args.get('to_value_date')) or defaults['to_value_date']
    formula_to_value_date = min(
        ensuretz(to_value_date) or defaults['to_value_date'], 
        defaults['to_value_date']
    )

    args['revision_date'] = min(query_revision_date, formula_revision_date)
    args['from_value_date'] = max(query_from_value_date, formula_from_value_date)
    args['to_value_date'] = min(query_to_value_date, formula_to_value_date)
    return _datagenic_rolling(model_id, **args)

def test_blueocean():
    query = """
        select pdate as date, mean(nwesimple) as value from dataengineering.oil_crude_euromargin
        where type=0 
        and ddate >= '{from_value_date:%Y-%m-%d}' 
        and ddate <= '{to_value_date:%Y-%m-%d}'
        group by date
    """
    assert _blueocean(query, from_value_date=pd.Timestamp('2023-02-08'), to_value_date=pd.Timestamp('2023-02-08')).values[0] == 5.16

def test_mtd():
    date_range = pd.date_range('2000-1-1', freq='D', periods=35)
    new_month = pd.date_range('2000-2-1', freq='D', periods=5)
    series = pd.Series(
        range(1, 36),
        index=date_range
    )
    new_month_series = pd.Series(
        range(1, 6),
        index=new_month
    )
    ans = new_month_series.combine_first(series)
    transformed = _mtd(series = pd.Series(1,index=date_range))
    assert (transformed - ans).sum() == 0

if __name__ == '__main__':
    # test_blueocean()
    # test_dynamic_adjustment()
    test_mtd()