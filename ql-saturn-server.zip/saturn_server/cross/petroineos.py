import pandas as pd

from tshistory.api import timeseries

from BlueOcean import DataAccessApi


ORDER = ['product', 'source', 'country',
         'economic_property', 'unit', 'frequency']


def get_genscape_refinery():
    query = f"""
        SELECT PDate, 
        sum(UnitCapacity * cast(UnitOnline as float)) / 1000 as available, 
        sum(UnitCapacity) / 1000 as capacity, 
        sum(UnitCapacity * cast(UnitOnline as float)) / sum(UnitCapacity) as utilization
        FROM dataengineering.oil_refinery_refineryunitdailystatus
        where ProcessingClass = 'Primary Processing' 
        and Region in ('Europe', 'European') 
        and UnitCategory = 'Atmospheric Crude Distillation'
        and isactive is true
        group by pdate
        order by pdate desc
        """
    print(query)
    data = DataAccessApi.GetDataframe(query)
    data.index = pd.to_datetime(data['PDate'])
    return data.sort_index()


def upload_genscape_refinery(tsa):
    series_dict = {
        'available': 'oil.genscape.europe.refinery_available_capacity.kbd.daily',
        'capacity': 'oil.genscape.europe.refinery_capacity.kbd.daily',
        'utilization': 'oil.genscape.europe.refinery_utilization_rate.pct.daily',
    }
    data = get_genscape_refinery()
    for name, series_id in series_dict.items():
        tsa.update(
            series_id,
            data[name],
            author='uploader',
        )


if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    upload_genscape_refinery(tsa)
