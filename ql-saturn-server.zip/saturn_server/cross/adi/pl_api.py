# Copyright (c) 2021 Petro-Logistics S.A., All rights reserved.
#
# This work is licensed under the terms of the MIT license.
# For a copy, see <https://opensource.org/licenses/MIT>.

# To run this example you need to install the 'pandas' package (Check the corresponding instalaltion procedure)
from msilib.schema import Error
from plapi.client import PLAPIClient
import pandas as pd
from datetime import datetime
from pathlib import Path 

ENV = 'PROD'

CHARLES_CLIENT = PLAPIClient(
            api_url="https://secure.petro-logistics.com/api/v2/movementsdata.php",
            api_key="q46mwj2uv00qw1307uih043o",
            api_hash="iPvkgwqoaaxaL4VxpcNGaI5xKlxpzbM3QKWAQuw93XwkL5z2eouw1YEhL2aBd1Nn",
            http_user="Charles.Cai_http_SK77Sjo0vwH6",
            http_pass="892Iu9NB0OY6wLTPKHkQdN47YeE9Fu6x"
)

LOIC_CLIENT = PLAPIClient(
            api_url="https://secure.petro-logistics.com/api/v2/movementsdata.php",
            api_key="46dq7wje8x2gt3o08z041c4h",
            api_hash="yNyf1sdei9wpFrKcrrHISOORQaV47BxmXttDkwc0170ZCpvqr0pXhuZq1gzgRhnR",
            http_user="Loic.Balland_http_yTEDw4y29C7n",
            http_pass="2z67NRa8WTl1NqV8I6Qg7pUGsR4T2WGT"
        )

BATCH_FOLDER = Path(
    r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\BatchUploader'
)

def extract_api_movements(name, raw):
    envelope = raw.get('envelope')
    header = envelope.get('header')
    print(f"{name}, {header}")
    success = header[0][1]
    return success, pd.DataFrame.from_dict(envelope.get('movements'))

# Initialize pandas object with API result
def batch_drop(result):
    api_results = list(map(lambda x: extract_api_movements(*x), result.items()))
    df = pd.concat([x[1] for x in api_results], axis=0)
    filename = 'Upload_OIL_CargoMovement'
    bulk_uploader_folder = BATCH_FOLDER / ENV
    df = df.replace({"'": '', ",":";"}, regex=True)
    df['load_port_date'] = pd.to_datetime(df['load_port_date'])
    df['discharge_port_date'] = df['discharge_port_date'].apply(lambda x: x if x not in ("0000-00-00", "0001-01-01") else '')
    df = df.drop_duplicates()
    df = df[df.load_port_date > pd.Timestamp.now() - pd.DateOffset(month=5)]
    name =  bulk_uploader_folder / f"{filename}-{datetime.today():%y%m%d%H%M%S}.csv"
    df.to_csv(
        path_or_buf=name, 
        header=True, 
        index=False
    )
    if 'fail' in [x[0] for x in api_results]:
        raise BaseException("One of the query failed, look at the logs")

if __name__ == '__main__':
    RESULTS = dict(
    fsu_all = LOIC_CLIENT.execute("FSU_CO_2022_P31"),
    fsu_go = LOIC_CLIENT.execute("FSU_GO_2012_P31"),
    fsu_naphtha = LOIC_CLIENT.execute("FSU_NA_2020_P31"),
    saudi_gasoil = LOIC_CLIENT.execute("Saudi_GO_2020_P31"),
    india_gasoil = LOIC_CLIENT.execute("India_GO_2020_P31"),    
    )
    batch_drop(RESULTS)
