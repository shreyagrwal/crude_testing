import os
import pandas as pd
import requests
from saturn_server.helpers import safe_update, safe_register_formula
from tqdm.contrib.concurrent import thread_map
from saturn_server import HERE
from saturn_server.safe_metadata_update import safely_update_metadata

api_key = os.environ["EIA_API_KEY"]
base_url = 'https://api.eia.gov/v2'

program = pd.read_csv(HERE / 'cross' / 'data' / 'eia.csv')
formulas = pd.read_csv(HERE / 'cross' / 'data' / 'eia_formulas.csv')

freqs = {
    'monthly': "%Y-%m",
    'weekly': "%Y-%m-%d",
}

def upload_formulas(tsa, record):
    safe_register_formula(tsa, **record)

def _get_eia(tsa, record):
    url = f"{base_url}/{record['base']}"
    payload = record.copy()
    payload['api_key'] = api_key
    del payload['base']
    del payload['series_id']
    payload_str = "&".join("%s=%s" % (k, payload[k]) for k in reversed(list(payload.keys())))
    print(f'url is -> {url}?{payload_str}')
    resp: requests.Response = requests.get(url=f'{url}?{payload_str}')
    print(f"Response from HTTP is {resp}")
    if not resp.ok:
        print(f"HTTP response was not successful. Exitting")
        return
    print(f"HTTP response was successful.")
    data = pd.DataFrame(resp.json().get('response').get('data'))
    data['value'] = pd.to_numeric(data['value'])
    data.index = pd.to_datetime(data.period,format=freqs[record['frequency']])
    print(data)
    print(data.info)
    meta = [
        'series-description', 'units',
        'series', 'area-name',
        'product', 'product-name',
        'process', 'process-name'
    ]
    for grp, gdata in data.groupby(meta):
        safe_update(
            tsa, 
            record['series_id'], 
            gdata['value'], 
            insertion_date=pd.Timestamp.now(), 
        )
        #safely_update_metadata(tsa, record['series_id'], dict(zip(meta, grp)))
        temp_metadata = dict(zip(meta, grp))
        temp_metadata['hs_is_safe_update'] = 1
        if record['frequency'] == 'monthly':
            temp_metadata['hs_data_ingestion_frequency'] = 31
        elif record['frequency'] == 'weekly':
            temp_metadata['hs_data_ingestion_frequency'] = 7
        else:
            print('No frequency detected!!')
        print(temp_metadata)
        safely_update_metadata(tsa, record['series_id'], temp_metadata)

def get_eia(tsa):
    list(map(lambda x: _get_eia(tsa, x), program.to_dict('records')))
    list(map(lambda x: upload_formulas(tsa, x), formulas.to_dict('records')))

if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    get_eia(tsa)    
    