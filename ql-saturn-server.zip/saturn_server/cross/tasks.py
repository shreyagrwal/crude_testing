import pandas as pd

from rework import api, io

from datetime import datetime as dt

from saturn_server.cross.jodi import upload_jodi
from saturn_server.cross.jodi_directfeed import upload_jodi_directfeed
from saturn_server.cross.iea import upload_iea
from saturn_server.cross.iea_directfeed import upload_iea_directfeed
from saturn_server.cross.petroineos import upload_genscape_refinery as _upload_genscape_refinery
from saturn_server.cross.euromargin import get_euromargin as _get_euromargin
from saturn_server.cross.euromargin import get_euromargin_daily as _get_euromargin_daily
from saturn_server.cross.petrologistics import upload_petrologistics
from saturn_server.cross.ea import get_energy_aspects as _get_energy_aspects
from saturn_server.cross.eia import get_eia as _get_eia

from saturn_server.cross.prices import (
    upload_rolling_timeseries,
    upload_spot_timeseries
)

from saturn_server.cross.bridgeton import (
    upload_bridgeton_data
)

from saturn_server import TSA, DG

@api.task(domain='cross', inputs=())
def get_bridgeton(task):
    with task.capturelogs(std=True):
        upload_bridgeton_data(TSA)

@api.task(domain='cross', inputs=())
def get_eia(task):
    with task.capturelogs(std=True):
        _get_eia(TSA)

@api.task(domain='cross', inputs=())
def get_jodi(task):
    with task.capturelogs(std=True):
        upload_jodi(TSA)

@api.task(domain='cross', inputs=())
def get_jodi_directfeed(task):
    with task.capturelogs(std=True):
        upload_jodi_directfeed(TSA)

@api.task(domain='cross', inputs=())
def get_iea(task):
    with task.capturelogs(std=True):
        upload_iea(TSA)

@api.task(domain='cross', inputs=())
def get_iea_directfeed(task):
    with task.capturelogs(std=True):
        upload_iea_directfeed(TSA)

@api.task(domain='cross', inputs=())
def get_european_genscape(task):
    with task.capturelogs(std=True):
        _upload_genscape_refinery(TSA)


@api.task(domain='cross', inputs=())
def get_energy_aspects(task):
    with task.capturelogs(std=True):
        _get_energy_aspects(TSA)


@api.task(domain='cross', inputs=())
def get_petrologistics(task):
    with task.capturelogs(std=True):
        upload_petrologistics(TSA)

@api.task(domain='cross', inputs=(
        io.moment('from', required=True),
))
def get_euromargins(task):
    with task.capturelogs(std=True):
        _get_euromargin(TSA, task.input['from'])
        _get_euromargin_daily(TSA, task.input['from'])


@api.task(domain='cross', inputs=(
    io.moment('start', required=False),
    io.moment('end', required=False),
))
def get_spot_prices(task):
    with task.capturelogs(std=True):
        upload_spot_timeseries(
            DG,
            TSA,
            task.input.get('start') or dt(2000, 1, 1),
            task.input.get('end') or dt.now(),
        )


@api.task(domain='cross', inputs=(
    io.moment('start', required=False),
    io.moment('end', required=False),
))
def get_rolling_prices(task):
    with task.capturelogs(std=True):
        upload_rolling_timeseries(
            DG,
            TSA,
            task.input.get('start') or dt(2000, 1, 1),
            task.input.get('end') or dt.now(),
        )
