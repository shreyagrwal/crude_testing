import pandas as pd

from tshistory.api import timeseries

from saturn_server import HERE
from saturn_server.helpers import (
    safe_update,
    safe_register_formula,
)
from BlueOcean import DataAccessApi
from tqdm import tqdm
from saturn_server.safe_metadata_update import safely_update_metadata

countries = pd.read_csv(HERE / 'cross' / 'data' /
                        'country_names.csv').set_index('saturn_name').iloc[:, 0].to_dict()

def get_forward_month(df, m):
    df_m = df.groupby('pdate').ddate.nth(m-1).to_frame().reset_index()
    df_final = pd.merge(df, df_m, on=['pdate', 'ddate'])
    df_final.set_index('pdate', inplace=True)
    return df_final

def get_euromargin(tsa, date=None):
    date = date or (pd.Timestamp.now().floor('D') - pd.DateOffset(days=1))
    query = f"""
    SELECT pdate, ddate, nwecomplex, medcomplex, nwehydroskim, nwetopping
    FROM dataengineering.oil_crude_euromargin
    where type = 2 and pdate >= '{date:%Y-%m-%d}' and isactive is true
    order by pdate , ddate
    """
    print(query)
    data = DataAccessApi.GetDataframe(query=query)
    for i in range(1,7):
        df_tmp = get_forward_month(data, i)
        df_tmp = df_tmp.drop_duplicates()
        for col in df_tmp.iloc[:, -4:].columns:
            df_tmp.index = pd.to_datetime(df_tmp.index).tz_localize(None)
            ser = pd.Series(df_tmp[col].values, index=df_tmp.index)
            ser = ser.sort_index()
            tsa.update(f'oil.petroineos.euromargin.{col}.m0{i}.usd_bbl.daily', ser, author='Behzad')
            hs_metadata = {
                'hs_is_safe_update': 1,
                'hs_data_ingestion_frequency': 2
            }
            safely_update_metadata(tsa, f'oil.petroineos.euromargin.{col}.m0{i}.usd_bbl.daily', hs_metadata)

    data['ddate'] = pd.to_datetime(data['ddate']).dt.to_period(freq='M').dt.start_time
    data['pdate'] = pd.to_datetime(data['pdate'])
    for pdate, per_day in tqdm(data.groupby(['pdate'])):
        df = per_day.groupby('ddate').mean().iloc[:, -4:]
        for col in df.columns:
            safe_update(
                tsa,
                f"oil.petroineos.euromargin.{col}.usd_bbl.monthly",
                df[col],
                insertion_date=pdate,
            )
            hs_metadata = {
                'hs_is_safe_update': 1,
                'hs_data_ingestion_frequency': 31
            }
            safely_update_metadata(tsa, f"oil.petroineos.euromargin.{col}.usd_bbl.monthly", hs_metadata)
    return data

def get_euromargin_daily(tsa, date=None):
    date = date or (pd.Timestamp.now().floor('D') - pd.DateOffset(days=1))
    query = f"""
    SELECT pdate, ddate, nwecomplex, medcomplex, nwehydroskim, nwetopping
    FROM dataengineering.oil_crude_euromargin
    where type = 0 and pdate >= '{date:%Y-%m-%d}' and isactive is true
    """
    print(query)
    data = DataAccessApi.GetDataframe(query=query)
    data['ddate'] = pd.to_datetime(data['ddate']).dt.to_period(freq='D').dt.start_time
    data['pdate'] = pd.to_datetime(data['pdate'])

    for col in data.iloc[:, -4:].columns:
        data['ddate'] = pd.to_datetime(data['ddate']).dt.tz_localize(None)
        ser = pd.Series(data[col].values, index=data['ddate'])
        ser = ser.sort_index()
        print(col,'\n',ser,'\n---------\n')
        tsa.update(
            f"oil.petroineos.euromargin.{col}.usd_bbl.daily",
            ser,
            author='behzad')
    return data

def build_available_capacity_formula(country):
    name = f"oil.petroineos.{country}.available_capacity_forecast.kbd.monthly"
    formula = f"""(add (series "oil.petroineos.{country}.cdu.capacity.kbd.monthly") (* -1 (priority (slice (add (series "oil.petroineos.{country}.cdu.total_outage_plus_economic.kbd.monthly") (series "crude.petroineos.{country}.unplanned_outage_forecast.kbd.monthly")) #:fromdate (start-of-month (today))) (series "oil.petroineos.{country}.cdu.total_outage_plus_economic.kbd.monthly"))))"""
    return name, formula

def build_utilization_rate_formula(country, params):
    name = f"oil.petroineos.{country}.cdu_utilization_rate.pct.monthly"
    formula = f"""(clip (+ {params.get('const') or 0.88} (add (* {params.get('nwe_coeff') or 0.} (series "oil.petroineos.euromargin.nwecomplex.usd_bbl.monthly")) (* {params.get('med_coeff') or 0.} (series "oil.petroineos.euromargin.medcomplex.usd_bbl.monthly")))) #:max 0.96 #:replacemax #t)"""
    return name, formula

def build_throughput_formula(country):
    name = f"oil.petroineos.{country}.throughput_forecast.kbd.monthly"
    formula = f"""(mul (series "oil.petroineos.{country}.cdu_utilization_rate.pct.monthly") (series "oil.petroineos.{country}.available_capacity_forecast.kbd.monthly"))"""
    return name, formula

def upload_formula(tsa):
    for country in countries:
        # Available capacity
        name, formula = build_available_capacity_formula(country)
        safe_register_formula(tsa, name, formula)


if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    get_euromargin(tsa, pd.Timestamp('2016-1-1'))
    get_euromargin_daily(tsa, pd.Timestamp('2016-1-1'))
    # upload_formula(tsa)