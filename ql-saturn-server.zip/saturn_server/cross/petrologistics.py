import pandas as pd

from tshistory.api import timeseries

from saturn_server import HERE
from saturn_server.helpers import (
    series_id,
    safe_register_formula,
    lowercase
)
from BlueOcean import DataAccessApi

def get_loadings(
        product_value,
        geo_loadings,
        geo_destination,
        geo_destination_value,
        geo_destination_exclude,
        geo_destination_exclude_value,
        qty_type):
    destination = f""" 
    and {geo_destination} = '{geo_destination_value}'
    """ if geo_destination else ""
    destination_exclude = f""" and {geo_destination_exclude} not in {tuple(geo_destination_exclude_value.split('_'))} """  if geo_destination_exclude else ""
    query = f"""
    SELECT {geo_loadings}, load_port_date, sum({qty_type} / 1000.) as qty
    FROM hive_metastore.dataengineering.oil_petrologistics_cargomovement t
	where cargo_type = '{product_value}' {destination} {destination_exclude} and isactive is true
	group by {geo_loadings}, load_port_date order by load_port_date desc
    """
    print(query)
    data = DataAccessApi.GetDataframe(query)
    print(data.head())
    if not data.empty:
        data['date'] = pd.to_datetime(data['load_port_date']).dt.tz_localize(None)
        data = data[['date', geo_loadings, 'qty']]
        data = data.groupby(['date', geo_loadings]).sum().unstack(1)
        data = data['qty']
        data.columns = (data.columns
        .str.lower()
        .str.replace(' |-', '_')
        .str.replace(r'[()]','')
        )
        return data.resample('D').mean().fillna(0)
    else:
        return pd.DataFrame()

ORDER = ['product', 'source', 'geo_loadings_value','geo_destination_value',
         'economic_property', 'unit', 'frequency']

def mav(series_id, days):
    return f'(rolling (series "{series_id}") {days})'

def upload_petrologistics(tsa):
    metadata = pd.read_csv(HERE / 'cross' / 'data' / 'petrologistics.csv')
    fields = [
        'product_value',
        'geo_loadings',
        'geo_destination',
        'geo_destination_value',
        'geo_destination_exclude',
        'geo_destination_exclude_value',
        'qty_type'
    ]
    for group, data_group in metadata.groupby(fields,dropna=False):
        kwargs = dict(zip(fields, [None if not isinstance(x, str) else x for x in group]))
        data = get_loadings(**kwargs)
        if not data.empty:
            for line in data_group.to_dict('records'):
                proper_order = [field for field in ORDER if isinstance(line.get(field), str)]
                proper_values = [lowercase(line[field]) for field in ORDER if isinstance(line.get(field), str)]
                proper_meta = dict(zip(proper_order,proper_values))
                serie_id = series_id(proper_meta, proper_order)
                series = data.get(proper_meta['geo_loadings_value'])
                if series is not None:
                    tsa.update(
                        serie_id,
                        series,
                        author='uploader',
                    )
                    for days in [7, 14, 30, 180]:
                        ts_name = '.'.join([serie_id, f"{days}mav"])
                        formula = mav(serie_id, days)
                        safe_register_formula(
                            tsa,
                            ts_name,
                            formula
                        )

if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    upload_petrologistics(tsa)