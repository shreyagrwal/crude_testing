from BlueOcean import DataAccessApi
import pandas as pd
from tshistory.api import timeseries

symbols = {
    'QS': 'ice_gasoil',
    'LGF1F2':'ice_gasoil_m1_m2',
    'CO': 'ice_brent',
    'BCF1F2': 'ice_brent_m1_m2',
    'BCZZR': 'ice_brent_z1_z2'
}

def get_bridgeton_data(symbols=symbols):
    query = f"""
    select sum(NetPosition) as NetPosition, Symbol, `Date` from dataengineering.algotrading_bridgeton_positions
    where Symbol in {tuple(symbols.keys())} and IsActive = True
    group by Symbol, `Date`
    order by `Date` desc
    """
    print(query)
    data = DataAccessApi.GetDataframe(query)
    data.Date = pd.to_datetime(data.Date)
    data.Symbol = data.Symbol.map(symbols).apply(lambda x: f'oil.bridgeton.{x}.net_positioning.normalised_risk_unit.daily')
    return data.set_index(['Symbol', 'Date']).unstack(0)

def upload_bridgeton_data(tsa:timeseries):
    data = get_bridgeton_data()['NetPosition']
    print(data.describe().T)
    for name in data.columns:
        print(name)
        tsa.update(
            name,
            data[name],
            author='uploader',
        )

if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    upload_bridgeton_data(tsa)
