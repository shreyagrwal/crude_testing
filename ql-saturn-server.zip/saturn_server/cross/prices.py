import os
from datetime import datetime as dt
import pandas as pd
from tshistory.api import timeseries
from tqdm.contrib.concurrent import thread_map
from itertools import product

#from datagenic_rest_client.datagenic import DataGenic
from ag_datagenic_rest_client import DataGenic
from saturn_server import HERE, DG
from saturn_server.safe_metadata_update import safely_update_metadata

def maturity_name(freq, number):
    return f'{freq}{number:02}'

def get_rolling_name(prefix, suffix, maturity_freq, maturity_number):
    maturity = f'{maturity_name(maturity_freq, maturity_number)}{suffix.strip()}'
    return '.'.join([prefix, maturity])

def saturn_id_rolling(product, source, price_name, maturity_freq, number, unit, freq):
    maturity = maturity_name(maturity_freq, number).lower()
    return '.'.join([product, source, price_name, maturity, unit, freq])

def saturn_id_spot(product,source, price_name, unit, freq):
    return '.'.join([product, source, price_name, unit, freq])

def upload_spot_timeseries(dg:DataGenic, tsa: timeseries, start ,end):
    datagenic_ts = pd.read_csv(
        HERE / 'cross'  / 'data' / 'datagenic_spot.csv').to_dict('records')
    
    def upload_rolling_prices(meta):
        metadata = {
            'series_id': saturn_id_spot(
                meta['product'], 
                meta['source'], 
                meta['price_name'], 
                meta['unit'], 
                meta['frequency']
                ),
                'name': meta['prefix'],
            **meta
        }
        try:
            data = dg.get_time_series(metadata['name'], start, end)
            data.index = data.index.tz_localize(None)
            print(metadata['series_id'])
            tsa.update(
                metadata['series_id'],
                data.iloc[:, -1].astype(float),
                author='uploader',
            )
            safely_update_metadata(tsa, metadata['series_id'], metadata)
        except:
            pass
        
    list(map(upload_rolling_prices, datagenic_ts))

def upload_rolling_timeseries(dg:DataGenic, tsa: timeseries, start ,end, freq='M', maturity=24):
    datagenic_ts = pd.read_csv(
        HERE / 'cross' / 'data' / 'datagenic_rolling.csv').to_dict('records')
    
    def upload_rolling_prices(meta, mat):
        metadata = {
            'series_id': saturn_id_rolling(
                meta['product'], 
                meta['source'], 
                meta['price_name'], 
                freq, 
                mat, 
                meta['unit'], 
                meta['frequency']),
            'name': get_rolling_name(meta['prefix'], meta['suffix'], freq, mat),
            'maturity': maturity,
            'maturity_freq': freq,
            **meta
        }
        try:
            data = dg.get_time_series(metadata['name'], start, end)
            data.index = data.index.tz_localize(None)
            print(metadata['series_id'])
            if data is not None:
                tsa.update(
                    metadata['series_id'],
                    data.iloc[:, -1].astype(float),
                    author='uploader',
                )
                safely_update_metadata(tsa, metadata['series_id'], metadata)
        except:
            pass
    
    maturities = range(0, maturity+1)
    list(map(upload_rolling_prices, *zip(*list(product(datagenic_ts, maturities)))))

if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    upload_spot_timeseries(DG, tsa, dt(2023,3, 1), dt.now())
    # upload_rolling_timeseries(DG, tsa, dt(2000,1,1), dt.now())