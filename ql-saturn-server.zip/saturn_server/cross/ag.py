import requests
import pandas as pd
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def ag_get_data(server, database, query):
    params = {"Database": database, "Query": query}
    resp = requests.post(f"{server}/genericdata/Fetch/",
                         json   =params, verify=False)
    jsonResult = resp.json()
    data = pd.DataFrame(jsonResult)
    return data