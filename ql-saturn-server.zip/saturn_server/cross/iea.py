import pandas as pd

from tshistory.api import timeseries

from saturn_server import HERE
from saturn_server.helpers import (
    safe_update, 
    series_id, 
    last_pdate
)
from BlueOcean import DataAccessApi
from saturn_server.safe_metadata_update import safely_update_metadata

ORDER_BALANCE = ['product', 'source', 'country',
         'economic_property', 'unit', 'frequency']

ORDER_FLOWS = ['product', 'source', 'from',
         'to','economic_property', 'unit', 'frequency']

def _reshape_series(data):
    data.index = pd.to_datetime(data.Month, format='%b%Y')
    return data.Value.resample('MS').sum()

def iea_last_publication(db):
    return last_pdate('PDate', db)

def get_iea_balance(db, countries, products, flows):
    countries, products, flows = [x.replace('_', ',') for x in (countries, products, flows)]
    query = f"""
        select t.Month, sum(t.Value) as Value 
        from {db} t
            inner join (
                select Country, ProductType, Flow 
                from {db} 
                where Country IN ({countries}) and ProductType IN ({products}) and Flow IN ({flows})
                group by Country, ProductType, Flow
        ) tm on t.Flow = tm.Flow and t.Country = tm.Country and t.ProductType = tm.ProductType 
        where t.PDate = (select max(pdate) from {db}) and isactive is true
        group by t.Month;
        """
    print(query)
    data = DataAccessApi.GetDataframe(query)
    return _reshape_series(data)

def get_iea_flows(db, from_country, to_country, products):
    source, destination, products = [x.replace('_', ',') for x in (from_country, to_country, products)]
    query = f"""
        select t.Month, sum(t.Value) as Value 
        from {db} t
            inner join (
                select max(PDate) as MaxDate, DestCountry, SourceCountry, ProductType 
                from {db} 
                where DestCountry IN ({destination}) and SourceCountry IN ({source}) and ProductType IN ({products})
                group by DestCountry, SourceCountry, ProductType
        ) tm on t.DestCountry = tm.DestCountry and t.SourceCountry = tm.SourceCountry and 
        t.ProductType = tm.ProductType and t.PDate = tm.MaxDate and isactive is true
        group by t.Month;
        """
    print(query)
    data = DataAccessApi.GetDataframe(query)
    return _reshape_series(data)

def upload_iea_balance(tsa, series):
    data = {
        (series_id(s, ORDER_BALANCE), iea_last_publication(s['db'])): 
        (s, get_iea_balance(s['db'], s['countries'], s['products'], s['flows']))
        for s in series
        }
    for (serie_id, pdate), (meta, data) in data.items():
        print(serie_id, pdate)
        safe_update(
            tsa,
            serie_id,
            data,
            insertion_date=pdate
        )
        #safely_update_metadata(tsa, serie_id, meta)
        temp_metadata = meta
        temp_metadata['hs_is_safe_update'] = 1
        temp_metadata['hs_data_ingestion_frequency'] = 31
        safely_update_metadata(tsa, serie_id, temp_metadata)


def upload_iea_flows(tsa, series):
    data = {
        (series_id(s, ORDER_FLOWS), iea_last_publication(s['db'])): 
        (s, get_iea_flows(s['db'], s['from_country'], s['to_country'], s['products']))
        for s in series
        }
    for (serie_id, pdate), (meta, data) in data.items():
        safe_update(
            tsa,
            serie_id,
            data,
            insertion_date=pdate
        )
        #safely_update_metadata(tsa, serie_id, meta)
        temp_metadata = meta
        temp_metadata['hs_is_safe_update'] = 1
        temp_metadata['hs_data_ingestion_frequency'] = 31
        safely_update_metadata(tsa, serie_id, temp_metadata)

def upload_iea(tsa):
    metadata = pd.read_csv(
        HERE / 'cross' / 'data' / 'iea_balance.csv').to_dict('records')
    upload_iea_balance(tsa, metadata)
    metadata = pd.read_csv(
        HERE / 'cross' / 'data' / 'iea_flows.csv').to_dict('records')
    upload_iea_flows(tsa, metadata)


if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    upload_iea(tsa)