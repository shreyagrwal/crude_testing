import pandas as pd
import os
import requests
import json
from pathlib import Path
from requests import Request
import numpy as np

from tqdm.contrib.concurrent import thread_map

from saturn_server.helpers import safe_update
from saturn_server.safe_metadata_update import safely_update_metadata

HERE = Path(__file__).parent

def get_ea_value(token, dataset_id):
    data = pd.read_csv(f'https://api.energyaspects.com/data/timeseries/csv?api_key={token}&dataset_id={dataset_id}')
    data = data.set_index('Date').iloc[:, -1]
    data.index = pd.to_datetime(data.index)
    print(data)
    return data

def get_ea_values(token, dataset_ids, release_date):
    params = {
        'dataset_id' : dataset_ids, 
        'api_key': token, 
        'date_from': '2002-1-1', 
        'release_date': f'{release_date:%Y-%m-%dT%H:%M:%S}'
    }
    url="https://api.energyaspects.com/data/timeseries/"
    print(f"Going to fetch data from the url:{url}")
    req = requests.get('https://api.energyaspects.com/data/timeseries/', params=params)
    print(req.status_code)
    if not req.ok:
        message=f"The HTTP request to https://api.energyaspects.com/data/timeseries/ failed with status code: {req.status_code} and response:{req.text}"
        print(message)
        raise Exception(message)
    print("Data was downloaded successfully")
    res = req.json()
    meta = pd.DataFrame([{**r['metadata'], 'dataset_id': int(r['dataset_id'])} for r in res])
    cols = pd.MultiIndex.from_frame(meta)
    _data = pd.DataFrame([r['data'] for r in res]).T
    data = pd.DataFrame(
        _data.values, 
        columns = cols, 
        index=pd.to_datetime(_data.index)
    )
    return data

def get_ea_meta(token, dataset_id):
    data = requests.get(f'https://api.energyaspects.com/data/datasets/timeseries/{dataset_id}?api_key={token}').json()
    meta = data.get('metadata')
    if meta:
        return {k: v for k,v in data.get('metadata').items() if isinstance(v, str)}
    else:
        return {}


def get_energy_aspects(tsa):
    token = '60bd348c-a6c2-4bad-8bde-0fa2ce2066d4'
    metadata = pd.read_csv(
        HERE / 'data' / 'ea.csv').to_dict('records')
    release_dates = pd.date_range(end=pd.Timestamp.now(), periods=2, freq='7D').floor('D')
    for release_date in release_dates:
        data = get_ea_values(token, [k['dataset_id'] for k in metadata], release_date)
        def _upload_series(dataset_id, name):
            dataxs = data.xs(dataset_id, level='dataset_id', axis=1)
            insertion_date = pd.Timestamp(
                    dataxs.columns.get_level_values('release_date').values[0]).floor('D')
            if tsa.insertion_dates(name) is not None:
                if insertion_date.tz_localize('UTC') < tsa.insertion_dates(name)[-1]:
                    return
            safe_update(
                tsa,
                name,
                dataxs.iloc[:, 0],
                insertion_date=insertion_date
            )
            #safely_update_metadata(tsa, name, dataxs.columns.to_frame().iloc[0].T.to_dict())
            temp_metadata = dataxs.columns.to_frame().iloc[0].T.to_dict()
            temp_metadata['hs_is_safe_update'] = 1
            temp_metadata['hs_data_ingestion_frequency'] = 31
            #print(temp_metadata)
            safely_update_metadata(tsa, name, temp_metadata)
        
        thread_map(lambda args: _upload_series(*args), [(k['dataset_id'], k['series_id']) for k in metadata])


if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    print(get_energy_aspects(tsa))