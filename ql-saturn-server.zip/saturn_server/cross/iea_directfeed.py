import os, sys
import time
import shutil
import pandas as pd
from datetime import datetime

from tshistory.api import timeseries

sys.path.append(os.getcwd())
from saturn_server import HERE
from saturn_server.helpers import (
    safe_update, 
    series_id, 
    last_pdate
)
from BlueOcean import DataAccessApi
from saturn_server.safe_metadata_update import safely_update_metadata

temp_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\IEA'
saturn_datafeed = os.path.join(temp_path, "saturn_dirct_datafeed\\")

ORDER_BALANCE = ['product', 'source', 'country',
         'economic_property', 'unit', 'frequency']

ORDER_FLOWS = ['product', 'source', 'from',
         'to','economic_property', 'unit', 'frequency']

def _reshape_series(data):
    data.index = pd.to_datetime(data.Month, format='%b%Y')
    return data.Value.resample('MS').sum()

def iea_last_publication(db):
    return last_pdate('PDate', db)

def get_direct_datafeed_balance(df, countries, products, flows):
    df['PDate'] = pd.to_datetime(df['PDate'])
    countries_list = [countries][0].split(',')
    products_list = [products][0].split(',')
    flows_list = [flows][0].split(',')

    countries = [element.strip("'") for element in countries_list]
    products = [element.strip("'") for element in products_list]
    flows = [element.strip("'") for element in flows_list]

    filtered_df = df.loc[
        (df['Country'].isin(countries)) &
        (df['ProductType'].isin(products)) &
        (df['Flow'].isin(flows))
    ].copy()
    filtered_df['Month'] = pd.to_datetime(filtered_df['Month'], format='%b%Y')
    result_df = filtered_df.groupby('Month')['Value'].sum().reset_index()
    #print(result_df)
    return result_df

def get_iea_balance(db, countries, products, flows, dfc, dfp):
    countries, products, flows = [x.replace('_', ',') for x in (countries, products, flows)]
    if 'oil_iea_ieacrudebal' in db:
        data = get_direct_datafeed_balance(dfc, countries, products, flows)
    elif 'oil_iea_ieaprodbal' in db:
        data = get_direct_datafeed_balance(dfp, countries, products, flows)
    return _reshape_series(data)

def get_direct_datafeed_flows(df, from_country, to_country, products):
    df['PDate'] = pd.to_datetime(df['PDate'])
    from_country_list = [from_country][0].split(',')
    to_country_list = [to_country][0].split(',')
    products_list = [products][0].split(',')

    from_country = [element.strip("'") for element in from_country_list]
    to_country = [element.strip("'") for element in to_country_list]
    products = [element.strip("'") for element in products_list]

    filtered_df = df.loc[
        (df['SourceCountry'].isin(from_country)) &
        (df['ProductType'].isin(products)) &
        (df['DestCountry'].isin(to_country))
    ].copy()
    filtered_df['Month'] = pd.to_datetime(filtered_df['Month'], format='%b%Y')
    result_df = filtered_df.groupby('Month')['Value'].sum().reset_index()
    #print(result_df)
    return result_df

def get_iea_flows(db, from_country, to_country, products, dfi, dfe):
    source, destination, products = [x.replace('_', ',') for x in (from_country, to_country, products)]
    if 'oil_iea_ieaoilimpor' in db:
        data = get_direct_datafeed_flows(dfi, source, destination, products)
    elif 'oil_iea_ieaoilexpor' in db:
        data = get_direct_datafeed_flows(dfe, source, destination, products)
    return _reshape_series(data)

def upload_iea_balance(tsa, series):

    if os.path.exists(saturn_datafeed + 'Upload_Oil_IEACRUDEBAL.csv') and os.path.exists(saturn_datafeed + 'Upload_Oil_IEAPRODBAL.csv'):
        df_crude = pd.read_csv(saturn_datafeed + 'Upload_Oil_IEACRUDEBAL.csv')
        df_product = pd.read_csv(saturn_datafeed + 'Upload_Oil_IEAPRODBAL.csv')
        # pdate = jodi_last_publication(db)
        pdate = pd.to_datetime(time.ctime(os.path.getmtime(saturn_datafeed + 'Upload_Oil_IEACRUDEBAL.csv')))
        print(f'pdate is {pdate}')

        data = {
            (series_id(s, ORDER_BALANCE), pdate): 
            (s, get_iea_balance(s['db'], s['countries'], s['products'], s['flows'], df_crude, df_product))
            for s in series
            }
        for (serie_id, pdate), (meta, data) in data.items():
            print(serie_id, pdate)
            safe_update(
                tsa,
                serie_id,
                data,
                insertion_date=pdate
            )
            #safely_update_metadata(tsa, serie_id, meta)
            temp_metadata = meta
            temp_metadata['hs_is_safe_update'] = 1
            temp_metadata['hs_data_ingestion_frequency'] = 31
            safely_update_metadata(tsa, serie_id, temp_metadata)

        print('moving Upload_Oil_IEAOILIMPOR to Archive')
        shutil.move(saturn_datafeed + 'Upload_Oil_IEACRUDEBAL.csv', saturn_datafeed + '\\Archive\\Upload_Oil_IEACRUDEBAL.csv')
        print('moving Upload_Oil_IEAOILEXPOR to Archive')
        shutil.move(saturn_datafeed + 'Upload_Oil_IEAPRODBAL.csv', saturn_datafeed + '\\Archive\\Upload_Oil_IEAPRODBAL.csv')
    
    else:
        print('No CSV files are found!!')


def upload_iea_flows(tsa, series):
    if os.path.exists(saturn_datafeed + 'Upload_Oil_IEAOILIMPOR.csv') and os.path.exists(saturn_datafeed + 'Upload_Oil_IEAOILEXPOR.csv'):
        df_import = pd.read_csv(saturn_datafeed + 'Upload_Oil_IEAOILIMPOR.csv')
        df_export = pd.read_csv(saturn_datafeed + 'Upload_Oil_IEAOILEXPOR.csv')
        pdate = pd.to_datetime(time.ctime(os.path.getmtime(saturn_datafeed + 'Upload_Oil_IEAOILIMPOR.csv')))
        print(f'pdate is {pdate}')

        data = {
            (series_id(s, ORDER_FLOWS), pdate): 
            (s, get_iea_flows(s['db'], s['from_country'], s['to_country'], s['products'], df_import, df_export))
            for s in series
            }
        for (serie_id, pdate), (meta, data) in data.items():
            print(serie_id, pdate)
            safe_update(
                tsa,
                serie_id,
                data,
                insertion_date=pdate
            )
            #safely_update_metadata(tsa, serie_id, meta)
            temp_metadata = meta
            temp_metadata['hs_is_safe_update'] = 1
            temp_metadata['hs_data_ingestion_frequency'] = 31
            safely_update_metadata(tsa, serie_id, temp_metadata)
        
        print('moving Upload_Oil_IEAOILIMPOR to Archive')
        shutil.move(saturn_datafeed + 'Upload_Oil_IEAOILIMPOR.csv', saturn_datafeed + '\\Archive\\Upload_Oil_IEAOILIMPOR.csv')
        print('moving Upload_Oil_IEAOILEXPOR to Archive')
        shutil.move(saturn_datafeed + 'Upload_Oil_IEAOILEXPOR.csv', saturn_datafeed + '\\Archive\\Upload_Oil_IEAOILEXPOR.csv')
    
    else:
        print('No CSV files are found!!')

def upload_iea_directfeed(tsa):
    metadata = pd.read_csv(
        HERE / 'cross' / 'data' / 'iea_balance.csv').to_dict('records')
    upload_iea_balance(tsa, metadata)
    metadata = pd.read_csv(
        HERE / 'cross' / 'data' / 'iea_flows.csv').to_dict('records')
    upload_iea_flows(tsa, metadata)


if __name__ == '__main__':
    from tshistory.api import timeseries
    print(datetime.now())
    tsa = timeseries('http://tst-qdev-ap12.petroineos.local/api/')
    upload_iea_directfeed(tsa)
    print(datetime.now())