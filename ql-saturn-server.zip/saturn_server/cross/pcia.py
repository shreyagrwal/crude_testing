import pandas as pd
from dotenv import load_dotenv
import os
from saturn_server.safe_metadata_update import safely_update_metadata
load_dotenv()

def get_pcia_balance(tsa):

    # PATH = os.environ.get('PCIA_LINK') or 'https://data51595354.s3.amazonaws.com/MODEL/PCIA_LATEST_CRUDE_MODEL_SUMMARY_LATEST.csv'
    PATH = '//petroineos.local/dfs/Department Shared Folders/~Analysis Department/crude/balance/pcia crude model.csv'
    data = pd.read_csv(PATH)
    data.drop(columns=['PDATE', 'LEVEL 3','LEVEL 4','Model Description','ORIGIN','DESTINATION', 'REFERENCE','CAPACITY'], inplace=True)
    def fn(x):
        name = ".".join([str(x[y]) if str(x[y]) != "nan" else "" for y in ['SOURCE', 'VIEW','LOCATION','LEVEL 1', 'LEVEL 2', 'UOM']])
        name = name.replace("->", "").replace(" ", "_").replace("-", "_").replace("|", "").replace("..", ".").replace("/", "_")
        return ".".join(['crude',name.lower(),'monthly'])
    data['series_name'] = data.apply(fn, axis=1)
    data = data.set_index(['series_name','SOURCE', 'VIEW','LOCATION','LEVEL 1', 'LEVEL 2', 'UOM'])
    data.columns = pd.to_datetime(data.columns)
    dimensions = data.index.drop_duplicates()
    names = [x[0] for x in dimensions]
    for name, dimension in zip(names, dimensions):
        series = data.xs(name).stack()
        tsa.update(
            name,
            series.xs(dimension[1:]).resample('MS').mean(),
            author='uploader',
        )
        print(name)
        metadata = dict(zip(dimensions.names, dimension))
        metadata = {k: str(v) or "" for k,v in metadata.items()}
        metadata['analysts'] = "Jon/Patrick"
        safely_update_metadata(tsa, name, metadata)

if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    get_pcia_balance(tsa)