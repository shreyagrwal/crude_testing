import pandas as pd
from tshistory.api import timeseries
from BlueOcean import DataAccessApi
from saturn_server.safe_metadata_update import safely_update_metadata

def bo_get_data(query):
    print(f"requesting this query {query} bia BO")
    data = DataAccessApi.GetDataframe(query)
    return data

oecd_europe = ('Slovenia','Poland','Turkey','Denmark','Estonia','Finland','Iceland','Ireland','Norway','Sweden','United Kingdom','Albania','Greece','Italy','Portugal','Spain','Belgium','France','Germany','Netherlands', 'Lithuania')
COUNTRY_LIST = ['United Kingdom','Norway','United States', 'Canada', 'Mexico','Nigeria', 'Angola', 'Brazil', 'Guyana', 'Colombia', 'Libya', 'Algeria', 'Tunisia', 'Saudi Arabia','United Arab Emirates', 'Iraq', 'Kuwait', 'Iran', 'Egypt','Russian Federation']
SUBCONTINENT_LIST = ['Western Africa', 'South America', 'Northern America']

nsea_exports_query = f'''select start date, sum(cargo_origin_barrels_split_by_product) volume from hive_metastore.dataengineering.oil_kpler_kplertradesversioned 
where (origin_country_name in ('United Kingdom', 'Norway') and  zone_origin_name != 'Ceyhan')
and continent_destination_name in ('Asia', 'Americas', 'Africa', 'Oceania')
and LoadTimeStamp = (select max(LoadTimeStamp) from hive_metastore.dataengineering.oil_kpler_kplertradesversioned)
group by start
order by start desc
'''

oecd_imports_query = f'''select end date, sum(cargo_origin_barrels_split_by_product) volume from hive_metastore.dataengineering.oil_kpler_kplertradesversioned 
where (origin_country_name not in {oecd_europe} or zone_origin_name = 'Ceyhan')
and destination_country_name in {oecd_europe}
and LoadTimeStamp = (select max(LoadTimeStamp) from hive_metastore.dataengineering.oil_kpler_kplertradesversioned)
group by end
order by end desc
'''

kazakh_imports_query = f'''select end date, sum(cargo_origin_barrels_split_by_product) volume from hive_metastore.dataengineering.oil_kpler_kplertradesversioned 
where closest_ancestor_grade in ('CPC', 'CPC Kazakhstan', 'KEBCO')
and destination_country_name in {oecd_europe}
and LoadTimeStamp = (select max(LoadTimeStamp) from hive_metastore.dataengineering.oil_kpler_kplertradesversioned)
group by end
order by end desc
'''

ceyhan_imports_query = f'''select end date, sum(cargo_origin_barrels_split_by_product) volume from hive_metastore.dataengineering.oil_kpler_kplertradesversioned 
where zone_origin_name = 'Ceyhan'
and destination_country_name in {oecd_europe}
and LoadTimeStamp = (select max(LoadTimeStamp) from hive_metastore.dataengineering.oil_kpler_kplertradesversioned)
group by end
order by end desc
'''

ceyhan_exports_query = f'''select start date, sum(cargo_origin_barrels_split_by_product) volume from hive_metastore.dataengineering.oil_kpler_kplertradesversioned 
where zone_origin_name = 'Ceyhan'
and LoadTimeStamp = (select max(LoadTimeStamp) from hive_metastore.dataengineering.oil_kpler_kplertradesversioned)
group by start
order by start desc
'''


def aggregate_daily_kbd(df):
    df.index = pd.to_datetime(df['date'])
    df_grouped = df.resample('D').sum().astype(float)
    df_grouped.index = df_grouped.index.tz_localize(None)
    return df_grouped['volume']/1000


def aggregate_monthly_kbd(df):
    df.index = pd.to_datetime(df.date)
    df_grouped = df.resample('MS').sum().astype(float)
    df_grouped['volume'] = df_grouped['volume']/(df_grouped.index.daysinmonth*1000)
    df_grouped.index = df_grouped.index.tz_localize(None)
    return df_grouped['volume']


def clean_names(str_list):
    new_list = []
    for i in range(len(str_list)):
        new_list.append(str_list[i].lower())
        new_list[i] = new_list[i].replace(' ','_')
    return new_list

### adding where clause to exclude CPC as Kpler includes cpc flows as russian
def db_country_imports(origin):
    country_imports_query = f'''select end date, sum(cargo_origin_barrels_split_by_product) volume from hive_metastore.dataengineering.oil_kpler_kplertradesversioned 
    where origin_country_name = '{origin}' and closest_ancestor_grade not in ('CPC', 'CPC Kazakhstan', 'KEBCO')
    and destination_country_name in {oecd_europe}
    and LoadTimeStamp = (select max(LoadTimeStamp) from hive_metastore.dataengineering.oil_kpler_kplertradesversioned)
    group by end
    order by end desc
    '''

    ts = aggregate_monthly_kbd(bo_get_data(country_imports_query))
    ts_daily = aggregate_daily_kbd(bo_get_data(country_imports_query))
    return ts, ts_daily

def db_total_exports(origin):
    query = f'''select start date, sum(cargo_origin_barrels_split_by_product) volume from hive_metastore.dataengineering.oil_kpler_kplertradesversioned 
    where origin_country_name = '{origin}' and closest_ancestor_grade not in ('CPC', 'CPC Kazakhstan', 'KEBCO')
    and LoadTimeStamp = (select max(LoadTimeStamp) from hive_metastore.dataengineering.oil_kpler_kplertradesversioned)
    group by start
    order by start desc
    '''

    ts = aggregate_monthly_kbd(bo_get_data(query))
    ts_daily = aggregate_daily_kbd(bo_get_data(query))
    return ts, ts_daily

def db_subcont_imports(origin):
    qry = f'''select end date, sum(cargo_origin_barrels_split_by_product) volume from hive_metastore.dataengineering.oil_kpler_kplertradesversioned 
    where origin_subcontinent_name = '{origin}' and destination_country_name in {oecd_europe}
    and LoadTimeStamp = (select max(LoadTimeStamp) from hive_metastore.dataengineering.oil_kpler_kplertradesversioned)
    group by end
    order by end desc
    '''

    ts = aggregate_monthly_kbd(bo_get_data(qry))
    ts_daily = aggregate_daily_kbd(bo_get_data(qry))
    return ts, ts_daily


def upload_kpler(tsa):
    name = 'crude.kpler.oecd_europe.exports.kbd.monthly'
    oecd_exports_ts = aggregate_monthly_kbd(bo_get_data(nsea_exports_query))
    tsa.update(name,oecd_exports_ts,'Syed Ahmad')
    oecd_exports_ts_daily = aggregate_daily_kbd(bo_get_data(nsea_exports_query))
    name = 'crude.kpler.oecd_europe.exports.kbd.daily'
    tsa.update(name, oecd_exports_ts_daily,'Syed Ahmad')
    name = 'crude.kpler.cpc.oecd_europe.imports.kbd.monthly'
    cpc_import_ts = aggregate_monthly_kbd(bo_get_data(kazakh_imports_query))
    tsa.update(name,cpc_import_ts,'Syed Ahmad')
    cpc_import_ts_daily = aggregate_daily_kbd(bo_get_data(kazakh_imports_query))
    name = 'crude.kpler.cpc.oecd_europe.imports.kbd.daily'
    tsa.update(name, cpc_import_ts_daily,'Syed Ahmad')
    name = 'crude.kpler.ceyhan.oecd_europe.imports.kbd.monthly'
    ceyhan_import_ts = aggregate_monthly_kbd(bo_get_data(ceyhan_imports_query))
    tsa.update(name,ceyhan_import_ts,'Syed Ahmad')
    ceyhan_import_ts_daily = aggregate_daily_kbd(bo_get_data(ceyhan_imports_query))
    name = 'crude.kpler.ceyhan.oecd_europe.imports.kbd.daily'
    tsa.update(name, ceyhan_import_ts_daily,'Syed Ahmad')
    ceyhan_export_ts_daily = aggregate_daily_kbd(bo_get_data(ceyhan_exports_query))
    name = 'crude.kpler.ceyhan.exports.kbd.daily'
    tsa.update(name, ceyhan_export_ts_daily,'Syed Ahmad')

def upload_kpler_country_loop(tsa):
    names = clean_names(COUNTRY_LIST)
    for c, n in zip(COUNTRY_LIST, names):
        ts, ts_daily = db_country_imports(c)
        name = f'crude.kpler.{n}.oecd_europe.imports.kbd.daily'
        tsa.update(name, ts_daily, 'Syed Ahmad')
        name = f'crude.kpler.{n}.oecd_europe.imports.kbd.monthly'
        tsa.update(name, ts, 'Syed Ahmad')
        exp_ts, exp_ts_daily = db_total_exports(c)
        name = f'crude.kpler.{n}.exports.kbd.daily'
        tsa.update(name, exp_ts_daily, 'Syed Ahmad')
        name = f'crude.kpler.{n}.exports.kbd.monthly'
        tsa.update(name, exp_ts, 'Syed Ahmad')
        print(f'{c} uploaded')
    return print (f'{len(COUNTRY_LIST)} countries uploaded')


def upload_kpler_subcont_loop(tsa):
    names = clean_names(SUBCONTINENT_LIST)
    for c, n in zip(SUBCONTINENT_LIST, names):
        ts, ts_daily = db_subcont_imports(c)
        name = f'crude.kpler.{n}.oecd_europe.imports.kbd.daily'
        tsa.update(name, ts_daily, 'Syed Ahmad')
        name = f'crude.kpler.{n}.oecd_europe.imports.kbd.monthly'
        tsa.update(name, ts, 'Syed Ahmad')
        print(f'{c} uploaded')
    return print (f'{len(SUBCONTINENT_LIST)} series uploaded')

ara_exports_query = f'''select start date, sum(cargo_origin_barrels_split_by_product) volume from hive_metastore.dataengineering.oil_kpler_kplertradesversioned 
    where origin_country_name in ('Netherlands', 'Belgium')
    and destination_country_name not in ('Netherlands', 'Belgium')
    and closest_ancestor_product = 'Crude'
    and LoadTimeStamp = (select max(LoadTimeStamp) from hive_metastore.dataengineering.oil_kpler_kplertradesversioned)
    group by start
    order by start desc
    '''

ara_imports_query = f'''select end date, sum(cargo_origin_barrels_split_by_product) volume from hive_metastore.dataengineering.oil_kpler_kplertradesversioned 
    where destination_country_name in ('Netherlands', 'Belgium')
    and origin_country_name not in ('Netherlands', 'Belgium')
    and closest_ancestor_product = 'Crude'
    and LoadTimeStamp = (select max(LoadTimeStamp) from hive_metastore.dataengineering.oil_kpler_kplertradesversioned)
    group by end
    order by end desc
    '''

def upload_ara_flows(tsa):
    menu = {
        'crude.kpler.ara.exports.kbd.daily': ara_exports_query,
        'crude.kpler.ara.imports.kbd.daily': ara_imports_query, 
    }
    for name, q in menu.items():
        data = aggregate_daily_kbd(
                bo_get_data(q)
            )
        tsa.update(
            name,
            data,
            author='uploader'
        )
        safely_update_metadata(tsa, name, {'query': q})


if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    server = 'https://TST-QDEV-AP1.petroineos.local:5001'
    upload_ara_flows(tsa)
    upload_kpler(tsa)
    upload_kpler_country_loop(tsa)
    upload_kpler_subcont_loop(tsa)

