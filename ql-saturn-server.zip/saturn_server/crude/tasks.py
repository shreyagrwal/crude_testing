import pandas as pd

from rework import api, io

from datetime import datetime as dt

from saturn_server.crude.kpler_flows import upload_kpler, upload_kpler_country_loop, upload_kpler_subcont_loop, upload_ara_flows
from saturn_server.crude.kpler_api import get_ara_daily_inventory, get_oil_on_water, get_fs, get_global_daily_inventory, get_regional_inventory
from saturn_server.crude.rystad_production import loop_and_upload, loop_and_upload_grades, loop_and_upload_us
from saturn_server.crude.refinery_outages import (
    upload_refinery_outages_weekly_updates,
    upload_refinery_capacity,
    upload_refinery_outages_weekly_updates_incl_economic,
    upload_refinery_outages_daily,
    upload_refinery_outages_daily_incl_economic,
    upload_refinery_planned_unplanned_outages)

from saturn_server import TSA, DG


@api.task(domain='crude', inputs=())
def get_kpler(task):
    with task.capturelogs(std=True):
        upload_kpler(TSA)
        upload_kpler_country_loop(TSA)
        upload_kpler_subcont_loop(TSA)
        upload_ara_flows(TSA)

@api.task(domain='crude', inputs=())
def get_kpler_api(task):
    with task.capturelogs(std=True):
        get_regional_inventory(TSA)
        get_ara_daily_inventory(TSA)
        get_oil_on_water(TSA)
        get_fs(TSA)
        get_global_daily_inventory(TSA)


@api.task(domain='crude', inputs=())
def demo_show_diagnostics(task):
    """Useful for diagnosing workers
    Args:
        task (_type_): 
    """
    with task.capturelogs(std=True):
        import sys
        import os
        print("Going to display the URL of the postgres database")
        print(f"{TSA=}")
        print("----------------------")
        print("Going to display the path to the Python interpreter")
        print(f"{sys.executable=}")
        print("----------------------")
        print(f"COMPUTERNAME={os.environ['COMPUTERNAME']}")
        print(f"Current Python file={__file__}")

@api.task(domain='crude', inputs=())
def get_rystad(task):
    with task.capturelogs(std=True):
        loop_and_upload(TSA)
        loop_and_upload_us(TSA)
        loop_and_upload_grades(TSA)
        
@api.task(domain='crude', inputs=(
    io.number('overwrite', required=True),
))
def get_refinery_outages(task):
    with task.capturelogs(std=True):
        upload_refinery_planned_unplanned_outages(TSA)
        upload_refinery_outages_weekly_updates(
            TSA,
            bool(task.input['overwrite']),
        )
        upload_refinery_capacity(TSA)
        upload_refinery_outages_weekly_updates_incl_economic(
                TSA, 
                bool(task.input['overwrite'])
        )

@api.task(domain='crude', inputs=(
    io.number('overwrite', required=True),
))
def get_refinery_outages_daily(task):
    with task.capturelogs(std=True):
        upload_refinery_outages_daily(
            TSA,
            bool(task.input['overwrite']),
        )
        upload_refinery_outages_daily_incl_economic(
                TSA, 
                bool(task.input['overwrite'])
        )

if __name__ =="__main__":
    print(f"Inside {__file__}")
    print(f"{TSA=}")
