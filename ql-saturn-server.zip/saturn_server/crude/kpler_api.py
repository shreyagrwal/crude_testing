import os
from datetime import date
from kpler.sdk import Platform
from kpler.sdk.configuration import Configuration
from kpler.sdk.resources.inventories import Inventories
from kpler.sdk.resources.fleet_metrics import FleetMetrics
from kpler.sdk import InventoriesSplit, FleetMetricsAlgo, FleetMetricsSplit, FleetMetricsPeriod, FleetMetricsMeasurementUnit
from saturn_server import TSA, HERE
from dotenv import load_dotenv
import pandas as pd
from tshistory.api import timeseries

load_dotenv()

def get_ara_daily_inventory(tsa):
    config = Configuration(
        Platform.Liquids, 
        os.environ.get("KPLER_EMAIL"), 
        os.environ.get("KPLER_PASSWORD")
    )
    inventories_client = Inventories(config)
    inventories = inventories_client.get(
        start_date=date(2020,10,1),
        end_date=pd.Timestamp.now(),
        zones=["Belgium", "Netherlands"],
        split=InventoriesSplit.ByTankType
    )
    inventory = inventories.set_index('Date')[['Commercial', 'Refinery']].astype(float).sum(axis=1) / 1000
    tsa.update(
        'crude.kpler.ara.ending_stocks.mb.daily',
        inventory,
        author='uploader'
    )

def get_regional_inventory(tsa):
    """API call to kpler pulling inventory data
    Regions driven by csv in data folder
    Some regions are split by commericial and refinery hence the need for separate global function
    """
    data = pd.read_csv(HERE / 'crude' / 'data' / 'regional_inventory.csv')
    config = Configuration(
        Platform.Liquids, 
        os.environ.get("KPLER_EMAIL"), 
        os.environ.get("KPLER_PASSWORD")
    )
    inventories_client = Inventories(config)
    for name, region in data.values:
        print(f'getting data for {name}')
        inventories = inventories_client.get(
            start_date=date(2017,1,1),
            end_date=pd.Timestamp.now(),
            zones=[region],
            split=InventoriesSplit.ByTankType
        )
        commercial = inventories.set_index('Date')[['Commercial', 'Refinery']].astype(float).sum(axis=1) / 1000
        meta = {
            'source':'kpler',
            'category':'commercial & refinery stocks',
            'location':name,
            }
        series_name = f'crude.kpler.{name}.commercial_stocks.mb.daily'
        tsa.update(
            series_name,
            commercial,
            author='uploader'
        )
        tsa.update_metadata(series_name,meta)
    return print(f'{len(data)} series uploaded')


def get_global_daily_inventory(tsa):
    """API call to kpler pulling inventory data
    Regions driven by csv in data folder
    Some regions are grouping commericial and refinery hence the need for separate global function
    """
    data = pd.read_csv(HERE / 'crude' / 'data' / 'global_inventory.csv')
    config = Configuration(
        Platform.Liquids, 
        os.environ.get("KPLER_EMAIL"), 
        os.environ.get("KPLER_PASSWORD")
    )
    inventories_client = Inventories(config)
    for name, region in data.values:
        print(f'getting data for {name}')
        inventories = inventories_client.get(
            start_date=date(2017,1,1),
            end_date=pd.Timestamp.now(),
            zones=[region],
            split=InventoriesSplit.ByTankType
        )
        commercial = inventories.set_index('Date')['commercial and refinery'].astype(float) / 1000
        strategic = inventories.set_index('Date')['SPR'].astype(float) / 1000
        name_commercial = f'crude.kpler.{name}.commercial_stocks.mb.daily'
        tsa.update(
            name_commercial,
            commercial,
            author='uploader'
        )
        meta = {
            'source':'kpler',
            'category':'commercial & refinery stocks',
            'location':name,
            }
        tsa.update_metadata(name_commercial,meta)
        name_spr = f'crude.kpler.{name}.strategic_stocks.mb.daily'
        tsa.update(
            name_spr,
            strategic,
            author='uploader'
        )
        meta = {
            'source':'kpler',
            'category':'strategic stocks',
            'location':name,
            }
        tsa.update_metadata(name_spr,meta)
    return print(f'{len(data)} series uploaded')

def get_oil_on_water(tsa):
    config = Configuration(
        Platform.Liquids, 
        os.environ.get("KPLER_EMAIL"), 
        os.environ.get("KPLER_PASSWORD")
    )
    fleet_metrics_client = FleetMetrics(config)
    oow = fleet_metrics_client.get(
        metric=FleetMetricsAlgo.LoadedVessels,
        unit=FleetMetricsMeasurementUnit.BBL,
        period=FleetMetricsPeriod.Daily,
        split=FleetMetricsSplit.Total,
        products=['Crude/Co']
    ).set_index('Date')    
    tsa.update(
        'crude.kpler.world.oil_on_water.mb.daily', 
        oow['Total']/1000, 
        'uploader'
    )

def get_fs(tsa):
    config = Configuration(
        Platform.Liquids, 
        os.environ.get("KPLER_EMAIL"), 
        os.environ.get("KPLER_PASSWORD")
    )
    fleet_metrics_client = FleetMetrics(config)
    fs = fleet_metrics_client.get(
        metric=FleetMetricsAlgo.FloatingStorage,
        unit=FleetMetricsMeasurementUnit.BBL,
        period=FleetMetricsPeriod.Daily,
        split=FleetMetricsSplit.Total,
        floating_storage_duration_min='7',
        floating_storage_duration_max='inf',
        products=['Crude/Co']
    ).set_index('Date')
    tsa.update(
        'crude.kpler.world.floating_storage.mb.daily', 
        fs['Total']/1000000, 
        'uploader'
    )

if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    get_regional_inventory(tsa)
    get_global_daily_inventory(tsa)
    get_ara_daily_inventory(tsa)
    get_oil_on_water(tsa)
    get_fs(tsa)
