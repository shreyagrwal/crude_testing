import requests
import pandas as pd
import urllib3
from BlueOcean import DataAccessApi
from pandas import DataFrame

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

OECD_EU_COUNTRIES = [
        'Austria',
        'Belgium',
        'Denmark',
        'Finland',
        'France',
        'Germany',
        'Greece',
        'Ireland',
        'Italy',
        'Netherlands',
        'Norway',
        'Portugal',
        'Spain',
        'Sweden',
        'United Kingdom',
        'Turkey',
        'Czech Republic',
        'Hungary',
        'Poland',
        'Slovakia',
        'Switzerland'
    ]

all_countries = [
        'CHINA',
        'UNITED ARAB EMIRATES',
        'GABON',
        'IRELAND',
        'TANZANIA',
        'EGYPT',
        'JORDAN',
        'ARGENTINA',
        'CROATIA',
        'SYRIA',
        'SRI LANKA',
        'PAPUA NEW GUINEA',
        'SPAIN',
        'CAMBODIA',
        'NIGERIA',
        'UKRAINE',
        'GHANA',
        'MONGOLIA',
        'AFGHANISTAN',
        'DENMARK',
        'UNITED KINGDOM',
        'QATAR',
        'BAHAMAS',
        'IRAN',
        'POLAND',
        'TUNISIA',
        'MOROCCO',
        'NORWAY',
        'COSTA RICA',
        'URUGUAY',
        'JAPAN',
        'SERBIA',
        'BOSNIA-HERZEGOVINA',
        'OMAN',
        'FINLAND',
        'NEW ZEALAND',
        'CANADA',
        'PARAGUAY',
        'MACEDONIA',
        'LIBYA',
        'YEMEN',
        'EL SALVADOR',
        'ESTONIA',
        'AUSTRIA',
        'ZAMBIA',
        'NAMIBIA',
        'SWITZERLAND',
        'SWEDEN',
        'MOZAMBIQUE',
        'CHILE',
        'TURKMENISTAN',
        'BELARUS',
        'ALBANIA',
        'BRAZIL',
        'SOUTH AFRICA',
        'CZECH REPUBLIC',
        'AZERBAIJAN',
        'MARTINIQUE',
        'ZIMBABWE',
        'LATVIA',
        'VENEZUELA',
        'SINGAPORE',
        'SLOVAKIA',
        'COLOMBIA',
        'PAKISTAN',
        'FRANCE',
        'UZBEKISTAN',
        'ALGERIA',
        'GREECE',
        'DJIBOUTI',
        'NIGER',
        'MALAYSIA',
        'INDIA',
        'BRUNEI',
        'U.S.A.',
        'ECUADOR',
        'SAUDI ARABIA',
        'LITHUANIA',
        'KAZAKHSTAN',
        'GUYANA',
        'MEXICO',
        'UGANDA',
        'ARUBA',
        'EQUATORIAL GUINEA',
        'NETHERLANDS ANTILLES',
        'ITALY',
        'LIBERIA',
        'KUWAIT',
        'PHILIPPINES',
        'NETHERLANDS',
        'DOMINICAN REPUBLIC',
        'BAHRAIN',
        'ISRAEL',
        'KENYA',
        'VIETNAM',
        'IRAQ',
        'PERU',
        'RUSSIA',
        'GEORGIA',
        'BANGLADESH',
        'SENEGAL',
        'JAMAICA',
        'LAOS',
        'AUSTRALIA',
        'TRINIDAD AND TOBAGO',
        'TAJIKISTAN',
        'NICARAGUA',
        'ANGOLA',
        'BULGARIA',
        'CUBA',
        'ROMANIA',
        'CONGO',
        'PORTUGAL',
        'GERMANY',
        'SUDAN',
        'CAMEROON',
        'TURKEY',
        'THAILAND',
        'INDONESIA',
        'HUNGARY',
        'BOLIVIA',
        'BELGIUM'
    ]

def bo_get_data(query):
    data = DataAccessApi.GetDataframe(query)
    return data


OUTAGES = {
    'Total': "'Planned','Unplanned'",
    'Planned': "'Planned'",
    'Unplanned': "'Unplanned'",
}


def enum_keys(key: int) -> tuple:
    query = f"""
            select {key}
            from hive_metastore.dataengineering.oil_refinery_plant where isActive = true
            group by {key}
            """
    value = bo_get_data(query).iloc[:, 0].to_list()
    return tuple(value)


def make_query(
        key: str = 'COUNTRY',
        value: tuple = None,
        unit_type: str = 'CDU',
        outage_type: str = 'Total',
        exclude_cause: tuple = None,
        pdate: pd.Timestamp = pd.Timestamp.utcnow()) -> str:
    # Make sure value is proper for injecting in the SQL statement
    if value is None:
        value = enum_keys(key)
    elif len(value) == 1:
        value = f"('{value[0].lower()}')"
    if isinstance(value, list):
        value = list(map(lambda x: x.lower(), value))
        value = tuple(value)
    # Make sure exclude cause is proper for injecting in the SQL statement
    if not exclude_cause:
        exclude_cause = tuple()
    if len(exclude_cause) == 1:
        exclude_cause = f"('{exclude_cause[0]}')"
    if isinstance(exclude_cause, list):
        exclude_cause = tuple(exclude_cause)
    cause = f"and (E_CAUSE not in {exclude_cause} or E_CAUSE is NULL)" if exclude_cause else ""
    query = f"""
            SELECT t.EVENT_ID, t.UNIT_NAME, t.UNIT_ID, t.PLANT_ID, t.PLANT_NAME, t.COUNTRY, 
            case when CAP_OFFLINE is null then 0 else CAP_OFFLINE end as CAP_OFFLINE
                  ,StartDate, EndDate, EVENT_TYPE, START_DATE, END_DATE, Capacity, manual_override, MaxDate
              FROM hive_metastore.dataengineering.oil_refinery_outage_all t
              inner join (
                  SELECT max(PublishedDate) as MaxDate, EVENT_ID, tu.UNIT_ID, tp.COUNTRY,
                  case 
                  when E_STATUS = 'ManualOverride' then 1. 
                  else 0.
                  end manual_override
                  FROM hive_metastore.dataengineering.oil_refinery_outage_all t
                  inner join (
                        select PLANT_ID, PLANT_NAME, COUNTRY
                        from hive_metastore.dataengineering.oil_refinery_plant
                        where lower({key}) in {value} AND isActive = true
                  ) tp on t.PLANT_ID = tp.PLANT_ID
                  inner join (
                        select UNIT_ID
                        from hive_metastore.dataengineering.oil_refinery_unit_view
                        where UNIT_GROUP in ('{unit_type}')
                  ) tu on t.UNIT_ID = tu.UNIT_ID
                  where PublishedDate <= '{pdate:%Y-%m-%d}'
                                    group by EVENT_ID, tu.UNIT_ID, tp.COUNTRY, E_STATUS
              ) tm on tm.EVENT_ID = t.EVENT_ID and t.UNIT_ID = tm.UNIT_ID and t.PublishedDate = tm.MaxDate
              right join(
                select uv.Unit_ID, case when tcapa.StartDate is null and uv.U_STATUS = 'Operational' then '2000-01-01' else tcapa.StartDate end as StartDate, case when tcapa.EndDate is null and uv.U_STATUS = 'Operational' then '9998-12-31' else tcapa.EndDate end as EndDate, case when tcapamax.Capacity is null then uv.U_CAPACITY else tcapamax.Capacity end as Capacity
                from hive_metastore.dataengineering.oil_refinery_unit_view uv -- we will use the full unit list instead of unit list from oil_refinery_unit_capacity_override
                    LEFT JOIN
                    hive_metastore.dataengineering.oil_refinery_unit_capacity_override tcapa on uv.UNIT_ID = tcapa.UNIT_ID
                    left join( -- changed to left join
                        select max(Pdate) as maxDate, StartDate, EndDate, Unit_ID, max(Capacity) as Capacity
                        from hive_metastore.dataengineering.oil_refinery_unit_capacity_override
                        group by Unit_ID, StartDate, EndDate
                    ) tcapamax on tcapa.PDate = tcapamax.maxDate 
                    and tcapa.Unit_ID = tcapamax.Unit_ID 
                    and tcapa.StartDate = tcapamax.StartDate 
                    and tcapa.EndDate = tcapamax.EndDate
                    AND tcapa.isActive = true
              ) tbounds on t.UNIT_ID = tbounds.Unit_ID 
              where EVENT_TYPE in ({OUTAGES[outage_type]}) and E_STATUS not in ('Cancelled', 'ManualCancel', 'ManualInactive') {cause}
              ORDER BY t.UNIT_ID, MaxDate
            """
    return query

def get_refinery_table_capacity(key='COUNTRY', value: list = None,
                       unit_type='CDU', outage_type='Total', exclude_cause=None, pdate=pd.Timestamp.utcnow(), verbose=False) -> DataFrame:
    query = make_query(key, value, unit_type,
                       outage_type, exclude_cause, pdate)
    if verbose:
        print(query)
    raw = bo_get_data(query)
    internals = ['manual_override', 'MaxDate']
    return (raw
            .groupby(['UNIT_ID', 'StartDate', 'EndDate']).first()
            .reset_index()
            .drop(internals, axis=1)
    )

def get_refinery_table_outages(key='COUNTRY', value: list = None,
                       unit_type='CDU', outage_type='Total', exclude_cause=None, pdate=pd.Timestamp.utcnow(), verbose=False) -> DataFrame:
    query = make_query(key, value, unit_type,
                       outage_type, exclude_cause, pdate)
    if verbose:
        print(query)
    raw = bo_get_data(query)
    internals = ['manual_override', 'MaxDate']
    groups = ['EVENT_ID', 'manual_override', 'MaxDate']
    return (raw
            .sort_values(groups, ascending=[False] * 3)
            .groupby('EVENT_ID')
            .first()
            .reset_index()
            .drop(internals, axis=1)
    )


def _generate_ids(data):
    plants = data.sort_values('START_DATE').groupby(
        'PLANT_ID')['PLANT_NAME'].first().to_dict()
    units = data.sort_values('START_DATE').groupby(
        'UNIT_ID')['UNIT_NAME'].first().to_dict()
    return plants, units


def _generate_date_range(data, fieldstart, fieldend, maxdate=pd.Timestamp.now()):
    try:
        _max = pd.to_datetime(data[fieldend].max())
    except:
        _max = maxdate
    _min = pd.to_datetime(data[fieldstart].min())
    return pd.date_range(_min, _max, freq='D')


def flatten_refinery_outage(data):
    plants, units = _generate_ids(data)
    index = _generate_date_range(data, 'START_DATE', 'END_DATE')
    data['DATE'] = data.apply(lambda x: pd.date_range(
        x['START_DATE'], x['END_DATE'], freq='D'), axis=1)
    pivoted = (
        data
        .explode('DATE')
        .groupby(
            ['COUNTRY', 'PLANT_ID', 'UNIT_ID', 'DATE'],
        )['CAP_OFFLINE'].max()
    )

    cols = pivoted.index.names[:-1]
    result = (
        pivoted
        .unstack(cols)
        .reindex(index)
        .fillna(0)
    )
    proper_names = [(c, plants[x], units[y]) for c, x, y in result.columns]
    result.columns = pd.MultiIndex.from_tuples(
        proper_names, names= ['COUNTRY', 'PLANT_NAME', 'UNIT_NAME'])
    return result


def flatten_refinery_capacity(data, maxdate=pd.Timestamp.now()):
    plants, units = _generate_ids(data)
    index = _generate_date_range(data, 'StartDate', 'EndDate', maxdate)
    units_life = data.groupby(['COUNTRY','PLANT_ID', 'UNIT_ID', 'StartDate', 'EndDate']).last()

    def define_range(data):
        try:
            __max = pd.to_datetime(data.name[-1])
        except:
            __max = index[-1]
        return pd.date_range(data.name[-2], __max, freq='D')
    units_life['RANGE'] = units_life.apply(lambda x: define_range(x), axis=1)
    pivoted = (
        units_life
        .explode('RANGE')
        .sort_index(axis=0, level=2)
        .groupby(
            ['COUNTRY','PLANT_ID', 'UNIT_ID', 'RANGE'],
        )['Capacity'].last()
    )

    cols = pivoted.index.names[:-1]
    ids = [i for i, _ in enumerate(cols)]
    result = (
        pivoted
        .unstack(ids)
        .reindex(index)
        .fillna(0)
    )
    proper_names = [(c, plants[x], units[y]) for c, x, y in result.columns]
    result.columns = pd.MultiIndex.from_tuples(
        proper_names, names= ['COUNTRY', 'PLANT_NAME', 'UNIT_NAME'])
    return result


class RefineryData():
    def get_outage(self,
                   key: str,
                   values: list,
                   unit_type,
                   outage_type=None,
                   exclude_cause=None,
                   pdate=None,
                   verbose=False):
        """
        Get refining outages
        """
        table = get_refinery_table_outages(
            key,
            values,
            unit_type,
            outage_type or 'Total',
            exclude_cause,
            pdate or pd.Timestamp.utcnow(),
            verbose,
        )
        return flatten_refinery_outage(table) / 1e3

    def get_capacity(self,
                     key: str,
                     values: list,
                     unit_type,
                     pdate=None,
                     max_date=pd.Timestamp('2030-1-1'),
                     verbose=False) -> DataFrame:
        """
        Get refining capacity
        """
        table = get_refinery_table_capacity(
            key,
            values,
            unit_type,
            'Total',
            None,
            pdate or pd.Timestamp.utcnow(),
            verbose,
        )
        return flatten_refinery_capacity(table, max_date) / 1e3

def _test_df(data, country, refinery, unit, date, value):
    test = (data.xs((country, refinery, unit), axis=1).loc[date][0] == value)
    if test:
        print(f"{refinery}, {unit}, {date}, {value} kb/d passed")
    return test



