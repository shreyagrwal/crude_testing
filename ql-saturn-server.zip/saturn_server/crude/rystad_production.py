import pandas as pd
from tshistory.api import timeseries
from BlueOcean import DataAccessApi

def get_data():
    query = f"""
        select * from fundamental.production.rystad_oil_production
        where isactive = true
        order by pdate desc
    """
    df = DataAccessApi.GetDataframe(query=query)
    df['DDate'] = pd.to_datetime(df['DDate'])
    return clean_names(df)

def clean_names(df):
    df['Country'] = df['Country'].replace("Cote_dIvoire", 'ivory_coast', regex=True)
    df['Country'] = df['Country'].replace("Timor_Leste", 'timor_leste', regex=True)
    df['Country'] = df['Country'].replace("Democratic_Republic_of_Congo", 'drc', regex=True)
    df['Country'] = df['Country'].replace("Malaysia_Thailand_JDA", 'malaysia_thailand_jda', regex=True)
    df['Country'] = df['Country'].str.lower()
    df['Crude_Grade'] = df['Crude_Grade'].str.lower()
    df['Crude_Grade'] = df['Crude_Grade'].replace(' ', '_', regex=True)
    df['EIA_PADD_District'] = df['EIA_PADD_District'].str.lower()
    return df

def loop_and_upload(tsa):

    df = get_data()
    df_country = df[df['API_Group']!='Non-Crude Liquids'].groupby(['DDate','Country'], as_index=False)['Production'].sum()
    df_country.set_index('DDate', inplace=True)
    print(df_country)

    country_list = df_country[df_country.columns[0]].unique()
    for c in country_list:
        name = f'crude.rystad.{c}.production.kbd.monthly'
        country_df = df_country[df_country[df_country.columns[0]]==c]
        country_production = country_df['Production']
        #print(country_production.head())
        tsa.update(name, country_production, 'Behzad')
    print(f'{len(country_list)} series uploaded')

def loop_and_upload_us(tsa):
    
    df = get_data()
    df_padd = df[(df['API_Group']!='Non-Crude Liquids')&(df['Country']=='united_states')].groupby(['DDate','EIA_PADD_District'], as_index=False)['Production'].sum()
    df_padd.set_index('DDate', inplace=True)

    padd_list = df_padd[df_padd.columns[0]].unique()
    for p in padd_list:
        name = f'crude.rystad.{p}.production.kbd.monthly'
        padd_df = df_padd[df_padd[df_padd.columns[0]]==p]
        padd_production = padd_df['Production']
        #print(name, padd_production.head())
        tsa.update(name, padd_production, 'Behzad')
    print(f'{len(padd_list)} series uploaded')

def loop_and_upload_grades(tsa):

    df = get_data()
    df_grade = df[df['API_Group']!='Non-Crude Liquids'].groupby(['DDate','Crude_Grade'], as_index=False)['Production'].sum()
    df_grade.set_index('DDate', inplace=True)

    #grade_list = df_grade[df_grade.columns[0]].unique()
    grade_list = ['kirkuk', 'cpc_blend', 'doba_blend']
    for g in grade_list:
        name = f'crude.rystad.{g}.production.kbd.monthly'
        grade_df = df_grade[df_grade[df_grade.columns[0]]==g]
        grade_production = grade_df['Production']
        #print(name, grade_production.head())
        tsa.update(name, grade_production, 'Behzad')

    print(f'{len(grade_list)} monthly grades uploaded')

    for g in grade_list:
        name = f'crude.rystad.{g}.production.kbd.daily'
        gg_df = df_grade[df_grade['Crude_Grade']==g].copy()
        gg_production = gg_df['Production'].resample('D').asfreq().fillna(method='ffill')
        #print(name, gg_production.head())
        tsa.update(name, gg_production, 'Behzad')
    
    print(f'{len(grade_list)} daily grades uploaded')


if __name__ == '__main__':

    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')

    #loop_and_upload(tsa)
    #loop_and_upload_us(tsa)
    #loop_and_upload_grades(tsa)