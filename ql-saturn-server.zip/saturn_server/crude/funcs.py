import pandas as pd
from typing import Optional, List
from datetime import datetime as dt
from tshistory_formula.registry import func
from saturn_server.crude.refinery import RefineryData

refinery_data = RefineryData()

@func('daily_outage')
def daily_outage(
        countries: str,
        unit_type: Optional[str] = 'CDU',
        outage_type: Optional[str] = 'Total') -> pd.Series:
    """
    Connector to central databases for country-level daily outages, based on the IIR data from ADI.

    * `country` provide the country name in full, as reported in the IIR data.

    * `unit_type` Unit group such as CDU, HCK, FCC, as reported in the IIR data

    * `outage_type` either planned or unplanned. if it is left blank, then it will take total outages.

    example: (daily_outage 'France' 'CDU')   
    """
    return refinery_data.get_outage('COUNTRY', [countries], unit_type, outage_type=outage_type).sum(axis=1)

@func('daily_available_capacity')
def daily_available_capacity(
        countries: str,
        unit_type: Optional[str] = 'CDU',
        outage_type: Optional[str] = 'Total') -> pd.Series:
    """
    Connector to central databases for refinery-level daily available capacity, based on the IIR data from BO.
    """
    capacity = refinery_data.get_capacity('COUNTRY', [countries], unit_type)
    outages = refinery_data.get_outage('COUNTRY', [countries], unit_type, outage_type=outage_type)
    return (capacity - outages.reindex(capacity.index).fillna(0)).sum(axis=1)

@func('daily_outage_by_refinery')
def daily_outage_by_refinery(
        refinery: str,
        unit_type: Optional[str] = 'CDU',
        outage_type: Optional[str] = 'Total') -> pd.Series:
    """
    Connector to central databases for refinery-level daily outages, based on the IIR data from ADI.

    * `refinery` provide the refinery name in full, as reported in the IIR data.

    * `unit_type` Unit group such as CDU, HCK, FCC, as reported in the IIR data

    * `outage_type` either planned or unplanned. if it is left blank, then it will take total outages.

    example: (daily_outage_by_refinery 'Feyzin Refinery' 'CDU')   
    """
    return refinery_data.get_outage('PLANT_NAME', [refinery], unit_type, outage_type=outage_type).sum(axis=1)

@func('daily_available_capacity_by_refinery')
def daily_available_capacity_by_refinery(
        refinery: str,
        unit_type: Optional[str] = 'CDU',
        outage_type: Optional[str] = 'Total') -> pd.Series:
    """
    Connector to central databases for refinery-level daily outages, based on the IIR data from ADI.

    * `refinery` provide the refinery name in full, as reported in the IIR data.

    * `unit_type` Unit group such as CDU, HCK, FCC, as reported in the IIR data

    * `outage_type` either planned or unplanned. if it is left blank, then it will take total outages.

    example: (daily_available_capacity_by_refinery 'Feyzin Refinery' 'CDU')   
    """
    capacity = refinery_data.get_capacity('PLANT_NAME', [refinery], unit_type)
    outages = refinery_data.get_outage('PLANT_NAME', [refinery], unit_type, outage_type=outage_type)
    return (capacity - outages.reindex(capacity.index).fillna(0)).sum(axis=1)
