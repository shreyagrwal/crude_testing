import pandas as pd
from tshistory.api import timeseries
from saturn_server.helpers import lowercase, safe_update
from saturn_server import HERE
# try:
#     from refinery.refinery_bo import RefineryData
# except ImportError:
#     from saturn_server.crude.refinery import RefineryData
from saturn_server.crude.refinery_bo import RefineryData
from saturn_server.crude.refinery_bo import OECD_EU_COUNTRIES, all_countries
from saturn_server.safe_metadata_update import safely_update_metadata

refinery_data = RefineryData()

ORDER = ['product', 'source', 'zone_value',
         'unit_group', 'economic_property', 'unit', 'frequency']


def get_latest_insertion_date(tsa, series_id):
    if not tsa.exists(series_id):
        return None
    else:
        return pd.Timestamp(tsa.insertion_dates(series_id)[-1]).floor('D')

def get_insertion_date_range_weekly_updates():
    end = pd.Timestamp.utcnow().floor('D')
    date_range = pd.date_range(end=end, freq='W-FRI', periods=3)
    return date_range

def get_insertion_date_range_daily_updates():
    end = pd.Timestamp.utcnow().floor('D')
    date_range = pd.date_range(end=end, freq='D', periods=40)
    return date_range

def upload_refinery_capacity(tsa):
    metadata = pd.read_csv(HERE / 'crude' / 'data' / 'capacity.csv')
    metadata['series_id'] = metadata.apply(
        lambda df: '.'.join([lowercase(df[s]) for s in ORDER]), axis=1)
    groups = metadata.groupby(
        ['zone_type', 'unit_group'])
    for (zone_type, unit_group), data in groups:
        zone_values = data.zone_value.tolist()
        capacities = refinery_data.get_capacity(
                zone_type,
                zone_values,
                unit_group,
        )
        capacities = capacities.groupby(axis=1, level=zone_type).sum()
        capacities.columns = capacities.columns.str.upper()
        for zone_value, _data in data.groupby('zone_value'):
            series = capacities.get(zone_value.upper()) if zone_value.upper() in capacities.columns else pd.Series(0, index=capacities.index)
            print(_data['series_id'].iloc[0])
            safe_update(
                tsa,
                _data['series_id'].iloc[0],
                series,
                insertion_date=pd.Timestamp('2000-1-1')
            )
            #safely_update_metadata(tsa, _data['series_id'].iloc[0], _data.to_dict('records')[0])
            temp_metadata = _data.to_dict('records')[0]
            temp_metadata['hs_is_safe_update'] = 1
            temp_metadata['hs_data_ingestion_frequency'] = 31
            safely_update_metadata(tsa, _data['series_id'].iloc[0], temp_metadata)

            formula = f'(resample (series "{_data["""series_id"""].iloc[0]}") "MS")'
            name = _data['series_id'].iloc[0].replace('daily', 'monthly')
            tsa.register_formula(name, formula)


def upload_refinery_outages_daily(tsa, overwrite):
    metadata = pd.read_csv(HERE / 'crude' / 'data' / 'outages_daily.csv')
    metadata['series_id'] = metadata.apply(
        lambda df: '.'.join([lowercase(df[s]) for s in ORDER]), axis=1)
    groups = metadata.groupby(
        ['zone_type', 'group', 'unit_group', 'outage_type'])
    for (zone_type, _, unit_group, outage_type), data in groups:
        zone_values = data.zone_value.tolist()
        if overwrite:
            for series_id in data.series_id.to_list():
                tsa.delete(series_id)
        for count, date in enumerate(get_insertion_date_range_daily_updates()):
            outages = refinery_data.get_outage(
                zone_type,
                zone_values,
                unit_group,
                outage_type,
                ['Economic'],
                date,
            )
            outages = outages.groupby(axis=1, level=zone_type).sum()
            outages.columns = outages.columns.str.upper()
            for zone_value, _data in data.groupby('zone_value'):
                series = outages.get(zone_value.upper()) if zone_value.upper() in outages.columns else pd.Series(0, index=outages.index)
                insertion_date = pd.Timestamp("2010-1-1") if count == 0  and overwrite else date.tz_localize(None)
                safe_update(
                    tsa,
                    _data['series_id'].iloc[0],
                    series,
                    insertion_date=insertion_date
                )
                #safely_update_metadata(tsa, _data['series_id'].iloc[0], _data.to_dict('records')[0])
                temp_metadata = _data.to_dict('records')[0]
                temp_metadata['hs_is_safe_update'] = 1
                temp_metadata['hs_data_ingestion_frequency'] = 7
                safely_update_metadata(tsa, _data['series_id'].iloc[0], temp_metadata)

                formula = f'(resample (series "{_data["""series_id"""].iloc[0]}") "MS")'
                name = _data['series_id'].iloc[0].replace('daily', 'monthly')
                tsa.register_formula(name, formula)

def upload_refinery_outages_daily_incl_economic(tsa, overwrite):
    metadata = pd.read_csv(HERE / 'crude' / 'data' / 'outages_daily.csv')
    metadata['series_id'] = metadata.apply(
        lambda df: '.'.join([lowercase(df[s]) for s in ORDER]), axis=1)
    groups = metadata.groupby(
        ['zone_type', 'group', 'unit_group', 'outage_type'])
    for (zone_type, _, unit_group, outage_type), data in groups:
        zone_values = data.zone_value.tolist()
        if overwrite:
            for series_id in data.series_id.to_list():
                tsa.delete(series_id)
        for count, date in enumerate(get_insertion_date_range_daily_updates()):
            outages = refinery_data.get_outage(
                zone_type,
                zone_values,
                unit_group,
                outage_type,
                ['none'],
                date,
            )
            outages = outages.groupby(axis=1, level=zone_type).sum()
            outages.columns = outages.columns.str.upper()
            for zone_value, _data in data.groupby('zone_value'):
                series_name =  _data['series_id'].iloc[0].replace("total_outage", "total_outage_plus_economic")
                series = outages.get(zone_value.upper()) if zone_value.upper() in outages.columns else pd.Series(0, index=outages.index)
                insertion_date = pd.Timestamp("2010-1-1") if count == 0  and overwrite else date.tz_localize(None)
                print(series_name)
                safe_update(
                    tsa,
                    series_name,
                    series,
                    insertion_date=insertion_date
                )
                print(series_name)
                #safely_update_metadata(tsa, series_name, _data.to_dict('records')[0])
                temp_metadata = _data.to_dict('records')[0]
                temp_metadata['hs_is_safe_update'] = 1
                temp_metadata['hs_data_ingestion_frequency'] = 7
                safely_update_metadata(tsa, series_name, temp_metadata)

                formula = f'(resample (series "{series_name}") "MS")'
                name = series_name.replace('daily', 'monthly')
                tsa.register_formula(name, formula)

def upload_refinery_outages_weekly_updates(tsa, overwrite):
    metadata = pd.read_csv(HERE / 'crude' / 'data' / 'outages_daily_updates_weekly.csv')
    metadata['series_id'] = metadata.apply(
        lambda df: '.'.join([lowercase(df[s]) for s in ORDER]), axis=1)
    groups = metadata.groupby(
        ['zone_type', 'group', 'unit_group', 'outage_type'])
    for (zone_type, _, unit_group, outage_type), data in groups:
        zone_values = data.zone_value.tolist()
        if overwrite:
            for series_id in data.series_id.to_list():
                tsa.delete(series_id)
        for count, date in enumerate(get_insertion_date_range_weekly_updates()):
            outages = refinery_data.get_outage(
                zone_type,
                zone_values,
                unit_group,
                outage_type,
                ['Economic'],
                date,
            )
            outages = outages.groupby(axis=1, level=zone_type).sum()
            outages.columns = outages.columns.str.upper()
            for zone_value, _data in data.groupby('zone_value'):
                series = outages.get(zone_value.upper()) if zone_value.upper() in outages.columns else pd.Series(0, index=outages.index)
                insertion_date = pd.Timestamp("2010-1-1") if count == 0  and overwrite else date.tz_localize(None)
                safe_update(
                    tsa,
                    _data['series_id'].iloc[0],
                    series,
                    insertion_date=insertion_date
                )
                #safely_update_metadata(tsa, _data['series_id'].iloc[0], _data.to_dict('records')[0])
                temp_metadata = _data.to_dict('records')[0]
                temp_metadata['hs_is_safe_update'] = 1
                temp_metadata['hs_data_ingestion_frequency'] = 7
                safely_update_metadata(tsa, _data['series_id'].iloc[0], temp_metadata)

                formula = f'(resample (series "{_data["""series_id"""].iloc[0]}") "MS")'
                name = _data['series_id'].iloc[0].replace('daily', 'monthly')
                tsa.register_formula(name, formula)

def upload_refinery_outages_weekly_updates_incl_economic(tsa, overwrite):
    metadata = pd.read_csv(HERE / 'crude' / 'data' / 'outages_daily_updates_weekly.csv')
    metadata['series_id'] = metadata.apply(
        lambda df: '.'.join([lowercase(df[s]) for s in ORDER]), axis=1)
    groups = metadata.groupby(
        ['zone_type', 'group', 'unit_group', 'outage_type'])
    for (zone_type, _, unit_group, outage_type), data in groups:
        zone_values = data.zone_value.tolist()
        if overwrite:
            for series_id in data.series_id.to_list():
                tsa.delete(series_id)
        for count, date in enumerate(get_insertion_date_range_weekly_updates()):
            outages = refinery_data.get_outage(
                zone_type,
                zone_values,
                unit_group,
                outage_type,
                ['none'],
                date,
            )
            outages = outages.groupby(axis=1, level=zone_type).sum()
            outages.columns = outages.columns.str.upper()
            for zone_value, _data in data.groupby('zone_value'):
                series_name =  _data['series_id'].iloc[0].replace("total_outage", "total_outage_plus_economic")
                series = outages.get(zone_value.upper()) if zone_value.upper() in outages.columns else pd.Series(0, index=outages.index)
                insertion_date = pd.Timestamp("2010-1-1") if count == 0  and overwrite else date.tz_localize(None)
                print(series_name)
                safe_update(
                    tsa,
                    series_name,
                    series,
                    insertion_date=insertion_date
                )
                print(series_name)
                #safely_update_metadata(tsa, series_name, _data.to_dict('records')[0])
                temp_metadata = _data.to_dict('records')[0]
                temp_metadata['hs_is_safe_update'] = 1
                temp_metadata['hs_data_ingestion_frequency'] = 7
                safely_update_metadata(tsa, series_name, temp_metadata)

                formula = f'(resample (series "{series_name}") "MS")'
                name = series_name.replace('daily', 'monthly')
                tsa.register_formula(name, formula)

def upload_refinery_planned_unplanned_outages(tsa):
    planned = RefineryData().get_outage('COUNTRY', OECD_EU_COUNTRIES, 'CDU', 'Planned', exclude_cause=['Economic'])
    unplanned = RefineryData().get_outage('COUNTRY', OECD_EU_COUNTRIES, 'CDU', 'Unplanned', exclude_cause=['Economic'])
    world_outages = RefineryData().get_outage('COUNTRY', all_countries, unit_type='CDU')
    planned_daily = planned.T.sum()
    unplanned_daily = unplanned.T.sum()
    world_outage = world_outages.T.sum()
    name_planned = f'oil.petroineos.oecd_europe.planned_outage.kbd.daily'
    name_unplanned = f'oil.petroineos.oecd_europe.unplanned_outage.kbd.daily'
    name_world = f'oil.petroineos.world.total_outage.kbd.daily'
    tsa.update(name_planned, planned_daily, 'Shrey Agarwal')
    tsa.update(name_unplanned, unplanned_daily, 'Shrey Agarwal')
    tsa.update(name_world, world_outage, 'Shrey Agarwal')

    planned_fcc = RefineryData().get_outage('COUNTRY', OECD_EU_COUNTRIES, 'FCC', 'Planned', exclude_cause=['Economic'])
    unplanned_fcc = RefineryData().get_outage('COUNTRY', OECD_EU_COUNTRIES, 'FCC', 'Unplanned', exclude_cause=['Economic'])
    world_outages_fcc = RefineryData().get_outage('COUNTRY', all_countries, unit_type='FCC')
    planned_daily_fcc = planned_fcc.T.sum()
    unplanned_daily_fcc = unplanned_fcc.T.sum()
    world_outage_fcc = world_outages_fcc.T.sum()
    name_planned_fcc = f'oil.petroineos.oecd_europe.planned_outage_fcc.kbd.daily'
    name_unplanned_fcc = f'oil.petroineos.oecd_europe.unplanned_outage_fcc.kbd.daily'
    name_world_fcc = f'oil.petroineos.world.total_outage_fcc.kbd.daily'
    tsa.update(name_planned_fcc, planned_daily_fcc, 'Behzad')
    tsa.update(name_unplanned_fcc, unplanned_daily_fcc, 'Behzad')
    tsa.update(name_world_fcc, world_outage_fcc, 'Behzad')

    planned_reformer = RefineryData().get_outage('COUNTRY', OECD_EU_COUNTRIES, 'Reformer', 'Planned', exclude_cause=['Economic'])
    unplanned_reformer = RefineryData().get_outage('COUNTRY', OECD_EU_COUNTRIES, 'Reformer', 'Unplanned', exclude_cause=['Economic'])
    world_outages_reformer = RefineryData().get_outage('COUNTRY', all_countries, unit_type='Reformer')
    planned_daily_reformer = planned_reformer.T.sum()
    unplanned_daily_reformer = unplanned_reformer.T.sum()
    world_outage_reformer = world_outages_reformer.T.sum()
    name_planned_reformer = f'oil.petroineos.oecd_europe.planned_outage_reformer.kbd.daily'
    name_unplanned_reformer = f'oil.petroineos.oecd_europe.unplanned_outage_reformer.kbd.daily'
    name_world_reformer = f'oil.petroineos.world.total_outage_reformer.kbd.daily'
    tsa.update(name_planned_reformer, planned_daily_reformer, 'Behzad')
    tsa.update(name_unplanned_reformer, unplanned_daily_reformer, 'Behzad')
    tsa.update(name_world_reformer, world_outage_reformer, 'Behzad')

    planned_fcc_usa = RefineryData().get_outage('COUNTRY', ['U.S.A.'], 'FCC', 'Planned', exclude_cause=['Economic'])
    unplanned_fcc_usa = RefineryData().get_outage('COUNTRY', ['U.S.A.'], 'FCC', 'Unplanned', exclude_cause=['Economic'])
    world_outages_fcc_usa = RefineryData().get_outage('COUNTRY', all_countries, unit_type='FCC')
    planned_daily_fcc_usa = planned_fcc_usa.T.sum()
    unplanned_daily_fcc_usa = unplanned_fcc_usa.T.sum()
    world_outage_fcc_usa = world_outages_fcc_usa.T.sum()
    name_planned_fcc_usa = f'oil.petroineos.usa.planned_outage_fcc.kbd.daily'
    name_unplanned_fcc_usa = f'oil.petroineos.usa.unplanned_outage_fcc.kbd.daily'
    tsa.update(name_planned_fcc_usa, planned_daily_fcc_usa, 'Behzad')
    tsa.update(name_unplanned_fcc_usa, unplanned_daily_fcc_usa, 'Behzad')
    
    planned_reformer_usa = RefineryData().get_outage('COUNTRY', ['U.S.A.'], 'Reformer', 'Planned', exclude_cause=['Economic'])
    unplanned_reformer_usa = RefineryData().get_outage('COUNTRY', ['U.S.A.'], 'Reformer', 'Unplanned', exclude_cause=['Economic'])
    world_outages_reformer_usa = RefineryData().get_outage('COUNTRY', all_countries, unit_type='Reformer')
    planned_daily_reformer_usa = planned_reformer_usa.T.sum()
    unplanned_daily_reformer_usa = unplanned_reformer_usa.T.sum()
    world_outage_reformer_usa = world_outages_reformer_usa.T.sum()
    name_planned_reformer_usa = f'oil.petroineos.usa.planned_outage_reformer.kbd.daily'
    name_unplanned_reformer_usa = f'oil.petroineos.usa.unplanned_outage_reformer.kbd.daily'
    tsa.update(name_planned_reformer_usa, planned_daily_reformer_usa, 'Behzad')
    tsa.update(name_unplanned_reformer_usa, unplanned_daily_reformer_usa, 'Behzad')

if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    upload_refinery_capacity(tsa)
    upload_refinery_outages_weekly_updates(tsa, False)
    upload_refinery_outages_weekly_updates_incl_economic(tsa, False)
    upload_refinery_outages_daily(tsa, False)
    upload_refinery_outages_daily_incl_economic(tsa, False)
    upload_refinery_planned_unplanned_outages(tsa)
    