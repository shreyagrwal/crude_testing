

from rework.api import task
import rework.io as rio
from rework import api, io


@api.task(domain='products',inputs=())
def demo_job_blueocean_001(task):
    with task.capturelogs(std=True):
        print(f"Hello world for blueocnean_001")

@api.task(domain='products',inputs=())
def demo_job_blueocean_002(task):
    with task.capturelogs(std=True):
        print(f"Hello world for blueocnean_002")
