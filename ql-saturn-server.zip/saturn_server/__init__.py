import os
from tshistory_refinery import helper
from pathlib import Path
from tshistory.api import timeseries
#from datagenic_rest_client.datagenic import DataGenic
from ag_datagenic_rest_client import DataGenic
from dotenv import load_dotenv
load_dotenv()

HERE = Path(__file__).parent
#URI = os.environ.get('URI')
#URI = "this was the connection string" #TODO use environment variable for Postgres cn string
URI = helper.config()['db']['uri']
# if URI is not None:
#TSA = timeseries(URI)
TSA = helper.apimaker(helper.config())
UPSTREAM_SERVER = None #os.environ.get('ADISERVER')
#URL = os.environ.get('URL')
#URL = "http://TST-QDEV-AP12.petroineos.local/api"
# DG = DataGenic(
#     os.environ.get('DGREST'),
#     os.environ.get('DGSERVER'), 
#     os.environ.get('DGUSER'),
#     os.environ.get('DGPASSWORD')
# )

DG = DataGenic.create_from_environment()
# you need to replace the above call with create_from_environment
# supply the environment variables

MAX_WORKERS = int(os.environ.get('WORKERS')) if os.environ.get('WORKERS') else 4
import saturn_server.funcs
