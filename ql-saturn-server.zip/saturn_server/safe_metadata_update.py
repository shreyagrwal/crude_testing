import os
from tshistory.api import timeseries

def safely_update_metadata(tsa, series_name, metadata: dict):
    esixting_metadata = tsa.metadata(series_name)
    tsa.update_metadata(series_name, esixting_metadata | metadata)

if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    #safely_update_matadata(tsa,'price.argus.butane_large_cargo_ara.usd_t.daily', {'testing_tag':'true'})