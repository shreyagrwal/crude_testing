import requests
import pandas as pd

def ag_get_data_databricks(query):
    """

    :param query:
    :return:
    """
    params = {"Query": query}
    endpoint_url = r"https://blueocean-dataapi.petroineos.co.uk"
    endpoint = r"/GenericData/GetGenericData"
    resp = requests.post(f'{endpoint_url}{endpoint}', json=params, verify=False)
    if resp.status_code == 200:
        json_result = resp.json()
        json_result = pd.DataFrame.from_records(json_result)
        return json_result
    else:
        raise ValueError(f"Query failed with response {resp.status_code}. Error: {resp.reason}")

query = """
select sum(NetPosition) as NetPosition, Market, `Date` from hive_metastore.dataengineering.algotrading_bridgeton_positions
where Symbol in ('QS', 'LGF1F2') and IsActive = True
group by Market, `Date`
order by `Date` desc
"""

if __name__ == '__main__':
    data = ag_get_data_databricks(query)
    print(data.describe())
