import click

import time
from sqlalchemy import create_engine
from apscheduler.schedulers.blocking import BlockingScheduler

from datetime import datetime, timedelta
from tshistory_formula.tsio import timeseries
from saturn_server import URI
from rework import api, io
import os
import random
import pandas as pd

from BlueOcean import DataAccessApi


@click.group()
def saturn():
    pass


@saturn.command()
def webstart():
    from saturn_server.wsgi import app
    app.run(debug=True)


rule = '0 0 4,5,6,7,8 * * *'
daily_rule = '0 30 5,19 * * *'
outage_rule = '0 0 6,18 * * *'
ea_rule = '0 0 7,10 * * *'
iea_rule = '0 3,4,5,6 9 * * *'
jodi_rule = '0 3,4,5 12 * * *'
euromargins_rule = '0 31,45,59 9 * * *'

CROSS_SCHEDULE = {
    'get_bridgeton': {
        'inputdata': (),
        'domain': 'cross',
        'rule': daily_rule
    },
    'get_eia': {
        'inputdata': (),
        'domain': 'cross',
        'rule': rule
    },
    'get_jodi': {
        'inputdata': (),
        'domain': 'cross',
        'rule': daily_rule
    },
    'get_jodi_directfeed': {
        'inputdata': (),
        'domain': 'cross',
        'rule': jodi_rule
    },
    'get_iea': {
        'inputdata': (),
        'domain': 'cross',
        'rule': daily_rule
    },
    'get_iea_directfeed': {
        'inputdata': (),
        'domain': 'cross',
        'rule': iea_rule
    },
    'get_energy_aspects': {
        'inputdata': (),
        'domain': 'cross',
        'rule': ea_rule
    },
    'get_petrologistics': {
        'inputdata': (),
        'domain': 'cross',
        'rule': daily_rule
    },
    'get_rolling_prices': {
        'inputdata': {
            'start': '(shifted (today) #:months -1)',
            'end': '(today)',
        },
        'domain': 'cross',
        'rule': rule
    },
    'get_spot_prices': {
        'inputdata': {
            'start': '(shifted (today) #:months -1)',
            'end': '(today)',
        },
        'domain': 'cross',
        'rule': rule
    },
    'get_euromargins': {
        'inputdata': {
            'from': '(shifted (today) #:days -15)',
        },
        'domain': 'cross',
        'rule': euromargins_rule
    }
}

PRODUCTS_SCHEDULE = {
    'get_wind_prices':{
        'inputdata': (),
        'domain': 'products',
        'rule': daily_rule
    },
    'make_freight_matrix':{
        'inputdata': (),
        'domain': 'products',
        'rule': daily_rule
    },
    'get_dtn_demand': {
        'inputdata': (),
        'domain': 'products',
        'rule': daily_rule
    },
    'get_german_trucking': {
        'inputdata': (),
        'domain': 'products',
        'rule': daily_rule
    },
    'get_ara_stocks': {
        'inputdata': (),
        'domain': 'products',
        'rule': daily_rule
    },
    'get_jet_forecast': {
        'inputdata': (),
        'domain': 'products',
        'rule': daily_rule
    },
    'get_vortexa_flows': {
        'inputdata': (),
        'domain': 'products',
        'rule': daily_rule

    },
    'get_indeed_postings': {
        'inputdata': (),
        'domain': 'products',
        'rule': rule
    },    
    'get_ny_report': {
        'inputdata': (),
        'domain': 'products',
        'rule': rule
    },
}

CRUDE_SCHEDULE = {
    'get_kpler': {
        'inputdata': (),
        'domain': 'crude',
        'rule': daily_rule
    },
    'get_kpler_api': {
        'inputdata': (),
        'domain': 'crude',
        'rule': daily_rule
    },
    'get_refinery_outages': {
        'inputdata': {
            'overwrite': 0,
        },
        'domain': 'crude',
        'rule': outage_rule
    },
    'get_refinery_outages_daily': {
        'inputdata': {
            'overwrite': 0,
        },
        'domain': 'crude',
        'rule': outage_rule
    },
}

TASKS = {**CROSS_SCHEDULE, **PRODUCTS_SCHEDULE, **CRUDE_SCHEDULE}


@api.task(inputs=(
    io.string('condition_query_date', required=True),
    io.string('operation', required=True),
    io.number('reboot_limit'),
    io.number('time_sleep'),
), domain='timeseries'
)
def blueocean_hacky_pubsub(task):
    with task.capturelogs(std=True):
        first_time = time.time()
        last = pd.Timestamp.now(tz='utc') 
        while True:
            time_sleep = task.input.get('time_sleep') or 300 # every 5 minutes
            reboot_limit = task.input.get('reboot_limit') or 86_400 # every day
            timesleep_delay = time_sleep + random.randint(5, 13)
            if time.time() - first_time < reboot_limit:
                time.sleep(timesleep_delay) # check every 300 seconds + 25 to 13 seconds
                now = pd.Timestamp.now()
                # 7am to 5pm on business days only
                in_business_hours = (now.hour >= 8) & (now.hour <= 20) & (now.day_of_week < 5) 
                print(f"Last timestamp: {now}, are we within business hours? {in_business_hours}")
                if in_business_hours:
                    raw_date = DataAccessApi.GetDataframe(task.input['condition_query_date']).iloc[0, 0]
                    last_load_date = pd.Timestamp(raw_date, tz='utc')
                    if last_load_date > last: # Ah new data!
                        print(
                            f"""
                            New data found on blueocean at time: {last_load_date}, 
                            spawning a new task to retrieve data!
                            """
                        )
                        engine = create_engine(URI)
                        inputs = TASKS[task.input['operation']]['inputdata']
                        domain = TASKS[task.input['operation']]['domain']
                        print(engine, inputs, domain, task.input)
                        child_task = api.schedule(
                            engine=engine,
                            opname=task.input['operation'], 
                            inputdata=inputs, 
                            domain=domain
                        ) 
                        # Scraping the data in BO
                        child_task.join()
                        last = last_load_date
                        # last_load_date becomes the new date from where we compare
            else:
                # lets respawn the continuous_bo_recovery task now
                engine = create_engine(URI)
                api.schedule(engine, 'blueocean_hacky_pubsub', task.input)
                break

def vacuum(dburi,
           domain='default',
           opname=None,
           horizon=timedelta(days=7)):
    morewhere = ''
    if opname:
        morewhere = 'and op.name = %(opname)s'
    sql = (
        f'with deleted as '
        f'(delete from rework.task as t '
        f'   using rework.operation as op '
        f'   where t.status = \'done\' and '
        f'         t.finished < %(finished)s and '
        f'         op.id = t.operation and '
        f'         op.domain = %(domain)s '
        f'         {morewhere} '
        f' returning 1) '
        f'select count(*) from deleted'
    )
    finished = datetime.utcnow() - horizon
    engine = create_engine(dburi)
    with engine.begin() as cn:
        count = cn.execute(
            sql,
            finished=finished,
            domain=domain,
            opname=opname
        ).scalar()
    return count


@saturn.command('start-scheduler')
def start_scheduler():
    scheduler = BlockingScheduler()
    for domain in ['crude', 'cross', 'products']:
        scheduler.add_job(
            lambda: vacuum(URI, domain),
            trigger='cron',
            hour='*'
        )
    scheduler.start()


@saturn.command('setup-tasks')
def setup_tasks():
    from tshistory_refinery import tasks  # make them available at freeze time
    from saturn_server import tasks  # make them available at freeze time
    engine = create_engine(URI)
    with engine.begin() as cn:
        cn.execute(
            "delete from rework.operation "
            "where path like '%%saturn_server%%'"
        )
    api.freeze_operations(engine)
    TASKS = {**CROSS_SCHEDULE, **PRODUCTS_SCHEDULE, **CRUDE_SCHEDULE}
    for taskname, task in TASKS.items():
        if task.get('condition_query_date') is None:
            api.prepare(
                engine,
                taskname,
                **task,
            )
        else:
            api.schedule(
                engine, 
                'blueocean_hacky_pubsub', 
                inputdata={
                    'condition_query_date': task['condition_query_date'],
                    'operation': taskname
                    }
                )

@saturn.command(name='test-formula')
@click.argument('db-uri')
@click.argument('formula')
@click.option('--pdbshell', is_flag=True, default=False)
@click.option('--namespace', default='tsh')
def test_formula(db_uri, formula, pdbshell=False, namespace='tsh'):
    engine = create_engine(db_uri)
    tsh = timeseries(namespace)
    ts = tsh.eval_formula(engine, formula)
    print(ts)
    if pdbshell:
        import ipdb
        ipdb.set_trace()
