import json
from flask import make_response, Blueprint

from flask_restx import (
    inputs,
    Resource,
    reqparse
)

from tshistory.http.util import onerror
from tshistory.http.client import unwraperror
from tshistory_refinery.http import (
    refinery_httpapi,
    refinery_httpclient
)

from tshistory.http.util import (
    enum,
)
from tshistory import util
import pandas as pd


def frame_response(format, frame, metadata, code):
    if format == 'json':
        if frame is not None:
            response = make_response(
                frame.to_json(orient='index',
                              date_format='iso')
            )
        else:
            response = make_response('null')
        response.headers['Content-Type'] = 'text/json'
        response.status_code = code
        return response
    else:
        
        if frame is not None:
            response = make_response(
                frame.to_csv(index=False)
            )
        else:
            response = make_response('null')
        response.headers['Content-Type'] = 'text/csv'
        response.status_code = code
        return response


table = reqparse.RequestParser()
table.add_argument(
    'name',
    type=str,
    required=True,
    action='append',
    help='series name'
)

table.add_argument(
    'format', type=enum('json', 'csv'), default='csv'
)

def get(tsa, name):
    ts = tsa.get(name)
    ts.index = ts.index.tz_localize(None)
    ts = ts.rename(name)
    ts.index.name = 'date'
    return ts

def get_table(tsa, names, format):
    print(f"get_tables names={names}")
    def create_dictionay_of_metadata_from_series_name(series_name: str)->dict:
        #existing_meta_data:dict=tsa.metadata(series_name, all=True) # This is deprecated, as per advice from Aurelien
        existing_meta_data:dict=tsa.internal_metadata(series_name) #As per advice from Aurelien - this is the method to uses
        new_meta_data={'id': series_name}
        columns=['tzaware','index_type','value_type','index_dtype','value_dtype']
        #date,id,tzaware,index_type,value_type,index_dtype,value_dtype
        for column in columns:
            new_meta_data[column] = existing_meta_data[column]
        return new_meta_data
    
    metadata = pd.DataFrame(
        dict(zip(names, map(lambda x: create_dictionay_of_metadata_from_series_name(series_name=x), names))))
        
    # The following was the original code written by Loic. This was taking all meta-data (system+custom) and making a flat table out it.
    # This was problematic because the system meta-data changed after the upgrade in Jan 2024
    # metadata = pd.DataFrame(
    #     dict(zip(names, map(lambda x: {'id': x, **tsa.metadata(x, all=True)}, names))))
    cols = pd.MultiIndex.from_frame(pd.DataFrame(metadata).T)
    frame = pd.concat(
        map(lambda x: get(tsa, x), names),
        axis=1
    )
    frame.columns = cols
    frame = frame.stack(level=list(range(len(cols.names)))).reset_index()
    return frame_response(
        format,
        frame,
        metadata,
        200
    )

class saturn_httpapi(refinery_httpapi):
    #__slots__ = 'tsa', 'bp', 'api', 'nss', 'nsg'

    def routes(self):
        super().routes()

        tsa = self.tsa
        api = self.api
        nst = self.nst = self.api.namespace(
            'table',
            description='get table'            
        )

        @nst.route('/get_frame')
        class Table(Resource):

            @api.expect(table)
            @onerror
            def get(self):
                args = table.parse_args()
                try:
                    return get_table(tsa, args.name, args.format)
                except Exception as e:
                    api.abort(409, str(e))

                return '', 204


class ServerClient(refinery_httpclient):

    def __repr__(self):
        return f"saturn-http-client(uri='{self.uri}')"

    @unwraperror
    def newget(self, name):

        res = self.session.get(f'{self.uri}/table/newget', data={
            'name': name,
        })

        if res.status_code == 409:
            raise ValueError(res.json()['message'])

        if res.status_code == 204:
            return

        return res
