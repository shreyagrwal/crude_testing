import pandas as pd
from saturn_server.helpers import safe_register_formula
from BlueOcean import DataAccessApi

query = """
SELECT ddate, product, region, sumnetvolume
FROM dataengineering.oil_us_oil_product_demand_dtn_adjusted_rack_sales
where pdate = (select max(pdate) from dataengineering.oil_us_oil_product_demand_dtn_adjusted_rack_sales)
and region in ('total', '1', '2', '3', '4', '5') and isactive is true
"""

product_space = {
    'jetfuel': 'jet',
    'gasoline': 'gasoline',
    'diesel': 'diesel',
}
def get_dtn(tsa):
    data = DataAccessApi.GetDataframe(query)
    data['ddate'] = pd.to_datetime(data.ddate)
    data['series_id'] = data.apply(lambda x: f"{product_space[x['product']]}.dtn.{x['region']}.rack_sales.kbd.daily" if x['region']=='total' else f"{product_space[x['product']]}.dtn.padd_{x['region']}.rack_sales.kbd.daily", axis=1)
    data = data.set_index('ddate')
    for series_id, _data in data.groupby('series_id'):
        print(series_id)
        tsa.update(series_id, _data['sumnetvolume'], author='dtn_script')
        for number in [7, 14, 30]:
            safe_register_formula(tsa,".".join([series_id, f"{number}mav"]), f'(rolling (series "{series_id}") {number})')

if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    get_dtn(tsa)
