import requests
import pandas as pd
from itertools import product
import urllib3
from tqdm.contrib.concurrent import thread_map
from datetime import datetime as dt
import numpy as np
import difflib
from pathlib import Path

from tshistory.api import timeseries

from saturn_server import HERE
from saturn_server.helpers import safe_update
from saturn_server.cross.ag import ag_get_data


PLAYERS = pd.read_csv(
        HERE / 'products' / 'data' / 'players.csv', index_col=0)

ORIGINS = pd.read_csv(
        HERE / 'products'  / 'data' / 'origins.csv', index_col=0)

VOYAGE = pd.read_csv(
        HERE / 'products'  / 'data' / 'travel_time.csv', index_col=0)

def get_fixtures_to_europe(server):
    query = """
    SELECT [PDate] ,[Player] ,[Origin] ,[Destination] ,[Tanker_Name], [Status] ,[Size] ,[Cargo] ,[Lay] ,[Can], [Type], [TANKER_TYPE]
    FROM [OIL].[dbo].[BrsFixtures]
    """
    data = ag_get_data(server, "Oil", query)
    for col in ['Can', 'Lay', 'PDate']:
        data[col] = pd.to_datetime(data[col])
    return data

def process_group_fixture(data):
    data = data[data.Lay <= data.PDate + pd.DateOffset(days=50)]
    data['origin'] = data.Origin.apply(lambda x: ORIGINS['Origin'][difflib.get_close_matches(x, ORIGINS.index)[0]])
    data['player'] = data.Player.apply(lambda x: PLAYERS['Player'][difflib.get_close_matches(x, PLAYERS.index)[0]])
    data['voyage'] = data.apply(lambda x: (VOYAGE.loc[x['origin'], 'UKC' if not 'MED' in x['Destination'] else 'MED']), axis=1).astype(int)
    data['arrival'] = data.apply(lambda x: x['Can'] + pd.DateOffset(days=x['voyage']), axis=1)
    data = data.sort_values(['PDate','arrival'])
    data.Size = data.Size.where(data.Status != 'FLD', -data.Size)   
    groups = data.groupby(['player', 'origin', 'Lay', 'Size'], sort=False).first()
    groups = groups.reset_index('Size')
    return groups

def process_sequential_fixture(data):
    groups = process_group_fixture(data)
    cumsum_groups = groups.groupby(['PDate', 'arrival'])['Size'].sum().groupby(level=0).cumsum()
    return cumsum_groups


def upload_to_saturn(tsa, data, name):
    insertions = data.index.get_level_values(0).drop_duplicates()
    if tsa.exists(name):
        tsa.delete(name)
    for n, date in enumerate(insertions):
        series = data.xs(level=0,key=date).astype(float)
        print(f'{n + 1}/{insertions.shape[0]}, {name}')
        tsa.update(
            name,
            series,
            insertion_date=date,
            author='loicballand',
        )

def get_optimistic_table(data, product_name, cargoes_names):
    status = ('FXD', 'SUBS', 'FLD')
    types = ('CARGOES',)
    data = data[
        (data.Status.astype(str).isin(status) | ~ data.Type.astype(str).isin(types)) & 
        data.Cargo.str.contains('|'.join(cargoes_names))]
    destination_filter = data.Destination.str.contains('UKC|MED|WEST|USAC|OPT|STATES')
    data = data[destination_filter]
    return process_group_fixture(data)
    
def get_optimistic_estimate(tsa, data, product_name, cargoes_names):
    status = ('FXD', 'SUBS', 'FLD')
    types = ('CARGOES',)
    data = data[
        (data.Status.astype(str).isin(status) | ~ data.Type.astype(str).isin(types)) & 
        data.Cargo.str.contains('|'.join(cargoes_names))]
    destination_filter = data.Destination.str.contains('UKC|MED|WEST|USAC|OPT|STATES')
    data = data[destination_filter]
    _data = process_sequential_fixture(data)
    name = f'{product_name}.brs.optimistic_ag_europe_arrivals.kt.daily'
    upload_to_saturn(tsa, _data, name)

def get_conservative_table(data, product_name, cargoes_names):
    status = ('FXD',)
    data = data[data.Status.astype(str).isin(status) & data.Cargo.str.contains('|'.join(cargoes_names))]
    destination_filter = (
        data.Destination.str.contains('UKC|MED|WEST') & ~data.Destination.str.contains('-') & ~data.Destination.str.contains('OPT')
    )
    data = data[destination_filter]
    _data = process_sequential_fixture(data)
    return process_group_fixture(data)

def get_conservative_estimate(tsa, data, product_name, cargoes_names):
    status = ('FXD',)
    data = data[data.Status.astype(str).isin(status) & data.Cargo.str.contains('|'.join(cargoes_names))]
    destination_filter = (
        data.Destination.str.contains('UKC|MED|WEST') & ~data.Destination.str.contains('-') & ~data.Destination.str.contains('OPT')
    )
    data = data[destination_filter]
    _data = process_sequential_fixture(data)
    name = f'{product_name}.brs.conservative_ag_europe_arrivals.kt.daily'
    upload_to_saturn(tsa, _data, name)

def generate_tables(server):
    PATH_APPLICATION_FOLDER = Path(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department')
    PATH =  PATH_APPLICATION_FOLDER / 'OilProd' / 'BRSFixtures'
    cols = 'player,origin,Destination,arrival,Cargo,Tanker_Name,TANKER_TYPE'.split(',')
    optimistic = get_optimistic_table(get_fixtures_to_europe(server), "diesel", ('ULSD', 'GO'))
    optimistic = optimistic.groupby(cols).Size.sum()
    optimistic = optimistic[optimistic > 0]
    conservative = get_conservative_table(get_fixtures_to_europe(server), "diesel", ('ULSD', 'GO'))
    conservative = conservative.groupby(cols).Size.sum()
    conservative = conservative[conservative > 0]
    range_diff = optimistic.sub(conservative.reindex(optimistic.index).fillna(0))
    range_diff = range_diff[range_diff > 0]
    optimistic.to_csv(PATH / 'optimistic_table.csv')
    conservative.to_csv(PATH / 'conservative_table.csv')
    range_diff.to_csv(PATH / 'range_diff.csv')


if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    UPSTREAM_SERVER = 'https://TST-QDEV-AP1.petroineos.local:5001'
    get_conservative_estimate(tsa, get_fixtures_to_europe(
        UPSTREAM_SERVER), "diesel", ('ULSD', 'GO'))
    get_optimistic_estimate(tsa, get_fixtures_to_europe(
        UPSTREAM_SERVER), "diesel", ('ULSD', 'GO'))
    get_conservative_estimate(tsa, get_fixtures_to_europe(
        UPSTREAM_SERVER), "jet", ('JET',))
    get_optimistic_estimate(tsa, get_fixtures_to_europe(
        UPSTREAM_SERVER), "jet", ('JET',))
    generate_tables(UPSTREAM_SERVER)
