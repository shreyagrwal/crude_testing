import pandas as pd

LINK = 'https://www.newyorkfed.org/medialibrary/media/research/archive/OIL_oil-price-dynamics_data.xls'

def get_ny_report():
    print("Inside get_ny_report")
    print(f"Going to download from URL:{LINK}")
    data = pd.read_excel(LINK, sheet_name='3_1986-today', skiprows=18, index_col=0)
    print("After calling read_excel method")
    data.index = pd.to_datetime(data.index)
    data.columns = data.columns.str.lower()
    data = data.resample('W').mean()
    print(data)
    return data.iloc[:, 1:]

def _upload_ny_report(tsa, data):
    for x in data.columns:
        name = f'oil.ny_fed_report.{x}.usd_bbl.weekly'
        tsa.update(
            name,
            data[x],
            author='loicballand'
        )


def upload_ny_report(tsa):
    data = get_ny_report()
    _upload_ny_report(
        tsa,
        data,
    )

if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    upload_ny_report(tsa)