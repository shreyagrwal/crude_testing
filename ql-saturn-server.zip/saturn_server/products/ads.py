import pandas as pd

LINK = 'https://www.philadelphiafed.org/-/media/frbp/assets/surveys-and-data/ads/ads_index_most_current_vintage.xlsx?la=en&hash=6DF4E54DFAE3EDC347F80A80142338E7'

def get_ads_report():
    data = pd.read_excel(LINK, index_col=0, engine='openpyxl')
    data.index = pd.to_datetime(data.index, format='%Y:%m:%d')
    return data.iloc[:, -1]

def _upload_ads_report(tsa, data):
    name = 'macro.aruoba_diebold_scotti_business_conditions_index.pct.daily'
    tsa.update(
        name,
        data,
        author='loic.balland'
    )


def upload_ads_report(tsa):
    data = get_ads_report()
    _upload_ads_report(
        tsa,
        data,
    )
