import os
from tshistory_refinery import helper
from rework import api, io

from saturn_server.products.german_trucking import upload_truck_milage
from saturn_server.products.ara_genscape import upload_ara_stocks, upload_gulf_coast_status, upload_ara_daily_status
from saturn_server.products.jet_oag import upload_jet_demand_forecast,upload_jet_demand_forecast_china
from saturn_server.products.adi.clarksons import get_clarksons_adi as _get_clarksons_adi
from saturn_server.products.adi.galbraiths import galbraiths_count
from saturn_server.products.vortexa import upload_vortexa_flows

from saturn_server.products.indeed import upload_indeed_postings
from saturn_server.products.ny_fed import upload_ny_report
from saturn_server.products.ads import upload_ads_report
from saturn_server.products.dtn import get_dtn
from saturn_server.products.freight_model import make_freight_matrix as _make_freight_matrix
from saturn_server.products.wind import get_wind_prices as _get_wind_prices


@api.task(domain='products', inputs=())
def get_wind_prices(task):
    with task.capturelogs(std=True):
        tsa = helper.apimaker(helper.config())
        _get_wind_prices(
            tsa
        )

@api.task(domain='products', inputs=())
def make_freight_matrix(task):
    with task.capturelogs(std=True):
        tsa = helper.apimaker(helper.config())
        _make_freight_matrix(
            tsa
        )


@api.task(domain='products', inputs=())
def get_galbraiths_ara_count(task):
    with task.capturelogs(std=True):
        tsa = helper.apimaker(helper.config())
        galbraiths_count(tsa)


@api.task(domain='products', inputs=())
def get_dtn_demand(task):
    with task.capturelogs(std=True):
        tsa = helper.apimaker(helper.config())
        get_dtn(tsa)


@api.task(domain='products', inputs=())
def get_ads_report(task):
    with task.capturelogs(std=True):
        tsa = helper.apimaker(helper.config())
        upload_ads_report(tsa)


@api.task(domain='products', inputs=())
def get_ny_report(task):
    with task.capturelogs(std=True):
        tsa = helper.apimaker(helper.config())
        upload_ny_report(tsa)


@api.task(domain='products', inputs=())
def get_indeed_postings(task):
    with task.capturelogs(std=True):
        tsa = helper.apimaker(helper.config())
        upload_indeed_postings(tsa)


@api.task(domain='products', inputs=())
def get_vortexa_flows(task):
    with task.capturelogs(std=True):
        tsa = helper.apimaker(helper.config())
        upload_vortexa_flows(tsa)


@api.task(domain='products', inputs=())
def get_german_trucking(task):
    with task.capturelogs(std=True):
        tsa = helper.apimaker(helper.config())
        upload_truck_milage(tsa)


@api.task(domain='products', inputs=())
def get_ara_stocks(task):
    with task.capturelogs(std=True):
        tsa = helper.apimaker(helper.config())
        upload_ara_stocks(tsa)
        upload_gulf_coast_status(tsa)
        upload_ara_daily_status(tsa)


@api.task(domain='products', inputs=())
def get_jet_forecast(task):
    with task.capturelogs(std=True):
        tsa = helper.apimaker(helper.config())
        upload_jet_demand_forecast(tsa)
        upload_jet_demand_forecast_china(tsa)


@api.task(domain='products', inputs=(
    io.number('reports', required=False),
))
def get_clarksons_adi(task):
    with task.capturelogs(std=True):
        _get_clarksons_adi(
            task.input.get('reports')
        )


@api.task(domain='products',inputs=())
def demo_job_get_devops_version(task):
    with task.capturelogs(std=True):
        #An interim measure to know what version of the code is running on the Job server
        # The idea is => 
        #   Azure Devops CI/CD will stamp the file 'devopsversion.txt' with the build number
        #   This will give us immense traceability by letting us know what version of the code is runing on the job server
        file_name='devopsversion.txt'
        print(f"This job will display the contents of the '{file_name}'")
        print(f"The purpose of the file {file_name} is to give a sense of traceability by helping us identify which verseion of the source code is running on the server")
        this_folder = os.path.dirname(__file__)
        root_folder = os.path.join(this_folder,"../../")
        version_file = os.path.join(root_folder,file_name)
        with open(version_file, "r") as f:
            all_lines=f.readlines()
        if all_lines is None:
            print(f"No lines were found in the file {file_name}. Exitting")
            return
        version=all_lines[0]
        print(f"The file {file_name=} was found. {version=}")


