import pandas as pd
import numpy as np

from tshistory.api import timeseries
from saturn_server.helpers import safe_register_formula

cols = [
    'fob_singapore_50ppm.usd_bbl',
    'fob_singapore_500ppm.usd_bbl',
    'usd_cny',
    'diesel_east_china.cny_t',
    'diesel_yangtze_river_region.cny_t',
    'diesel_shangdong_refinery.cny_t',
    'diesel_waterborne_coasal_quote_chimbusco_caofeidian.cny_t',
    'diesel_hangzhou.cny_t',
]

def get_wind_prices(tsa):
    data = pd.read_excel(
    r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\Scrapers\WindFinancial\China_Diesel_Prices_EN.xlsx',
    index_col=0, 
    skiprows=2
    )
    data.index = pd.to_datetime(data.index)
    data.columns = [f'price.wind_terminal.china.{x}.daily' for x in cols]
    data = data.resample('D').mean().replace(0, np.nan)
    for x in data:
        tsa.delete
        tsa.update(
            x,
            data[x],
            author='loic balland',
        )
    return data

def build_formulas(tsa, data):
    for x in data.columns[:2]:
        print(x)
        formula = f'(* 7.45 (series "{x}"))'
        formula_name = x.replace('usd_bbl', 'usd_t')
        safe_register_formula(
            tsa,
            formula_name,
            formula,
        )
    for y in data.columns[3:]:
        print(y)
        tax_per_liter = 1.2
        liter_in_ton = 159 * 7.45
        vat_free_y = f'(/ (+ -{tax_per_liter * liter_in_ton:.3f} (series "{y}")) 1.13)'
        formula = f'(div {vat_free_y} (series "{data.columns[2]}"))'
        formula_name = y.replace('cny_t', 'usd_t')
        safe_register_formula(
            tsa,
            formula_name,
            formula,
        )
        formula_name


if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    get_wind_prices(tsa)
    # build_formulas(TSA, data)