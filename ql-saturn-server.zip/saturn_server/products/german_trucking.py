import pandas as pd

from tshistory.api import timeseries
from saturn_server.safe_metadata_update import safely_update_metadata
from BlueOcean import DataAccessApi

def get_german_truck():
    query = r"SELECT ddate,mean(seasonally_adj_values) as seasonally_adj_values FROM dataengineering.oil_mobility_germantruckmileage where isactive is true group by ddate"
    data = DataAccessApi.GetDataframe(query)
    return data

def get_german_truck_unadj():
    query = r"SELECT ddate,mean(unadjusted_values) as unadjusted_values FROM dataengineering.oil_mobility_germantruckmileage where isactive is true group by ddate"
    data = DataAccessApi.GetDataframe(query)
    return data

def upload_truck_milage(tsa: timeseries):
    metadata = {
        'series_id': 'oil.germany.truck_mileage.index.daily.seasonally_adj',
        'zone': 'germany',
        'economic_property': 'truck_mileage',
        'unit': 'index',
        'frequency': 'daily',
    }
    data = get_german_truck().set_index('ddate')
    data.index = pd.to_datetime(data.index)
    tsa.update(
        metadata['series_id'],
        data.iloc[:, -1],
        'uploader'
    )
    safely_update_metadata(tsa, metadata['series_id'], metadata)
    metadata = {
        'series_id': 'oil.germany.truck_mileage.index.daily',
        'zone': 'germany',
        'economic_property': 'truck_mileage',
        'unit': 'index',
        'frequency': 'daily',
    }
    data = get_german_truck_unadj().set_index('ddate')
    data.index = pd.to_datetime(data.index)
    tsa.update(
        metadata['series_id'],
        data.iloc[:, -1],
        'uploader'
    )
    safely_update_metadata(tsa, metadata['series_id'], metadata)

if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    upload_truck_milage(tsa)