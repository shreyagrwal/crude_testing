import pandas as pd

from tshistory.api import timeseries

from saturn_server.helpers import safe_update
from BlueOcean import DataAccessApi
from saturn_server.safe_metadata_update import safely_update_metadata

def get_eu_jet_demand(vintage_date=pd.Timestamp.now()):
    query = f"""
    select t.DDate as date, t.DemandForecast as value, t.Region as region
    FROM dataengineering.oil_jet_jetfueldemand2 as t
    inner join (
        select max(PDate) as maxDate, DDate, Region, Benchmark
        FROM dataengineering.oil_jet_jetfueldemand2
        where Benchmark = 'IEA' and Region in ('Europe : Western Europe', 'Italy', 'Germany','Spain', 'Turkey', 'Turkiye', 'United Kingdom', 'France') and PDate <= '{vintage_date.strftime('%Y-%m-%d')}'
        group by DDate, Region, Benchmark
    ) as tm on t.DDate = tm.DDate and t.Pdate = tm.maxDate and t.Region = tm.Region and t.Benchmark = tm.Benchmark
    where isactive is true
    group by t.DDate, t.DemandForecast, t.Region
    order by t.DDate 
    """
    data = DataAccessApi.GetDataframe(query)
    data['region'] = data['region'].replace('Europe : Western Europe', 'oecd_europe', regex=True).replace('United Kingdom', 'UK', regex=True).replace('Turkiye', 'Turkey', regex=True)
    data['region'] = data['region'].str.lower()
    #data.index = pd.to_datetime(data.date)
    return data

def get_china_jet_demand(vintage_date=pd.Timestamp.now()):
    query = f"""
    select t.DDate as date, t.DemandForecast as value
    FROM dataengineering.oil_jet_jetfueldemand2 as t
    inner join (
        select max(PDate) as maxDate, DDate, Region, Benchmark
        FROM dataengineering.oil_jet_jetfueldemand2
        where Benchmark = 'JODI' and Region in ('China') and PDate <= '{vintage_date.strftime('%Y-%m-%d')}'
        group by DDate, Region, Benchmark
    ) as tm on t.DDate = tm.DDate and t.Pdate = tm.maxDate and t.Region = tm.Region and t.Benchmark = tm.Benchmark
    where isactive is true
    group by t.DDate, t.DemandForecast
	order by t.DDate 
    """
    data = DataAccessApi.GetDataframe(query)
    data.index = pd.to_datetime(data.date)
    data = data.value.resample('MS').mean() 
    return data * data.index.days_in_month / 7.88

def upload_jet_demand_forecast(tsa):
    # The following countries are added as harcoded list to have a for loop to cover the vintages date logic, if one care about
    # the last date, this code can be written in a better way..
    for reg in ['france', 'turkey', 'uk', 'italy', 'oecd_europe', 'germany', 'spain']:
        metadata = {
            'series_id': f'jet.petroineos.{reg}.demand.kt.monthly',
            'product': 'jet_fuel',
            'economic_property': 'demand',
            'frequency': 'monthly',
            'region': f'{reg}',
            'unit': 'kt',
            'source': 'petroineos/oag',
            'hs_is_safe_update': 1,
            'hs_data_ingestion_frequency': 31
        }
        today = pd.Timestamp.utcnow().floor('D')
        past_insertions = tsa.insertion_dates(metadata['series_id'])
        start = today if not past_insertions else past_insertions[-1].floor('D')
        vintages = pd.date_range(start=start, end=today,
                                freq='D').tz_localize(None)
        for vintage in vintages:
            data = get_eu_jet_demand(vintage_date=vintage)
            df_tmp = data[['date','value']][data.region==reg]
            df_tmp['date'] = pd.to_datetime(df_tmp['date']).dt.tz_localize(None)
            ser = pd.Series(df_tmp['value'].values, index=df_tmp['date'])
            ser = ser[~ser.index.duplicated(keep='last')] # Removes index duplicates (mainly for Turkey)
            print(reg, ser)
            safe_update(
                tsa,
                metadata['series_id'],
                ser,
                vintage
            )
        safely_update_metadata(tsa, metadata['series_id'], metadata)

def upload_jet_demand_forecast_china(tsa):
    metadata = {
        'series_id': 'jet.petroineos.china.demand.kt.monthly',
        'product': 'jet_fuel',
        'economic_property': 'demand',
        'frequency': 'monthly',
        'country': 'china',
        'unit': 'kt',
        'source': 'petroineos/oag',
        'hs_is_safe_update': 1,
        'hs_data_ingestion_frequency': 31
    }
    today = pd.Timestamp.utcnow().floor('D')
    past_insertions = None #tsa.insertion_dates(metadata['series_id'])
    start = today - pd.DateOffset(years=1) if not past_insertions else past_insertions[-1].floor('D')
    vintages = pd.date_range(start=start, end=today,
                             freq='D').tz_localize(None)
    for vintage in vintages:
        print(vintage)
        data = get_china_jet_demand(vintage_date=vintage)
        safe_update(
            tsa,
            metadata['series_id'],
            data,
            vintage
        )
    safely_update_metadata(tsa, metadata['series_id'], metadata)
    

if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    upload_jet_demand_forecast(tsa)
    upload_jet_demand_forecast_china(tsa)
