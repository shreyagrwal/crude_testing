#from datagenic_rest_client.datagenic import DataGenic
from ag_datagenic_rest_client import DataGenic
import pandas as pd
from saturn_server import DG
from tshistory.api import timeseries
import numpy as np
from tqdm.contrib.concurrent import thread_map
import statsmodels.api as sm
from statsmodels.formula.api import ols
import statsmodels.formula.api as smf
from functools import reduce


def transformation(x): return np.log(x + 100)
def transformation_1(x): return np.exp(x) - 100


tickers = {
    'utilization': 'diesel.ara.genscape.storage_utilization.kt.weekly',
    'stocks': 'diesel.ara.genscape.ending_stocks.kt.weekly',
    'eu_stocks': 'diesel.iea.oecd_europe.ending_stocks.kt.monthly',
    'eu_stocks_forecast': 'diesel.petroineos.oecd_europe.ending_commercial_stocks.kt.monthly.forecast',
    'price': 'price.ice.ice_gasoil.usd_t.daily',
    'spreads': 'ice_gasoil_intermonth_spread.usd_t.daily',
    'skew': 'diesel.reuters.ice_gasoil.30d_skew.pct.daily',
    'iv': 'diesel.reuters.ice_gasoil.iv.pct.daily',
}


def generate_outright(base, leg_long: pd.Timestamp):
    base = f"{base}.{leg_long:%YM%m}"
    return base


def generate_spread(base, leg_long: pd.Timestamp):
    leg_short = leg_long + pd.DateOffset(months=1)
    base = f"{base}.{leg_long:%YM%m}_{leg_short:%YM%m}"
    return base


def get_pen_date(dg, instrument, expiry):
    ticker = generate_spread(instrument, expiry)
    data = dg.get_time_series(
        ticker,
        from_date=expiry - pd.DateOffset(months=3),
        to_date=expiry - pd.DateOffset(months=1),
    )
    return data


def lsgo_get_pen_date(dg, instrument, x):
    try:
        return get_pen_date(dg, instrument, x).dropna(axis=0).iloc[:-1, -1].rename(f"{x:%yM%m}").to_frame()
    except:
        return pd.DataFrame()


class StockModel(sm.tsa.statespace.MLEModel):
    def __init__(self, endog):
        # Initialize the state space model
        super(StockModel, self).__init__(
            endog,
            k_states=1,
            k_posdef=1,
            initialization='approximate_diffuse')

        # Setup the fixed components of the state space representation
        self['design'] = [[1.], [1.]]
        self['transition'] = [[1.]]
        self['selection', 0, 0] = 1.
        self['state_cov', 0, 0] = (0.8 * endog.iloc[:, 0].std()) ** 2
        self['obs_cov'] = [[1., 0], [0., 1.]]

    @property
    def param_names(self):
        return ['design.europe', 'sigma.ara', 'sigma.europe']

    def transform_params(self, unconstrained):
        return (unconstrained + 1e-6)**2

    def untransform_params(self, constrained):
        return constrained**0.5 - 1e-6

    @property
    def start_params(self):
        return [1.5, 1., 1.]

    # Describe how parameters enter the model
    def update(self, params, transformed=True, **kwargs):
        params = super(StockModel, self).update(params, transformed, **kwargs)
        self['design', 1, 0] = params[0]
        self['obs_cov', -1, -1] = params[-1]
        self['obs_cov', -2, -2] = params[-2]


def append_implied_utilization(data):
    ara_index = data['eu_stocks'].dropna().index
    fara_index = data['eu_stocks_forecast'].dropna().index
    data['capacity'] = data['stocks'] / data['utilization']
    date_range = pd.date_range(ara_index[0], ara_index[-1], freq='D')
    endog = data[['stocks', 'eu_stocks']].reindex(
        date_range).resample('D').ffill().resample('W').last()
    fdate_range = pd.date_range(fara_index[0], fara_index[-1], freq='D')
    fendog = data[['stocks', 'eu_stocks_forecast']].reindex(
        fdate_range).resample('D').ffill().resample('W').last()
    mod = StockModel(endog=endog.apply(np.log))
    fitted = mod.fit()
    modf = StockModel(endog=fendog.apply(np.log))
    smoother = modf.smooth(fitted.params)
    forecast = pd.Series(
        np.exp(smoother.smoother_results.smoothed_forecasts[0]), index=fendog.index)
    last_date = data['capacity'].last_valid_index()
    last_capacity = data.loc[last_date]['capacity']
    data = data.resample('D').mean().reindex(pd.date_range(
        fara_index[0], fara_index[-1], freq='D')).ffill()
    fused = pd.concat((data['utilization'][:last_date],
                      forecast[last_date:] / last_capacity), axis=0)
    data['utilization'] = fused
    return data


def prepare_data(data, price_col):
    pdata = data.copy()
    pdata['skew'] = (data['skew'] + np.log(data['price']))
    pdata['iv'] = (data['iv'] + np.log(data['price']))
    pdata['outlier'] = np.where(
        pdata.index == pd.Timestamp('2020-04-21'), 1, 0)
    pdata[price_col] = data[price_col].apply(transformation)
    pdata = pdata[[price_col, 'utilization', 'skew', 'iv', 'outlier']].resample(
        'D').mean().ffill().dropna(axis=0)
    return pdata


def rlm_forecast(data, price_col='front_spread', quantile=0.5):
    pdata = prepare_data(data, price_col)
    mod_quantile = smf.rlm(
        formula=f"{price_col} ~ utilization + I(utilization**2) +  I(utilization**3) + skew + iv + outlier + I(skew/iv)",
        data={col: pdata[col][:pd.Timestamp.now()] for col in pdata.columns}
    )
    fitted = mod_quantile.fit()
    prediction = fitted.predict({
        'utilization': pdata.ffill()['utilization'],
        'skew': pdata.ffill()['skew'],
        'iv': pdata.ffill()['iv'],
        'outlier': pdata.ffill()['outlier']}
    )
    return prediction


def quantile_forecast(data, price_col='front_spread', quantile=0.5):
    pdata = prepare_data(data, price_col)
    mod_quantile = smf.quantreg(
        formula=f"{price_col} ~ utilization + I(utilization**2) +  I(utilization**3) + skew  + iv  + I(skew/iv) + outlier",
        data={col: pdata[col][:pd.Timestamp.now()] for col in pdata.columns}
    )
    fitted = mod_quantile.fit(q=quantile, max_iter=10_000)
    print(fitted.summary())
    prediction = fitted.predict({
        'utilization': pdata.ffill()['utilization'],
        'skew': pdata.ffill()['skew'],
        'iv': pdata.ffill()['iv'],
        'outlier': pdata.ffill()['outlier']}
    )
    return prediction


def main(dg, tsa):
    instrument = 'model://ICE_GO_SP/EU.RP.ARA.ICE.GASOIL.FUT.SP'
    endog = pd.concat(map(tsa.get, tickers.values()), axis=1).rename(columns={v:k for k,v in tickers.items()})
    dates = pd.date_range(start='2012-1-1', end=pd.Timestamp.now() + pd.DateOffset(months=1), freq='MS')
    front_spread = pd.concat(thread_map(lambda x: lsgo_get_pen_date(dg, instrument, x), dates, max_workers=10), axis=1)
    # get_last = lambda x: pd.Series(x[x.last_valid_index()], index=[x.last_valid_index()])
    # proper_pen_dates = front_spread.apply(get_last, axis=0).sum(axis=1).rename('pen_date')
    series_ = [x.rename('price').to_frame() for x in front_spread.to_dict('Series').values()]
    front_spread = reduce(lambda first, last: first.combine_first(last), series_).iloc[:, -1].rename('front_spread')
    data = pd.concat((endog, front_spread.to_frame()), axis=1)
    data.to_csv('endog.csv')
    data = pd.read_csv('endog.csv', index_col=0)
    data.index = pd.to_datetime(data.index)
    tsa.update(
        'diesel.petroineos.ice_gasoil_spread.front_spread.usd_t.daily',
        data['front_spread'],
        author='loic.balland'
    )
    # tsa.update(
    #     'diesel.petroineos.ice_gasoil_spread.front_spread_pen_day.usd_t.daily',
    #     data['pen_date'],
    #     author='loic.balland'
    # )
    data = append_implied_utilization(data)
    tsa.update(
        'diesel.petroineos.ara.storage_utilization.pct.weekly',
        data['utilization'],
        author='loic.balland'
    )
    fair_value = rlm_forecast(data)
    name = 'diesel.petroineos.ice_gasoil_spread.fair_value.rlm.usd_t.daily'
    tsa.delete(name)
    tsa.update(
        name,
        transformation_1(fair_value),
        author='loic.balland'
    )
    for q in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:
        qfair_value = quantile_forecast(data, quantile=q)
        name = f'diesel.petroineos.ice_gasoil_spread.fair_value.quantile_{q:0.2f}.usd_t.daily'
        tsa.delete(name)
        tsa.update(
            name,
            transformation_1(qfair_value),
            author='loic.balland'
        )

if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    dg = DataGenic(
        'http://lon-qdev-ap11/',
        'http://petro.datagenic.net:8080/',
        'PIT018',
        'PIT018$1',

    )
    print(main(dg, tsa))
