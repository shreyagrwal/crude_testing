import pandas as pd


def generate_link(iso2c):
    return f'https://raw.githubusercontent.com/hiring-lab/job_postings_tracker/master/{iso2c}/aggregate_job_postings_{iso2c}.csv'


def get_indeed_postings(iso2c):
    link = generate_link(iso2c)
    print(link)
    data = pd.read_csv(generate_link(iso2c))
    data.date = pd.to_datetime(data.date)
    data = data.set_index(['date', 'variable'])
    data.columns = data.columns.str.replace(' ', '_')
    return data.indeed_job_postings_index_SA.unstack(1)


def upload_indeed_postings(tsa):
    postings = {
        'DE': {
            'new postings': f"macro.indeed.germany.new_postings.index.daily",
            'total postings': f"macro.indeed.germany.total_postings.index.daily"
        },
        'GB': {
            'new postings': f"macro.indeed.united_kingdom.new_postings.index.daily",
            'total postings': f"macro.indeed.united_kingdom.total_postings.index.daily"
        },
        'US': {
            'new postings': f"macro.indeed.united_states.new_postings.index.daily",
            'total postings': f"macro.indeed.united_states.total_postings.index.daily"
        },
        'CA': {
            'new postings': f"macro.indeed.canada.new_postings.index.daily",
            'total postings': f"macro.indeed.canada.total_postings.index.daily"
        },
        'AU': {
            'new postings': f"macro.indeed.austeria.new_postings.index.daily",
            'total postings': f"macro.indeed.austeria.total_postings.index.daily"
        },
        'IE': {
            'new postings': f"macro.indeed.ireland.new_postings.index.daily",
            'total postings': f"macro.indeed.ireland.total_postings.index.daily"
        }
        #,
        #'FR': {
        #    'new postings': f"macro.indeed.france.new_postings.index.daily",
        #    'total postings': f"macro.indeed.france.total_postings.index.daily"
        #}
    }
    for country, tickers in postings.items():
        data = get_indeed_postings(country)
        for t in tickers:
            tsa.update(
                tickers[t],
                data[t],
                author='loicballand'
            )


if __name__ == '__main__':
    from tshistory.api import timeseries
    upload_indeed_postings(
        timeseries('http://tst-qdev-ap9.petroineos.local/api'))
