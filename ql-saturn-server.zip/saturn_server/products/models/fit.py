import pandas as pd
import numpy as np
from datetime import datetime as dt
import statsmodels.api as sm
import json

from saturn_server.products.models.demand import HeatingOilModel, DemandModel
from saturn_server.products.models.russian_loadings import RussianLoadings
from saturn_server.products.models.flows import Flows
from saturn_server.products.models.yields import YieldModel, JetYieldModel
from saturn_server.products.models.rhine import RhineFlows

def transformation(data) -> pd.DataFrame:
    data = data.apply(lambda x: x / x.index.days_in_month)
    data = np.log(data)
    return data


def transformation_daily(data) -> pd.DataFrame:
    data = np.log(data)
    return data

def transformation_weekly(data) -> pd.DataFrame:
    data = data.resample('W-FRI').mean()
    return data

# Construct the model

class AR10(sm.tsa.SARIMAX):
    def __init__(self, endog):
        super(AR10, self).__init__(endog, order=(10, 0, 0), trend='c')

class LocalLevelSeasonal(sm.tsa.UnobservedComponents):
    def __init__(self, endog):
        monthly_dummies = pd.get_dummies(endog.index.to_period('M').month, prefix='d')
        monthly_dummies.index = endog.index
        super(LocalLevelSeasonal, self).__init__(endog=endog, exog=monthly_dummies, level='lltrend')

MODELS = {
    'diesel.ara.demand': {
        'params': {'beta_trucking_demand': 0.10, 'efficiency':-0.002},
        'model_type': DemandModel,
        'transformation': transformation,
        'transformation_1': lambda df: df.apply(lambda x: np.exp(x) * x.index.days_in_month).iloc[:, 0],
        'serieslist': [
            'diesel.jodi.ara.demand.kt.monthly',
            'oil.germany.truck_mileage.index.daily.seasonally_adj.monthly'
        ]
    },
    'colonial_pipeline': {
        'params': {'sigma2.level': 5 ** 2},
        'model_type': LocalLevelSeasonal,
        'transformation': lambda x:x,
        'transformation_1': lambda x:x.iloc[:, 0],
        'serieslist': [
            'diesel.eia.colonial_pipeline_flows.kbd.monthly',
        ]
    },
    'colonial_pipeline_gasoline': {
        'params': {'sigma2.level': 5 ** 2},
        'model_type': LocalLevelSeasonal,
        'transformation': lambda x:x,
        'transformation_1': lambda x:x.iloc[:, 0],
        'serieslist': [
            'gasoline.eia.colonial_pipeline_flows.kbd.monthly',
        ]
    },
    'kaub': {
        'params': {},
        'model_type': AR10,
        'transformation': lambda x:x,
        'transformation_1': lambda x:x.iloc[:, 0],
        'serieslist': [
            'oil.transafe.kaub.water_level.cm.daily.log',
        ]
    },
    'diesel.ara.rhine_flows': {
        'params': {},
        'model_type': RhineFlows,
        'transformation': transformation_weekly,
        'transformation_1': lambda x: x.iloc[:, 0],
        'serieslist': [
            'diesel.petroineos.ara.rhine_flows.kt.weekly',
            'oil.transafe.kaub.water_level.cm.daily.below_300',
        ]
    },
    'diesel.oecd_europe.non_road_demand': {
        'params': {},
        'model_type': HeatingOilModel,
        'transformation': transformation,
        'transformation_1': lambda df: df.apply(lambda x: np.exp(x) * x.index.days_in_month).iloc[:, 0],
        'serieslist': [
            'diesel.iea.oecd_europe.non_road_demand.kt.monthly',
        ]
    },
    'kerosene.oecd_europe.demand': {
        'params': {},
        'model_type': HeatingOilModel,
        'transformation': transformation,
        'transformation_1': lambda df: df.apply(lambda x: np.exp(x) * x.index.days_in_month).iloc[:, 0],
        'serieslist': [
            'kerosene.iea.oecd_europe.demand.kt.monthly',
        ]
    },
    'diesel.oecd_europe.road_demand': {
        'params': {},
        'model_type': DemandModel,
        'transformation': transformation,
        'transformation_1': lambda df: df.apply(lambda x: np.exp(x) * x.index.days_in_month).iloc[:, 0],
        'serieslist': [
            'diesel.iea.oecd_europe.road_demand.kt.monthly',
            'oil.germany.truck_mileage.index.daily.seasonally_adj.monthly'
        ]
    },
    'diesel.baltic_sea.loadings': {
        'params': {},
        'model_type': RussianLoadings,
        'transformation': lambda x: x,
        'transformation_1': lambda x: x.iloc[:, 0],
        'serieslist': [
            'diesel.petrologistics.baltic_sea.loadings.kt.daily.30mav',
            'oil.petroineos.russia.total_outage.kbd.daily.45mav'
        ]
    },
    'diesel.black_sea.loadings': {
        'params': {},
        'model_type': RussianLoadings,
        'transformation': lambda x: x,
        'transformation_1': lambda x: x.iloc[:, 0],
        'serieslist': [
            'diesel.petrologistics.black_sea.loadings.kt.daily.30mav',
            'oil.petroineos.russia.total_outage.kbd.daily.45mav'
        ]
    },
    'diesel.asia.imports': {
        'params': {},
        'model_type': Flows,
        'transformation': lambda x: x,
        'transformation_1': lambda x: x.iloc[:, 0],
        'serieslist': [
            'diesel.petroineos.asia.oecd_europe.imports.kt.daily.30mav',
            'price.baltic_exchange.tc5.usd_t.daily',
            'price.pvm.10ppm_ew_spread.m03.usd_t.daily',
        ]
    },
    'diesel.asia.exports': {
        'params': {'beta_arb': 0, 'beta_freight': 0},
        'model_type': Flows,
        'transformation': lambda x: x,
        'transformation_1': lambda x: x.iloc[:, 0],
        'serieslist': [
            'diesel.kpler.asia.oecd_europe.exports.kt.daily.30mav',
            'price.baltic_exchange.tc5.usd_t.daily',
            'price.pvm.10ppm_ew_spread.m03.usd_t.daily',
        ]
    },
    'diesel.americas.imports': {
        'params': {'beta_arb': 0},
        'model_type': Flows,
        'transformation': lambda x: x,
        'transformation_1': lambda x: x.iloc[:, 0],
        'serieslist': [
            'diesel.kpler.americas.oecd_europe.imports.kt.daily.30mav',
            'price.baltic_exchange.tc5.usd_t.daily',
            'price.pvm.10ppm_ew_spread.m03.usd_t.daily',

        ]
    },
    'diesel.americas.exports': {
        'params': {'beta_arb': 0},
        'model_type': Flows,
        'transformation': lambda x: x,
        'transformation_1': lambda x: x.iloc[:, 0],
        'serieslist': [
            'diesel.kpler.americas.oecd_europe.exports.kt.daily.30mav',
            'price.baltic_exchange.tc5.usd_t.daily',
            'price.pvm.10ppm_ew_spread.m03.usd_t.daily',
        ]
    },
    'diesel.africa.exports': {
        'params': {'beta_arb': 0, 'beta_freight': 0},
        'model_type': Flows,
        'transformation': lambda x: x,
        'transformation_1': lambda x: x.iloc[:, 0],
        'serieslist': [
            'diesel.kpler.africa.oecd_europe.exports.kt.daily.30mav',
            'price.baltic_exchange.tc5.usd_t.daily',
            'price.pvm.10ppm_ew_spread.m03.usd_t.daily',
        ]
    },
    'diesel.africa.imports': {
        'params': {'beta_arb': 0},
        'model_type': Flows,
        'transformation': lambda x: x,
        'transformation_1': lambda x: x.iloc[:, 0],
        'serieslist': [
            'diesel.kpler.africa.oecd_europe.imports.kt.daily.30mav',
            'price.baltic_exchange.tc5.usd_t.daily',
            'price.pvm.10ppm_ew_spread.m03.usd_t.daily',
        ]
    },
    'jet_kerosene.oecd_europe.yield': {
        'params': {'alpha':0.6},
        'model_type': JetYieldModel,
        'transformation': lambda x: x.resample('MS').mean(),
        'transformation_1': lambda x: x.iloc[:, 0],
        'serieslist': [
            'jet_kerosene.jodi.oecd_europe.yield.pct.monthly',
            'diesel.petroineos.regrade_cif_nwe_curve.usd_bbl.upsampled',
            'jet.petroineos.oecd_europe.demand.kt.monthly.forecast.12mav',
        ]
    },
    'distillate.oecd_europe.yield': {
        'params': {},
        'model_type': YieldModel,
        'transformation': lambda x: x.resample('MS').mean(),
        'transformation_1': lambda x: x.iloc[:, 0],
        'serieslist': [
            'distillates.jodi.oecd_europe.refining_yield.pct.monthly',
            'nwe_gasoline_diesel_spread.usd_bbl.upsampled',
        ]
    },

}


def save_params(tsa, res, params_series_id):
    series = pd.Series(
        data=res.params.to_json(),
        index=[pd.Timestamp.now()]
    )
    tsa.update(params_series_id, series, author=params_series_id)


def load_params(tsa, params_series_id):
    exists = tsa.exists(params_series_id)
    if exists:
        series = tsa.get(params_series_id)
        return json.loads(series.iloc[-1])
    else:
        return None


def fit(endog, params, model_type):
    maxiter = 10_000
    model = model_type(endog)
    if params:
        res = model.fit_constrained(params, maxiter=maxiter)
    else:
        _res = model.fit(method='nm')
        res = model.fit(start_params=_res.params, maxiter=maxiter)
    return res


def conditional_forecasts(endog, params, model_type, end_date, freq):
    index = pd.date_range(endog.index[0], end_date.replace(tzinfo=None), freq=freq)
    endog = endog.reindex(index)
    model = model_type(endog)
    fit = model.fit_constrained(params)
    forecasts = pd.DataFrame(
        fit.smoother_results.smoothed_forecasts.T,
        index=fit.states.smoothed.index,
        columns=endog.columns
    )
    return forecasts


def forecasts(tsa, serieslist, model_name, freq='D', overwrite=None, fromdate=None, todate=None, end_date=None):
    constraint_params, model_type, fn, inv_fn, _ = MODELS[model_name].values(
    )
    data = pd.concat([s.tz_localize(None) for s in serieslist], axis=1)
    data = fn(data)
    params_series_id = '.'.join(['params', model_name])
    params = load_params(tsa, params_series_id) if not overwrite else {}
    if not end_date:
        end_date = data.index[-1]
    if not params:
        fitted = fit(data, constraint_params, model_type)
        print(fitted.summary())
        save_params(tsa, fitted, params_series_id)
        params = fitted.params
    params.update(constraint_params)
    data = inv_fn(
        conditional_forecasts(data, params, model_type, end_date, freq)
    )
    if fromdate:
        data = data[fromdate:]
    if todate:
        data = data[:todate]
    return data
                


if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    model = 'diesel.oecd_europe.road_demand'
    serieslist = MODELS[model]['serieslist']
    data = list(map(lambda x: tsa.get(x).tz_localize(
        None)[:pd.Timestamp.now()], serieslist))
    import matplotlib.pyplot as plt
    cond = forecasts(
        tsa,
        data,
        model,
        'MS',
        True,
        end_date=pd.Timestamp('2030-1-1')
    )

    cond.plot()
    data[0].plot()
    plt.show()
