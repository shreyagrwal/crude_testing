import pandas as pd
import numpy as np
from datetime import datetime as dt
import statsmodels.api as sm
import json

class YieldModel(sm.tsa.statespace.MLEModel):
    def __init__(self, endog):
        # Initialize the state space model
        super(YieldModel, self).__init__(endog, k_states=3, k_posdef=3, initialization='approximate_diffuse')
        std = endog.diff().std()
        self.std = std
        self.months = endog.index.month
        # Setup the fixed components of the state space representation
        self['design'] = np.tile(np.array([[1, 1, 0.5], [0, 0, 1]])[..., None], (1, 1, endog.shape[0]))
        self['transition'] = np.eye(3)
        self['selection'] = np.eye(3)
        self['state_cov'] = np.diagflat([0.02 * std.values[0], 0.98 * std.values[0], 0.1 * std.values[-1]]) ** 2
        self['obs_cov'] = 1e-9 * np.eye(2)

    # Specify start parameters and parameter names
    @property
    def start_params(self):
        zeros = [0 for x in range(12)]
        return zeros + [0.05, 0.4]  # these are very simple

    @property
    def param_names(self):
        seasonals = [f'seas.{i}' for i in range(12)]
        return seasonals + ['regrade', 'alpha']

    def transform_alpha(self, param, untransform=False):
        # Capital share must be between 0 and 1
        epsilon = 1e-3  # bound it slightly away from exactly 0 or 1
        if not untransform:
            return np.abs(1 / (1 + np.exp(param)) - epsilon)
        else:
            return np.log((1 - param + epsilon) / (param + epsilon))

    def transform_params(self, unconstrained):
        constrained = unconstrained
        constrained[-1] = self.transform_alpha(unconstrained[-1])
        return constrained

    def untransform_params(self, constrained):
        unconstrained = constrained
        unconstrained[-1] = self.transform_alpha(
            constrained[-1], untransform=True)
        return unconstrained

    # Describe how parameters enter the model
    def update(self, params, transformed=True, **kwargs):
        params = super(YieldModel, self).update(params, transformed, **kwargs)
        seasonals = params[:12] + [- sum(params[:12])]
        dummy_month = pd.get_dummies(self.months).values[None,...]
        self['state_intercept'] = np.concatenate(
            (dummy_month, np.zeros_like(dummy_month), np.zeros_like(dummy_month)), axis=0) @ seasonals
        self['design', 0, -1] = params[-2]
        self['transition', 1, 1] = params[-1]
        self['transition', 2, 2] = 0.95
        self['state_cov', 1, 1] = (self.std.values[0] ** 2) * (1 - params[-1])
        self['state_cov', -1, -1] = (self.std.values[-1] ** 2) * (1 - 0.95)


class JetYieldModel(sm.tsa.statespace.MLEModel):
    def __init__(self, endog):
        # Initialize the state space model
        super(JetYieldModel, self).__init__(endog, k_states=4,
                                         k_posdef=4, initialization='approximate_diffuse')
        std = endog.diff().std()
        self.std = std
        self.months = endog.index.month
        # Setup the fixed components of the state space representation
        self['design'] = np.tile(
            np.array(
                [
                    [1, 1, 0, 0],
                    [0, 0, 1, 0],
                    [0, 0, 0, 1]
                ]
            )[..., None], (1, 1, endog.shape[0]))
        self['transition'] = np.eye(4)
        self['selection'] = np.eye(4)
        self.syield = std.values[0]
        self.lt = 0.4
        self['state_cov'] = np.diagflat(
            [self.lt * self.syield, 
            (1 - self.lt) * self.syield, 
            0.1 * std.values[1], 
            std.values[2]]) ** 2
        self['obs_cov'] = 1e-9 * np.eye(3)

    # Specify start parameters and parameter names
    @property
    def start_params(self):
        zeros = [0 for x in range(12)]
        return zeros + [0.05, 0.4]  # these are very simple

    @property
    def param_names(self):
        seasonals = [f'seas.{i}' for i in range(12)]
        return seasonals + ['regrade', 'alpha']

    def transform_alpha(self, param, untransform=False):
        # Capital share must be between 0 and 1
        epsilon = 1e-3  # bound it slightly away from exactly 0 or 1
        if not untransform:
            return np.abs(1 / (1 + np.exp(param)) - epsilon)
        else:
            return np.log((1 - param + epsilon) / (param + epsilon))

    def transform_params(self, unconstrained):
        constrained = unconstrained
        constrained[-1] = self.transform_alpha(unconstrained[-1])
        return constrained

    def untransform_params(self, constrained):
        unconstrained = constrained
        unconstrained[-1] = self.transform_alpha(
            constrained[-1], untransform=True)
        return unconstrained

    # Describe how parameters enter the model
    def update(self, params, transformed=True, **kwargs):
        params = super(JetYieldModel, self).update(params, transformed, **kwargs)
        seasonals = params[:12] + [- sum(params[:12])]
        dummy_month = pd.get_dummies(self.months).values[None, ...]
        self['state_intercept'] = np.concatenate(
            (
                dummy_month,
                np.zeros_like(dummy_month),
                np.zeros_like(dummy_month),
                np.zeros_like(dummy_month),
            ),
            axis=0) @ seasonals
        self['design', 0, -2] = params[-2]
        self['transition', 1, 1] = params[-1]
        self['transition', 2, 2] = 0.9
        self['state_cov', 1, 1] = (self.std.values[0] ** 2) * (1 - params[-1])
        self['state_cov', 2, 2] = (self.std.values[1] ** 2) * (1 - 0.9)
        self['state_cov', 0, 3] = 0.7 * self.lt * \
            self.syield * self.std.values[-1]
        self['state_cov', 3, 0] = 0.7 * self.lt * \
            self.syield * self.std.values[-1]
