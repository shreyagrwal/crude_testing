import pandas as pd
import numpy as np
from datetime import datetime as dt
import statsmodels.api as sm
import json

# Construct the model
class RhineFlows(sm.tsa.statespace.MLEModel):
    def __init__(self, endog):
        # Initialize the state space model
        super(RhineFlows, self).__init__(endog, k_states=2, k_posdef=2,
                                  initialization='approximate_diffuse')
        self.std_rhine = endog.iloc[:, -1].diff().std()

        # Setup the fixed components of the state space representation
        self['design'] = [[1, 1], 
                          [1, 0]]
        self['transition'] = [[1, 0],
                              [0, 1]]
        self['selection'] = [[1, 0],
                              [0, 1]]
        self['state_cov'] =  [[self.std_rhine ** 2, 0],
                              [0                  , 1]]
        self['obs_cov'] = [[5 ** 2, 0],
                           [0     , 1e-5]]

    # Specify start parameters and parameter names
    @property
    def start_params(self):
        return [.7, 1, 0.5]  # these are very simple
    
    @property
    def param_names(self):
        return ['reversion', 'sigma_trend', 'beta_water_flows']  # these are very simple

    # Describe how parameters enter the model
    def update(self, params, transformed=True, **kwargs):
        params = super(RhineFlows, self).update(params, transformed, **kwargs)
        self['state_intercept', 0] = 300 * ( 1 - params[0])
        self['transition', 0, 0] = params[0]
        self['state_cov', 1, 1] = params[1] ** 2
        self['design', 0, 0] = -params[2]