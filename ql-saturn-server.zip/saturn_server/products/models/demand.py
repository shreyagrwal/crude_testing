import pandas as pd
import numpy as np
from datetime import datetime as dt
import statsmodels.api as sm
import json

def HeatingOilModel(endog):
    restricted_model = {
        'level': 'local linear trend', 'seasonal': 12, 'autoregressive': 1,
    }
    return sm.tsa.UnobservedComponents(
        endog, **restricted_model
    )

class DemandModel(sm.tsa.statespace.MLEModel):
    def __init__(self, endog):
        # Initialize the state space model
        super(DemandModel, self).__init__(endog, k_states=2, k_posdef=2, initialization='approximate_diffuse')
        self.sigma_demand = endog.iloc[:, 0].diff().std()
        self.sigma_trucking = endog.iloc[:, -1].diff().std()
        self.growth_trucking = endog.iloc[:, -1].diff().mean()
        self.months = endog.index.month
        # Setup the fixed components of the state space representation
        self['design'] = np.tile(np.array([[1, 1],
                                           [0, 1]])[..., None], (1, 1, endog.shape[0]))
        self['transition'] = [[0.8, 0],
                              [0, 1]]
        
        self['selection'] = [[1, 0], [0, 1]]
        self['state_cov'] = [[0, 0], [0, (0.5 * self.sigma_trucking) ** 2]]
        self['obs_cov'] = [[(0.1 * self.sigma_demand) ** 2, 0],
                           [0, (0.1 * self.sigma_trucking) ** 2]]

    # Specify start parameters and parameter names
    @property
    def start_params(self):
        zeros = [0 for x in range(12)]
        return zeros + [-0.001, 1, 0.1]  # these are very simple

    @property
    def param_names(self):
        seasonals = [f'seas.{i}' for i in range(12)]
        return seasonals + ['efficiency', 'beta_trucking_demand', 'sigma_mean_reversion']

    # Describe how parameters enter the model
    def update(self, params, transformed=True, **kwargs):
        params = super(DemandModel, self).update(params, transformed, **kwargs)
        seasonals = params[:12] + [- sum(params[:12])]
        dummy_month = pd.get_dummies(self.months).values[None,...]
        self['state_intercept'] = np.concatenate(
            (dummy_month, np.zeros_like(dummy_month)), axis=0) @ seasonals
        self['state_intercept', 0, :] += params[-3]
        self['state_intercept', 1, :] += self.growth_trucking
        self['design', 0, 1] = params[-2]
        self['state_cov', 0, 0] = params[-1] ** 2