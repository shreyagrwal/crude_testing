import pandas as pd
import numpy as np
from datetime import datetime as dt
import statsmodels.api as sm
import json

class RussianLoadings(sm.tsa.statespace.MLEModel):
    def __init__(self, endog):
        # Initialize the state space model
        super(RussianLoadings, self).__init__(endog, k_states=2, k_posdef=2, initialization='approximate_diffuse')
        std = endog.diff().std()
        self.months = endog.index.month
        # Setup the fixed components of the state space representation
        self['design'] = np.tile(np.array([[1, 1], [0, 1]])[..., None], (1, 1, endog.shape[0]))
        self['transition'] = np.eye(2)
        self['selection'] = np.eye(2)
        self['state_cov'] = np.diagflat(std.values)
        self['obs_cov'] = 1e-9 * np.eye(2)

    # Specify start parameters and parameter names
    @property
    def start_params(self):
        zeros = [0 for x in range(12)]
        return zeros + [-0.5]  # these are very simple

    @property
    def param_names(self):
        seasonals = [f'seas.{i}' for i in range(12)]
        return seasonals + ['beta_loading_outage']

    # Describe how parameters enter the model
    def update(self, params, transformed=True, **kwargs):
        params = super(RussianLoadings, self).update(params, transformed, **kwargs)
        seasonals = params[:12] + [- sum(params[:12])]
        dummy_month = pd.get_dummies(self.months).values[None,...]
        self['state_intercept'] = np.concatenate(
            (dummy_month, np.zeros_like(dummy_month)), axis=0) @ seasonals
        self['design', 0, -1] = params[-1]