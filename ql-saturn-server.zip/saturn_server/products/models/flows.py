import pandas as pd
import numpy as np
from datetime import datetime as dt
import statsmodels.api as sm
import json


class Flows(sm.tsa.statespace.MLEModel):
    def __init__(self, endog):
        # Initialize the state space model
        super(Flows, self).__init__(
            endog, 
            k_states=4,
            k_posdef=4, 
            initialization='approximate_diffuse'
            )
        self.k_exog = 0
        std = endog.diff().std()
        self.growth = endog.diff().mean()
        _, self.m_freight, self.m_arb = 0, 30, -20
        self.months = endog.index.month
        # Setup the fixed components of the state space representation
        self['design'] = np.tile(np.array([
            [1, 0, 0, 1],
            [0, 1, 0, 0],
            [0, 0, 1, 0],
        ])[..., None], (1, 1, endog.shape[0]))
        self['transition'] = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 0.99],
        ])
        self['selection'] = np.eye(4)
        self['state_cov'] = [
            [std.values[0] * 0.01, 0, 0, 0],
            [0, std.values[1], 0, 0],
            [0, 0, std.values[2], 0],
            [0, 0, 0, std.values[0] * 0.99],
        ]
        self['obs_cov'] = 1e-9 * np.eye(3)

    # Specify start parameters and parameter names
    @property
    def start_params(self):
        zeros = [0 for x in range(12)]
        return zeros + [0.5, 0.5, 0.99]  # these are very simple

    @property
    def param_names(self):
        seasonals = [f'seas.{i}' for i in range(12)]
        return seasonals + ['beta_freight', 'beta_arb', 'alpha']

    def transform_beta(self, param, untransform=False):
        # Capital share must be between 0 and 1
        epsilon = 1e-3  # bound it slightly away from exactly 0 or 1
        if not untransform:
            return np.abs(1 / (1 + np.exp(param)) - epsilon)
        else:
            return np.log((1 - param + epsilon) / (param + epsilon))

    def transform_alpha(self, param, untransform=False):
        # Capital share must be between 0 and 1
        epsilon = 1e-3  # bound it slightly away from exactly 0 or 1
        if not untransform:
            return np.abs(1 / (1 + np.exp(param)) - epsilon)
        else:
            return np.log((1 - param + epsilon) / (param + epsilon))

    def transform_params(self, unconstrained):
        constrained = unconstrained
        constrained[-3:-1] = self.transform_beta(unconstrained[-3:-1])
        constrained[-1] = self.transform_alpha(unconstrained[-1])
        return constrained

    def untransform_params(self, constrained):
        unconstrained = constrained
        unconstrained[-3:-
                      1] = self.transform_beta(constrained[-3:-1], untransform=True)
        unconstrained[-1] = self.transform_alpha(
            constrained[-1], untransform=True)
        return unconstrained

    # Describe how parameters enter the model
    def update(self, params, transformed=True, **kwargs):
        params = super(Flows, self).update(params, transformed, **kwargs)
        seasonals = params[:12] + [- sum(params[:12])]
        dummy_month = pd.get_dummies(self.months).values[None, ...]
        self['state_intercept'] = np.concatenate(
            (dummy_month, 
            np.zeros_like(dummy_month), 
            np.zeros_like(dummy_month), 
            np.zeros_like(dummy_month)), axis=0) @ seasonals
        # self['state_intercept', 0, :] += self.growth.iloc[0]
        self['state_intercept', 1, :] = self.m_freight * (1 - params[-1])
        self['state_intercept', 2, :] = self.m_arb * (1 - params[-1])
        self['design', 0, 1] = - params[-3]
        self['design', 0, 2] = - params[-2]
        self['transition', 1, 1] = params[-1]
        self['transition', 2, 2] = params[-1]
