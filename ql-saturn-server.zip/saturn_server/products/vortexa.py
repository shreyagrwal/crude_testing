from datetime import datetime as dt
import numpy as np
import pandas as pd
from tshistory.api import timeseries
import yaml
from tqdm.contrib.concurrent import thread_map
from saturn_server.safe_metadata_update import safely_update_metadata
from BlueOcean import DataAccessApi

from saturn_server.helpers import (
    safe_register_formula,
    series_id,
)

from saturn_server import HERE

TIMESTAMP_CHOICE = {
    'load': 'load_timestamp',
    'unload': 'unload_timestamp',
}


def load_yaml(path):
    with open(path, "r") as stream:
        try:
            return yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)


def str_iterable(iterable):
    if isinstance(iterable, list):
        iterable = tuple(iterable)
    size = len(iterable)
    if size == 0:
        return "(NULL)"
    if size == 1:
        return f"('{iterable[0]}')"
    else:
        return f"{iterable}"

def _hot_flow_query(
        product_layer,
        product_values,
        lift_layer,
        lift_values,
        exclude_lift_layer,
        exclude_lift_values,
        discharge_layer,
        discharge_values,
        exclude_discharge_layer,
        exclude_discharge_values,
        pdate,
        timestamp='load',
        ):
    query2 = f"""select {TIMESTAMP_CHOICE[timestamp]} as date, sum(quantity_tonnes) / 1000 as value from fundamental.shipping.vortexa_cargo_movements_cleanproducts where isactive is true and"""
    str_product_layer = " ".join(["(", " OR ".join([f"{product_layer} like '%{p}%'" for p in product_values]), ")"])
    str_lift_layer = " ".join(["(", " OR ".join([f"{lift_layer} like '%{p}%'" for p in lift_values]), ")"])
    str_exclude_lift_layer = " ".join(["(", " OR ".join([f"{exclude_lift_layer} not like '%{p}%'" for p in exclude_lift_values]), ")"])
    str_discharge_layer = " ".join(["(", " OR ".join([f"{discharge_layer} like '%{p}%'" for p in discharge_values]), ")"])
    str_exclude_discharge_layer = " ".join(["(", " OR ".join([f"{exclude_discharge_layer} not like '%{p}%'" for p in exclude_discharge_values]), ")"])
    where_conditions = " AND ".join([
        str_product_layer,
        str_lift_layer,
        str_exclude_lift_layer,
        str_discharge_layer,
        str_exclude_discharge_layer,
    ])
    group_by_clause = f" group by {TIMESTAMP_CHOICE[timestamp]}"
    return query2 + where_conditions + group_by_clause

def _flow_query(
        product_layer,
        product_values,
        lift_layer,
        lift_values,
        exclude_lift_layer,
        exclude_lift_values,
        discharge_layer,
        discharge_values,
        exclude_discharge_layer,
        exclude_discharge_values,
        timestamp='load', *args, **kwargs):
    query_hot = _hot_flow_query(
        product_layer,
        product_values,
        lift_layer,
        lift_values,
        exclude_lift_layer,
        exclude_lift_values,
        discharge_layer,
        discharge_values,
        exclude_discharge_layer,
        exclude_discharge_values,
        dt.now(),
        timestamp,
    )
    _hot = DataAccessApi.GetDataframe(query_hot)
    if not _hot.empty:
        dates = pd.date_range(
            start=pd.to_datetime(_hot.date).min(),
            end=pd.to_datetime(_hot.date).max(),
            freq='D', 
        ).tz_localize(None)
        hot = _hot.set_index('date')
        hot.index = pd.to_datetime(hot.index).tz_localize(None)
        return hot.reindex(dates).fillna(0).iloc[:, -1]
    else:
        return pd.DataFrame()


ORDER = ['product', 'source', 'from', 'to',
         'economic_property', 'unit', 'frequency']


def mav(series_id, days):
    return f'(rolling (mul (series "one.daily.naive") (series "{series_id}" #:fill 0)) {days})'

def upload_rolling_formula(tsa, series_id):
    for roll in [7, 14, 30]:
        text = mav(series_id, roll)
        name = '.'.join([series_id, f"{roll}mav"])
        safe_register_formula(tsa, name, text)

def upload_vortexa_flows(tsa):
    flows_desc = load_yaml(HERE / 'products' / 'data'/ 'vortexa.yml')
    def fn_upload(desc):
        data = _flow_query(**desc)
        if not data.empty:
            _series_id = series_id(desc, ORDER)
            tsa.update(_series_id, data, author='uploader')
            safely_update_metadata(
                tsa, _series_id, {k: v.__str__() for k, v in desc.items()})
            upload_rolling_formula(tsa, _series_id)
            safe_register_formula(
                tsa=tsa, 
                name=_series_id.replace('daily', 'monthly'), 
                formula= f'(resample (series "{_series_id}") "MS" #:method "sum")'
                )
            safe_register_formula(
                tsa=tsa, 
                name=_series_id.replace('daily', 'yearly'), 
                formula= f'(resample (series "{_series_id}") "AS" #:method "sum")'
                )
            safe_register_formula(
                tsa=tsa, 
                name=_series_id.replace('daily', 'weekly'), 
                formula= f'(resample (series "{_series_id}") "W" #:method "sum")'
                )
    return thread_map(fn_upload, flows_desc, max_workers=10)


if __name__ == '__main__':
    assert str_iterable(['a', 'b', 'c']) == "('a', 'b', 'c')"
    assert str_iterable(['a']) == "('a')"
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    upload_vortexa_flows(tsa)
