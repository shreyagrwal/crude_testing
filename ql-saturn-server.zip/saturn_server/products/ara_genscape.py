import pandas as pd

from tshistory.api import timeseries
from saturn_server.safe_metadata_update import safely_update_metadata
from BlueOcean import DataAccessApi


def get_ara_stocks():
    query = f"""
    SELECT reportDate, sum(storageAmount / 1000.) as storage, sum(storageAmount / 1.) / sum(operationalCapacity / 1.) as utilization
    FROM dataengineering.oil_genscape_genscapearainventory 
    where region != 'New York Harbor'
    and product = 'Heating Oil/Diesel' and isactive = true
    group by reportDate
    ORDER by reportDate
    """
    data = DataAccessApi.GetDataframe(query)
    return data

def get_ara_hck_daily_status():
    query = """
        SELECT PDate
        ,FacilityName
        ,UnitName
        ,UnitCapacity
        ,ProcessingClass
        ,UnitCategory
        ,UnitOnline
        ,OutageType
    FROM dataengineering.oil_refinery_refineryunitdailystatus t
    inner join (
        SELECT VendorValue
        FROM dataengineering.oil_refinery_refineryunitmapping t
        inner join (
            select UNIT_ID FROM dataengineering.oil_refinery_unit_view t
            inner join (
                SELECT PLANT_ID
                FROM dataengineering.oil_refinery_plant
                where COUNTRY in ('BELGIUM', 'NETHERLANDS')
            ) tm on t.PLANT_ID = tm.PLANT_ID
            WHERE t.UNIT_GROUP in ('HCK')
        ) tm on t.UNIT_ID = tm.UNIT_ID
    ) tm on t.UnitId = tm.VendorValue
    where isactive is true
    order by PDate desc
    """
    data = DataAccessApi.GetDataframe(query)
    data['capa'] = data['UnitCapacity'] * ~data['UnitOnline']
    data['PDate'] = pd.to_datetime(data['PDate'])
    return data.groupby('PDate')['capa'].sum() / 1e3

def get_gulf_coast_daily_status():
    query = """
    SELECT pdate, sum(UnitCapacity) / 1000. as capacity, sum(UnitCapacity * cast(UnitOnline as float)) / 1000. as available_capacity
    FROM dataengineering.oil_refinery_refineryunitdailystatus
    where UnitCategory = 'Atmospheric Crude Distillation' and Region = 'Gulf Coast' and isactive is true
    group by PDate
    order by pdate
    """
    data = DataAccessApi.GetDataframe(query)
    data['pdate'] = pd.to_datetime(data['pdate'])
    return data.groupby('pdate').mean()

def get_ara_fcc_daily_status():
    query = """
        SELECT PDate
        ,FacilityName
        ,UnitName
        ,UnitCapacity
        ,ProcessingClass
        ,UnitCategory
        ,UnitOnline
        ,OutageType
    FROM dataengineering.oil_refinery_refineryunitdailystatus t
    inner join (
        SELECT VendorValue
        FROM dataengineering.oil_refinery_refineryunitmapping t
        inner join (
            select UNIT_ID FROM dataengineering.oil_refinery_unit_view t
            inner join (
                SELECT PLANT_ID
                FROM dataengineering.oil_refinery_plant
                where COUNTRY in ('BELGIUM', 'NETHERLANDS')
            ) tm on t.PLANT_ID = tm.PLANT_ID
            WHERE t.UNIT_GROUP in ('FCC')
        ) tm on t.UNIT_ID = tm.UNIT_ID
    ) tm on t.UnitId = tm.VendorValue
    where isactive is true
    order by PDate desc
    """
    data = DataAccessApi.GetDataframe(query)
    data['capa'] = data['UnitCapacity'] * ~data['UnitOnline']
    data['PDate'] = pd.to_datetime(data['PDate'])
    return data.groupby('PDate')['capa'].sum() / 1e3

def get_ara_cdu_daily_status():
    query = """
        SELECT PDate
        ,FacilityName
        ,UnitName
        ,UnitCapacity
        ,ProcessingClass
        ,UnitCategory
        ,UnitOnline
        ,OutageType
    FROM dataengineering.oil_refinery_refineryunitdailystatus t
    inner join (
        SELECT VendorValue
        FROM dataengineering.oil_refinery_refineryunitmapping t
        inner join (
            select UNIT_ID FROM dataengineering.oil_refinery_unit_view t
            inner join (
                SELECT PLANT_ID
                FROM dataengineering.oil_refinery_plant
                where COUNTRY in ('BELGIUM', 'NETHERLANDS')
            ) tm on t.PLANT_ID = tm.PLANT_ID
            WHERE t.UNIT_GROUP in ('CDU')
        ) tm on t.UNIT_ID = tm.UNIT_ID
    ) tm on t.UnitId = tm.VendorValue
    where isactive is true
    order by PDate desc
    """
    data = DataAccessApi.GetDataframe(query)
    data['capa'] = data['UnitCapacity'] * ~data['UnitOnline']
    data['PDate'] = pd.to_datetime(data['PDate'])
    return data.groupby('PDate')['capa'].sum() / 1e3

def get_europe_hck_daily_status():
    query = """
        SELECT PDate
        ,FacilityName
        ,UnitName
        ,UnitCapacity
        ,ProcessingClass
        ,UnitCategory
        ,UnitOnline
        ,OutageType
    FROM dataengineering.oil_refinery_refineryunitdailystatus t
    inner join (
        SELECT VendorValue
        FROM dataengineering.oil_refinery_refineryunitmapping t
        inner join (
            select UNIT_ID FROM dataengineering.oil_refinery_unit_view t
            inner join (
                SELECT PLANT_ID
                FROM dataengineering.oil_refinery_plant
                where COUNTRY in ('SPAIN', 'UNITED KINGDOM', 'ITALY', 'FRANCE', 'BELGIUM', 'NETHERLANDS', 'DENMARK', 'GERMANY', 'POLAND', 'SLOVAKIA', 'HUNGARY', 'CZECH REPUBLIC')
            ) tm on t.PLANT_ID = tm.PLANT_ID
            WHERE t.UNIT_GROUP in ('HCK')
        ) tm on t.UNIT_ID = tm.UNIT_ID
    ) tm on t.UnitId = tm.VendorValue
    where isactive is true
    order by PDate desc
    """
    data = DataAccessApi.GetDataframe(query)
    data['capa'] = data['UnitCapacity'] * ~data['UnitOnline']
    data['PDate'] = pd.to_datetime(data['PDate'])
    return data.groupby('PDate')['capa'].sum() / 1e3

def get_europe_fcc_daily_status():
    query = """
        SELECT PDate
        ,FacilityName
        ,UnitName
        ,UnitCapacity
        ,ProcessingClass
        ,UnitCategory
        ,UnitOnline
        ,OutageType
    FROM dataengineering.oil_refinery_refineryunitdailystatus t
    inner join (
        SELECT VendorValue
        FROM dataengineering.oil_refinery_refineryunitmapping t
        inner join (
            select UNIT_ID FROM dataengineering.oil_refinery_unit_view t
            inner join (
                SELECT PLANT_ID
                FROM dataengineering.oil_refinery_plant
                where COUNTRY in ('SPAIN', 'UNITED KINGDOM', 'ITALY', 'FRANCE', 'BELGIUM', 'NETHERLANDS', 'DENMARK', 'GERMANY', 'POLAND', 'SLOVAKIA', 'HUNGARY', 'CZECH REPUBLIC')
            ) tm on t.PLANT_ID = tm.PLANT_ID
            WHERE t.UNIT_GROUP in ('FCC')
        ) tm on t.UNIT_ID = tm.UNIT_ID
    ) tm on t.UnitId = tm.VendorValue
    where isactive is true
    order by PDate desc
    """
    data = DataAccessApi.GetDataframe(query)
    data['capa'] = data['UnitCapacity'] * ~data['UnitOnline']
    data['PDate'] = pd.to_datetime(data['PDate'])
    return data.groupby('PDate')['capa'].sum() / 1e3

def get_europe_cdu_daily_status():
    query = """
        SELECT PDate
        ,FacilityName
        ,UnitName
        ,UnitCapacity
        ,ProcessingClass
        ,UnitCategory
        ,UnitOnline
        ,OutageType
    FROM dataengineering.oil_refinery_refineryunitdailystatus t
    inner join (
        SELECT VendorValue
        FROM dataengineering.oil_refinery_refineryunitmapping t
        inner join (
            select UNIT_ID FROM dataengineering.oil_refinery_unit_view t
            inner join (
                SELECT PLANT_ID
                FROM dataengineering.oil_refinery_plant
                where COUNTRY in ('SPAIN', 'UNITED KINGDOM', 'ITALY', 'FRANCE', 'BELGIUM', 'NETHERLANDS', 'DENMARK', 'GERMANY', 'POLAND', 'SLOVAKIA', 'HUNGARY', 'CZECH REPUBLIC')
            ) tm on t.PLANT_ID = tm.PLANT_ID
            WHERE t.UNIT_GROUP in ('CDU')
        ) tm on t.UNIT_ID = tm.UNIT_ID
    ) tm on t.UnitId = tm.VendorValue
    where isactive is true
    order by PDate desc
    """
    data = DataAccessApi.GetDataframe(query)
    data['capa'] = data['UnitCapacity'] * ~data['UnitOnline']
    data['PDate'] = pd.to_datetime(data['PDate'])
    return data.groupby('PDate')['capa'].sum() / 1e3

def upload_ara_stocks(tsa: timeseries):
    metadata = {
        'storage': {
            'series_id': 'diesel.ara.genscape.ending_stocks.kt.weekly',
            'product': 'diesel',
            'zone': 'ara',
            'source': 'genscape',
            'economic_property': 'ending_stocks',
            'unit': 'kt',
            'frequency': 'week',
        },
        'utilization': {
            'series_id': 'diesel.ara.genscape.storage_utilization.kt.weekly',
            'product': 'diesel',
            'zone': 'ara',
            'source': 'genscape',
            'economic_property': 'storage_utilization',
            'unit': 'kt',
            'frequency': 'week',
        }

    }
    data = get_ara_stocks().set_index('reportDate')
    data.index = pd.to_datetime(data.index)
    for k in metadata:
        try:
            tsa.update(
                metadata[k]['series_id'],
                data[k],
                'uploader'
            )
        except:
            print(f"{k} not imported as raw data")
        safely_update_metadata(tsa, metadata[k]['series_id'], metadata[k])


def upload_gulf_coast_status(tsa: timeseries):
    metadata = {
        'capacity': {
            'series_id': 'oil.gulf_coast.genscape.capacity.kbd.daily',
        },
        'available_capacity': {
            'series_id': 'oil.gulf_coast.genscape.available_capacity.kbd.daily',
        }
    }
    data = get_gulf_coast_daily_status()
    for k in metadata:
        tsa.update(
        metadata[k]['series_id'],
        data[k],
        'uploader'
        )
        safely_update_metadata(tsa, metadata[k]['series_id'], metadata[k])

def upload_ara_daily_status(tsa):
    data = get_ara_hck_daily_status()
    tsa.update(
        'diesel.genscape.ara.hck.outage.kbd.daily',
        data,
        author='loic.balland'
    )
    data = get_ara_fcc_daily_status()
    tsa.update(
        'diesel.genscape.ara.fcc.outage.kbd.daily',
        data,
        author='loic.balland'
    )
    data = get_ara_cdu_daily_status()
    tsa.update(
        'diesel.genscape.ara.cdu.outage.kbd.daily',
        data,
        author='behzad'
    )
    data = get_europe_hck_daily_status()
    tsa.update(
        'oil.genscape.europe.hck.outage.kbd.daily',
        data,
        author='behzad'
    )
    data = get_europe_fcc_daily_status()
    tsa.update(
        'oil.genscape.europe.fcc.outage.kbd.daily',
        data,
        author='behzad'
    )
    data = get_europe_cdu_daily_status()
    tsa.update(
        'oil.genscape.europe.cdu.outage.kbd.daily',
        data,
        author='behzad'
    )

if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    upload_gulf_coast_status(tsa)
    upload_ara_daily_status(tsa)
    upload_ara_stocks()
