from tshistory.api import timeseries
import pandas as pd
import numpy as np
from saturn_server import DG, HERE
from linearmodels import PanelOLS
from saturn_server.helpers import safe_register_formula, safe_update
from formulaic import Formula


def make_freight_matrix(tsa):
    excel = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\OilProd\clean_freight.xlsx'
    data = pd.read_excel(
        excel, header=list(range(8)), index_col=0)
    voyage = pd.read_csv(HERE / 'products' / 'data' / 'freight_travel_time.csv', index_col=0)
    for quote in data.columns:
        freight = DG.get_time_series(quote[-1], pd.Timestamp(2012, 1, 1), pd.Timestamp.now())
        freight.index = freight.index.tz_localize(None)
        data = data.reindex(freight.index)
        data[quote] = data[quote].combine_first(freight['PRICE'])
    long = data.stack(list(range(8))).rename('freight').reset_index()
    long['Time'] = pd.to_datetime(long['Time'])
    endog = long.set_index(['level_7', 'Time'])
    y, X = Formula("freight ~ np.log(size) + duration + destination -1").get_model_matrix(endog)
    mod = PanelOLS(y, X, time_effects=True)
    fitted = mod.fit()
    common_comp = fitted.estimated_effects.groupby(axis=0, level=[0, 1]).mean().unstack(0).iloc[:, 1]
    duration = voyage.stack() * fitted.params['duration']
    size = ((voyage.stack() * 0) + np.log(80)) * fitted.params['np.log(size)']
    destination = pd.Series(
        ("destination[T." + voyage.stack().index.get_level_values(0) +"]").map(fitted.params[:-2]),
        index = voyage.stack().index
    )
    total = duration + size + destination
    for (dest, source), scale in total.groupby(axis=0, level=[0, 1]):
        freight = (common_comp + scale.values).clip(lower=1)
        name = f'freight.petroineos.{source.lower()}.{dest.lower()}.clean_lr2_80kt.usd_t.daily'
        print(name)
        print(freight)
        tsa.update(
            name,
            freight,
            author='uploader',
        )
        formula = f"""(mul
                (series "{name}" #:fill "ffill")
                (options
                    (+
                        1
                        (series "tc5_spread_curve.usd_t.daily.cumsum"))
                    #:fill 1))"""
        safe_register_formula(tsa, name + ".forward", formula)
        

if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    make_freight_matrix(
        tsa
    )