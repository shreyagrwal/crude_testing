import requests
import pandas as pd

regions = dict(
oecd_north_america = 'https://api.iea.org/stats/?series=OIL&countries=OECDAM',
apac = 'https://api.iea.org/stats/?series=OIL&countries=WEOASIAPAC',
oecd_europe = 'https://api.iea.org/stats/?series=OIL&countries=OECDEUR',
)
print(regions)
demand = [
        "agriculture_forestry",
        "energy_industry_own_use", 
        "electricity_plants", 
        "final_consumption", 
        "fishing", 
        "industry", 
        "non_energy_use",
        "residential",
        "transport",
]

def load_iea_web(tsa, country, link):
    data = pd.DataFrame(requests.get(link).json())
    data.year = pd.to_datetime(data.year, format="%Y")
    data = data[data['product'] == 'NONBIODIES']
    data.value = data.value / (43.38 * 0.9) / 12 # TJ to kt
    data.flowLabel = data.flowLabel.str.lower().str.replace('/', '').str.replace('  ', ' ').str.replace(' ', '_').str.replace('-', '_')
    data = data.query('flowLabel in @demand')
    data.flowLabel = data.flowLabel.apply(lambda x: f"diesel.iea.{country}.{x}.ktm.yearly")
    data = data.set_index(['year'])
    for series_id, _data in data.groupby('flowLabel'):
        print(series_id)
        tsa.update(series_id, _data['value'], author='loicballand')

if __name__ == '__main__':
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    list(map(lambda x: load_iea_web(tsa, x[0], x[1]), regions.items()))