import requests
import pandas as pd
from pathlib import Path
from datetime import datetime as dt

ENV = 'PROD'
PATH_APPLICATION_FOLDER = Path(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department')
BULK_UPLOADER_FOLDER = PATH_APPLICATION_FOLDER / 'ApplicationFolder' / 'BatchUploader' / ENV
API_KEY = '65e4b9c1d531434eb181b504297d9f3f'

def get_products_ara_inventories():
    headers = {'Gen-Api-Key': API_KEY}
    ENDPOINT = f'https://api.genscape.com/storage/oil/v1/region-volumes' \
               f'?regions=Amsterdam,Rotterdam,Antwerp,Flushing&products=HeatingOil,GasolineComponents&' \
               f'revision=published&limit=2500&offset=0'
    response = requests.get(ENDPOINT, headers=headers)
    now = dt.now()
    date_fmt = '%y%m%d%H%M%S'
    prefix = 'Upload_OIL_GenscapeAraInventory'
    filename = f"{prefix}-{pd.Timestamp(now).strftime(date_fmt)}.csv"
    print(f'CSV path: {BULK_UPLOADER_FOLDER / filename}')
    data = pd.DataFrame.from_records(response.json()['data'])
    data.to_csv(BULK_UPLOADER_FOLDER / filename, index=False)

def get_druzbha_north(tsa):
    headers = {'Gen-Api-Key': API_KEY}
    ENDPOINT = "https://api.genscape.com/transportation/oil/v2/pipeline-flows/daily?regions=Europe&pipelineIDs=347&revision=revised&startDate=2020-03-03&offset=0"
    response = requests.get(ENDPOINT, headers=headers)
    data = pd.DataFrame.from_records(response.json()['data'])
    data = data.set_index('reportDate')
    data.index = pd.to_datetime(data.index)
    tsa.update(
        'crude.genscape.northern_druzbha.flows.kbd.daily',
        data['flowBpd'] / 1000,
        author='loic.balland'
    )
    return data

if __name__ == '__main__':
    get_products_ara_inventories()
    # from tshistory.api import timeseries
    # tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    # get_druzbha_north(tsa)
