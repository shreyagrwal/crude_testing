from vortexasdk import CargoMovements, Geographies, Products
from datetime import datetime as dt
from dateutil.relativedelta import relativedelta
import pandas as pd
import argparse
from pathlib import Path
import numpy as np

LOCS = {
    'events.cargo_port_load_event.0.location.port.label':'load_port',
    'events.cargo_port_load_event.0.location.country.label':'load_country',
    'events.cargo_port_load_event.0.location.region.label':'load_region',
    'events.cargo_port_load_event.0.location.shipping_region.label':'load_shipping_region',
    'events.cargo_port_load_event.0.location.terminal.label':'load_terminal',
    'events.cargo_port_load_event.0.location.sts_zone.label':'load_sts_zone',
    'events.cargo_port_load_event.0.location.trading_block.label':'load_trading_block',
    'events.cargo_port_load_event.0.location.trading_region.label':'load_trading_region',
    'events.cargo_port_load_event.0.location.trading_subregion.label':'load_trading_subregion',
    'events.cargo_port_unload_event.0.location.port.label':'unload_port',
    'events.cargo_port_unload_event.0.location.country.label':'unload_country',
    'events.cargo_port_unload_event.0.location.region.label':'unload_region',
    'events.cargo_port_unload_event.0.location.shipping_region.label':'unload_shipping_region',
    'events.cargo_port_unload_event.0.location.terminal.label':'unload_terminal',
    'events.cargo_port_unload_event.0.location.sts_zone.label':'unload_sts_zone',
    'events.cargo_port_unload_event.0.location.trading_block.label':'unload_trading_block',
    'events.cargo_port_unload_event.0.location.trading_region.label':'unload_trading_region',
    'events.cargo_port_unload_event.0.location.trading_subregion.label':'unload_trading_subregion',
    'vessels.0.name': 'vessel_name',
}

DATES_COLS = {
    'events.cargo_port_load_event.0.end_timestamp': 'load_timestamp',
    'events.cargo_port_unload_event.0.start_timestamp': 'unload_timestamp',
}

COLUMNS = {
    'cargo_movement_id': 'cargo_movement_id',
    'product.grade.label': 'grade',
    'product.group_product.label':'group_product',
    'product.category.label': 'product_category',
    'product.category.probability': 'product_category_probability',
    'quantity': 'quantity_tonnes',
    'status': 'status',
    'vessels.0.imo':'vessel_imo',
    'vessels.0.vessel_class': 'vessel_class',
    'parent_ids.0.id': 'parent_id_0', 
    'parent_ids.1.id': 'parent_id_1',
    **LOCS,
    **DATES_COLS,
}

def write_csv(bulk_folder: str, prefix: str, vintage: pd.Timestamp, data: pd.DataFrame) -> None:
    date_fmt = '%y%m%d%H%M%S'
    data_split = np.array_split(data, 10)
    for i, data in enumerate(data_split):
        suffix = f"{prefix}-{vintage.strftime(date_fmt)}-{i}.csv"
        filename = bulk_folder / suffix
        data.to_csv(filename, index=False, encoding="latin")
        print(f'CSV path: {filename}')


def get_vortexa_api(look_back_days, look_forward_days, database='adi', n=5):
    ENV = 'PROD'
    PATH_APPLICATION_FOLDER = Path(
            r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department')
        
    if database == 'adi':
        BULK_UPLOADER_FOLDER = PATH_APPLICATION_FOLDER / \
            'ApplicationFolder' / 'BatchUploader' / ENV
    elif database == 'blueocean':
        BULK_UPLOADER_FOLDER = PATH_APPLICATION_FOLDER / \
            'ApplicationFolder' / 'BlueOceanBlobDataUploader' / ENV / 'incoming'
    now = dt.utcnow()
    today = dt(now.year, now.month, now.day)
    forward = today + relativedelta(days=look_forward_days or 90)
    backward = (today - relativedelta(days=look_back_days)) if look_back_days else dt(2016, 1, 1)
    prods = Products().search(term="Clean Petroleum Products", exact_term_match=True).to_list()[0].id
    history = pd.date_range(backward, forward, freq='D')
    results = []
    for histories in np.array_split(history, n if (forward - backward).days > 400 else 1):
        search_result = CargoMovements().search(
            filter_activity='loading_state',
            filter_time_min=histories[0],
            filter_time_max=histories[-1],
            filter_products=prods,
            cm_unit='t',
        )
        df = search_result.to_df(columns=list(COLUMNS.keys()))
        results.append(df)
    df = pd.concat(results, axis=0, ignore_index=True)
    for d in DATES_COLS:
        df[d] = df[d].dt.floor('D').dt.strftime('%Y-%m-%d %H:%M:%S')
    for ugly in LOCS:
        df[ugly] = df[ugly].astype(str).str.replace(r'[^\x00-\x7F]+', '', regex=True).str.replace(",","").str.replace("'","").replace('nan',np.nan)
    df = df.rename(columns=COLUMNS)
    df['pdate'] = pd.Timestamp(today)
    df['pdate'] = df['pdate'].dt.strftime('%Y-%m-%d %H:%M:%S')
    write_csv(BULK_UPLOADER_FOLDER, 'Upload_OIL_VortexaCleanProducts', today, df)
    

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='get vortexa db')
    parser.add_argument('-lb', '--look_back_days', type=int, required=False)
    parser.add_argument('-lf', '--look_forward_days', type=int, required=False)
    parser.add_argument('-db', '--database', choices=['blueocean', 'adi'], type=str, required=False)
    args = parser.parse_args()
    get_vortexa_api(args.look_back_days, args.look_forward_days, args.database)