import os
from pathlib import Path
import re
import argparse
from itertools import product
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime as dt


SIZES = [90, 60, 35]
PROPER_SIZES = ["LR2", "LR1", "MR"]
SIZES_VALS = dict(zip(PROPER_SIZES, SIZES))
SIZES = ["LR2's", "LR1's", "MR's"]
STATUSES = ["CARGOES", "ONSUBS", "FXD/FLD"]
PROPER_STATUSES = ["CARGOES", "SUBS", "FIXED/FAILED"]
COLS = ['player', 'laycan', 'size_cargo', 'origin',
        'destination', 'tanker_name', 'rate', 'status']
SIZES_DICT = dict(zip(SIZES, PROPER_SIZES))
STATUSES_DICT = dict(zip(STATUSES, PROPER_STATUSES))

def nextoccurrenceof(ref_date: dt, month: int, day: int) -> dt:
    pseudo_date = dt(year=ref_date.year, month=month, day=day)
    if pseudo_date <= ref_date:
        next_occurrence = pseudo_date.replace(year=pseudo_date.year + 1)
    else:
        next_occurrence = pseudo_date
    return next_occurrence


def lastoccurrenceof(ref_date, month, day):
    pseudo_date = dt(year=ref_date.year, month=month, day=day)
    if pseudo_date > ref_date:
        last_occurrence = pseudo_date.replace(year=pseudo_date.year - 1)
    else:
        last_occurrence = pseudo_date
    return last_occurrence


def select_along_first(table, filter_item, filter_list):
    """
    Isolate sections of the email body.
    """
    table = table.reset_index(drop=True)
    idx = filter_list.index(filter_item)
    start = table.query('player == @filter_item').index[0] + 1
    if len(filter_list) - 1 == idx:
        end = None
    else:
        end = table.query('player == @filter_list[@idx + 1]').index[0]
    return table[start:end]


def regularize_columns(table, asof, status, size, statuses_dict, sizes_dict):
    """
    Handles sections problematic colums for better db ingestion.
    """
    string_cols = [x for x in COLS if x not in ['size_cargo', 'laycan']]
    added_cols = ['lay', 'can', 'tanker_type', 'type', 'size', 'cargo']
    columns = string_cols + added_cols
    if (not table.empty) and (not table.origin.isna().any()):
        cargoes = table.size_cargo.str.split(
            pat=r'(\d+)(\s+)([A-Za-z]+)', expand=True)[[1, 3]]
        cargoes.columns = ['size', 'cargo']
        try:
            laycan = table.laycan.str.split(
                pat=r'(\d+)(-)(\d+)(\s+)([A-Za-z]+)', expand=True)[[1, 3, 5]]
        except:
            # Handes when the broker says mid nov, early dec and all those funky stuff
            laycan = table.laycan.str.split(
                pat=r'(\w+)(\s+)([A-Za-z]+)', expand=True)[[0, 1, 3]]
            if laycan[1].iloc[0] in ('Ely',):
                laycan[0], laycan[1] = "1", "5"
            if laycan[1].iloc[0] in ('Mid',):
                laycan[0], laycan[1] = "10", "20"
            if laycan[1].iloc[0] in ('End',):
                laycan[0], laycan[1] = "25", "28"
            else:
                laycan[0], laycan[1] = 1, 28
        laycan.columns = ['lay', 'can', 'month']
        fmt = '%d%b%Y'
        # Big assumption, if there is weird data, use the laycan below or above
        laycan = laycan.fillna(method='bfill').fillna(method='ffill')
        can = pd.to_datetime(
            laycan['can'] + laycan['month'] + str(asof.year), format=fmt)
        # back one month ago to not jump by a year when the laycan is lagging a bit much
        can = can.apply(lambda x: nextoccurrenceof(
            asof + pd.DateOffset(months=-1), x.month, x.day))
        # handles laycan across months
        cond = laycan.lay.astype(int) <= laycan.can.astype(int)
        lay_month = can.where(cond, can + pd.DateOffset(months=-1))
        try:
            lay = pd.to_datetime(
                laycan['lay'] + lay_month.dt.strftime('%b') + can.dt.year.astype(str), format=fmt)
        except:
            # Sometimes the month is the one of lay, not can
            lay = pd.to_datetime(
                laycan['lay'] + can.dt.strftime('%b') + can.dt.year.astype(str), format=fmt)
        datas = (table.drop(['size_cargo', 'laycan'], axis=1),
                 cargoes, lay.rename('lay'), can.rename('can'))
        data = pd.concat(datas, axis=1)
        data['tanker_name'] = data['tanker_name'].fillna(
            'TBN')  # To be nominated
        data['tanker_type'], data['type'] = sizes_dict[size], statuses_dict[status]
        _string_cols = string_cols + ['tanker_name', 'tanker_type']
        for col in _string_cols:
            data[col] = data[col].str.replace(
                r'[^A-Za-z0-9-.\s]+', ' ', regex=True)
        data['destination'] = data['destination'].fillna('OPTIONS')
        data['size'] = data['size'].fillna(SIZES_VALS[SIZES_DICT[size]])

    else:
        data = pd.DataFrame(columns=columns)
    return data[columns]


def sanity_date(email_date, data, yearformat='%Y'):
    """
    Check what date format could be the most likely between the report date and the email subject date
    """
    options = {
        'daymonth': f'%d/%m/{yearformat}',
        'monthday': f'%m/%d/{yearformat}',
    }
    asof_option = dict()

    try:
        asof_option['monthday'] = pd.to_datetime(
            data.iloc[0, 1], format=options['monthday'])
        infered_date = (pd.Series(asof_option) -
                        email_date).apply(abs).sort_values().index[0]
        return asof_option[infered_date]
    except:
        asof_option['daymonth'] = pd.to_datetime(data.iloc[0, 1], 
        format=options['daymonth'])
        return asof_option['daymonth']


def process_asof_date(email_date, data):
    try:
        return sanity_date(email_date, data, yearformat='%Y')
    except:
        return sanity_date(email_date, data, yearformat='%y')


def _process_email(email_date, data):
    """
    Loop over all dimensions of the dataset and create a vintage date column
    """
    asof = process_asof_date(email_date, data)
    data.columns = COLS
    data.player = data.player.str.replace(
        r'(\s+)', '', regex=True)  # Strip whitespaces
    regularized = []
    for size, status in product(SIZES, STATUSES):
        regularized.append(
            regularize_columns(
                select_along_first(
                    select_along_first(data, size, SIZES), status, STATUSES),
                asof, status, size, STATUSES_DICT, SIZES_DICT
            )
        )
    data = pd.concat(regularized, axis=0)
    data['PDate'] = asof
    return asof, data.reset_index(drop=True)


def process_whole_email(link):
    """
    Process an HTML file to give a table
    """
    with open(link, "r") as f:
        print(link)
        soup = BeautifulSoup(f, features="lxml")
        email_title = [x.parent for x in soup.find_all(
            'b') if x.text == 'Subject:'][-1].text.split('\n')[-1]
        components = re.findall(r'\d+', email_title)
        components[-1] = components[-1][-4:]
        email_date = pd.to_datetime(''.join(components), format='%d%m%Y')
        table = soup.find('table', {'class': 'MsoNormalTable'})
        raw_table = pd.read_html(str(table))[0]
        data = raw_table.dropna(axis=0, how='all').dropna(
            axis=1, how='all').T.drop_duplicates().T
        return _process_email(email_date, data)


def write_csv(bulk_folder: str, prefix: str, vintage: dt, data: pd.DataFrame) -> None:
    date_fmt = '%y%m%d%H%M%S'
    suffix = f"{prefix}-{pd.Timestamp(vintage).strftime(date_fmt)}.csv"
    filename = bulk_folder / suffix
    data.to_csv(filename, index=False)
    print(f'CSV path: {filename}')


def main(n_emails):
    ENV = 'PROD'
    PATH_APPLICATION_FOLDER = Path(
        r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department')
    EMAIL_FOLDER = PATH_APPLICATION_FOLDER / 'Providers External' / 'BRS'
    BULK_UPLOADER_FOLDER = PATH_APPLICATION_FOLDER / \
        'ApplicationFolder' / 'BatchUploader' / ENV
    emails = os.listdir(EMAIL_FOLDER)
    emails_path = [(EMAIL_FOLDER / e, os.path.getmtime(EMAIL_FOLDER / e))
                   for e in emails
                   if os.path.isfile(EMAIL_FOLDER / e)]
    recent_emails_path = sorted(emails_path, key=lambda x: x[-1])
    if isinstance(n_emails, int):
        recent_emails_path = recent_emails_path[-int(n_emails):]
    csvs = list(map(lambda x: process_whole_email(x[0]), recent_emails_path))
    prefix = 'Upload_OIL_BrsFixtures'
    for vintage, data in csvs:
        write_csv(BULK_UPLOADER_FOLDER, prefix, vintage, data)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Process BRS Fixtures emails')
    parser.add_argument('-n', '--emails', type=int, required=False,
                        help='number of report to process, if left black, processes everything')
    main(parser.parse_args().emails)
