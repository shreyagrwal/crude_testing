import tabula
import os
from pathlib import Path
import pandas as pd
import argparse

COLS = 'VESSEL,CHRTRS,VOL,GRADE,LC,LOAD,DISCH,ETA/ATA,DATE,STATUS'.split(',')

def parse_date(date):
    now = pd.Timestamp.now()
    offset = [-1, 0, 1]
    candidates = [pd.Timestamp(f'{date}-{now.year + o}') for o in offset]
    closest_choice = [abs((c - now).days) for c in candidates]
    closest = min(closest_choice)
    return dict(zip(closest_choice, candidates))[closest]

def extract_clarksons(report_type, report_path, destinations):
    tables = tabula.read_pdf(report_path, pages="all", stream=True, multiple_tables=True)
    tables[0].columns = COLS
    table = tables[0].assign(TRADING_REGION_DESTINATION=lambda x: x.VESSEL.map(destinations).ffill())
    table = table.dropna(axis=0, subset=['LC'])
    table.LC = table.LC.apply(parse_date)
    table.DATE = table.DATE.ffill().apply(parse_date)
    table['CARGO_TYPE'] = report_type
    table = table.rename(columns={'ETA/ATA': 'ETA_ATA', 'DATE': 'DISCHARGE_DATE', 'LOAD': 'LOADING_PORT'})
    table['VESSEL'] = table['VESSEL'].str.replace("'","").str.replace(".","") 
    return table

def write_csv(bulk_folder: str, prefix: str, vintage: pd.Timestamp, data: pd.DataFrame) -> None:
    date_fmt = '%y%m%d%H%M%S'
    suffix = f"{prefix}-{vintage.strftime(date_fmt)}.csv"
    filename = bulk_folder / suffix
    data.to_csv(filename, index=False)
    print(f'CSV path: {filename}')

def process_pdfs(filters, destinations, product_name, report_prefix, n_reports):
    ENV = 'PROD'
    PATH_APPLICATION_FOLDER = Path(
        r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department')
    BULK_UPLOADER_FOLDER = PATH_APPLICATION_FOLDER / 'ApplicationFolder' / 'BatchUploader' / ENV
    download_path = PATH_APPLICATION_FOLDER / 'Providers External' / 'Clarksons'
    files = [x for x in os.listdir(download_path) if any([keyword for keyword in filters if keyword in x])] 
    filtered_files = sorted(files, key=lambda x: os.path.getmtime(download_path / x))[-n_reports:]
    files_time = {filename: os.path.getmtime(download_path / filename) for filename in filtered_files}
    for file, time in files_time.items():
        try:
            data = extract_clarksons(product_name, download_path / file, destinations)
            pdate = pd.Timestamp.fromtimestamp(time).floor('D')
            data['pdate'] = pd.Timestamp.fromtimestamp(time).floor('D')
            write_csv(BULK_UPLOADER_FOLDER, report_prefix + f'-{product_name}', pdate, data)
        except:
            pass

def get_clarksons_adi(reports):
    destinations = {
        'MED/UKC': 'MED/UKC', 
        'USA / CARIBS': 'USA / CARIBS',
        'USA / CANADA / CARIBS': 'USA / CANADA / CARIBS',
        'WCCAM / SAM / WAF':  'WCCAM / SAM / WAF',
        'SAM / WCSAM / WCCAM': 'SAM / WCSAM / WCCAM', 
        'WAF': 'WAF', 
        'EAST': 'EAST', 
        'MED/BS/UKC/SCANDEN/BALTIC':'MED/UKC'
    }
    report_prefix = 'Upload_OIL_ClarksonsCleanAGFixture'
    filters = ('JET',)
    product_name = 'JET'
    process_pdfs(filters, destinations, product_name, report_prefix, reports or 1)
    filters = ('ULSD', 'GO', 'DIST')
    product_name = 'ULSD_GO'
    process_pdfs(filters, destinations, product_name, report_prefix, reports or 1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Clarksons scraper')
    parser.add_argument('-r', '--reports', type=int, required=False,
                    help='number of reports to process')
    args = parser.parse_args()
    get_clarksons_adi(args.reports)
