import pandas as pd
import numpy as np
from tshistory.api import timeseries

def main():
    data = pd.read_excel(
        r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\Providers External\Transafe\Fuel_Circulaire_PITL_2022.xls',
            sheet_name='DATA entry', skiprows=range(4), usecols='A:F')
    data.index = data.iloc[:, 0].rename('date')
    kaub = data.iloc[:, -1].dropna(axis=0)
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    tsa.update(
        'oil.transafe.kaub.water_level.cm.daily',
        kaub,
        author='loic.balland'
    )

if __name__ == '__main__':
    main()