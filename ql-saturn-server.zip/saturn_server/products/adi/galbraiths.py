import pandas as pd
import os
from pathlib import Path
from tshistory.api import timeseries

from tqdm.contrib.concurrent import thread_map

def _read_galbraith_csv(path):
    data = pd.read_excel(path, engine='openpyxl')
    data = data.ffill()
    data.columns = data.columns.str.upper() 
    return data

def _get_departures(path, cgo, origin, destination=None):
    data = _read_galbraith_csv(path)
    mask = data.CGO.str.contains(cgo) & data.FROM.str.fullmatch(origin)
    if destination is not None:
        mask = mask & data.TO.str.fullmatch(destination)
    data = data[mask]
    data = data.drop(["BLT", "DWT", "RATE", "DEMUR"],axis=1)
    if any(mask):
        data.LAYCAN = pd.to_datetime(data.LAYCAN, format="%Y-%m-%d %H:%M:%S", errors='coerce')
        data.LAYCAN = data.LAYCAN.fillna(pd.Timestamp.today())
        data['WEEK'] = data.LAYCAN.dt.to_period('W-FRI').dt.end_time.dt.floor('D')
        return data

def get_ara_departures(path):
    return _get_departures(path, 'ULSD|GO|GTL|DIST', 'ARA')

def get_us_gulf_departures(path):
    return _get_departures(path, 'ULSD|GO|GTL|DIST', 'USG')

def get_ag_china_departures(path):
    return _get_departures(path, 'DTY', 'ARABIAN GULF', 'CHINA')

def get_latest_report(get_func, n_reports=2000):
    folder = Path(
        r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\Providers External\Galbraiths')
    files = os.listdir(folder)
    filtered_files = sorted(
        filter(lambda x: x.endswith('xlsx'), files), 
        key=lambda x: os.path.getmtime(folder / x)
        )[-n_reports:]
    return pd.concat(thread_map(lambda x: get_func(folder / x), filtered_files, max_workers=10), axis=0)

def cargo_count(tsa, data, series_id):
    data = data.sort_values('DATE').groupby(["IMO #"]).last()
    data = data[data.STATUS.str.fullmatch('RPTD')]
    tsa.update(
        series_id,
        data.groupby('WEEK')['SIZE'].sum() / 1e3,
        author='loic.balland'
    )
    return data

def galbraiths_count(tsa):
    save_folder = Path(
        r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\OilProd\GalbraithsFixtures')
    dataset = get_latest_report(_read_galbraith_csv)
    dataset.iloc[:, :15].to_csv('galbraiths.csv', index=False)
    china = get_latest_report(get_ag_china_departures)
    china = cargo_count(tsa, china, 'diesel.galbraiths.ag.china.exports.kt.weekly')
    china.to_csv(save_folder / 'ag_china.csv')
    ara = get_latest_report(get_ara_departures)
    ara = cargo_count(tsa, ara, 'diesel.galbraiths.ara.exports.kt.weekly')
    ara.to_csv(save_folder / 'ara_departures.csv')
    usgulf = get_latest_report(get_us_gulf_departures)
    usgulf = cargo_count(tsa, usgulf, 'diesel.galbraiths.us_gulf.exports.kt.weekly')
    usgulf.to_csv(save_folder / 'usgulf_departures.csv')

if __name__ == '__main__':
    galbraiths_count(
        timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    )