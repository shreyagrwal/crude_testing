from typing import Optional, List
from datetime import datetime as dt
from numbers import Number

import pandas as pd
import numpy as np


from tshistory_formula.registry import func, metadata, history

from saturn_server.products.models.fit import forecasts


@func('smoothed_forecasts')
def smoothed_forecasts(
        __interpreter__,
        model_name:str,
        frequency:str,
        end_date: pd.Timestamp,
        *serieslist:pd.Series) -> pd.Series:
    """
    smooth forecast operator taking existing models and running the forecast
    """
    from tshistory_refinery import helper
    tsa = helper.apimaker(helper.config())
    args = __interpreter__.getargs.copy()
    fromdate = args.get('from_value_date')
    todate = args.get('to_value_date')
    return forecasts(
        tsa,
        serieslist, 
        model_name, 
        frequency, 
        False, 
        fromdate,
        todate,
        end_date,
    )