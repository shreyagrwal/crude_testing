. $PSScriptRoot\common.ps1



$reworkPath=Join-Path -Path $global:VenvFolder -ChildPath "Scripts/rework.exe"

Write-Host $reworkPath




KillAllReworkProcesses
LaunchAllWorkersOneByOne
Write-Host "All workers launched"
Get-Location
