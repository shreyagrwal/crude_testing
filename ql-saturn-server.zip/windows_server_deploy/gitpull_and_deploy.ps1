. $PSScriptRoot\common.ps1

Write-Host "This script will do a GIT pull of ql-saturn-server and then re-start IIS, followed by installation of packages"

$repoUrl="https://petroineostrading@dev.azure.com/petroineostrading/DataAnalysis/_git/ql-saturn-server"
$global:Branchname="feature/pbi-8747-run-loic-worker-code-on-ap12-with-aurelien"  # should come from environment
$Global:CloneUrl=$null



###########################

function VerifyPattoken()
{
    $Global:pattoken=$env:saturnpattoken
    if ([string]::IsNullOrWhiteSpace($pattoken))
    {
        Write-Error -Message "The environment variable 'saturnpattoken' was not found. We need this to do a GIT clone"
    }
    else
    {
        Write-Host "The PAT token was found in the environment vartiable 'saturnpattoken'"
    }
    $Global:CloneUrl="https://{0}@dev.azure.com/petroineostrading/DataAnalysis/_git/ql-saturn-server" -f $global:pattoken
}

function GetCodeAndBranch()
{
    if (Test-Path -Path $global:SourceFolder)
    {
        Write-Host "Deleting $global:SourceFolder"
        Get-ChildItem -Path $global:SourceFolder -Recurse -Force | Remove-Item -force -recurse
        Remove-Item -Path $global:SourceFolder -Force -Recurse
        Write-Host "Deletion of $global:SourceFolder is done"
    }
    else
    {
        Write-Host "Not deleting the folder $global:SourceFolder because it was not found"
    }

    Write-Host "Going to clone to $global:SourceFolder"

    & git clone $Global:CloneUrl  $global:SourceFolder
    Write-Host "git clone is done"

    Write-Host "Git pull begin"
    Push-Location $global:SourceFolder
    & git pull
    Pop-Location
    Write-Host "Git pull complete"

    Push-Location $global:SourceFolder
    & git checkout $global:Branchname
    & git branch

    Pop-Location

}



Write-Host "Current environment is '$global:environment'"
VerifyPattoken

Write-Host "The repo is $repoUrl"
Write-Host "The repo will be installed to $global:SourceFolder"

StopIISPool -pool $Global:IISAppPool
GetCodeAndBranch
UpdateWebConfig
StartIISPool -pool $Global:IISAppPool

<#
$webconfigTemplate=Join-Path -Path $global:SourceFolder -ChildPath "windows_server_deploy\iis\web.config.template"
$webconfigContent= Get-Content -Path $webconfigTemplate
#>
