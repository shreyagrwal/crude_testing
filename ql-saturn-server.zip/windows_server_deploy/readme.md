[[_TOC_]]


# About
This is a README which I created while migrating to newer version of Saturn. 



# gitpull_and_deploy.ps1
This is a temporary measure . 
1. Stop IIS
1. We are pulling the code from GIT
1. Copy over the code to IIS folder
1. Update the web.config with the path of Phython from the VENV folder
1. Start IIS

# What is the future?
We have already implemented a CI/CD pipeline which copies over source files to \\TST-QDEV-AP12\AzureDevops\ql-saturnserver\.
Therefore no need for "git clone and git pull" . Just raise a PR and kick off the pipeline

# Who does the IIS stop and start ?
While we wait for running the CI/CD pipeline on AP12. The intermediate measure is to trigger via Active Batch job

# How many Active Batch scripts do we need ?
Two
1. Copy over sources to IIS foler and after having stopped IIS
1. Stop IIS, copy over sources and then re-create the VENV.

---

# How to restore from backup of AP9?

## Steps involved
1. Do a remote desktop to **AP12**
2. Clone this repo to some folder on AP12. Example: `c:\work\mycode`
3. Launch a PowerShell prompt with elevated Administrator rights
5. **Attention!** Do not use Powershell ISE to run this script. It does not work! I do not know why.
6. Set the following environment variables 
   1. `$env:environment="dev"`
   2. `$env:PGPASSWORD=Pass@*****`
4. Change the folder `c:\work\mycode\windows_server_deploy\` using `cd` command
5. Run the script `.\restore_recent_backup_from_prod_to_dev.ps1`
6.  This will take a long time (30 minutes or more) and might require you to respond to an user prompt (Can't change this!)
 


![powershell_prompt_example!](docs/powershell_prompt_example.png)


## How to test if the database was refreshed?

1. Connect to POSTGRES instance on AP12 using Azure Data Studio
2. You should see the following database listed 
3. Look into the table `rework.log` and you should see activity dating to the last moments before the backup was restored


![rework table!](docs/rework_log_table.png)

---
