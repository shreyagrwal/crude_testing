. $PSScriptRoot\common.ps1


$BackupLocation="\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\Saturn\Database Backups\ap9"
$PostgresBinFolder=Join-Path -Path $env:ProgramFiles -ChildPath "PostgreSQL\15\bin\"
$TempDatabaseName="temp_restore_ap9"
$DevDatbaseName="devsaturndatabase"
$StdErrFile=Join-Path -Path $PSScriptRoot  -ChildPath "errors.txt"
$Psql=Join-Path -Path $PostgresBinFolder -ChildPath "psql.exe"


function ThrowErrorIfExitCode($message){
    if (0 -eq $LASTEXITCODE){
        return
    }
    Write-Error -Message $message
}

###########################################

#
#Check for presence of PGPASSWORD
#
if ($null -eq $env:PGPASSWORD)
{
    Write-Error -Message "The environment variable PGPASSWORD was not set"
}

$backups=Get-ChildItem -Path $BackupLocation -Filter "*.back"  | Sort-Object -Descending -Property LastWriteTimeUtc
$backups

$MostRecentBakcup = $backups[0].FullName
Write-Host "the most recent backup fie is $MostRecentBakcup"





if ((Test-Path -path $PostgresBinFolder) -eq $false)
{
    Write-Error -Message "The Postgres folder $PostgresBinFolder was not found"
}
Write-Host "The folder $PostgresBinFolder exists"



<#
Create role SVC-QDEV-TST

Write-Host "Going to create the role SVC-QDEV-TST"
& $Psql --username postgres -h localhost   -c  "CREATE ROLE `"SVC-QDEV-TST`" LOGIN;  "
Read-Host -Prompt "Wait wait"
#>

Write-Host "Checking for live connections to the database  $TempDatabaseName"
& $Psql --username postgres -h localhost   -c  "SELECT COUNT(*) FROM pg_stat_activity WHERE datname= '$TempDatabaseName' "


Write-Host "Forcing all connections to the database $TempDatabaseName"
& $Psql --username postgres -h localhost   -c  "SELECT  pg_terminate_backend(pid) FROM  pg_stat_activity WHERE datname= '$TempDatabaseName'"


Write-Host "Begin-Going to drop the database $TempDatabaseName if it exists"

<#
Using the try-catch approach because I found no other way to avoid STDERROR from psql halting the execution
https://stackoverflow.com/questions/75766127/need-to-handle-psql-errors-in-powershell
#>
try
{
& $Psql --username postgres -h localhost   -c  "DROP DATABASE IF EXISTS $TempDatabaseName;"  
ThrowErrorIfExitCode -message "Could not drop database $TempDatabaseName"
}
catch
{
}
Write-Host "DROP complete"



<#
Create the database
#>

& "$PostgresBinFolder\createdb.exe" --username=postgres $TempDatabaseName
ThrowErrorIfExitCode -message "Could not create an empty database $TempDatabaseName"
Write-Host "CREATEDB of $TempDatabaseName complete"


<#
Restore the database
#>

try
{
& "$PostgresBinFolder\pg_restore.exe" --username=postgres --dbname=$TempDatabaseName $MostRecentBakcup
ThrowErrorIfExitCode -message "Could not restore backup from path: $MostRecentBakcup to the new database: $TempDatabaseName"
}
catch
{
}

Write-Host "The database backup: $MostRecentBakcup was restored to $TempDatabaseName"


<#
Active the Python environment
Run the file metadatacheck.py
#>

& $global:VenvFolder\Scripts\Activate.ps1
Write-Host "Activating the venv at $Global:VenvFolder"


<#
Run metadatacheck.py to fix the meta-data of the database
#>



$encodedPassword=[System.Net.WebUtility]::UrlEncode($env:PGPASSWORD)
$cnstring="postgresql://postgres:$encodedPassword@TST-QDEV-AP12/$TempDatabaseName"

$pathtometadatafix=Join-Path -Path $global:RootFolder -ChildPath "$env:environment\code\upgrade_fix\metadatacheck.py"
$pathtocfgTemplate=Join-Path -Path $global:RootFolder -ChildPath "$env:environment\code\upgrade_fix\tshistory.template.cfg"
$pathtocfgActual=Join-Path -Path $global:RootFolder -ChildPath "$env:environment\code\upgrade_fix\tshistory.cfg"

Write-Host "Begin-Fixing meta-data by running the Python file $pathtometadatafix"
& python $pathtometadatafix $cnstring
Write-Host "Fixing meta-data complete. "




<#
Run the tsh upgrade
#>
Write-Host "Going to replace with new cn string:  $cnstring"
$raw=Get-Content -Path $pathtocfgTemplate -Raw
Write-Host "Raw content:"
$raw
$modifiedTemplateContent=$raw.Replace("cnstring_comes_here",$cnstring)

$Utf8NoBomEncoding = New-Object System.Text.UTF8Encoding $False
#
#You should save without the BOM, otherwise Python cannot read! Do not use Out-file
#
[System.IO.File]::WriteAllLines($pathtocfgActual, $modifiedTemplateContent, $Utf8NoBomEncoding)
Write-Host "Modified the CN string in the template file $pathtocfgActual"



Write-Host "Runinng tsh migrate command"
$folderWithCfg=[System.IO.Path]::GetDirectoryName($pathtocfgActual)
Push-Location -Path  $folderWithCfg
Write-Host "Current location is "
$PWD.Path
& tsh.exe migrate --interactive uri
Pop-Location



<#
Stop all connection to DEV
#>
Write-Host "Begin-Forcing all connections to the database $DevDatbaseName"
& $Psql --username postgres -h localhost   -c  "SELECT  pg_terminate_backend(pid) FROM  pg_stat_activity WHERE datname= '$DevDatbaseName'"
Write-Host "End-Forcing all connections to the database $DevDatbaseName"



<#
Drop database DEV
#>
Write-Host "Begin-Dropping all connections to the database $DevDatbaseName"
& $Psql --username postgres -h localhost   -c  "DROP DATABASE $DevDatbaseName;"
Write-Host "End-Dropping all connections to the database $DevDatbaseName"


<#
Stop all connections to TEMP
#>
Write-Host "Forcing all connections to the database $TempDatabaseName"
& $Psql --username postgres -h localhost   -c  "SELECT  pg_terminate_backend(pid) FROM  pg_stat_activity WHERE datname= '$TempDatabaseName'"



<#
Rename the TEMP to DEV
#>
Write-Host "Begin-Rename the database $TempDatabaseName to the database $DevDatbaseName"
& $Psql --username postgres -h localhost   -c  "ALTER DATABASE $TempDatabaseName RENAME TO $DevDatbaseName;"
Write-Host "End-Rename the database $TempDatabaseName to the database $DevDatbaseName"


