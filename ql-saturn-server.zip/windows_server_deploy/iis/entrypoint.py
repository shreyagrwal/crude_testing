from waitress import serve
import logging
import logging.handlers
import os
import datetime
import os
import sys



print(f"Inside  {__file__}")
print("Going to initialize logging")
BASE_LOG_FOLDER="c:/petroineos/logs/saturnweb"
MAX_LOG_BACKUP_COUNT=7000



def configure_logging():
    d=datetime.datetime.now()
    log_file_name="current.log"
    log_file_path=os.path.join(BASE_LOG_FOLDER,os.environ["environment"],log_file_name)

    print(rf"this log will be created in this file: {log_file_path}")
    file_handler = logging.handlers.TimedRotatingFileHandler(filename=log_file_path, when="M" ,  interval=1, backupCount=MAX_LOG_BACKUP_COUNT)
    logging.basicConfig(format='%(asctime)s %(levelname)s %(filename)s %(lineno)d: %(message)s',
                        encoding='utf-8', level=logging.INFO,
                        handlers=[file_handler,logging.StreamHandler(sys.stdout)])
    logging.info(f"Logging was initialized at {d}")


configure_logging()    
from saturn_server.wsgi import app
logging.info(f"Going to call waitress.serve")
serve(app, host='0.0.0.0', port=int(os.environ["ASPNETCORE_PORT"]), threads=16, channel_timeout=1800)
