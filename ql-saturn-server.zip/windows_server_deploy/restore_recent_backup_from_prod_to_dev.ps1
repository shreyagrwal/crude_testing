<#
When to use this script?
------------------------
You want to do some testing on DEV. You want the latest Saturn series.
To do achieve this, you want to refresh the DEV instance with the most recent database backup from PROD.
#>

. $PSScriptRoot\common.ps1


$BackupLocation="\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\Saturn\Database Backups\ap9-2024"
$PostgresBinFolder=Join-Path -Path $env:ProgramFiles -ChildPath "PostgreSQL\11\bin\"
$TempDatabaseName="temp_restore_ap9"
$DevDatbaseName="ap9_2024_restore"
$StdErrFile=Join-Path -Path $PSScriptRoot  -ChildPath "errors.txt"
$Psql=Join-Path -Path $PostgresBinFolder -ChildPath "psql.exe"
$StartTime=Get-Date

function ThrowErrorIfExitCode($message){
    if (0 -eq $LASTEXITCODE){
        return
    }
    Write-Error -Message $message
}

###########################################

#
#Check for presence of PGPASSWORD
#
if ($null -eq $env:PGPASSWORD)
{
    Write-Error -Message "The environment variable PGPASSWORD was not set"
}

$backups=Get-ChildItem -Path $BackupLocation -Filter "*.back"  | Sort-Object -Descending -Property LastWriteTimeUtc
$backups

$MostRecentBakcup = "\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\Saturn\Database Backups\ap9-2024\16-Jun-2024-03-00.back"
# $backups[0].FullName
Write-Host "the most recent backup fie is $MostRecentBakcup"





if ((Test-Path -path $PostgresBinFolder) -eq $false)
{
    Write-Error -Message "The Postgres folder $PostgresBinFolder was not found"
}
Write-Host "The folder $PostgresBinFolder exists. Very good"

<#
We wil create a Temp database where the backup can be restored
#>
Write-Host "Checking for live connections to the database  $TempDatabaseName"
& $Psql --username postgres -h localhost   -c  "SELECT COUNT(*) FROM pg_stat_activity WHERE datname= '$TempDatabaseName' "

<#
Ensure that all connections to the database are killed before we can drop the Temp database
#>
Write-Host "Forcing all connections to the database $TempDatabaseName"
& $Psql --username postgres -h localhost   -c  "SELECT  pg_terminate_backend(pid) FROM  pg_stat_activity WHERE datname= '$TempDatabaseName'"


<#
Drop the Temp database if it does not exist
#>
Write-Host "Begin-Going to drop the database $TempDatabaseName if it exists"


<#
Using the try-catch approach because I found no other way to avoid STDERROR from psql halting the execution
https://stackoverflow.com/questions/75766127/need-to-handle-psql-errors-in-powershell
#>
try
{
& $Psql --username postgres -h localhost   -c  "DROP DATABASE IF EXISTS $TempDatabaseName;"  
ThrowErrorIfExitCode -message "Could not drop database $TempDatabaseName"
}
catch
{
    & "$PostgresBinFolder\pg_restore.exe" --username=postgres --dbname=$TempDatabaseName $MostRecentBakcup
    ThrowErrorIfExitCode -message "Could not restore backup from path: $MostRecentBakcup to the new database: $TempDatabaseName"

}
write-Host "Dropping of $TempDatabaseName done"


<#
Create the Temp database
#>

& "$PostgresBinFolder\createdb.exe" --username=postgres $TempDatabaseName
ThrowErrorIfExitCode -message "Could not create an empty database $TempDatabaseName"
Write-Host "CREATEDB of $TempDatabaseName complete"


<#
Restore the database
#>

try
{
& "$PostgresBinFolder\pg_restore.exe" --username=postgres --dbname=$TempDatabaseName $MostRecentBakcup
ThrowErrorIfExitCode -message "Exit code was non-zero during restoration of the backup from path: $MostRecentBakcup to the new database: $TempDatabaseName . But, this does not indicate an error/"
}
catch
{
    Write-Host "Exception was caught whiel trying to restore database $MostRecentBakcup to $TempDatabaseName"
    Write-Host $_
}

Write-Host "The database backup: $MostRecentBakcup was restored to $TempDatabaseName"

<#
Stop all connection to DEV
#>
Write-Host "Begin-Forcing all connections to the database $DevDatbaseName"
& $Psql --username postgres -h localhost   -c  "SELECT  pg_terminate_backend(pid) FROM  pg_stat_activity WHERE datname= '$DevDatbaseName'"
Write-Host "End-Forcing all connections to the database $DevDatbaseName"



<#
Drop database DEV
#>
Write-Host "Begin-Dropping all connections to the database $DevDatbaseName"
& $Psql --username postgres -h localhost   -c  "DROP DATABASE $DevDatbaseName;"
Write-Host "End-Dropping database $DevDatbaseName"


<#
Stop all connections to TEMP
#>
Write-Host "Forcing all connections to the database $TempDatabaseName"
& $Psql --username postgres -h localhost   -c  "SELECT  pg_terminate_backend(pid) FROM  pg_stat_activity WHERE datname= '$TempDatabaseName'"


<#
Stop all connection to DEV
#>
Write-Delimiter
Write-Host "Begin-Forcing all connections to the database $DevDatbaseName"
& $Psql --username postgres -h localhost   -c  "SELECT  pg_terminate_backend(pid) FROM  pg_stat_activity WHERE datname= '$DevDatbaseName'"
Write-Host "End-Forcing all connections to the database $DevDatbaseName"



<#
Drop database DEV
#>
Write-Delimiter
Write-Host "Begin-Dropping all connections to the database $DevDatbaseName"
& $Psql --username postgres -h localhost   -c  "DROP DATABASE $DevDatbaseName;"
Write-Host "End-Dropping database $DevDatbaseName"




<#
Rename the TEMP to DEV
#>
Write-Delimiter
Write-Host "Begin-Rename the database $TempDatabaseName to the database $DevDatbaseName"
& $Psql --username postgres -h localhost   -c  "ALTER DATABASE $TempDatabaseName RENAME TO $DevDatbaseName;"
Write-Host "End-Rename the database $TempDatabaseName to the database $DevDatbaseName"


################
Write-Delimiter
Write-Host "The most recent backup fie: $MostRecentBakcup was restored to the database $DevDatbaseName"
Write-Host "All steps done"
Write-Host "Start time: $StartTime"
Write-Host "End time: $(Get-Date)"

