Set-StrictMode -Version "latest"
$ErrorActionPreference="Stop"


Write-Host "Inside common"

$global:environment=$env:environment

if ([string]::IsNullOrWhiteSpace($environment))
{
    Write-Error -Message "The environment variable 'environment' was not found. Should be DEV or PROD"
}
$global:environment=$global:environment.ToLower()


$env:GIT_REDIRECT_STDERR="2>&1"  #https://stackoverflow.com/questions/54372601/running-git-clone-from-powershell-giving-errors-even-when-it-seems-to-work


$global:RootFolder="C:\saturn-demo\saturn-new\"
$global:SourceFolder=Join-path -Path $rootFolder -ChildPath "$global:environment\code"
$global:VenvFolder=Join-path -Path $rootFolder -ChildPath "$global:environment\venv"
$global:Worker=Join-path -Path $global:SourceFolder -ChildPath "\windows_server_deploy\iis"
$global:LogsFolder=Join-Path -Path "C:\Petroineos\logs\saturn\" -ChildPath $global:environment

$global:IISAppPool="saturn-$global:environment"


$Global:BasePython="C:\Program Files\Python39\python.exe"

$global:AppCmdPath="$env:windir\system32\inetsrv\appcmd.exe"

if ((Test-Path -Path $global:AppCmdPath) -eq $false)
{
    Write-Error -Message "The IIS tool appcmd was not found at the path $global:AppCmdPath"
}


function StopIISPool($pool)
{
    Write-Host "Going to stop the application pool $pool"
    & $appcmdpath stop APPPOOL $pool
    Write-Host "The app pool $pool was stopped"
    Write-Delimiter
}

function StartIISPool($pool)
{
    Write-Host "Going to start the application pool $pool"
    & $appcmdpath start APPPOOL $pool
    Write-Host "The app pool $pool was started"
    Write-Delimiter

}

function Write-Delimiter
{
    Write-Host "------------------------"
}


<#
Helper function to delete any folder
#>
function RecursivelyDeleteFolder($folder)
{
    if ((Test-Path -Path $folder) -eq $false)
    {
        Write-Host "Not deleting the folder $folder because it was not found"
        return;
    }
    Write-Host "Deleting $folder"
    Get-ChildItem -Path $folder -Recurse -Force | Remove-Item -force -recurse
    Remove-Item -Path $folder -Force -Recurse
    Write-Host "Deletion of $folder is done"

}


<#
Creates a copy of the template web.config and updates the VENV path
#>
function UpdateWebConfig()
{
    $iisfolder=Join-Path -Path $global:SourceFolder -ChildPath "windows_server_deploy\iis"
    $webconfigTemplateFile=Join-Path -Path $iisfolder -ChildPath "\web.config.template"
    $webconfigContent= Get-Content -Path $webconfigTemplateFile -Raw


    $webconfigContent = $webconfigContent.Replace("[VENVPATH]",$global:VenvFolder)
    $webconfigContent = $webconfigContent.Replace("[ENVIRONMENT]",$global:environment)

    $webconfigFile=Join-Path -Path $iisfolder -ChildPath "\web.config"
    $webconfigContent | Out-File -FilePath $webconfigFile -Encoding utf8
    Write-Host "The web.config file at $webconfigFile was updated"
}

function LaunchAllWorkersOneByOne
{
    
    $domains=@("products", "timeseries", "cross", "crude")
    foreach ($domain in $domains)
    {

        #
        #check for running process first and kill if environment matches
        #
        $reworkCmd="monitor   db  --maxruns 1  --maxworkers   6  --minworkers  0 --domain $domain"
        $childScript="$PSScriptRoot\launch_any_worker.ps1"
        Write-Host "Going to launch rework with domain: $domain using the script $childScript"
        #& $reworkPath monitor   db  --maxruns 1  --maxworkers   6  --minworkers  0 --domain $domain
        #Start-Process -FilePath $reworkPath -WorkingDirectory $global:Worker -ArgumentList $arguments
        #& notepad.exe #this works
        #& ping.exe www.google.com -t > .\junk.log
    
        #ping.exe www.google.com -t > .\junk.log #this works , does the continous logging
    
        #Write-Host "Launching of domain: $domain complete"
        #Write-Host "--------"
        
        Start-Process -FilePath powershell.exe -ArgumentList "$childScript  -domain $domain -workingfolder $global:Worker" 
    }
}


function KillAllReworkProcesses
{
    
    #$procs=Get-CimInstance Win32_Process | where Name -eq rework.exe  | Select-Object ProcessId,Name,CommandLine
    $procs=Get-Process -Name rework -ErrorAction SilentlyContinue
    if ($procs -eq $null)
    {
        Write-Host "No running rework processes found."
        return
    }
    $procs=@($procs)
    Write-Host "Found $($procs.Count) processes"
    foreach($proc in $procs)
    {

        Write-Host "Found a REWORK process with Id: $($proc.id) at $($proc.Path)"
        $pathToExe=$proc.Path
        if ([string]::IsNullOrWhiteSpace($pathToExe))
        {
            Write-Error -Message "The path of Rework.exe was empty $($proc.Id))"
        }
        #C:\saturn-demo\saturn-new\dev\venv\Scripts\rework.exe
        $parentFolder = [System.IO.Path]::GetDirectoryName($pathToExe)
        $grandParentFolder = [System.IO.Path]::GetDirectoryName($parentFolder)
        if ($grandParentFolder -ne $global:VenvFolder)
        {
            Write-Host "Skipping.The grand parent of $path did not match the VENV folder $global:VenvFolder"
            continue
        }
        Write-Host "The grand parent of $pathToExe matched the VENV folder $global:VenvFolder"

        Write-Host "Going to kill $($proc.Id) "
        TASKKILL /F /PID $proc.Id
        Write-Host "After TaskKIll LASTEXITCODE=$LASTEXITCODE"
        
        continue
        <#
        $firstArg=$proc.CommandLine.split(" ")[0]
        $isMatchingEnvironment=$firstArg.contains("\$global:environment\")
        Write-Host "The process $($proc.CommandLine) , environment match=$isMatchingEnvironment"
        if ($isMatchingEnvironment -eq $false)
        {
            Write-Host "Not killing because not a match"
            continue
        }
        Write-Host "Going to kill $($proc.CommandLine)"
        $proc | Get-Member
        Write-Host "Process id $($proc.ProcessId)"

        #Stop-Process -Id $($proc.ProcessId)  #Did not work from Active Batch. Not sure why
        TASKKILL /F /PID $proc.ProcessId
        Write-Host "Killed process $($proc.Commandline)"
        Write-Host "---------------"
        #>
    }        
}