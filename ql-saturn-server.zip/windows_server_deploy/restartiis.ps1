. $PSScriptRoot\common.ps1


<#
Restart the environment specific IIS app pool
#>


StopIISPool -pool $Global:IISAppPool

StartIISPool -pool $Global:IISAppPool
