# How to hit the database directly ?

## Step-1-Create a tshistory.cfg
```
[dburi]
db = postgresql://postgres:*******@TST-QDEV-AP12/devsaturndatabase

```


## Step-2-Command line 

```
python loader.py primary_series.txt "postgresql://postgres:****@TST-QDEV-AP12/devsaturndatabase"
```