
# Steps

## Launch a CMD with Administrative privileges

## Remove PIP_EXTRA_INDEX_URL
I got package not found error

```
pip install wfastgi
```

## One time enable

```
wfastcgi-enable
```

## IIS Fast CGI Settings
![Alt text](pics/iis_fast_cgi.png)

# References
https://pypi.org/project/wfastcgi/


# Web.config that worked
```xml
<configuration>
    <system.webServer>
        <handlers>
            <add name="PythonHandler" path="*" verb="*" modules="FastCgiModule" 
			scriptProcessor="C:\saturn-demo\9090\.venv\Scripts\python.exe|C:\saturn-demo\9090\.venv\Lib\site-packages\wfastcgi.py" 
			resourceType="Unspecified" requireAccess="Script" />
        </handlers>
        <rewrite>
            <rules>
                <rule name="Main Rule" stopProcessing="true">
                    <match url=".*" />
                    <conditions logicalGrouping="MatchAll">
                        <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
                    </conditions>
                    <action type="Rewrite" url="handler.fcgi/{R:0}" />
                </rule>
            </rules>
        </rewrite>
    </system.webServer>
	<appSettings>
		<add key="WSGI_HANDLER" value="app1.app" />
		<add key="WSGI_RESTART_FILE_REGEX" value=".*((\.py)|(\.config))$" />
		<add key="PYTHONPATH" value="C:\saturn-demo\9091\dev\code\windows_server_deploy\iis\" />
		<add key="WSGI_LOG" value="C:\saturn-demo\9091\dev\code\windows_server_deploy\iis\logs\app.log" />
	</appSettings>
</configuration>




```

# Web.config not working

```
scriptProcessor="C:\saturn-demo\saturn-new\dev\venv\Scripts\python.exe|C:\saturn-demo\saturn-new\dev\venv\Lib\site-packages\wfastcgi.py" 
```


