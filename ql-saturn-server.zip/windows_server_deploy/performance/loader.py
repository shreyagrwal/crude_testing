from collections import defaultdict
import os
import sys
from time import time
from pathlib import Path
from pprint import pprint
import statistics as stat
from tshistory.api import timeseries
from tshistory.util import threadpool


def load(filename: str):
    input_file_path=os.path.join(os.path.dirname(__file__),filename)
    print(f"Going to read the file: {input_file_path}")
    series_names=Path(input_file_path).read_text().split()
    print(f"Found {len(series_names)} series after reading the file: {input_file_path}")
    return series_names

def run(series, url: str):
    start=time()
    print(f"Going to use the URL: {url}")
    pool = threadpool(16)
    tsa = timeseries(url)
    out = {}
    def get(name):
        t0 = time()
        try:
            ts = tsa.get(name)
            assert ts is not None
            assert len(ts)
            out[name] = time() - t0
        except:
            print(f"Error with series:{name}")
    times = []
    for i in range(10):
        t0 = time()
        pool(get, [[name,] for name in series])
        times.append(time() - t0)
        t0 = time()
    print('number of points:')
    pprint(out)
    median = stat.median(times)
    stdev = stat.stdev(times)
    end=time()
    elapsed= end-start
    print(f'run in {median=} seconds, {stdev=}, url={url}, count of series={len(series)}, total time={round(elapsed,1)} secs')
    
def run_with_individual_median_capture(series,url: str):
    print("function run_with_individual_median_capture ")
    print(f"Going to use the URL: {url}")
    start=time()
    pool = threadpool(16)
    tsa = timeseries(url)
    out = defaultdict(list)
    def get(name):
        t0 = time()
        ts = tsa.get(name)
        assert ts is not None
        assert len(ts)
        out[name].append(time() - t0)
    times = []
    for i in range(10):
        t0 = time()
        pool(get, [[name,] for name in series])
        times.append(time() - t0)
        t0 = time()
    print('median per series:')
    pprint({k: stat.median(v) for k, v in out.items()})
    print('stdev per series:')
    pprint({k: stat.stdev(v) for k, v in out.items()})
    median = stat.median(times)
    stdev = stat.stdev(times)
    end=time()
    elapsed= end-start    
    print(f'run in {median=} seconds, {stdev=}, url={url}, count of series={len(series)}, total time={round(elapsed,1)} secs')
    

if __name__ == '__main__':
    #
    #Example of url = 'http://localhost:9090/api'
    #
    run_with_individual_median_capture(load(filename=sys.argv[1]), url=sys.argv[2])