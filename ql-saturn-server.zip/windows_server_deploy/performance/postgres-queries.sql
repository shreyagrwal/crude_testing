/*
--run this query to check for activity, useful when you have restored a database and want to verify if the new database is the latest
select  id
,task
,tstamp
,line
from rework.log
ORDER BY tstamp desc
LIMIT 1000
*/

/*
-- this took over 50 minutes last time
REINDEX DATABASE devsaturndatabase;
*/

--SHOW ALL
SHOW log_directory
SELECT * FROM pg_stat_activity  where datname='devsaturndatabase'

--Show all databases
SELECT * FROM pg_database


