
[[_TOC_]]

# Test-Hit 130 primary series via HTTP

## Sumary
In this test the client was made to hit a list of primary series  via HTTP

Attempt no|Metric(secs) | AP9 | AP12
---------|----------|---------|-----|
1 |Median | 0.49 | 0.9|
1 |Total | 6.7 | 10.2|
2 |Median | 0.5 | 0.94|
2 |Total | 11.6 | 10.4|
3 |Median | 2.8 | 0.98|
3 |Total |  33.7| 11.0|
4 |Median | 0.44 | 1.0|
4 |Total |  16.9| 12.3|

## AP12
.\loader.py .\primary_series.txt  http://saturndev/api/

```
run in median=0.9329941272735596 seconds, stdev=0.04866760279308634, url=http://saturndev/api/, count of series=130, total time=10.2 secs
run in median=0.9480088949203491 seconds, stdev=0.03300651226459583, url=http://saturndev/api/, count of series=130, total time=10.4 secs
run in median=0.9835087060928345 seconds, stdev=0.14596684685833886, url=http://saturndev/api/, count of series=130, total time=11.0 secs
run in median=1.0465044975280762 seconds, stdev=0.07994220414573083, url=http://saturndev/api/, count of series=130, total time=12.3 secs
```

## AP9
.\loader.py .\primary_series.txt  http://tst-qdev-ap9/api/

```
run in median=0.49027323722839355 seconds, stdev=0.09336873449728318, url=http://tst-qdev-ap9/api/, count of series=130, total time=6.7 secs
run in median=0.504999041557312 seconds, stdev=1.868989560353047, url=http://tst-qdev-ap9/api/, count of series=130, total time=11.6 secs
run in median=2.826326012611389 seconds, stdev=2.969909535995331, url=http://tst-qdev-ap9/api/, count of series=130, total time=33.7 secs
run in median=0.44546687602996826 seconds, stdev=2.452619060356627, url=http://tst-qdev-ap9/api/, count of series=130, total time=16.9 secs
```

---


# Test-Hit 130 primary series via Postgres


## Summary

In this test the client was made to hit a list of primary series  directly via Postgres (no HTTP)

Example command line:
```
python loader.py primary_series.txt "postgresql://SVC-QDEV-TST@localhost:5432/saturndatabase2"
``````


|Metric(secs)|AP9|AP12|
|-------|---|---|
|Total time taken|11.6|11|
|Median time taken|0.98|0.89|


## AP12

run in median=0.8885030746459961 seconds, stdev=0.09174298573079623, url=postgresql://postgres:*****@TST-QDEV-AP12/devsaturndatabase, count of series=130, total time=11.3 secs

```json
{'crude.argus.russia.pivdenne.pipe_exports.kbd.monthly': 0.023006796836853027,
 'crude.argus.russia.poland.pipe_exports.kbd.monthly': 0.05350029468536377,
 'crude.argus.russia.primorsk.pipe_exports.kbd.monthly': 0.05050325393676758,
 'crude.argus.russia.slovakia.pipe_exports.kbd.monthly': 0.05799973011016846,
 'crude.argus.russia.total_exports.pipe_exports.kbd.monthly': 0.05545961856842041,
 'crude.argus.russia.tuapse.pipe_exports.kbd.monthly': 0.021999239921569824,
 'crude.argus.russia.ust_luga.pipe_exports.kbd.monthly': 0.04899489879608154,
 'crude.clipper.padd1.total.exports.kbd.monthly': 0.022999286651611328,
 'crude.clipper.padd1.total.exports.waterborne.kbd.monthly': 0.022015094757080078,
 'crude.clipper.padd1.total.imports.kbd.monthly': 0.023497939109802246,
 'crude.clipper.padd1.total.imports.waterborne.kbd.monthly': 0.023000717163085938,
 'crude.clipper.padd3.total.exports.kbd.monthly': 0.02551567554473877,
 'crude.clipper.padd3.total.exports.waterborne.kbd.monthly': 0.06899917125701904,
 'crude.clipper.padd3.total.imports.kbd.monthly': 0.11650347709655762,
 'crude.clipper.padd3.total.imports.waterborne.kbd.monthly': 0.11750078201293945,
 'crude.clipper.padd5.total.exports.kbd.monthly': 0.07500362396240234,
 'crude.clipper.padd5.total.exports.waterborne.kbd.monthly': 0.07099640369415283,
 'crude.clipper.padd5.total.imports.kbd.monthly': 0.12348377704620361,
 'crude.clipper.padd5.total.imports.waterborne.kbd.monthly': 0.029999971389770508,
 'crude.eia.padd_3.throughput.kbd.weekly': 0.05899763107299805,
 'crude.eia_psm.cushing.total.build_draw.mb.monthly': 0.02250218391418457,
 'crude.eia_psm.cushing.total.stocks.mb.monthly': 0.021999001502990723,
 'crude.eia_psm.p1__fl.total.production.kbd.monthly': 0.020985722541809082,
 'crude.eia_psm.p1__ny.total.production.kbd.monthly': 0.020998597145080566,
 'crude.eia_psm.p1__pa.total.production.kbd.monthly': 0.028007149696350098,
 'crude.eia_psm.p1__va.total.production.kbd.monthly': 0.07249200344085693,
 'crude.eia_psm.p1__wv.total.production.kbd.monthly': 0.08050549030303955,
 'crude.eia_psm.p2__il.total.production.kbd.monthly': 0.029998421669006348,
 'crude.eia_psm.p2__in.total.production.kbd.monthly': 0.0370025634765625,
 'crude.eia_psm.p2__ks.total.production.kbd.monthly': 0.028999924659729004,
 'crude.eia_psm.p2__ky.total.production.kbd.monthly': 0.02350485324859619,
 'crude.eia_psm.p2__mi.total.production.kbd.monthly': 0.027502059936523438,
 'crude.eia_psm.p2__mo.total.production.kbd.monthly': 0.03649473190307617,
 'crude.eia_psm.p2__nd.total.production.kbd.monthly': 0.029001593589782715,
 'crude.eia_psm.p2__ne.total.production.kbd.monthly': 0.02799999713897705,
 'crude.eia_psm.p2__oh.total.production.kbd.monthly': 0.027500510215759277,
 'crude.eia_psm.p2__ok.total.production.kbd.monthly': 0.02400028705596924,
 'crude.eia_psm.p2__sd.total.production.kbd.monthly': 0.026996493339538574,
 'crude.eia_psm.p2__tn.total.production.kbd.monthly': 0.026496052742004395,
 'crude.eia_psm.p3__al.total.production.kbd.monthly': 0.028000950813293457,
 'crude.eia_psm.p3__ar.total.production.kbd.monthly': 0.03900480270385742,
 'crude.eia_psm.p3__fed_gom.total.production.kbd.monthly': 0.025501132011413574,
 'crude.eia_psm.p3__la.total.production.kbd.monthly': 0.028496742248535156,
 'crude.eia_psm.p3__ms.total.production.kbd.monthly': 0.03400003910064697,
 'crude.eia_psm.p3__nm.total.production.kbd.monthly': 0.02450692653656006,
 'crude.eia_psm.p3__tx.total.production.kbd.monthly': 0.023998141288757324,
 'crude.eia_psm.p4__co.total.production.kbd.monthly': 0.07099771499633789,
 'crude.eia_psm.p4__id.total.production.kbd.monthly': 0.028497815132141113,
 'crude.eia_psm.p4__mt.total.production.kbd.monthly': 0.022000908851623535,
 'crude.eia_psm.p4__ut.total.production.kbd.monthly': 0.023006200790405273,
 'crude.eia_psm.p4__wy.total.production.kbd.monthly': 0.020999550819396973,
 'crude.eia_psm.p5__nv.total.production.kbd.monthly': 0.024502277374267578,
 'crude.eia_psm.padd2.total.adjustment.kbd.monthly': 0.02150285243988037,
 'crude.eia_psm.padd2.total.build_draw.kbd.monthly': 0.03799927234649658,
 'crude.eia_psm.padd2.total.build_draw.mb.monthly': 0.023000121116638184,
 'crude.eia_psm.padd2.total.deliveries.kbd.monthly': 0.029497981071472168,
 'crude.eia_psm.padd2.total.demand.kbd.monthly': 0.0630040168762207,
 'crude.eia_psm.padd2.total.exports.kbd.monthly': 0.02400350570678711,
 'crude.eia_psm.padd2.total.imports.kbd.monthly': 0.02399611473083496,
 'crude.eia_psm.padd2.total.production.kbd.monthly': 0.021999597549438477,
 'crude.eia_psm.padd2.total.receipts.kbd.monthly': 0.023499608039855957,
 'crude.eia_psm.padd2.total.runs.kbd.monthly': 0.034998416900634766,
 'crude.eia_psm.padd2.total.spr.kbd.monthly': 0.027500271797180176,
 'crude.eia_psm.padd2.total.stocks.mb.monthly': 0.06749296188354492,
 'crude.eia_psm.padd2.total.supply.kbd.monthly': 0.030001521110534668,
 'crude.eia_psm.padd3.total.adjustment.kbd.monthly': 0.11000001430511475,
 'crude.eia_psm.padd3.total.build_draw.kbd.monthly': 0.09549987316131592,
 'crude.eia_psm.padd3.total.build_draw.mb.monthly': 0.0879981517791748,
 'crude.eia_psm.padd3.total.deliveries.kbd.monthly': 0.07549583911895752,
 'crude.eia_psm.padd3.total.demand.kbd.monthly': 0.023000121116638184,
 'crude.eia_psm.padd3.total.exports.kbd.monthly': 0.02299344539642334,
 'crude.eia_psm.padd3.total.imports.kbd.monthly': 0.0239945650100708,
 'crude.eia_psm.padd3.total.production.kbd.monthly': 0.024007558822631836,
 'crude.eia_psm.padd3.total.receipts.kbd.monthly': 0.02599811553955078,
 'crude.eia_psm.padd3.total.runs.kbd.monthly': 0.02400052547454834,
 'crude.eia_psm.padd3.total.spr.kbd.monthly': 0.03550148010253906,
 'crude.eia_psm.padd3.total.stocks.mb.monthly': 0.08750450611114502,
 'crude.eia_psm.padd3.total.supply.kbd.monthly': 0.030495762825012207,
 'crude.eia_psm.padd4.total.adjustment.kbd.monthly': 0.02500176429748535,
 'crude.eia_psm.padd4.total.build_draw.kbd.monthly': 0.03700721263885498,
 'crude.eia_psm.padd4.total.build_draw.mb.monthly': 0.019982576370239258,
 'crude.eia_psm.padd4.total.deliveries.kbd.monthly': 0.02249741554260254,
 'crude.eia_psm.padd4.total.demand.kbd.monthly': 0.024499893188476562,
 'crude.eia_psm.padd4.total.exports.kbd.monthly': 0.023500800132751465,
 'crude.eia_psm.padd4.total.imports.kbd.monthly': 0.021514892578125,
 'crude.eia_psm.padd4.total.production.kbd.monthly': 0.026497960090637207,
 'crude.eia_psm.padd4.total.receipts.kbd.monthly': 0.02700042724609375,
 'crude.eia_psm.padd4.total.runs.kbd.monthly': 0.024998784065246582,
 'crude.eia_psm.padd4.total.spr.kbd.monthly': 0.03050863742828369,
 'crude.eia_psm.padd4.total.stocks.mb.monthly': 0.12199950218200684,
 'crude.eia_psm.padd4.total.supply.kbd.monthly': 0.11550068855285645,
 'crude.eia_psm.padd_1__padd_2.total.deliveries.kbd.monthly': 0.06749987602233887,
 'crude.eia_psm.padd_1__padd_3.total.deliveries.kbd.monthly': 0.11699199676513672,
 'crude.eia_psm.padd_1__padd_4.total.deliveries.kbd.monthly': 0.11399996280670166,
 'crude.eia_psm.padd_2__padd_1.total.deliveries.kbd.monthly': 0.07799911499023438,
 'crude.eia_psm.padd_2__padd_3.total.deliveries.kbd.monthly': 0.03399777412414551,
 'crude.eia_psm.padd_2__padd_4.total.deliveries.kbd.monthly': 0.03549909591674805,
 'crude.eia_psm.padd_2__padd_5.total.deliveries.kbd.monthly': 0.039499759674072266,
 'crude.eia_psm.padd_3__padd_1.total.deliveries.kbd.monthly': 0.08945226669311523,
 'crude.eia_psm.padd_3__padd_2.total.deliveries.kbd.monthly': 0.0470881462097168,
 'crude.eia_psm.padd_3__padd_4.total.deliveries.kbd.monthly': 0.025998711585998535,
 'crude.eia_psm.padd_3__padd_5.total.deliveries.kbd.monthly': 0.02649378776550293,
 'crude.eia_psm.padd_4__padd_1.total.deliveries.kbd.monthly': 0.02650582790374756,
 'crude.eia_psm.padd_4__padd_2.total.deliveries.kbd.monthly': 0.025993824005126953,
 'crude.eia_psm.padd_4__padd_3.total.deliveries.kbd.monthly': 0.0240020751953125,
 'crude.eia_psm.padd_4__padd_5.total.deliveries.kbd.monthly': 0.02350795269012451,
 'crude.eia_psm.padd_5__padd_2.total.deliveries.kbd.monthly': 0.021499276161193848,
 'crude.eia_psm.padd_5__padd_3.total.deliveries.kbd.monthly': 0.026993989944458008,
 'crude.eia_psm.padd_5__padd_4.total.deliveries.kbd.monthly': 0.024999499320983887,
 'lng.kpler.cargo_arrivals.europe.Europe.Unknown.cargoes.15days.daily': 0.02051568031311035,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Belgium.cargoes.15days.daily': 0.12800049781799316,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.France.cargoes.15days.daily': 0.1305067539215088,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Germany.cargoes.15days.daily': 0.14350104331970215,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Netherlands.cargoes.15days.daily': 0.15050244331359863,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Total.cargoes.15days.daily': 0.019501566886901855,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.United_Kingdom.cargoes.15days.daily': 0.15856289863586426,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Finland.cargoes.15days.daily': 0.155501127243042,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Greece.cargoes.15days.daily': 0.16006231307983398,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Italy.cargoes.15days.daily': 0.16155803203582764,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Lithuania.cargoes.15days.daily': 0.17499804496765137,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Poland.cargoes.15days.daily': 0.16299974918365479,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Portugal.cargoes.15days.daily': 0.023001670837402344,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Spain.cargoes.15days.daily': 0.18706190586090088,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Total.cargoes.15days.daily': 0.01801466941833496,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Turkey.cargoes.15days.daily': 0.019498586654663086,
 'lng.kpler.cargo_on_water.all_vessels.laden_tonnage.ton.daily': 0.06099295616149902,
 'lng.kpler.cargo_on_water.all_vessels.pctg_ballast.pctg.daily': 0.0522843599319458,
 'lng.kpler.cargo_on_water.all_vessels.pctg_laden.pctg.daily': 0.06150329113006592,
 'lng.kpler.cargo_on_water.all_vessels.speed_ballast.knot.daily': 0.043495774269104004,
 'lng.kpler.cargo_on_water.all_vessels.speed_laden.knot.daily': 0.05278825759887695}
stdev per series:
{'crude.argus.russia.pivdenne.pipe_exports.kbd.monthly': 0.005031136478172735,
 'crude.argus.russia.poland.pipe_exports.kbd.monthly': 0.01789811996387954,
 'crude.argus.russia.primorsk.pipe_exports.kbd.monthly': 0.01791308285075604,
 'crude.argus.russia.slovakia.pipe_exports.kbd.monthly': 0.01626011090493673,
 'crude.argus.russia.total_exports.pipe_exports.kbd.monthly': 0.01819541815816721,
 'crude.argus.russia.tuapse.pipe_exports.kbd.monthly': 0.003433166759171511,
 'crude.argus.russia.ust_luga.pipe_exports.kbd.monthly': 0.014330820259244733,
 'crude.clipper.padd1.total.exports.kbd.monthly': 0.03150437148865883,
 'crude.clipper.padd1.total.exports.waterborne.kbd.monthly': 0.03374794751238606,
 'crude.clipper.padd1.total.imports.kbd.monthly': 0.036737052630474096,
 'crude.clipper.padd1.total.imports.waterborne.kbd.monthly': 0.06827530428623454,
 'crude.clipper.padd3.total.exports.kbd.monthly': 0.06050208870343951,
 'crude.clipper.padd3.total.exports.waterborne.kbd.monthly': 0.05956161336703346,
 'crude.clipper.padd3.total.imports.kbd.monthly': 0.06574926457986206,
 'crude.clipper.padd3.total.imports.waterborne.kbd.monthly': 0.05823971797659436,
 'crude.clipper.padd5.total.exports.kbd.monthly': 0.06440437023276947,
 'crude.clipper.padd5.total.exports.waterborne.kbd.monthly': 0.062480637341540246,
 'crude.clipper.padd5.total.imports.kbd.monthly': 0.054756473108481404,
 'crude.clipper.padd5.total.imports.waterborne.kbd.monthly': 0.05443592565548743,
 'crude.eia.padd_3.throughput.kbd.weekly': 0.057333530451121134,
 'crude.eia_psm.cushing.total.build_draw.mb.monthly': 0.05250993728602053,
 'crude.eia_psm.cushing.total.stocks.mb.monthly': 0.05350515204601592,
 'crude.eia_psm.p1__fl.total.production.kbd.monthly': 0.003359617425673191,
 'crude.eia_psm.p1__ny.total.production.kbd.monthly': 0.03708251714220984,
 'crude.eia_psm.p1__pa.total.production.kbd.monthly': 0.05942894195468334,
 'crude.eia_psm.p1__va.total.production.kbd.monthly': 0.05661807776325251,
 'crude.eia_psm.p1__wv.total.production.kbd.monthly': 0.05727782876672683,
 'crude.eia_psm.p2__il.total.production.kbd.monthly': 0.0545690845414033,
 'crude.eia_psm.p2__in.total.production.kbd.monthly': 0.05909595875291255,
 'crude.eia_psm.p2__ks.total.production.kbd.monthly': 0.04962126284218808,
 'crude.eia_psm.p2__ky.total.production.kbd.monthly': 0.050099222253582425,
 'crude.eia_psm.p2__mi.total.production.kbd.monthly': 0.057685241765639404,
 'crude.eia_psm.p2__mo.total.production.kbd.monthly': 0.05009994205204675,
 'crude.eia_psm.p2__nd.total.production.kbd.monthly': 0.053228368983459465,
 'crude.eia_psm.p2__ne.total.production.kbd.monthly': 0.05684563171908737,
 'crude.eia_psm.p2__oh.total.production.kbd.monthly': 0.0625132202611936,
 'crude.eia_psm.p2__ok.total.production.kbd.monthly': 0.060047301542847355,
 'crude.eia_psm.p2__sd.total.production.kbd.monthly': 0.06217311683053633,
 'crude.eia_psm.p2__tn.total.production.kbd.monthly': 0.05848862263436344,
 'crude.eia_psm.p3__al.total.production.kbd.monthly': 0.05333560934448573,
 'crude.eia_psm.p3__ar.total.production.kbd.monthly': 0.06108446853802196,
 'crude.eia_psm.p3__fed_gom.total.production.kbd.monthly': 0.05640304407033719,
 'crude.eia_psm.p3__la.total.production.kbd.monthly': 0.053176685714127744,
 'crude.eia_psm.p3__ms.total.production.kbd.monthly': 0.06460441142761733,
 'crude.eia_psm.p3__nm.total.production.kbd.monthly': 0.044191430835161895,
 'crude.eia_psm.p3__tx.total.production.kbd.monthly': 0.04897442070886448,
 'crude.eia_psm.p4__co.total.production.kbd.monthly': 0.05997055870942951,
 'crude.eia_psm.p4__id.total.production.kbd.monthly': 0.048878993663188326,
 'crude.eia_psm.p4__mt.total.production.kbd.monthly': 0.04457301974566448,
 'crude.eia_psm.p4__ut.total.production.kbd.monthly': 0.05284701800883181,
 'crude.eia_psm.p4__wy.total.production.kbd.monthly': 0.0277573739288567,
 'crude.eia_psm.p5__nv.total.production.kbd.monthly': 0.048818693779001686,
 'crude.eia_psm.padd2.total.adjustment.kbd.monthly': 0.04016876386967344,
 'crude.eia_psm.padd2.total.build_draw.kbd.monthly': 0.04681868288857117,
 'crude.eia_psm.padd2.total.build_draw.mb.monthly': 0.04298268373609305,
 'crude.eia_psm.padd2.total.deliveries.kbd.monthly': 0.05395063286603735,
 'crude.eia_psm.padd2.total.demand.kbd.monthly': 0.05406129496247988,
 'crude.eia_psm.padd2.total.exports.kbd.monthly': 0.05765814257346218,
 'crude.eia_psm.padd2.total.imports.kbd.monthly': 0.05325062198212578,
 'crude.eia_psm.padd2.total.production.kbd.monthly': 0.05268152753267188,
 'crude.eia_psm.padd2.total.receipts.kbd.monthly': 0.05022204398763087,
 'crude.eia_psm.padd2.total.runs.kbd.monthly': 0.06234476017753738,
 'crude.eia_psm.padd2.total.spr.kbd.monthly': 0.058796956662480956,
 'crude.eia_psm.padd2.total.stocks.mb.monthly': 0.05324901177531595,
 'crude.eia_psm.padd2.total.supply.kbd.monthly': 0.05532040416588069,
 'crude.eia_psm.padd3.total.adjustment.kbd.monthly': 0.05671745503444717,
 'crude.eia_psm.padd3.total.build_draw.kbd.monthly': 0.07103594558858581,
 'crude.eia_psm.padd3.total.build_draw.mb.monthly': 0.0676240006351866,
 'crude.eia_psm.padd3.total.deliveries.kbd.monthly': 0.0665406052347566,
 'crude.eia_psm.padd3.total.demand.kbd.monthly': 0.06531429059081043,
 'crude.eia_psm.padd3.total.exports.kbd.monthly': 0.056937627118162124,
 'crude.eia_psm.padd3.total.imports.kbd.monthly': 0.041143590143078286,
 'crude.eia_psm.padd3.total.production.kbd.monthly': 0.044300291006848805,
 'crude.eia_psm.padd3.total.receipts.kbd.monthly': 0.03493284869360771,
 'crude.eia_psm.padd3.total.runs.kbd.monthly': 0.041331241438049705,
 'crude.eia_psm.padd3.total.spr.kbd.monthly': 0.052805321068383995,
 'crude.eia_psm.padd3.total.stocks.mb.monthly': 0.053611539493429144,
 'crude.eia_psm.padd3.total.supply.kbd.monthly': 0.053613643442704605,
 'crude.eia_psm.padd4.total.adjustment.kbd.monthly': 0.03113144823752245,
 'crude.eia_psm.padd4.total.build_draw.kbd.monthly': 0.04337301318439917,
 'crude.eia_psm.padd4.total.build_draw.mb.monthly': 0.0373972029552612,
 'crude.eia_psm.padd4.total.deliveries.kbd.monthly': 0.04079402792024674,
 'crude.eia_psm.padd4.total.demand.kbd.monthly': 0.040061597427188164,
 'crude.eia_psm.padd4.total.exports.kbd.monthly': 0.02981729913671041,
 'crude.eia_psm.padd4.total.imports.kbd.monthly': 0.033781126629504374,
 'crude.eia_psm.padd4.total.production.kbd.monthly': 0.037808648448637475,
 'crude.eia_psm.padd4.total.receipts.kbd.monthly': 0.037675678231403685,
 'crude.eia_psm.padd4.total.runs.kbd.monthly': 0.05033933600117788,
 'crude.eia_psm.padd4.total.spr.kbd.monthly': 0.05856822354533651,
 'crude.eia_psm.padd4.total.stocks.mb.monthly': 0.05538993853547784,
 'crude.eia_psm.padd4.total.supply.kbd.monthly': 0.054344597038665475,
 'crude.eia_psm.padd_1__padd_2.total.deliveries.kbd.monthly': 0.06849811806850345,
 'crude.eia_psm.padd_1__padd_3.total.deliveries.kbd.monthly': 0.056558487906418695,
 'crude.eia_psm.padd_1__padd_4.total.deliveries.kbd.monthly': 0.05992997511351116,
 'crude.eia_psm.padd_2__padd_1.total.deliveries.kbd.monthly': 0.06842671942798575,
 'crude.eia_psm.padd_2__padd_3.total.deliveries.kbd.monthly': 0.05690311426410324,
 'crude.eia_psm.padd_2__padd_4.total.deliveries.kbd.monthly': 0.05051407576892711,
 'crude.eia_psm.padd_2__padd_5.total.deliveries.kbd.monthly': 0.054806604976736596,
 'crude.eia_psm.padd_3__padd_1.total.deliveries.kbd.monthly': 0.0595766152959622,
 'crude.eia_psm.padd_3__padd_2.total.deliveries.kbd.monthly': 0.051292231245376324,
 'crude.eia_psm.padd_3__padd_4.total.deliveries.kbd.monthly': 0.04829359254442923,
 'crude.eia_psm.padd_3__padd_5.total.deliveries.kbd.monthly': 0.05225194344851573,
 'crude.eia_psm.padd_4__padd_1.total.deliveries.kbd.monthly': 0.059622913222634084,
 'crude.eia_psm.padd_4__padd_2.total.deliveries.kbd.monthly': 0.05350015709536621,
 'crude.eia_psm.padd_4__padd_3.total.deliveries.kbd.monthly': 0.043995104076148504,
 'crude.eia_psm.padd_4__padd_5.total.deliveries.kbd.monthly': 0.0063067959786859765,
 'crude.eia_psm.padd_5__padd_2.total.deliveries.kbd.monthly': 0.008471599555484053,
 'crude.eia_psm.padd_5__padd_3.total.deliveries.kbd.monthly': 0.046347143874054766,
 'crude.eia_psm.padd_5__padd_4.total.deliveries.kbd.monthly': 0.030531187905837514,
 'lng.kpler.cargo_arrivals.europe.Europe.Unknown.cargoes.15days.daily': 0.007869733621023707,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Belgium.cargoes.15days.daily': 0.03269991386076391,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.France.cargoes.15days.daily': 0.017160369763426577,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Germany.cargoes.15days.daily': 0.023128038807467003,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Netherlands.cargoes.15days.daily': 0.02393400706262132,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Total.cargoes.15days.daily': 0.003359691860325836,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.United_Kingdom.cargoes.15days.daily': 0.04088769006236563,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Finland.cargoes.15days.daily': 0.024654447787003535,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Greece.cargoes.15days.daily': 0.02882966100016332,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Italy.cargoes.15days.daily': 0.02612676349115474,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Lithuania.cargoes.15days.daily': 0.03210075539943516,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Poland.cargoes.15days.daily': 0.031445840553441455,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Portugal.cargoes.15days.daily': 0.005374133252547743,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Spain.cargoes.15days.daily': 0.036908017424956335,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Total.cargoes.15days.daily': 0.0065540650055572365,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Turkey.cargoes.15days.daily': 0.006413808703877255,
 'lng.kpler.cargo_on_water.all_vessels.laden_tonnage.ton.daily': 0.03355848077753336,
 'lng.kpler.cargo_on_water.all_vessels.pctg_ballast.pctg.daily': 0.03683453385549196,
 'lng.kpler.cargo_on_water.all_vessels.pctg_laden.pctg.daily': 0.035412069654858824,
 'lng.kpler.cargo_on_water.all_vessels.speed_ballast.knot.daily': 0.041504321526035656,
 'lng.kpler.cargo_on_water.all_vessels.speed_laden.knot.daily': 0.0653536091975063}
```

## AP9

run in median=1.6566187143325806 seconds, stdev=0.1505218722505588, url=postgresql://SVC-QDEV-TST@localhost:5432/saturndatabase2, count of series=130, total time=18.8 secs
```json

{'crude.argus.russia.pivdenne.pipe_exports.kbd.monthly': 0.023438334465026855,
 'crude.argus.russia.poland.pipe_exports.kbd.monthly': 0.01562976837158203,
 'crude.argus.russia.primorsk.pipe_exports.kbd.monthly': 0.015630006790161133,
 'crude.argus.russia.slovakia.pipe_exports.kbd.monthly': 0.015628457069396973,
 'crude.argus.russia.total_exports.pipe_exports.kbd.monthly': 0.0312502384185791,
 'crude.argus.russia.tuapse.pipe_exports.kbd.monthly': 0.023441076278686523,
 'crude.argus.russia.ust_luga.pipe_exports.kbd.monthly': 0.0312502384185791,
 'crude.clipper.padd1.total.exports.kbd.monthly': 0.03125166893005371,
 'crude.clipper.padd1.total.exports.waterborne.kbd.monthly': 0.11719131469726562,
 'crude.clipper.padd1.total.imports.kbd.monthly': 0.0625,
 'crude.clipper.padd1.total.imports.waterborne.kbd.monthly': 0.19564366340637207,
 'crude.clipper.padd3.total.exports.kbd.monthly': 0.2343813180923462,
 'crude.clipper.padd3.total.exports.waterborne.kbd.monthly': 0.257826566696167,
 'crude.clipper.padd3.total.imports.kbd.monthly': 0.26563918590545654,
 'crude.clipper.padd3.total.imports.waterborne.kbd.monthly': 0.25782668590545654,
 'crude.clipper.padd5.total.exports.kbd.monthly': 0.22656333446502686,
 'crude.clipper.padd5.total.exports.waterborne.kbd.monthly': 0.25781774520874023,
 'crude.clipper.padd5.total.imports.kbd.monthly': 0.2268965244293213,
 'crude.clipper.padd5.total.imports.waterborne.kbd.monthly': 0.1484464406967163,
 'crude.eia.padd_3.throughput.kbd.weekly': 0.06250405311584473,
 'crude.eia_psm.cushing.total.build_draw.mb.monthly': 0.10938239097595215,
 'crude.eia_psm.cushing.total.stocks.mb.monthly': 0.07031762599945068,
 'crude.eia_psm.p1__fl.total.production.kbd.monthly': 0.05469655990600586,
 'crude.eia_psm.p1__ny.total.production.kbd.monthly': 0.046880245208740234,
 'crude.eia_psm.p1__pa.total.production.kbd.monthly': 0.03906357288360596,
 'crude.eia_psm.p1__va.total.production.kbd.monthly': 0.03125202655792236,
 'crude.eia_psm.p1__wv.total.production.kbd.monthly': 0.03125476837158203,
 'crude.eia_psm.p2__il.total.production.kbd.monthly': 0.031249523162841797,
 'crude.eia_psm.p2__in.total.production.kbd.monthly': 0.031246066093444824,
 'crude.eia_psm.p2__ks.total.production.kbd.monthly': 0.03124821186065674,
 'crude.eia_psm.p2__ky.total.production.kbd.monthly': 0.03125202655792236,
 'crude.eia_psm.p2__mi.total.production.kbd.monthly': 0.03125202655792236,
 'crude.eia_psm.p2__mo.total.production.kbd.monthly': 0.07813084125518799,
 'crude.eia_psm.p2__nd.total.production.kbd.monthly': 0.039070844650268555,
 'crude.eia_psm.p2__ne.total.production.kbd.monthly': 0.039067864418029785,
 'crude.eia_psm.p2__oh.total.production.kbd.monthly': 0.179695725440979,
 'crude.eia_psm.p2__ok.total.production.kbd.monthly': 0.2500119209289551,
 'crude.eia_psm.p2__sd.total.production.kbd.monthly': 0.2430272102355957,
 'crude.eia_psm.p2__tn.total.production.kbd.monthly': 0.24304234981536865,
 'crude.eia_psm.p3__al.total.production.kbd.monthly': 0.2815687656402588,
 'crude.eia_psm.p3__ar.total.production.kbd.monthly': 0.2893860340118408,
 'crude.eia_psm.p3__fed_gom.total.production.kbd.monthly': 0.30501067638397217,
 'crude.eia_psm.p3__la.total.production.kbd.monthly': 0.07812714576721191,
 'crude.eia_psm.p3__ms.total.production.kbd.monthly': 0.21097004413604736,
 'crude.eia_psm.p3__nm.total.production.kbd.monthly': 0.06250381469726562,
 'crude.eia_psm.p3__tx.total.production.kbd.monthly': 0.06250572204589844,
 'crude.eia_psm.p4__co.total.production.kbd.monthly': 0.05468893051147461,
 'crude.eia_psm.p4__id.total.production.kbd.monthly': 0.03125596046447754,
 'crude.eia_psm.p4__mt.total.production.kbd.monthly': 0.03125429153442383,
 'crude.eia_psm.p4__ut.total.production.kbd.monthly': 0.03906738758087158,
 'crude.eia_psm.p4__wy.total.production.kbd.monthly': 0.031252503395080566,
 'crude.eia_psm.p5__nv.total.production.kbd.monthly': 0.032086730003356934,
 'crude.eia_psm.padd2.total.adjustment.kbd.monthly': 0.031246662139892578,
 'crude.eia_psm.padd2.total.build_draw.kbd.monthly': 0.03125035762786865,
 'crude.eia_psm.padd2.total.build_draw.mb.monthly': 0.03125143051147461,
 'crude.eia_psm.padd2.total.deliveries.kbd.monthly': 0.03125178813934326,
 'crude.eia_psm.padd2.total.demand.kbd.monthly': 0.03125178813934326,
 'crude.eia_psm.padd2.total.exports.kbd.monthly': 0.03125262260437012,
 'crude.eia_psm.padd2.total.imports.kbd.monthly': 0.10938084125518799,
 'crude.eia_psm.padd2.total.production.kbd.monthly': 0.10938382148742676,
 'crude.eia_psm.padd2.total.receipts.kbd.monthly': 0.195318341255188,
 'crude.eia_psm.padd2.total.runs.kbd.monthly': 0.21124756336212158,
 'crude.eia_psm.padd2.total.spr.kbd.monthly': 0.2500115633010864,
 'crude.eia_psm.padd2.total.stocks.mb.monthly': 0.2265768051147461,
 'crude.eia_psm.padd2.total.supply.kbd.monthly': 0.2500145435333252,
 'crude.eia_psm.padd3.total.adjustment.kbd.monthly': 0.2503405809402466,
 'crude.eia_psm.padd3.total.build_draw.kbd.monthly': 0.24252355098724365,
 'crude.eia_psm.padd3.total.build_draw.mb.monthly': 0.25814902782440186,
 'crude.eia_psm.padd3.total.deliveries.kbd.monthly': 0.22687184810638428,
 'crude.eia_psm.padd3.total.demand.kbd.monthly': 0.07813239097595215,
 'crude.eia_psm.padd3.total.exports.kbd.monthly': 0.05469393730163574,
 'crude.eia_psm.padd3.total.imports.kbd.monthly': 0.06250524520874023,
 'crude.eia_psm.padd3.total.production.kbd.monthly': 0.07813191413879395,
 'crude.eia_psm.padd3.total.receipts.kbd.monthly': 0.046877384185791016,
 'crude.eia_psm.padd3.total.runs.kbd.monthly': 0.031249642372131348,
 'crude.eia_psm.padd3.total.spr.kbd.monthly': 0.031253695487976074,
 'crude.eia_psm.padd3.total.stocks.mb.monthly': 0.031250834465026855,
 'crude.eia_psm.padd3.total.supply.kbd.monthly': 0.03125262260437012,
 'crude.eia_psm.padd4.total.adjustment.kbd.monthly': 0.031255245208740234,
 'crude.eia_psm.padd4.total.build_draw.kbd.monthly': 0.03906548023223877,
 'crude.eia_psm.padd4.total.build_draw.mb.monthly': 0.046878695487976074,
 'crude.eia_psm.padd4.total.deliveries.kbd.monthly': 0.04688143730163574,
 'crude.eia_psm.padd4.total.demand.kbd.monthly': 0.039064645767211914,
 'crude.eia_psm.padd4.total.exports.kbd.monthly': 0.14121794700622559,
 'crude.eia_psm.padd4.total.imports.kbd.monthly': 0.14062786102294922,
 'crude.eia_psm.padd4.total.production.kbd.monthly': 0.23438429832458496,
 'crude.eia_psm.padd4.total.receipts.kbd.monthly': 0.24219608306884766,
 'crude.eia_psm.padd4.total.runs.kbd.monthly': 0.16452062129974365,
 'crude.eia_psm.padd4.total.spr.kbd.monthly': 0.23438405990600586,
 'crude.eia_psm.padd4.total.stocks.mb.monthly': 0.20313286781311035,
 'crude.eia_psm.padd4.total.supply.kbd.monthly': 0.15625762939453125,
 'crude.eia_psm.padd_1__padd_2.total.deliveries.kbd.monthly': 0.07031285762786865,
 'crude.eia_psm.padd_1__padd_3.total.deliveries.kbd.monthly': 0.07812869548797607,
 'crude.eia_psm.padd_1__padd_4.total.deliveries.kbd.monthly': 0.10201966762542725,
 'crude.eia_psm.padd_2__padd_1.total.deliveries.kbd.monthly': 0.07031655311584473,
 'crude.eia_psm.padd_2__padd_3.total.deliveries.kbd.monthly': 0.10982906818389893,
 'crude.eia_psm.padd_2__padd_4.total.deliveries.kbd.monthly': 0.09375441074371338,
 'crude.eia_psm.padd_2__padd_5.total.deliveries.kbd.monthly': 0.07812929153442383,
 'crude.eia_psm.padd_3__padd_1.total.deliveries.kbd.monthly': 0.06250369548797607,
 'crude.eia_psm.padd_3__padd_2.total.deliveries.kbd.monthly': 0.03906214237213135,
 'crude.eia_psm.padd_3__padd_4.total.deliveries.kbd.monthly': 0.031246185302734375,
 'crude.eia_psm.padd_3__padd_5.total.deliveries.kbd.monthly': 0.03124833106994629,
 'crude.eia_psm.padd_4__padd_1.total.deliveries.kbd.monthly': 0.03124988079071045,
 'crude.eia_psm.padd_4__padd_2.total.deliveries.kbd.monthly': 0.03124988079071045,
 'crude.eia_psm.padd_4__padd_3.total.deliveries.kbd.monthly': 0.031255125999450684,
 'crude.eia_psm.padd_4__padd_5.total.deliveries.kbd.monthly': 0.05469393730163574,
 'crude.eia_psm.padd_5__padd_2.total.deliveries.kbd.monthly': 0.09375691413879395,
 'crude.eia_psm.padd_5__padd_3.total.deliveries.kbd.monthly': 0.1328195333480835,
 'crude.eia_psm.padd_5__padd_4.total.deliveries.kbd.monthly': 0.07031965255737305,
 'lng.kpler.cargo_arrivals.europe.Europe.Unknown.cargoes.15days.daily': 0.03125107288360596,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Belgium.cargoes.15days.daily': 0.23438453674316406,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.France.cargoes.15days.daily': 0.2503312826156616,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Germany.cargoes.15days.daily': 0.2743856906890869,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Netherlands.cargoes.15days.daily': 0.2968916893005371,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Total.cargoes.15days.daily': 0.046874284744262695,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.United_Kingdom.cargoes.15days.daily': 0.2890782356262207,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Finland.cargoes.15days.daily': 0.28158044815063477,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Greece.cargoes.15days.daily': 0.3046966791152954,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Italy.cargoes.15days.daily': 0.28938961029052734,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Lithuania.cargoes.15days.daily': 0.3047018051147461,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Poland.cargoes.15days.daily': 0.3212693929672241,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Portugal.cargoes.15days.daily': 0.039061665534973145,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Spain.cargoes.15days.daily': 0.3134472370147705,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Total.cargoes.15days.daily': 0.03906571865081787,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Turkey.cargoes.15days.daily': 0.04687631130218506,
 'lng.kpler.cargo_on_water.all_vessels.laden_tonnage.ton.daily': 0.03125202655792236,
 'lng.kpler.cargo_on_water.all_vessels.pctg_ballast.pctg.daily': 0.03125715255737305,
 'lng.kpler.cargo_on_water.all_vessels.pctg_laden.pctg.daily': 0.03125202655792236,
 'lng.kpler.cargo_on_water.all_vessels.speed_ballast.knot.daily': 0.031255364418029785,
 'lng.kpler.cargo_on_water.all_vessels.speed_laden.knot.daily': 0.031255245208740234}
stdev per series:
{'crude.argus.russia.pivdenne.pipe_exports.kbd.monthly': 0.010926540644413072,
 'crude.argus.russia.poland.pipe_exports.kbd.monthly': 0.008067905469884574,
 'crude.argus.russia.primorsk.pipe_exports.kbd.monthly': 0.015096939521470756,
 'crude.argus.russia.slovakia.pipe_exports.kbd.monthly': 0.007548678818514782,
 'crude.argus.russia.total_exports.pipe_exports.kbd.monthly': 0.007548992361672646,
 'crude.argus.russia.tuapse.pipe_exports.kbd.monthly': 0.010926714669392438,
 'crude.argus.russia.ust_luga.pipe_exports.kbd.monthly': 0.085838254997571,
 'crude.clipper.padd1.total.exports.kbd.monthly': 0.0955354259253677,
 'crude.clipper.padd1.total.exports.waterborne.kbd.monthly': 0.10438234204984549,
 'crude.clipper.padd1.total.imports.kbd.monthly': 0.0915450027010419,
 'crude.clipper.padd1.total.imports.waterborne.kbd.monthly': 0.12215755387583487,
 'crude.clipper.padd3.total.exports.kbd.monthly': 0.09263867766801626,
 'crude.clipper.padd3.total.exports.waterborne.kbd.monthly': 0.07520101063467997,
 'crude.clipper.padd3.total.imports.kbd.monthly': 0.06627520631397561,
 'crude.clipper.padd3.total.imports.waterborne.kbd.monthly': 0.030149624602400733,
 'crude.clipper.padd5.total.exports.kbd.monthly': 0.08691300280547257,
 'crude.clipper.padd5.total.exports.waterborne.kbd.monthly': 0.0904884931656437,
 'crude.clipper.padd5.total.imports.kbd.monthly': 0.10274429770317499,
 'crude.clipper.padd5.total.imports.waterborne.kbd.monthly': 0.11884574322711955,
 'crude.eia.padd_3.throughput.kbd.weekly': 0.09788796484310855,
 'crude.eia_psm.cushing.total.build_draw.mb.monthly': 0.11164197670735321,
 'crude.eia_psm.cushing.total.stocks.mb.monthly': 0.11263128651160309,
 'crude.eia_psm.p1__fl.total.production.kbd.monthly': 0.10496274203191805,
 'crude.eia_psm.p1__ny.total.production.kbd.monthly': 0.08549597756517646,
 'crude.eia_psm.p1__pa.total.production.kbd.monthly': 0.0892302382320107,
 'crude.eia_psm.p1__va.total.production.kbd.monthly': 0.012765451562262059,
 'crude.eia_psm.p1__wv.total.production.kbd.monthly': 0.015183858050936928,
 'crude.eia_psm.p2__il.total.production.kbd.monthly': 0.014730604888584579,
 'crude.eia_psm.p2__in.total.production.kbd.monthly': 0.008066140586786969,
 'crude.eia_psm.p2__ks.total.production.kbd.monthly': 0.053341875056227034,
 'crude.eia_psm.p2__ky.total.production.kbd.monthly': 0.045879677853687906,
 'crude.eia_psm.p2__mi.total.production.kbd.monthly': 0.11610311842736475,
 'crude.eia_psm.p2__mo.total.production.kbd.monthly': 0.12182572171698595,
 'crude.eia_psm.p2__nd.total.production.kbd.monthly': 0.1287141051961596,
 'crude.eia_psm.p2__ne.total.production.kbd.monthly': 0.10855564122645388,
 'crude.eia_psm.p2__oh.total.production.kbd.monthly': 0.11742177514558085,
 'crude.eia_psm.p2__ok.total.production.kbd.monthly': 0.1086563322323461,
 'crude.eia_psm.p2__sd.total.production.kbd.monthly': 0.10922740567263459,
 'crude.eia_psm.p2__tn.total.production.kbd.monthly': 0.10758458762679858,
 'crude.eia_psm.p3__al.total.production.kbd.monthly': 0.11177566903796578,
 'crude.eia_psm.p3__ar.total.production.kbd.monthly': 0.11135413048063728,
 'crude.eia_psm.p3__fed_gom.total.production.kbd.monthly': 0.14170922492782068,
 'crude.eia_psm.p3__la.total.production.kbd.monthly': 0.12946216451028641,
 'crude.eia_psm.p3__ms.total.production.kbd.monthly': 0.1248722720439418,
 'crude.eia_psm.p3__nm.total.production.kbd.monthly': 0.1297357071800546,
 'crude.eia_psm.p3__tx.total.production.kbd.monthly': 0.10696605571488865,
 'crude.eia_psm.p4__co.total.production.kbd.monthly': 0.10388399380165637,
 'crude.eia_psm.p4__id.total.production.kbd.monthly': 0.11038029334810048,
 'crude.eia_psm.p4__mt.total.production.kbd.monthly': 0.0774665844729571,
 'crude.eia_psm.p4__ut.total.production.kbd.monthly': 0.054200920067828576,
 'crude.eia_psm.p4__wy.total.production.kbd.monthly': 0.024309266117050348,
 'crude.eia_psm.p5__nv.total.production.kbd.monthly': 0.06483881980138832,
 'crude.eia_psm.padd2.total.adjustment.kbd.monthly': 0.061189725823004144,
 'crude.eia_psm.padd2.total.build_draw.kbd.monthly': 0.066401839284981,
 'crude.eia_psm.padd2.total.build_draw.mb.monthly': 0.08143346583262512,
 'crude.eia_psm.padd2.total.deliveries.kbd.monthly': 0.07519292334775776,
 'crude.eia_psm.padd2.total.demand.kbd.monthly': 0.08528104938154739,
 'crude.eia_psm.padd2.total.exports.kbd.monthly': 0.08877676469199892,
 'crude.eia_psm.padd2.total.imports.kbd.monthly': 0.11097786750577343,
 'crude.eia_psm.padd2.total.production.kbd.monthly': 0.12170439074316372,
 'crude.eia_psm.padd2.total.receipts.kbd.monthly': 0.10830736907847906,
 'crude.eia_psm.padd2.total.runs.kbd.monthly': 0.10287901021985824,
 'crude.eia_psm.padd2.total.spr.kbd.monthly': 0.10451002540378285,
 'crude.eia_psm.padd2.total.stocks.mb.monthly': 0.10464700918174623,
 'crude.eia_psm.padd2.total.supply.kbd.monthly': 0.0940371070137222,
 'crude.eia_psm.padd3.total.adjustment.kbd.monthly': 0.120797254520329,
 'crude.eia_psm.padd3.total.build_draw.kbd.monthly': 0.11627848232534506,
 'crude.eia_psm.padd3.total.build_draw.mb.monthly': 0.11743293103112577,
 'crude.eia_psm.padd3.total.deliveries.kbd.monthly': 0.10957031333844683,
 'crude.eia_psm.padd3.total.demand.kbd.monthly': 0.12904832045415873,
 'crude.eia_psm.padd3.total.exports.kbd.monthly': 0.13019692272742325,
 'crude.eia_psm.padd3.total.imports.kbd.monthly': 0.14080749221551003,
 'crude.eia_psm.padd3.total.production.kbd.monthly': 0.13040890096739124,
 'crude.eia_psm.padd3.total.receipts.kbd.monthly': 0.11230343632836019,
 'crude.eia_psm.padd3.total.runs.kbd.monthly': 0.07621271405465538,
 'crude.eia_psm.padd3.total.spr.kbd.monthly': 0.060407135713707615,
 'crude.eia_psm.padd3.total.stocks.mb.monthly': 0.05106207347305091,
 'crude.eia_psm.padd3.total.supply.kbd.monthly': 0.07373332521057066,
 'crude.eia_psm.padd4.total.adjustment.kbd.monthly': 0.08875936890291124,
 'crude.eia_psm.padd4.total.build_draw.kbd.monthly': 0.06848718359728372,
 'crude.eia_psm.padd4.total.build_draw.mb.monthly': 0.09913134634045877,
 'crude.eia_psm.padd4.total.deliveries.kbd.monthly': 0.09260853083406079,
 'crude.eia_psm.padd4.total.demand.kbd.monthly': 0.06514069268981047,
 'crude.eia_psm.padd4.total.exports.kbd.monthly': 0.11289507218991086,
 'crude.eia_psm.padd4.total.imports.kbd.monthly': 0.09996641091618755,
 'crude.eia_psm.padd4.total.production.kbd.monthly': 0.11905157114327057,
 'crude.eia_psm.padd4.total.receipts.kbd.monthly': 0.12597430115347946,
 'crude.eia_psm.padd4.total.runs.kbd.monthly': 0.10508360078325613,
 'crude.eia_psm.padd4.total.spr.kbd.monthly': 0.11883545704842853,
 'crude.eia_psm.padd4.total.stocks.mb.monthly': 0.11384110817826625,
 'crude.eia_psm.padd4.total.supply.kbd.monthly': 0.12017605955346698,
 'crude.eia_psm.padd_1__padd_2.total.deliveries.kbd.monthly': 0.12343778607189818,
 'crude.eia_psm.padd_1__padd_3.total.deliveries.kbd.monthly': 0.12459295557463156,
 'crude.eia_psm.padd_1__padd_4.total.deliveries.kbd.monthly': 0.11084489759467712,
 'crude.eia_psm.padd_2__padd_1.total.deliveries.kbd.monthly': 0.12525974321436778,
 'crude.eia_psm.padd_2__padd_3.total.deliveries.kbd.monthly': 0.10460652474104366,
 'crude.eia_psm.padd_2__padd_4.total.deliveries.kbd.monthly': 0.10603053298673844,
 'crude.eia_psm.padd_2__padd_5.total.deliveries.kbd.monthly': 0.11563819548896759,
 'crude.eia_psm.padd_3__padd_1.total.deliveries.kbd.monthly': 0.11671237969502536,
 'crude.eia_psm.padd_3__padd_2.total.deliveries.kbd.monthly': 0.13346834150569895,
 'crude.eia_psm.padd_3__padd_4.total.deliveries.kbd.monthly': 0.10185478345394741,
 'crude.eia_psm.padd_3__padd_5.total.deliveries.kbd.monthly': 0.09560401248965512,
 'crude.eia_psm.padd_4__padd_1.total.deliveries.kbd.monthly': 0.08043901304617646,
 'crude.eia_psm.padd_4__padd_2.total.deliveries.kbd.monthly': 0.09105091524249674,
 'crude.eia_psm.padd_4__padd_3.total.deliveries.kbd.monthly': 0.09427041337722385,
 'crude.eia_psm.padd_4__padd_5.total.deliveries.kbd.monthly': 0.09462738323630038,
 'crude.eia_psm.padd_5__padd_2.total.deliveries.kbd.monthly': 0.07829593954444156,
 'crude.eia_psm.padd_5__padd_3.total.deliveries.kbd.monthly': 0.0776714289088411,
 'crude.eia_psm.padd_5__padd_4.total.deliveries.kbd.monthly': 0.0710535191445554,
 'lng.kpler.cargo_arrivals.europe.Europe.Unknown.cargoes.15days.daily': 0.061279073017074526,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Belgium.cargoes.15days.daily': 0.13271326210729234,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.France.cargoes.15days.daily': 0.071296306247273,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Germany.cargoes.15days.daily': 0.13732139445407598,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Netherlands.cargoes.15days.daily': 0.06973088646996872,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.Total.cargoes.15days.daily': 0.026610749787285826,
 'lng.kpler.cargo_arrivals.europe.NW_Europe.United_Kingdom.cargoes.15days.daily': 0.06916857441032402,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Finland.cargoes.15days.daily': 0.1133911543369887,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Greece.cargoes.15days.daily': 0.13038143074637834,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Italy.cargoes.15days.daily': 0.12202577806995532,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Lithuania.cargoes.15days.daily': 0.12261284885473132,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Poland.cargoes.15days.daily': 0.11780374986593577,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Portugal.cargoes.15days.daily': 0.07905800862201968,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Spain.cargoes.15days.daily': 0.15171690352291978,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Total.cargoes.15days.daily': 0.03901138785724163,
 'lng.kpler.cargo_arrivals.europe.Rest_of_Europe.Turkey.cargoes.15days.daily': 0.02057289032600394,
 'lng.kpler.cargo_on_water.all_vessels.laden_tonnage.ton.daily': 0.1399736308331322,
 'lng.kpler.cargo_on_water.all_vessels.pctg_ballast.pctg.daily': 0.17276744447689102,
 'lng.kpler.cargo_on_water.all_vessels.pctg_laden.pctg.daily': 0.17924112735963324,
 'lng.kpler.cargo_on_water.all_vessels.speed_ballast.knot.daily': 0.1522070729771017,
 'lng.kpler.cargo_on_water.all_vessels.speed_laden.knot.daily': 0.1885108753423108}
```

---

# Test-Hit 89 series from Sonaia's Excel via HTTP using loader.py from client computer

## Summary
89 series were hit using Loader.py via HTTP

|Metric(secs)|AP9|AP12|
-------|---|---|
Total time taken|736|2674|
Median time taken|72|266|
|crude.petroineos.oecd_europe.throughput.kbd.monthly.forecast|33|191|
|crude.petroineos.oecd_europe.throughput.kt.monthly.forecast|33|186|
|gasoline.petroineos.oecd_europe.ending_stocks.kt.monthly.forecast|45|220|
|gasoline.petroineos.oecd_europe.commercial_stocks.kt.monthly.forecast|47|219|
|gasoline.petroineos.oecd_europe.net_length.kt.monthly.forecast|42|208|
|gasoline.petroineos.oecd_europe.implied_stock_change.kt.monthly.forecast|43|218|

## AP12

.\loader.py excel_series.txt http://saturndev/api
run in median=266.5592064857483 seconds, stdev=2.1682600431865993, url=http://tst-qdev-ap12:8086/api, count of series=89, total time=2674.9 secs

```json
Found 89 series after reading the file: C:\Users\saurabhdasgupta\source\repos-devops\DataAnalysisAllRepos\ql-saturn-server\windows_server_deploy\performance\excel_series.txt
function run_with_individual_median_capture
Going to use the URL: http://saturndev/api
median per series:
{'crude.petroineos.oecd_europe.throughput.kbd.monthly.forecast': 191.2872805595398,
 'crude.petroineos.oecd_europe.throughput.kt.monthly.forecast': 186.537823677063,
 'diesel.ara.genscape.ending_stocks.kt.weekly': 1.226529598236084,
 'diesel.eia.padd_1.stocks.kb.weekly': 0.20669424533843994,
 'diesel.eia.usa.padd_1.imports.kbd.weekly': 0.20301079750061035,
 'diesel.iea.france.demand.kt.monthly': 0.1215050220489502,
 'diesel.iea.oecd_europe.refining_yield.pct.monthly': 0.31999003887176514,
 'gasoline.eia.padd_1.stocks.kb.weekly': 0.19999241828918457,
 'gasoline.genscape.ara.ending_stocks.kt.weekly': 1.0290067195892334,
 'gasoline.genscape.nyh.ending_stocks.kt.weekly': 1.0504823923110962,
 'gasoline.iea.oecd_europe.ending_stocks.kt.monthly': 0.14001047611236572,
 'gasoline.iea.oecd_europe.refining_yield.pct.monthly': 0.34150099754333496,
 'gasoline.jodi.france.demand.kt.monthly': 0.1184995174407959,
 'gasoline.petroineos.oecd_europe.brazil.exports.kt.monthly.forecast': 0.14250147342681885,
 'gasoline.petroineos.oecd_europe.canada.exports.kt.monthly.forecast': 0.14950084686279297,
 'gasoline.petroineos.oecd_europe.commercial_stocks.kt.monthly.forecast': 219.9979681968689,
 'gasoline.petroineos.oecd_europe.demand.kt.monthly.forecast': 2.353788375854492,
 'gasoline.petroineos.oecd_europe.east_africa.exports.kt.monthly.forecast': 0.2835080623626709,
 'gasoline.petroineos.oecd_europe.ending_stocks.kt.monthly.forecast': 220.01356208324432,
 'gasoline.petroineos.oecd_europe.far_east.exports.kt.monthly.forecast': 0.15999484062194824,
 'gasoline.petroineos.oecd_europe.implied_stock_change.kt.monthly.forecast': 218.1013616323471,
 'gasoline.petroineos.oecd_europe.interproduct_transfers_for_blending.kt.monthly.forecast': 4.525214314460754,
 'gasoline.petroineos.oecd_europe.latin_america.exports.kt.monthly.forecast': 0.13050246238708496,
 'gasoline.petroineos.oecd_europe.mexico.exports.kt.monthly.forecast': 0.2809964418411255,
 'gasoline.petroineos.oecd_europe.middle_east.exports.kt.monthly.forecast': 0.1645030975341797,
 'gasoline.petroineos.oecd_europe.net_length.kt.monthly.forecast': 208.9548695087433,
 'gasoline.petroineos.oecd_europe.refinery_yield.pct.monthly.forecast': 2.7301735877990723,
 'gasoline.petroineos.oecd_europe.refining_production.kt.monthly.forecast': 201.19770467281342,
 'gasoline.petroineos.oecd_europe.south_africa.exports.kt.monthly.forecast': 0.12640714645385742,
 'gasoline.petroineos.oecd_europe.strategic_stocks.kt.monthly.forecast': 0.2799961566925049,
 'gasoline.petroineos.oecd_europe.usa.exports.kt.monthly.forecast': 0.4490056037902832,
 'gasoline.petroineos.oecd_europe.waf.exports.kt.monthly.forecast': 0.2953972816467285,
 'gasoline.petroineos.oecd_europe.world.net_exports.kt.monthly.forecast': 4.7535480260849,
 'gasoline_components.genscape.ara.ending_stocks.kt.weekly': 1.2895199060440063,
 'mogas_naphtha_spread_curve.usd_t.daily': 2.8895037174224854,
 'naphtha.genscape.ara.ending_stocks.kt.weekly': 1.0249968767166138,
 'nwe_gasoline_diesel_spread.usd_bbl': 2.582385778427124,
 'oil.energy_aspects.india.throughput.kbd.monthly': 0.08449280261993408,
 'oil.petroineos.euromargin.medcomplex.usd_bbl.monthly': 0.07149827480316162,
 'oil.petroineos.euromargin.nwecomplex.usd_bbl.monthly': 0.07849502563476562,
 'oil.petroineos.oecd_europe.cdu.total_outage_plus_economic.kbd.monthly': 1.8760149478912354,
 'oil.petroineos.oecd_europe.cdu_utilization_rate.pct.monthly.full': 240.92393493652344,
 'oil.petroineos.oecd_europe.fcc_ref_cdu.available_capacity_yield.pct.monthly': 14.666722297668457,
 'price.argus.nwe_net_fcc_margin.usd_bbl.daily': 4.312022924423218,
 'price.argus.nwe_net_hydrocracking_margin.usd_bbl.daily': 4.3686203956604,
 'price.nymex.rbob.m01.usd_gal.daily.spread': 0.8241901397705078,
 'price.nymex.rbob_ho_spread.m01.usd_bbl.daily': 0.5710510015487671,
 'price.platts.eurobob_10ppm_spread.m01.usd_t.daily': 6.446410179138184,
 'price.platts.naphtha_cif_nwe_cargo_crack.m01.usd_bbl.daily': 0.31227922439575195,
 'price.platts.platts_eurobob_barge_crack.m12.usd_bbl.daily': 0.2908841371536255,
 'price.platts.platts_eurobob_barge_crack_box.m01.usd_bbl.daily': 0.3609936237335205,
 'price.platts.platts_eurobob_barge_crack_curve.m01.usd_bbl.daily': 2.914841890335083,
 'price.platts.us_gulf_arbitrage_to_ukc.usd_t.daily.forward': 7.839820027351379}
stdev per series:
{'crude.petroineos.oecd_europe.throughput.kbd.monthly.forecast': 2.9476394620772135,
 'crude.petroineos.oecd_europe.throughput.kt.monthly.forecast': 3.127865135679261,
 'diesel.ara.genscape.ending_stocks.kt.weekly': 0.13322941220273277,
 'diesel.eia.padd_1.stocks.kb.weekly': 0.05890413748588155,
 'diesel.eia.usa.padd_1.imports.kbd.weekly': 0.043337805867183395,
 'diesel.iea.france.demand.kt.monthly': 0.013858922702018793,
 'diesel.iea.oecd_europe.refining_yield.pct.monthly': 0.06782363539697693,
 'gasoline.eia.padd_1.stocks.kb.weekly': 0.031031271717485726,
 'gasoline.genscape.ara.ending_stocks.kt.weekly': 0.09741136456235805,
 'gasoline.genscape.nyh.ending_stocks.kt.weekly': 2.9316074965866488,
 'gasoline.iea.oecd_europe.ending_stocks.kt.monthly': 0.027612474165610846,
 'gasoline.iea.oecd_europe.refining_yield.pct.monthly': 0.09425750281089015,
 'gasoline.jodi.france.demand.kt.monthly': 0.015909641311160013,
 'gasoline.petroineos.oecd_europe.brazil.exports.kt.monthly.forecast': 0.09102390027639062,
 'gasoline.petroineos.oecd_europe.canada.exports.kt.monthly.forecast': 0.03640027181441185,
 'gasoline.petroineos.oecd_europe.commercial_stocks.kt.monthly.forecast': 1.7551954734499877,
 'gasoline.petroineos.oecd_europe.demand.kt.monthly.forecast': 0.25102431203486875,
 'gasoline.petroineos.oecd_europe.east_africa.exports.kt.monthly.forecast': 0.025906782476268642,
 'gasoline.petroineos.oecd_europe.ending_stocks.kt.monthly.forecast': 1.7793335153581453,
 'gasoline.petroineos.oecd_europe.far_east.exports.kt.monthly.forecast': 0.01636165990290699,
 'gasoline.petroineos.oecd_europe.implied_stock_change.kt.monthly.forecast': 4.717878930916355,
 'gasoline.petroineos.oecd_europe.interproduct_transfers_for_blending.kt.monthly.forecast': 1.8464738817077373,
 'gasoline.petroineos.oecd_europe.latin_america.exports.kt.monthly.forecast': 0.05037033951515508,
 'gasoline.petroineos.oecd_europe.mexico.exports.kt.monthly.forecast': 0.014764016327749777,
 'gasoline.petroineos.oecd_europe.middle_east.exports.kt.monthly.forecast': 0.02843390029657803,
 'gasoline.petroineos.oecd_europe.net_length.kt.monthly.forecast': 2.531736890374007,
 'gasoline.petroineos.oecd_europe.refinery_yield.pct.monthly.forecast': 0.38389073223580755,
 'gasoline.petroineos.oecd_europe.refining_production.kt.monthly.forecast': 4.168877504559193,
 'gasoline.petroineos.oecd_europe.south_africa.exports.kt.monthly.forecast': 0.012749130839080566,
 'gasoline.petroineos.oecd_europe.strategic_stocks.kt.monthly.forecast': 0.017876774217339977,
 'gasoline.petroineos.oecd_europe.usa.exports.kt.monthly.forecast': 0.1757273408950356,
 'gasoline.petroineos.oecd_europe.waf.exports.kt.monthly.forecast': 0.14331743425190904,
 'gasoline.petroineos.oecd_europe.world.net_exports.kt.monthly.forecast': 2.0960236487778827,
 'gasoline_components.genscape.ara.ending_stocks.kt.weekly': 0.19050245131343488,
 'mogas_naphtha_spread_curve.usd_t.daily': 0.13263148983771758,
 'naphtha.genscape.ara.ending_stocks.kt.weekly': 0.17127455447726753,
 'nwe_gasoline_diesel_spread.usd_bbl': 0.3415596916486239,
 'oil.energy_aspects.india.throughput.kbd.monthly': 0.014702261436072029,
 'oil.petroineos.euromargin.medcomplex.usd_bbl.monthly': 0.010094325123663279,
 'oil.petroineos.euromargin.nwecomplex.usd_bbl.monthly': 0.009475308632829171,
 'oil.petroineos.oecd_europe.cdu.total_outage_plus_economic.kbd.monthly': 0.12624068135640001,
 'oil.petroineos.oecd_europe.cdu_utilization_rate.pct.monthly.full': 84.60112363341035,
 'oil.petroineos.oecd_europe.fcc_ref_cdu.available_capacity_yield.pct.monthly': 5.028803671502924,
 'price.argus.nwe_net_fcc_margin.usd_bbl.daily': 0.4226825952226362,
 'price.argus.nwe_net_hydrocracking_margin.usd_bbl.daily': 0.1680458446084904,
 'price.nymex.rbob.m01.usd_gal.daily.spread': 0.1328357146584879,
 'price.nymex.rbob_ho_spread.m01.usd_bbl.daily': 0.19096822685602732,
 'price.platts.eurobob_10ppm_spread.m01.usd_t.daily': 0.35165068294487556,
 'price.platts.naphtha_cif_nwe_cargo_crack.m01.usd_bbl.daily': 0.07585325926490853,
 'price.platts.platts_eurobob_barge_crack.m12.usd_bbl.daily': 0.05662880027705716,
 'price.platts.platts_eurobob_barge_crack_box.m01.usd_bbl.daily': 0.07928026401910021,
 'price.platts.platts_eurobob_barge_crack_curve.m01.usd_bbl.daily': 0.13004544543022556,
 'price.platts.us_gulf_arbitrage_to_ukc.usd_t.daily.forward': 0.27331642189613403}
run in median=261.53820979595184 seconds, stdev=1.6331386968198724, url=http://saturndev/api, count of series=89, total time=2621.7 secs
```




## AP9

.\loader.py excel_series.txt http://tst-qdev-ap9.petroineos.local/api/

run in median=71.75239539146423 seconds, stdev=5.519159517254079, url=http://tst-qdev-ap9.petroineos.local/api/, count of series=89, total time=735.6 secs

```json
{'crude.petroineos.oecd_europe.throughput.kbd.monthly.forecast': 32.195552587509155,
 'crude.petroineos.oecd_europe.throughput.kt.monthly.forecast': 32.6653596162796,
 'diesel.ara.genscape.ending_stocks.kt.weekly': 0.8979883193969727,
 'diesel.eia.padd_1.stocks.kb.weekly': 0.1595975160598755,
 'diesel.eia.usa.padd_1.imports.kbd.weekly': 0.18599021434783936,
 'diesel.iea.france.demand.kt.monthly': 0.10000157356262207,
 'diesel.iea.oecd_europe.refining_yield.pct.monthly': 0.11398744583129883,
 'gasoline.eia.padd_1.stocks.kb.weekly': 0.18350374698638916,
 'gasoline.genscape.ara.ending_stocks.kt.weekly': 0.8217728137969971,
 'gasoline.genscape.nyh.ending_stocks.kt.weekly': 0.8400208950042725,
 'gasoline.iea.oecd_europe.ending_stocks.kt.monthly': 0.2054980993270874,
 'gasoline.iea.oecd_europe.refining_yield.pct.monthly': 0.14149248600006104,
 'gasoline.jodi.france.demand.kt.monthly': 0.043727874755859375,
 'gasoline.petroineos.oecd_europe.brazil.exports.kt.monthly.forecast': 0.0560075044631958,
 'gasoline.petroineos.oecd_europe.canada.exports.kt.monthly.forecast': 0.04349052906036377,
 'gasoline.petroineos.oecd_europe.commercial_stocks.kt.monthly.forecast': 47.087908029556274,
 'gasoline.petroineos.oecd_europe.demand.kt.monthly.forecast': 1.1820241212844849,
 'gasoline.petroineos.oecd_europe.east_africa.exports.kt.monthly.forecast': 0.09451711177825928,
 'gasoline.petroineos.oecd_europe.ending_stocks.kt.monthly.forecast': 45.73749780654907,
 'gasoline.petroineos.oecd_europe.far_east.exports.kt.monthly.forecast': 0.03645765781402588,
 'gasoline.petroineos.oecd_europe.implied_stock_change.kt.monthly.forecast': 43.22575628757477,
 'gasoline.petroineos.oecd_europe.interproduct_transfers_for_blending.kt.monthly.forecast': 1.9709669351577759,
 'gasoline.petroineos.oecd_europe.latin_america.exports.kt.monthly.forecast': 0.0492708683013916,
 'gasoline.petroineos.oecd_europe.mexico.exports.kt.monthly.forecast': 0.07899594306945801,
 'gasoline.petroineos.oecd_europe.middle_east.exports.kt.monthly.forecast': 0.026023268699645996,
 'gasoline.petroineos.oecd_europe.net_length.kt.monthly.forecast': 42.8582067489624,
 'gasoline.petroineos.oecd_europe.refinery_yield.pct.monthly.forecast': 1.6295214891433716,
 'gasoline.petroineos.oecd_europe.refining_production.kt.monthly.forecast': 37.31862223148346,
 'gasoline.petroineos.oecd_europe.south_africa.exports.kt.monthly.forecast': 0.03799140453338623,
 'gasoline.petroineos.oecd_europe.strategic_stocks.kt.monthly.forecast': 0.11650955677032471,
 'gasoline.petroineos.oecd_europe.usa.exports.kt.monthly.forecast': 0.1595073938369751,
 'gasoline.petroineos.oecd_europe.waf.exports.kt.monthly.forecast': 0.12155866622924805,
 'gasoline.petroineos.oecd_europe.world.net_exports.kt.monthly.forecast': 2.442396640777588,
 'gasoline_components.genscape.ara.ending_stocks.kt.weekly': 1.0070226192474365,
 'mogas_naphtha_spread_curve.usd_t.daily': 1.6830573081970215,
 'naphtha.genscape.ara.ending_stocks.kt.weekly': 0.8920480012893677,
 'nwe_gasoline_diesel_spread.usd_bbl': 1.8780016899108887,
 'oil.energy_aspects.india.throughput.kbd.monthly': 0.16653430461883545,
 'oil.petroineos.euromargin.medcomplex.usd_bbl.monthly': 0.04299759864807129,
 'oil.petroineos.euromargin.nwecomplex.usd_bbl.monthly': 0.027001500129699707,
 'oil.petroineos.oecd_europe.cdu.total_outage_plus_economic.kbd.monthly': 0.7422757148742676,
 'oil.petroineos.oecd_europe.cdu_utilization_rate.pct.monthly.full': 42.67929768562317,
 'oil.petroineos.oecd_europe.fcc_ref_cdu.available_capacity_yield.pct.monthly': 8.104197025299072,
 'price.argus.nwe_net_fcc_margin.usd_bbl.daily': 2.116928219795227,
 'price.argus.nwe_net_hydrocracking_margin.usd_bbl.daily': 0.9705129861831665,
 'price.nymex.rbob.m01.usd_gal.daily.spread': 0.4495135545730591,
 'price.nymex.rbob_ho_spread.m01.usd_bbl.daily': 0.29603540897369385,
 'price.platts.eurobob_10ppm_spread.m01.usd_t.daily': 6.069600939750671,
 'price.platts.naphtha_cif_nwe_cargo_crack.m01.usd_bbl.daily': 0.13999545574188232,
 'price.platts.platts_eurobob_barge_crack.m12.usd_bbl.daily': 0.04399394989013672,
 'price.platts.platts_eurobob_barge_crack_box.m01.usd_bbl.daily': 0.20151102542877197,
 'price.platts.platts_eurobob_barge_crack_curve.m01.usd_bbl.daily': 2.244244694709778,
 'price.platts.us_gulf_arbitrage_to_ukc.usd_t.daily.forward': 3.924772262573242}
stdev per series:
{'crude.petroineos.oecd_europe.throughput.kbd.monthly.forecast': 4.3015259264902745,
 'crude.petroineos.oecd_europe.throughput.kt.monthly.forecast': 4.511049768696869,
 'diesel.ara.genscape.ending_stocks.kt.weekly': 0.7888970195229852,
 'diesel.eia.padd_1.stocks.kb.weekly': 0.0891714626886544,
 'diesel.eia.usa.padd_1.imports.kbd.weekly': 0.09617055330851457,
 'diesel.iea.france.demand.kt.monthly': 0.09170696788864105,
 'diesel.iea.oecd_europe.refining_yield.pct.monthly': 0.057428223771680574,
 'gasoline.eia.padd_1.stocks.kb.weekly': 0.10584758594781918,
 'gasoline.genscape.ara.ending_stocks.kt.weekly': 0.7642027717671611,
 'gasoline.genscape.nyh.ending_stocks.kt.weekly': 0.3057336550603149,
 'gasoline.iea.oecd_europe.ending_stocks.kt.monthly': 0.13726948169275524,
 'gasoline.iea.oecd_europe.refining_yield.pct.monthly': 0.12132573209802491,
 'gasoline.jodi.france.demand.kt.monthly': 0.025529197022181295,
 'gasoline.petroineos.oecd_europe.brazil.exports.kt.monthly.forecast': 0.047614850801261516,
 'gasoline.petroineos.oecd_europe.canada.exports.kt.monthly.forecast': 0.016025853483915616,
 'gasoline.petroineos.oecd_europe.commercial_stocks.kt.monthly.forecast': 4.653710140854641,
 'gasoline.petroineos.oecd_europe.demand.kt.monthly.forecast': 0.4049441133123404,
 'gasoline.petroineos.oecd_europe.east_africa.exports.kt.monthly.forecast': 0.12181088099036434,
 'gasoline.petroineos.oecd_europe.ending_stocks.kt.monthly.forecast': 4.134785155074143,
 'gasoline.petroineos.oecd_europe.far_east.exports.kt.monthly.forecast': 0.011027666181648521,
 'gasoline.petroineos.oecd_europe.implied_stock_change.kt.monthly.forecast': 5.875393639897719,
 'gasoline.petroineos.oecd_europe.interproduct_transfers_for_blending.kt.monthly.forecast': 0.45845253887124066,
 'gasoline.petroineos.oecd_europe.latin_america.exports.kt.monthly.forecast': 0.02863146521502134,
 'gasoline.petroineos.oecd_europe.mexico.exports.kt.monthly.forecast': 0.08720465167007081,
 'gasoline.petroineos.oecd_europe.middle_east.exports.kt.monthly.forecast': 0.013908691968133775,
 'gasoline.petroineos.oecd_europe.net_length.kt.monthly.forecast': 6.69710100379093,
 'gasoline.petroineos.oecd_europe.refinery_yield.pct.monthly.forecast': 1.040461192577652,
 'gasoline.petroineos.oecd_europe.refining_production.kt.monthly.forecast': 4.931523997926105,
 'gasoline.petroineos.oecd_europe.south_africa.exports.kt.monthly.forecast': 0.013196765328974673,
 'gasoline.petroineos.oecd_europe.strategic_stocks.kt.monthly.forecast': 0.08620646288469051,
 'gasoline.petroineos.oecd_europe.usa.exports.kt.monthly.forecast': 0.06663417712357778,
 'gasoline.petroineos.oecd_europe.waf.exports.kt.monthly.forecast': 0.09760613602554154,
 'gasoline.petroineos.oecd_europe.world.net_exports.kt.monthly.forecast': 1.1910678106461206,
 'gasoline_components.genscape.ara.ending_stocks.kt.weekly': 0.7593594398235877,
 'mogas_naphtha_spread_curve.usd_t.daily': 0.09090520221248892,
 'naphtha.genscape.ara.ending_stocks.kt.weekly': 0.7584157288514823,
 'nwe_gasoline_diesel_spread.usd_bbl': 0.237822354231751,
 'oil.energy_aspects.india.throughput.kbd.monthly': 0.10903799339981496,
 'oil.petroineos.euromargin.medcomplex.usd_bbl.monthly': 0.35696442097987124,
 'oil.petroineos.euromargin.nwecomplex.usd_bbl.monthly': 0.17480676878684892,
 'oil.petroineos.oecd_europe.cdu.total_outage_plus_economic.kbd.monthly': 0.8317632074087944,
 'oil.petroineos.oecd_europe.cdu_utilization_rate.pct.monthly.full': 4.633028354780668,
 'oil.petroineos.oecd_europe.fcc_ref_cdu.available_capacity_yield.pct.monthly': 2.923581324144707,
 'price.argus.nwe_net_fcc_margin.usd_bbl.daily': 0.5111144361782357,
 'price.argus.nwe_net_hydrocracking_margin.usd_bbl.daily': 0.3834130343498571,
 'price.nymex.rbob.m01.usd_gal.daily.spread': 0.30542392173393557,
 'price.nymex.rbob_ho_spread.m01.usd_bbl.daily': 0.21885919743492446,
 'price.platts.eurobob_10ppm_spread.m01.usd_t.daily': 0.23735135214924488,
 'price.platts.naphtha_cif_nwe_cargo_crack.m01.usd_bbl.daily': 0.09758628570577103,
 'price.platts.platts_eurobob_barge_crack.m12.usd_bbl.daily': 0.053143828003465045,
 'price.platts.platts_eurobob_barge_crack_box.m01.usd_bbl.daily': 0.18556208825088286,
 'price.platts.platts_eurobob_barge_crack_curve.m01.usd_bbl.daily': 0.5732942643595889,
 'price.platts.us_gulf_arbitrage_to_ukc.usd_t.daily.forward': 0.20793732993987377}
```

---

# Test-Excel addin results from the backend when logging was introduced (AP12 only)

## Overview
The objective was to test the fine grained time consumption on the back end when the Excel button **Get Tab** is pressed. To achieve this,
we added `logging.info` in the **BluePrint.py** of the installed PIP component **tshistory_xl**

## Why on AP12 only and not on AP9?
Do not want to de-stablize a production box by making insite changes to an active Python component 


## Which Excel sheet ?
This is the Sheet **Pull_002** , which has 26 series and is a subset from the much larger Sonia's document

## Summary list of time taken

The following series take considerable time. The rest took less than **1 second**!


Series name | Elapsed time(sec)|
---------|----------|
 crude.petroineos.oecd_europe.throughput.kt.monthly.forecast | 94 | 
 crude.petroineos.oecd_europe.throughput.kbd.monthly.forecast | 97 | 
 gasoline.petroineos.oecd_europe.refining_production.kt.monthly.forecast | 99 | 
 gasoline.petroineos.oecd_europe.net_length.kt.monthly.forecast | 105 | 
 gasoline.petroineos.oecd_europe.commercial_stocks.kt.monthly.forecast | 108 | 
 gasoline.petroineos.oecd_europe.implied_stock_change.kt.monthly.forecast | 108 | 
 gasoline.petroineos.oecd_europe.ending_stocks.kt.monthly.forecast | 109 | 
 oil.petroineos.oecd_europe.cdu_utilization_rate.pct.monthly.full | 113 | 




## Extract from the logs

```
Search "elapsed" (27 hits in 3 files of 35 searched)
  C:\Petroineos\logs\saturnweb\dev\current.log.2023-12-07_16-56 (2 hits)
	Line  8: 2023-12-07 16:56:46,642 INFO blueprint.py 87: Complete-seriename='crude.kpler.ara.ending_stocks.mb.daily' and zonename='rwc_sau' , elapsed=0.1 secs
	Line 10: 2023-12-07 16:56:46,642 INFO blueprint.py 87: Complete-seriename='crude.kpler.china.commercial_stocks.mb.daily' and zonename='rwc_sau' , elapsed=0.1 secs
  C:\Petroineos\logs\saturnweb\dev\current.log.2023-12-07_16-57 (17 hits)
	Line 19: 2023-12-07 16:57:53,506 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.strategic_stocks.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=0.3 secs
	Line 20: 2023-12-07 16:57:53,506 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.mexico.exports.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=0.3 secs
	Line 22: 2023-12-07 16:57:53,522 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.east_africa.exports.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=0.3 secs
	Line 24: 2023-12-07 16:57:53,662 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.usa.exports.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=0.5 secs
	Line 30: 2023-12-07 16:57:54,225 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.latin_america.exports.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=0.1 secs
	Line 32: 2023-12-07 16:57:54,256 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.brazil.exports.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=0.1 secs
	Line 34: 2023-12-07 16:57:54,287 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.south_africa.exports.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=0.2 secs
	Line 36: 2023-12-07 16:57:54,381 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.waf.exports.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=0.3 secs
	Line 42: 2023-12-07 16:57:55,162 INFO blueprint.py 87: Complete-seriename='gasoline.jodi.france.demand.kt.monthly' and zonename='rwc_pull_002' , elapsed=0.1 secs
	Line 44: 2023-12-07 16:57:55,193 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.middle_east.exports.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=0.1 secs
	Line 47: 2023-12-07 16:57:55,193 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.far_east.exports.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=0.1 secs
	Line 48: 2023-12-07 16:57:55,209 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.canada.exports.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=0.1 secs
	Line 50: 2023-12-07 16:57:55,600 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.refinery_yield.pct.monthly.forecast' and zonename='rwc_pull_002' , elapsed=2.4 secs
	Line 52: 2023-12-07 16:57:55,834 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.demand.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=2.7 secs
	Line 55: 2023-12-07 16:57:56,272 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.interproduct_transfers_for_blending.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=3.1 secs
	Line 57: 2023-12-07 16:57:57,303 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.world.net_exports.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=4.1 secs
	Line 59: 2023-12-07 16:58:00,491 INFO blueprint.py 87: Complete-seriename='oil.petroineos.oecd_europe.fcc_ref_cdu.available_capacity_yield.pct.monthly' and zonename='rwc_pull_002' , elapsed=7.3 secs
  C:\Petroineos\logs\saturnweb\dev\current.log.2023-12-07_16-59 (8 hits)
	Line  2: 2023-12-07 16:59:27,203 INFO blueprint.py 87: Complete-seriename='crude.petroineos.oecd_europe.throughput.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=94.0 secs
	Line  4: 2023-12-07 16:59:32,718 INFO blueprint.py 87: Complete-seriename='crude.petroineos.oecd_europe.throughput.kbd.monthly.forecast' and zonename='rwc_pull_002' , elapsed=96.7 secs
	Line  6: 2023-12-07 16:59:33,015 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.refining_production.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=99.8 secs
	Line  8: 2023-12-07 16:59:38,158 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.net_length.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=105.0 secs
	Line 10: 2023-12-07 16:59:41,939 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.commercial_stocks.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=108.7 secs
	Line 12: 2023-12-07 16:59:41,986 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.implied_stock_change.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=108.8 secs
	Line 14: 2023-12-07 16:59:42,408 INFO blueprint.py 87: Complete-seriename='gasoline.petroineos.oecd_europe.ending_stocks.kt.monthly.forecast' and zonename='rwc_pull_002' , elapsed=109.2 secs
	Line 16: 2023-12-07 16:59:47,049 INFO blueprint.py 87: Complete-seriename='oil.petroineos.oecd_europe.cdu_utilization_rate.pct.monthly.full' and zonename='rwc_pull_002' , elapsed=113.9 secs

```
---

# Test-Hit a small number of very high time consuming Series from Exel (incuding as_of)
## Summary
We used a smaller set of series which were found to be time consuming and fired the modified script on this file (excel_asof_series_small.txt)
```
python .\loader_asof.py .\excel_asof_series_small.txt  http://saturndev/api/
```

## AP12
run in median=52.794066071510315 seconds, stdev=0.4706014143933425
Just 1 series
run in median=19.462299942970276 seconds, stdev=0.25342838288021474 total time=196.6 secs

## AP9
run in median=79.49974274635315 seconds, stdev=8.27685234125017

Just 1 series
run in median=30.831906914711 seconds, stdev=2.293681706501112 total time=311.0 secs

---

# Test-Modified "As Of"  test with just 1 Series

## Summary

We hit just 1 time consuming series over several attempts.

Attempt no|Metric(secs) | AP9 | AP12
---------|----------|---------|-----|
1 |Median | 75 | 54|
1 |Total | 151 | 109|
2 |Median | 100 | 53|
2 |Total | 200 | 107|
3 |Median | 78 | 53|
3 |Total | 158 | 108|
4 |Median | 99 | 53|
4 |Total | 199 | 107|
5 |Median | 91 | 54|
5 |Total | 184 | 109|


## Which Series ?
gasoline.petroineos.oecd_europe.commercial_stocks.kt.monthly.forecast

## Command line

.\loader_asof.py .\excel_asof_series_small.txt  http://tst-qdev-ap9/api/
.\loader_asof.py .\excel_asof_series_small.txt  http://saturndev/api/


## AP12
```
run in median=54.41012251377106 seconds, stdev=0.49330070772520934 total time=109.6 secs
run in median=53.21400511264801 seconds, stdev=0.1640016483381968 total time=107.7 secs , url=http://saturndev/api/
run in median=53.46980178356171 seconds, stdev=0.1033314284941589 total time=108.3 secs , url=http://saturndev/api/
run in median=53.47993302345276 seconds, stdev=0.22083229028289228 total time=107.7 secs , url=http://saturndev/api/
run in median=54.05582046508789 seconds, stdev=0.8198442061565797 total time=109.4 secs , url=http://saturndev/api/
```

## AP9
```
run in median=75.22526860237122 seconds, stdev=2.1251954933991284 total time=151.8 secs
run in median=100.41642820835114 seconds, stdev=28.24692829674428 total time=201.5 secs
run in median=78.82541298866272 seconds, stdev=11.234956606779972 total time=158.4 secs , url=http://tst-qdev-ap9/api/
run in median=99.27782595157623 seconds, stdev=9.082544533073843 total time=199.3 secs , url=http://tst-qdev-ap9/api/
run in median=91.7977569103241 seconds, stdev=20.808594701416208 total time=184.5 secs , url=http://tst-qdev-ap9/api/
```

---

# Test-Excel emulator on 130 primary series

## Summary
Total time(secs) taken to hit 130 series using the file `primary_series.txt`
Attempt no| AP9 | AP12
---------|----------|---------|
1 | 6.8 | 1.8|
2 | 6.8 | 1.7|
3 | 7.0 | 1.6|
4 | 20.6 | 1.8|


## AP12
```
url=http://tst-qdev-ap12:9091, count of series=130, total time=1.8 secs	
url=http://tst-qdev-ap12:9091, count of series=130, total time=1.7 secs
url=http://tst-qdev-ap12:9091, count of series=130, total time=1.6 secs
url=http://tst-qdev-ap12:9091, count of series=130, total time=1.8 secs
```


## AP9
```
url=http://saturntest, count of series=130, total time=6.8 secs
url=http://saturntest, count of series=130, total time=6.8 secs
url=http://saturntest, count of series=130, total time=7.0 secs
url=http://saturntest, count of series=130, total time=20.6 secs
```

---

# Test- 7 time consuming series

Total time(secs) to hit all the series using the file `excel_asof_series_small.txt`

Attempt no| AP9 | AP12
---------|----------|---------|
1 | 72.7 | 40.4|
2 | 70.4 | 40.0|
3 | 75.4 | 39.9 |
4 | 70.4 | 39.9|


## AP9

```
http://saturntest, count of series=7, total time=72.7 secs
http://saturntest, count of series=7, total time=70.4 secs
http://saturntest, count of series=7, total time=75.4 secs
http://saturntest, count of series=7, total time=70.4 secs
```

## Ap12

```
http://tst-qdev-ap12:9091, count of series=7, total time=40.4 secs
http://tst-qdev-ap12:9091, count of series=7, total time=40.0 secs
http://tst-qdev-ap12:9091, count of series=7, total time=39.9 secs
http://tst-qdev-ap12:9091, count of series=7, total time=39.9 secs

```

# Test-89 time consuming series (Dec 2023)


## Summary
Total time(secs) to hit all the series using the file `excel_asof_series.txt`

```
\excel_emulator.py  http://tst-qdev-ap12:9091 .\excel_asof_series.txt myzone
```

Attempt no| AP9 | AP12
---------|----------|---------|
1 | 46.5 | 102.6|
2 | 42.4 | 103.1|
3 | 46.0 | 103.7|

## AP9

```
url=http://saturntest, count of series=89, total time=46.5 secs
url=http://saturntest, count of series=89, total time=42.4 secs
url=http://saturntest, count of series=89, total time=46.0 secs
```

## AP12

```
url=http://tst-qdev-ap12:9091, count of series=89, total time=102.6 secs
url=http://tst-qdev-ap12:9091, count of series=89, total time=103.1 secs
url=http://tst-qdev-ap12:9091, count of series=89, total time=103.7 secs

```

---

# Test-89 time consuming series (Jan 10, 2024)

```
.\windows_server_deploy\performance\excel_emulator.py http://tst-qdev-ap12:9091 excel_asof_series.txt myzone 
.\windows_server_deploy\performance\excel_emulator.py http://tst-qdev-ap9 excel_asof_series.txt myzone
```
## Summary

Attempt no| AP9 | AP12
---------|----------|---------|
1 | 25 | 91|
2 | 25 | 92|
3 | 25 | 91|

## AP9

```
url=http://tst-qdev-ap9, count of series=89, total time=25.4 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap9, count of series=89, total time=25.3 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap9, count of series=89, total time=25.0 secs , filename='excel_asof_series.txt'
```

## AP12

```
url=http://tst-qdev-ap12:9091, count of series=89, total time=90.5 secs , filename='excel_asof_series.txt',
url=http://tst-qdev-ap12:9091, count of series=89, total time=91.3 secs , filename='excel_asof_series.txt',
```


---

# Reindexing the database on AP12

I did the re-indexing immediately after restoration from AP9. It tool over 50 minutes!!!!

```
REINDEX DATABASE devsaturndatabase;
```

![database_reindex.png](pics/database_reindex.png)


---

# Performance after reindexing on AP12

## Summary

Attempt no|  AP12
---------|----------|
1 | 91|
2 | 92|
3 | 90|


## Logs

```
url=http://tst-qdev-ap12:9091, count of series=89, total time=90.2 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=91.1 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=89.8 secs , filename='excel_asof_series.txt'
```

---

# Performane after changing max_parallel_workers_per_gather to 20
```
.\windows_server_deploy\performance\excel_emulator.py http://tst-qdev-ap12:9091 excel_asof_series.txt myzone
```

## Summary

Attempt no|  AP12
---------|----------|
1 | 85|
2 | 86|
3 | 87|


## Logs
```
url=http://tst-qdev-ap12:9091, count of series=89, total time=84.9 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=85.8 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=86.2 secs , filename='excel_asof_series.txt'
```

---


# Performance after changing work_mem = 2000MB
```
.\windows_server_deploy\performance\excel_emulator.py http://tst-qdev-ap12:9091 excel_asof_series.txt myzone
```

## Summary
Attempt no|  AP12
---------|----------|
1 | 89|
2 | 87|
3 | 86|


## Logs
```
url=http://tst-qdev-ap12:9091, count of series=89, total time=89.1 secs ,filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=88.5 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=86.7 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=85.6 secs , filename='excel_asof_series.txt',
```

---

# Performance after changing max_parallel_workers_per_gather = 200

```
.\windows_server_deploy\performance\excel_emulator.py http://tst-qdev-ap12:9091 excel_asof_series.txt myzone
```

## Summary

Attempt no|  AP12
---------|----------|
1 | 87|
2 | 86|
3 | 86|


## Logs
```
url=http://tst-qdev-ap12:9091, count of series=89, total time=86.5 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=86.2 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=86.1 secs , filename='excel_asof_series.txt'
```

---


# Passmark benchmark

The PassMark tool was used. Note - AP9 was live while the tool was used. 

## AP9
![pass-mark-ap9.PNG
](pics/pass-mark-ap9.PNG)



## AP12

![pass-mark-ap9.PNG](pics/pass-mark-ap12.PNG)


---

# Performance after changing max_connections = 3000

## Summary

Attempt no|  AP12
---------|----------|
1 | 91|
2 | 91|
3 | 91|


## Logs
```
url=http://tst-qdev-ap12:9091, count of series=89, total time=90.7 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=91.4 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=91.3 secs , filename='excel_asof_series.txt'
```

---

# Performance after shared_buffers = 8GB

```
.\windows_server_deploy\performance\excel_emulator.py http://tst-qdev-ap12:9091 excel_asof_series.txt myzone
```

## Summary

Attempt no|  AP12
---------|----------|
1 | 91|
2 | 91|
3 | 102|


## Logs
```
url=http://tst-qdev-ap12:9091, count of series=89, total time=91.0 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=91.3 secs , filename='excel_asof_series.txt'
url=http://tst-qdev-ap12:9091, count of series=89, total time=101.7 secs , filename='excel_asof_series.txt'
```

---

# Performance after setting NTHREAD to 320

```python
NTHREAD = 320 #increased from 32 to 320, Jan 11
```
## Which file?
C:\saturn-demo\9090\.venv\Lib\site-packages\tshistory_xl\blueprint.py

## Summary

Attempt no|  AP12
---------|----------|
1 | 94|
2 | 92|
3 | 95|


## Logs
```
url=http://tst-qdev-ap12:9091, count of series=89, total time=93.5 secs , filename='excel_asof_series.txt'
```

---