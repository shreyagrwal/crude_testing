from collections import defaultdict
from time import time
from pathlib import Path
from pprint import pprint
import statistics as stat
import pandas as pd
from tshistory.api import timeseries
from tshistory.util import threadpool
import os
import sys

#url = 'https://refinery.eflower.pythonian.fr/api'
def load(filename: str):
    input_file_path=os.path.join(os.path.dirname(__file__),filename)
    print(f"Going to read the file: {input_file_path}")
    series_names=Path(input_file_path).read_text().split()
    print(f"Found {len(series_names)} series after reading the file: {input_file_path}")
    #return Path('series.txt').read_text().split()
    return series_names

def read_asof(name):
    items = name.split('(')
    if len(items) == 1:
        return name, None
    name, rest = items
    if 'asof' in rest:
        for item in rest.split(','):
            if item.startswith('asof'):
                _, datestr = item.split('=')
                return name, pd.Timestamp(datestr)
    return name, None

def run(series, url: str):
    MAX_TRIES=2
    start=time()
    pool = threadpool(1)
    tsa = timeseries(url)
    out = defaultdict(list)
    def get(name):
        name, revdate = read_asof(name)
        t0 = time()
        print(name, revdate)
        ts = tsa.get(name, revision_date=revdate)
        assert ts is not None
        assert len(ts)
        out[name].append(time() - t0)
    times = []
    for i in range(MAX_TRIES):
        t0 = time()
        pool(get, [[name,] for name in series])
        times.append(time() - t0)
        t0 = time()
    print('median per series:')
    pprint({k: stat.median(v) for k, v in out.items()})
    print('stdev per series:')
    pprint({k: stat.stdev(v) for k, v in out.items()})
    median = stat.median(times)
    stdev = stat.stdev(times)
    end=time()
    elapsed= end-start        
    print(f'run in {median=} seconds, {stdev=} total time={round(elapsed,1)} secs , url={url}')

if __name__ == '__main__':
    series_names=load(filename=sys.argv[1])
    run(series=series_names, url=sys.argv[2])
