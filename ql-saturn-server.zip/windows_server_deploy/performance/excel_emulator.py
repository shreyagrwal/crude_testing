import pandas as pd
from tshistory_xl.http_custom import HTTPClient
import sys
import os
from pathlib import Path
from time import time

#uri = 'https://refinery.eflower.pythonian.fr'


def load(filename: str):
    input_file_path=os.path.join(os.path.dirname(__file__),filename)
    print(f"Going to read the file: {input_file_path}")
    series_names=Path(input_file_path).read_text().split()
    print(f"Found {len(series_names)} series after reading the file: {input_file_path}")
    return series_names

def get(zone, names, uri: str):
    start=time()
    query = [
        (zone, name,
         {'name': name,
          'revision_date': pd.Timestamp.now(tz='UTC'),
          'from_value_date': None,
          'to_value_date': None,
          'delta': None}
         )
        for name in names
    ]
    client = HTTPClient(uri)
    out = client.get_many(query)
    for zone, name, _asof, ts in out:
        print('*' * 50)
        print(name)
        print(ts)
    end=time()
    elapsed=end-start
    print(f'url={uri}, count of series={len(series_names)}, total time={round(elapsed,1)} secs')
    
def get_15_years(zone, names, uri: str, filename: str):
    start=time()
    to_date=pd.Timestamp.now(tz='UTC')
    from_date=to_date+pd.offsets.DateOffset(years=-17)
    query = [
        (zone, name,
         {'name': name,
          'revision_date': pd.Timestamp.now(tz='UTC'),
          'from_value_date': from_date,
          'to_value_date': to_date,
          'delta': None}
         )
        for name in names
    ]
    client = HTTPClient(uri)
    out = client.get_many(query)
    for zone, name, _asof, ts in out:
        print('*' * 50)
        print(name)
        print(ts)
    end=time()
    elapsed=end-start
    print(f'url={uri}, count of series={len(series_names)}, total time={round(elapsed,1)} secs , {filename=}, {from_date=}, {to_date=}')
# get('foo', [
#     'co2.marginal.at.g-kwh.eflower.fcst.h',
#     'co2.marginal.be.g-kwh.eflower.fcst.h'
# ])

#
#Usage:
#   excel_emulator.py http://saturntest <name of flat file with series names>  myzone
#
if __name__ == "__main__":
    print(f"Command line argumetns: {sys.argv}")
    uri=sys.argv[1] #http://saturntest
    filename=sys.argv[2] #a flat file with names of series, no header 
    zone=sys.argv[3] #name of the Excel region, e.g. myregion
    series_names=load(filename=filename)
    print(f"Found {len(series_names)} series in the file {filename=}")
    #get(zone=zone,names=series_names, uri=uri)
    get_15_years(zone=zone,names=series_names, uri=uri, filename=filename)
