import time
from tshistory.api import timeseries
from time import time
import sys
import os
from pathlib import Path
import pandas as pd

#
#This can handle series with 'asof'
#oil.petroineos.euromargin.nwecomplex.usd_bbl.monthly(asof=2023-11-03)
#

def load_series_names(filename: str):
    input_file_path=os.path.join(os.path.dirname(__file__),filename)
    print(f"Going to read the file: {input_file_path}")
    series_names=Path(input_file_path).read_text().split()
    print(f"Found {len(series_names)} series after reading the file: {input_file_path}")
    return series_names

def read_asof(name):
    items = name.split('(')
    if len(items) == 1:
        return name, None
    name, rest = items
    if 'asof' in rest:
        for item in rest.split(','):
            if item.startswith('asof'):
                _, datestr = item.split('=')
                return name, pd.Timestamp(datestr)
    return name, None

def run_with_series(url:str, series: list[str]):
    start=time()
    tsa = timeseries(url)
    print("got tsa instance")
    for series in series:
        name, revdate = read_asof(series)
        print(f"Fetching {name=}, {revdate=} ")
        
        df=tsa.get(series,revision_date=revdate)
        print(f"Got data frame ,rows:{len(df)}")

    end=time()
    total_elapsed=round(end-start)    
    print(f"All done, Total series={len(series)}, Total time={total_elapsed}, {url=}")
    

if __name__ == '__main__':
    file=sys.argv[1]
    print(f"{file=}")
    url= sys.argv[2]
    print(f"{url=}")
    #series=["lng.kpler.cargo_on_water.all_vessels.laden_tonnage.ton.daily", "gasoline.petroineos.oecd_europe.commercial_stocks.kt.monthly.forecast"]
    series=load_series_names(filename=file)
    run_with_series(url=url,series=series)
