param($domain, $workingfolder)

. $PSScriptRoot\common.ps1

$CurrentFolder=$PSScriptRoot

Write-Host "Inside the script. Going to run rework on domain '$domain' , workingfolder=$workingfolder"
Get-Location
Push-Location -Path $workingfolder
Get-Location

$currentTimeStamp=(Get-Date).ToString("dd-MMM-yyyy-dd-HH-mm")
$logFileName="worker-$domain-$currentTimeStamp.log"
$logFilePath=Join-Path -Path $global:LogsFolder -ChildPath $logFileName

Write-Host "Logging will be done to $logFilePath"
$message="Inside the script. Going to run rework on domain '$domain' $(Get-Date)"
Write-Host $message



$PathToActiveScript= Join-Path -path $global:VenvFolder  -ChildPath "Scripts\Activate.ps1"
& $PathToActiveScript
Write-host "Activated VENV $domain from path $PathToActiveScript"


Write-Host "Going to launch rework with $domain"

#The redirection of both STDOUT and STDERR is causing some problem, produces a file, but nothing is written. Not sure if this is a buffering issue
#& rework monitor db --maxruns 1 --maxworkers 6 --minworkers 0 --domain $domain > $logFilePath 2>&1


#the following works, but no log files
#& rework monitor db --maxruns 1 --maxworkers 6 --minworkers 0 --domain $domain 

#Trying out simple STDOUT redirection
& rework monitor db --maxruns 1 --maxworkers 6 --minworkers 0 --domain $domain > $logFilePath




