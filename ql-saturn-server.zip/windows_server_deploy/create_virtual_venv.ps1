param([Parameter(Mandatory)][System.Boolean]$erasefolder)
. $PSScriptRoot\common.ps1



Write-Host "The folder '$global:VenvFolder' will be used for creating a virtual environment"
Write-Host "You specified erasefolder=$erasefolder"


#
#Stop the IIS Pool
#
StopIISPool -pool $Global:IISAppPool
KillAllReworkProcesses


#
#Clean the existing VENV folder
#
if ($erasefolder)
{
    Write-Host "Erasing the VENV folder because you specified $erasefolder"
    RecursivelyDeleteFolder -folder $global:VenvFolder
    Write-Host "Going to create virtual env using BasePython $global:BasePython"
    New-Item -Path $global:VenvFolder -ItemType Directory
}
else
{
    Write-Host "Not erasing the VENV folder because you specified $erasefolder"
}

#
#Create the VENV
#
Write-Host "Creating the VENV"
& $global:BasePython -m venv $global:VenvFolder

#
#Install the dependencies
#
& $global:VenvFolder\Scripts\Activate.ps1
Write-Host "Activating the venv at $Global:VenvFolder"

$requirementsFile = Join-Path -Path $PSScriptRoot -ChildPath requirements.txt
& pip install --upgrade pip
& pip install -r $requirementsFile
& pip install -e $global:SourceFolder
& pip install saturn-server
StartIISPool -pool $Global:IISAppPool

