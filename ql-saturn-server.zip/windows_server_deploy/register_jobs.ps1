. $PSScriptRoot\common.ps1


<#
Use this script when only when you have added/deleted a task and you want the system to recognize the modified jobs
#>

Write-Host "Going to activate VENV at $Global:VenvFolder"
& $global:VenvFolder\Scripts\Activate.ps1
Write-Host "Activating the venv at $Global:VenvFolder complete"

Write-host "Value of VIRTUAL_ENV is '$env:VIRTUAL_ENV'"


Write-Host "Changing current directory to $global:Worker"
Push-Location -Path $global:Worker
Write-Host "Current working directory is $((Get-Location).Path)"
#& tsh setup-tasks db
& saturn setup-tasks
Write-Host "Completed saturn setup-tasks"
exit $LASTEXITCODE
