. $PSScriptRoot\common.ps1

<#
This is a temporary script which will copy over the source files from the current location to IIS folder

Attention
---------
Use this while coding on AP12. Do not use other wise

#>


Write-Host "Current environment is '$global:environment'"

StopIISPool -pool $Global:IISAppPool
KillAllReworkProcesses

$sourceRoot = Join-Path -Path $PSScriptRoot -ChildPath "..\"
Write-Host "Source: $sourceRoot"
Write-Host "Destination: $global:SourceFolder"

RecursivelyDeleteFolder -folder $global:SourceFolder


& robocopy $sourceRoot $global:SourceFolder /s /v

UpdateWebConfig


StartIISPool -pool $Global:IISAppPool
LaunchAllWorkersOneByOne