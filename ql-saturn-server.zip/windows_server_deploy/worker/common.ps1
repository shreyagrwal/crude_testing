Set-StrictMode -Version "latest"
$ErrorActionPreference="Stop"
$global:DEST="C:\saturn-jobs-2024\ql-saturn-server" # Run time folder where worker code is copied over
$global:VENV_FOLDER=Join-Path -Path $global:DEST -ChildPath ".VENV"

 $global:SaturnLogsFolder="C:\Petroineos\logs\saturn\"



function ThrowErrorIfExitCode($message)
{
    if (0 -eq $LASTEXITCODE)
    {
        return 0
    }
    Write-Error -Message $message
}

function WriteSeparator
{
    Write-Host "-------------------------------"
}

$global:LogFile=$null
Function InitLogFileIfNotInitialized()
{
    if ($null -eq $global:LogFile)
    {
        $filename=(Get-Date).tostring("dd-MMM-yyyy-HH-mm\.\t\x\t")
        $global:LogFile=Join-Path -Path $global:SaturnLogsFolder -ChildPath $filename
        Write-Host "Logging initialized, filename = $global:LogFile"
    }
}
Function WriteLog()
{
    Param ([Parameter(Mandatory=$true)][string]$LogString)
    InitLogFileIfNotInitialized
    $Stamp      = (Get-Date).toString("yyyy-MM-dd HH:mm:ss")
    $LogMessage = "$Stamp $LogString"
    #Add-content $LogFile -value $LogMessage
    $LogMessage | Out-File -FilePath $LogFile -Append
}

Function DumpEnvironmentToLog()
{
    InitLogFileIfNotInitialized
    "-------------" | Out-File -FilePath $LogFile -Append
    dir env: | Out-File -FilePath $LogFile -Append
    "-------------" | Out-File -FilePath $LogFile -Append
}