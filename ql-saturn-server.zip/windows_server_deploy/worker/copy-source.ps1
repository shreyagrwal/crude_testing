. $PSscriptRoot\common.ps1

<#
Responsible for copying source code to the Worker destination runtime folder
#>

$SOURCE_OBJECT=Join-Path -Path $PSscriptRoot -ChildPath "../../"
$SOURCE=(Resolve-Path -Path $SOURCE_OBJECT).Path

Write-Host "Displaying the current devops version"
$devopsfile= Join-Path -Path $SOURCE -childpath "devopsversion.txt"
type $devopsfile
Write-Host "---------------------"
Write-Host "Copying over source code from $SOURCE to $DEST"
& robocopy $SOURCE $DEST /s
Write-Host "---------------------"
Write-Host "Rocopy produced the exit code $LASTEXITCODE"
if ($LASTEXITCODE -eq 16)
{
	Write-Error -Message "Robocopy failed!!!"
}
Write-Host "Robocopy completed with success"
exit 0
# Refer https://ss64.com/nt/robocopy-exit.html for exit codes

