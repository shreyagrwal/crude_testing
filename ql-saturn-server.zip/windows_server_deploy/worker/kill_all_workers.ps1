. $PSscriptRoot\common.ps1

<#
Responsible for killing all instances of rework process
#>

function KillAllReworkProcesses
{

    #$procs=Get-CimInstance Win32_Process | where Name -eq rework.exe  | Select-Object ProcessId,Name,CommandLine
    $procs=Get-Process -Name rework -ErrorAction SilentlyContinue
    if ($procs -eq $null)
    {
        Write-Host "No running rework processes found."
        return
    }
    $procs=@($procs)
    Write-Host "Found $($procs.Count) processes"
    foreach($proc in $procs)
    {

        Write-Host "Found a REWORK process with Id: $($proc.id) at $($proc.Path)"
        WriteLog -LogString "Found a REWORK process with Id: $($proc.id) at path=$($proc.Path)"
        $pathToExe=$proc.Path
        if ([string]::IsNullOrWhiteSpace($pathToExe))
        {
            Write-Host -Message "The path of Rework.exe was empty $($proc.Id))"
            continue
        }
        $parentFolder = [System.IO.Path]::GetDirectoryName($pathToExe)
        $grandParentFolder = [System.IO.Path]::GetDirectoryName($parentFolder)
        if ($grandParentFolder -ne $global:VENV_FOLDER)
        {
            Write-Host "Skipping.The grand parent of $pathToExe did not match the VENV folder $global:VENV_FOLDER"
            continue
        }
        Write-Host "The grand parent $grandParentFolder matched the VENV folder $global:VENV_FOLDER"

        Write-Host "Going to kill $($proc.Id) "
        WriteLog -LogString "Going to kill $($proc.Id) "
        TASKKILL /F /PID $proc.Id
        Write-Host "After TaskKIll LASTEXITCODE=$LASTEXITCODE"

    }
}

DumpEnvironmentToLog
WriteLog -LogString "Inside KillAllWorkers.ps1"
KillAllReworkProcesses
WriteLog -LogString "Complete KillAllWorkers.ps1"