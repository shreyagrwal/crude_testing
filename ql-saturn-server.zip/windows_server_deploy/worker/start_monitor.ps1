param([Parameter(Mandatory=$true)]$domain)
. $PSscriptRoot\common.ps1

<#
Responsible for launching a rework instance with a specific domain
#>
WriteLog -LogString "-----------------------"
WriteLog -LogString "Inside start_monitor.ps1 with domain $domain"
WriteLog -LogString "Current time is $(Get-Date)"

Write-Host "Activating the venv at $Global:VENV_FOLDER"
& $global:VENV_FOLDER\Scripts\Activate.ps1
Write-Host "VENV was activated, $global:VENV_FOLDER"
WriteLog -LogString "VENV was activated, $global:VENV_FOLDER"




Push-Location -Path $global:DEST
$REWORK_EXE=Join-Path -Path $global:VENV_FOLDER -childPath "scripts\rework.exe"
& $REWORK_EXE monitor db --maxruns 1 --minworkers 1 --maxworkers 1 --domain $domain
# Write-Host "After launching rework with domain $domain"
# Pop-Location

WriteLog -LogString "Complete -  start_monitor.ps1 with domain $domain"
WriteLog -LogString "-----------------------"