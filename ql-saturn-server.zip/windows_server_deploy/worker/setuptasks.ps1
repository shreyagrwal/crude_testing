. $PSscriptRoot\common.ps1
<#
Responsible for registering jobs into the postgres. Should be invoked only when a new job is created.
This will delete all job transaction history
#>
$global:SATURN_EXE=Join-Path -Path $global:DEST -ChildPath ".VENV\scripts\saturn.exe"

Push-Location -Path $global:DEST
Write-Host "Current location is $($PWD.Path)"
& $global:SATURN_EXE setup-tasks
Pop-Location
Write-Host "Setup tasks complete"