. $PSscriptRoot\common.ps1

<#
Responsible for launching all rework instances
#>
function LaunchAllWorkersOneByOne
{

    $domains=@("timeseries", "products", "cross", "crude")
    #
    foreach ($domain in $domains)
    {

        #
        #check for running process first and kill if environment matches
        #
        $childScript="$PSScriptRoot\start_monitor.ps1"
        Write-Host "Going to launch rework with domain: $domain using the script $childScript"
        WriteLog -LogString "Going to launch the script $childScript with domain $domain"
        Start-Process -FilePath powershell.exe -ArgumentList "$childScript  -domain $domain"
        Write-Host "--------"
        Start-Sleep -seconds 5
    }
}
DumpEnvironmentToLog
WriteLog -LogString "Inside start_all_monitors.ps1"
WriteLog -LogString "Current time is $(Get-Date)"
LaunchAllWorkersOneByOne
Write-Host "LaunchAllWorkersOnByOne complete"
Write-Host "Displaying all new rework instances"
Get-Process -Name rework -ErrorAction SilentlyContinue

WriteLog -LogString "Complete.  start_all_monitors.ps1"