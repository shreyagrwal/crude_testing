"""
This is a Python script that will assist the end user in creating program menu shortcuts which will reference the file saturn_push_pull.py

How to use this script ?
------------------------
This script will be delivered to a network share.
The user should 
    - use Windows File Explorer
    - Select the file
    - Right click
    - Select "Open with" menu option and then select "Python" option

"""
import logging
import sys
import traceback
import os
import subprocess
import json

SATURN_START_MENU_NAME="SaturnExcelPushPull"

def create_program_menu_folder()->str:
    """
    Creates the subfolder under the user's Program Menu where the short cut files will reside. 
    The Program Menu provides a convenient option to launch short cuts

    Returns:
        str: The absolute path to the subfolder
    """
    logging.info("Going to create program menu folder")
    app_data_folder=os.environ["AppData"]
    logging.info(f"The value of {app_data_folder=}")
    start_menu_folder=os.path.join(app_data_folder,rf"Microsoft\Windows\Start Menu\Programs\{SATURN_START_MENU_NAME}")    
    logging.info(f"The value of {start_menu_folder=}")
    if not os.path.exists(start_menu_folder):
        os.mkdir(start_menu_folder)
        logging.info(f"The Progra Menu folder: '{start_menu_folder}' was created")
    else:
        logging.info(f"The Progra Menu folder: '{start_menu_folder}' already exists. Not creating again")
    return start_menu_folder
    
def prompt_user_for_excel_document()->str:
    path=input("Specify path to Excel:") 
    return path.strip(" \"")

def get_settings_file_path()->str:
    """
    Returns the absolute path to the JSON file which will be used for storing the settings.
    The folder under AppData is created if first time

    Returns:
        str: Absolute file path
    """
    app_data_folder=os.environ["AppData"]
    settings_folder=os.path.join(app_data_folder,SATURN_START_MENU_NAME)
    if not os.path.exists(settings_folder):
        os.mkdir(settings_folder)
    saturn_app_data_settings_file=os.path.join(settings_folder,"settings.json")
    return saturn_app_data_settings_file

def get_settings_dictionary()->dict:
    """
    Returns the settings as a dictionary by reading the JSON file. 
    This dictionary stores the path to the python interpreter path to reduce data entry

    Returns:
        dict: Dictionary
    """
    saturn_app_data_settings_file=get_settings_file_path()
    if not os.path.exists(saturn_app_data_settings_file):
        with open(saturn_app_data_settings_file, mode="+w") as new_file_handle:
            json.dump({}, new_file_handle)
            logging.info(f"Created empty settings.json file at {saturn_app_data_settings_file}")
    else:
        logging.info(f"The settings.json file at {saturn_app_data_settings_file} already exists")
    logging.info(f"Going to read the settings file {saturn_app_data_settings_file}")
    with open(saturn_app_data_settings_file) as f:
        settings_data:dict=json.load(f)
    return settings_data
    
def prompt_user_for_python()->str:
    python_exe_path=input("Specify the absolute path to Python interpreter. You will find this setting on xlwings Tab of Excel:")
    python_exe_path=python_exe_path.strip()
    python_exe_path=python_exe_path.strip(" \"")
    validate_python_interpreter(python_exe=python_exe_path)
    return python_exe_path

def validate_python_interpreter(python_exe: str)->None:
    if not os.path.exists(path=python_exe):
        logging.warning(f"The Python interpreter: '{python_exe}' was not found")
        raise FileNotFoundError()
    if os.path.basename(python_exe).lower() != "python.exe":
        raise ValueError(f"The python interpreter: {python_exe} does not appear to be a valid 'python.exe' ")
    pass

def get_python_interpreter_from_settings()->str:
    settings_data:dict=get_settings_dictionary()
    python_exe=settings_data.get("python_interpreter",None)
    validate_python_interpreter(python_exe=python_exe)
    return python_exe

def save_python_interpreter_in_settings(python_exe: str)->None:
    saturn_app_data_settings_file=get_settings_file_path()
    settings_dict = get_settings_dictionary()
    with open(saturn_app_data_settings_file,"+w") as f:
        settings_dict["python_interpreter"]=python_exe
        json.dump(settings_dict, f)
    logging.info(f"The Python interpreter path was saved into the settings file: {saturn_app_data_settings_file}")
    

def get_python_interpreter_by_prompting_or_from_past_settings()->str:
    try:
        python_exe=get_python_interpreter_from_settings()
        continue_using_saved_interpreter_path=input(f"The last known Python interpreter was: {python_exe} . Do you wish to continue using this?  (yes/n):")
        logging.info(f"The Python interpreter path in the settings file was: {python_exe}")
        logging.info(f"You entered '{continue_using_saved_interpreter_path}'")
        if "yes" != continue_using_saved_interpreter_path.lower():
            raise Exception()
    except:
        python_exe=prompt_user_for_python()
        save_python_interpreter_in_settings(python_exe=python_exe)
    return python_exe

def prompt_user_for_pull_push_choice()->str:
    while True:
        push_or_pull=input("Specify whether you want to do 'pull' or 'push' :")
        push_or_pull=push_or_pull.lower()
        if push_or_pull in ["push", "pull"]:
            break
        continue    
    return push_or_pull.strip("'")

def install_pywin32_module(python_interpreter_path: str)->None:
    """
    Install the pywin32 module so that we can interact with the WScript.Shell objects for creating shortcut files (.lnk)
    Args:
        python_interpreter_path (str): The path to the python interpreter where xlwings and saturn addin is installed
    """
    python_folder=os.path.dirname(sys.executable)
    
    # Uncomment the following only if there is a serious need to debug
    # pip_path=os.path.join(python_folder,"pip.exe").strip("\"")
    # logging.info(f"Path to pip is {pip_path}")
    # subprocess.run([pip_path,"install", "pywin32"])
    logging.info("Going to run pip to install the module 'pywin32'")
    subprocess.run([sys.executable,"-m", "pip", "install", "pywin32", "--upgrade"])
    logging.info("After running pywin32")
    
    
def create_program_menu_short_cut(python_interpreter_path: str, excel_file: str, pull_or_push: str)->None:
    program_menu_shortcuts_folder=create_program_menu_folder()
    logging.info("Going to create program menu shortcut")
    logging.info("The Progra Menu shortcusts folder is: {program_menu_shortcuts_folder}")
    logging.info(f"Path to Python={python_interpreter_path}")
    logging.info(f"Excel document={excel_file}")
    logging.info(f"Pull or Push={pull_or_push}")
    logging.info("Creating shortcut complete")
    excel_file_name=os.path.basename(excel_file)
    shortcut_file_name = "{excel_file_name}-{push_pull}.lnk".format(excel_file_name=excel_file_name,push_pull=pull_or_push)
    path_to_shortcut=os.path.join(program_menu_shortcuts_folder,shortcut_file_name)
    
    launcher_python_script=os.path.join(os.path.dirname(__file__), "saturn_push_pull.py")
    import win32com.client
    shellApp = win32com.client.Dispatch("WScript.Shell")
    short_cut = shellApp.CreateShortcut(path_to_shortcut)
    short_cut.TargetPath = python_interpreter_path
    short_cut.Arguments= f"{launcher_python_script} {pull_or_push} \"{excel_file}\""
    short_cut.Save()
    logging.info(f"Short cut was save to: {path_to_shortcut}")    


def log_separator()->None:
    logging.info("---------------------")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    try:
        logging.info("Start")
        logging.info(f"Python is running from {sys.executable}")
        path_to_excel=prompt_user_for_excel_document()
        path_python=get_python_interpreter_by_prompting_or_from_past_settings()
        pull_or_push=prompt_user_for_pull_push_choice()
        install_pywin32_module(path_python)
        create_program_menu_short_cut(path_python,path_to_excel,pull_or_push)
        log_separator()
        logging.info("Complete")
        input("Press ENTER to close this window")
        log_separator()
        sys.exit(0)
    except Exception as e:
        logging.warn("Error was caught")
        logging.warn(str(e))
        logging.warn("---------------------")
        logging.warn(traceback.format_exc())
        input("Press ENTER to conitnue")
        sys.exit(1)
