"""
This script will carry out a Saturn pull or push operation on the specified Excel document
Should be executed in the same Virtual environment where xlwings and saturn addin was installed

The broad objective is to by pass the Excel's xlwing addin which has problems with Windows Defender while launching Excel
"""

import os
import sys
import subprocess
import enum
import traceback
import subprocess
import logging


class Action(enum.Enum):
    PULL = 1
    PUSH = 2

def log_separator()->None:
    logging.info("---------------------")

def display_command_line_usage()->None:
    print("Usage:")
    this_script_name  = os.path.basename(__file__)
    print(f"<path_to_python_interpreter_with_xlwings> {this_script_name} <action> <path to excel file>")

def press_a_key_to_continue()->None:
    x=input("Press a key to continue")
    
def get_tsh_path_from_python(pythonexe:str)->str:
    """
    This is important because Conda environment has the Python exe in a slightly different location

    Args:
        pythonexe (str): Absolute path to python

    Returns:
        str: Absolute to tsh.exe
    """
    python_folder=os.path.dirname(pythonexe)
    if "conda" in pythonexe.lower():
        logging.info(f"The Python was launched from Conda environment")
        tsh_exe_path=os.path.join(python_folder, "scripts","tsh.exe")
    else:
        logging.info(f"The Python was launched from non-Conda environment")
        tsh_exe_path=os.path.join(python_folder, "tsh.exe")
    return tsh_exe_path

def launch_python(pythonexe:str, action: Action, excel: str)->None:
    """
    Launches tsh executable and carries out the specified action

    Args:
        pythonexe (str): The absolute path to the Python interpreter(python.exe) where xlwings and saturn addin was installed
        action (Action): The pull/push action to be carried out
        excel (str): The absolute path to the Excel file on which the pull/push action will be carried out

    """
    logging.info(f"{pythonexe=} , {action=}")
    existing_path_environment=os.environ["PATH"]
    python_folder=os.path.dirname(pythonexe)
    logging.info(f"The folder which contains Python interpreter is {python_folder}")
    new_path_environment=f"{python_folder};{existing_path_environment}"
    os.environ["PATH"]=new_path_environment
    logging.info("-----------")
    logging.info("Going to display the initial portion of the new PATH variable")
    logging.info("{initial}{obfuscate}".format(initial=new_path_environment[:100],obfuscate="*******"))
    logging.info("-----------")

    logging.info("Going to check where python.exe is running from")
    subprocess.run(["where.exe","python.exe"])
    logging.info("-----------")

    tsh_exe_path=get_tsh_path_from_python(pythonexe=pythonexe)
    logging.info(f"Path to tsh={tsh_exe_path}")
    if not os.path.exists(tsh_exe_path):
        raise RuntimeError(f"The path to tsh.exe {tsh_exe_path} was not found")
    logging.info(f"Going to execute 'tsh' with the action={action}, on the Excel file: {excel_file}")
    logging.info(f"The path to tsh is {tsh_exe_path} ")
    subprocess.run([tsh_exe_path,"xl" , action.name.lower() , excel_file])
    pass

def process_command_line_arguments()->tuple[str,Action,str]:
    """
    Parses the command line arguments and returns a tuple with the following elements:
        (path to Python interpreter,action,path to excel file)
    Returns:
        tuple[str,Action,str]: A tuple with 3 elements
    """
    logging.info("Displaying command line argument.........")
    logging.info(sys.argv)
    if len(sys.argv) != 3:
        print("Invalid command line arguments")
        display_command_line_usage()
        press_a_key_to_continue()
        exit(1)
    action=Action[sys.argv[1].upper().strip()]
    excel_file = sys.argv[2].strip()
    python_interpreter=sys.executable
    return python_interpreter, action, excel_file

def validate_path(path: str)->None:
    logging.info(f"Validating the path {path}")
    if not os.path.exists(path=path):
        raise FileNotFoundError(path)
    logging.info(f"The {path=} was found")
    return

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    logging.info("Start")
    try:
        venv_python, action, excel_file =process_command_line_arguments()
        logging.info(f"{venv_python=}")
        logging.info(f"{action=}")
        logging.info(f"{excel_file=}")
        validate_path(path=venv_python)
        validate_path(path=excel_file)
        launch_python(pythonexe=venv_python, action=action, excel=excel_file)
        log_separator()
        logging.info(f"{action.name} action completed on the document: {excel_file}")
        log_separator()
        input("Press ENTER to close this window")  #Good to have this. Otherwise user does not get any feedback of what really happened
        sys.exit(0)
    except Exception as e:
        logging.info("Error was caught")
        logging.info(str(e))
        logging.info("Stack trace")
        logging.info("---------------------")
        logging.info(traceback.format_exc())
        logging.info("There were errors!!!!")
        input("Press ENTER to conitnue")
        sys.exit(1)
    
    
    
