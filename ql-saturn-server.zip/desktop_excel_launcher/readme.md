[[_TOC_]]

# About
Python script which can be used to launch Saturn pull and push actions.

---

# What problem are we solving ?
**Saturn Excel** addin does not work on may of the VDIs because of recent Windows Defender restrictions/policies that have been rolled. These policies try to prevent Excel from launching external processes like **CMD.EXE**. Therefore, we have worked out an alternative where by we launch the Python script externally. To simplify things we intend to wrap this up into a **Desktop** shortcut.

---

# How does it work at a high level ?

```
    Start
        |
        |
        |
        V
    End user has a short cut link under the standard Program Menu
    (one per every Saturn XL document pull and one per push)
        |
        |
        |
        V
    user clicks on this short cut 
        |
        |
        |
        V
    This short cut launches Python to do the pull or push action
        |
        |
        |
        V
    Excel is launched and document is updated (if pull) or server updated (if push)
        |
        |
        |
        V
    Excel stays open
        |
        |
        |
        V
    User does some editing and clicks on the same short again to perform the pull/push action
        |
        |
        |
        V

    End
```

---

# How to create shortcuts in the Program Menu using the shortcut_creator.py ?

## Step-1-Navigate to the network folder where the scripts are delivered

![shortcut_creator_windows_explorer.png](docs/shortcut_creator_windows_explorer.png)


## Step-2-Right cick and run with Python
![launch_using_python.png](docs/launch_using_python.png)

## Step-3-Follow the prompts

![alt text](docs/prompt_for_excel_file.png)

## Step-4-Locate the document under Start menu

![start_menu_locate_menu_item.png](docs/start_menu_locate_menu_item.png)


## Step-5-Locate the document quickly by typing in Start Menu

![start_menu_type_doc_name.png](docs/start_menu_type_doc_name.png)

---

# How to create a Desktop shortcut manually?

## Step-1-Launch the Shared folder in Windows Explorer

This is the network share where the Python file to launch Saturn pull/push is saved. In the following steps we will create a desktop shortcut to this file.

![windows_file_explorer.png](docs/windows_file_explorer.png)


## Step-2-Drag the python file from the network share

- Keeping the right click steady , drag the file over to a region on the Desktop

![alt text](docs/dragover_copy_to_desktop.png)
- When you finish the drag operation, select the option below to create a shortcut


![right_click_drag_create_shortcut](docs/right_click_drag_create_shortcut.png)

## Step-3-Open the Link properties dialog

Right click on the shortcut to reveal the following menu.

![edit_link_properties.png](docs/edit_link_properties.png)

## Step-4-Set the Link properties
![alt text](docs/link_properties_dialog.png)

"S:\~Analysis Department\Sau\saturn_push_pull.py"  "REPLACE_WITH_PYTHON_EXE_FROM_XLWINGS" "REPLACE WITH pull/push"  "PATH TO EXEL FILE"




example
```
"S:\~Analysis Department\Sau\saturn_push_pull.py"  c:\Users\saurabhdasgupta\SaturnExcelAddin\.myvenv\Scripts\python.exe pull  "H:\MyWork\Saturn\PushPullAddinFromOutsideExcel\Roza.xlsx"
```


---


# Notes for developer - Debugging locally


## Debugging from VS Code

- Place a break point somewhere inside `if name=="__main__" ` block
- Use the following command to launch the debugger and prompt you for arguments
- 
![debug_locally](docs/vs_code_debug.png)

## How to avoid specifying arguments every time ?

You can create a new configuration in the file `.vscode/launch.json` and specify the argumetns in the `args` element

## Executing from command line

```
python.exe C:\Users\saurabhdasgupta\source\repos-devops\DataAnalysisAllRepos\ql-saturn-server\desktop_excel_launcher\saturn_push_pull.py C:\Users\saurabhdasgupta\source\repos-devops\DataAnalysisAllRepos\ql-saturn-server\.venv\Scripts\python.exe pull "H:\MyWork\Saturn\PushPullAddinFromOutsideExcel\Roza.xlsx"
```

---

# References

## Creating a shortcut programmatically
This example shows how to use CScript/WScript to create a shortcut
https://admhelp.microfocus.com/uft/en/all/VBScript/Content/html/2f2d4ad5-af6d-4387-b120-64bb8e78bb71.htm

## How to invoke COM objects from Python using the pywin32 package ?
This is helpful in calling WShell
https://pbpython.com/windows-com.html

## Debugging inside VS Code
https://code.visualstudio.com/docs/editor/debugging#_launchjson-attributes

---
