from setuptools import setup
import os




REQUIREMENTS = [
    'tqdm',
    'statsmodels',
    'numpy',
    'pandas',
    'pyyaml',
    'python-dotenv',]

    # 'markupsafe==2.0.1',
    # 'python-dateutil==2.8.2',
    # 'requests==2.27.1',
    # 'responses==0.17.0',
    # 'urllib3==1.26.9',


setup(
    name='saturn-server',
    version='1.0',
    packages=['saturn_server'],
    package_dir={
        'saturn_server': 'saturn_server'
    },
    install_requires=REQUIREMENTS,
    entry_points={
        'console_scripts': [
            'saturn=saturn_server.cli:saturn',
        ],
    },
)
