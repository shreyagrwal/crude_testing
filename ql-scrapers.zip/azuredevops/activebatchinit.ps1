Set-StrictMode -Version "latest"
$ErrorActionPreference="Stop"
Write-Host "hello world"

<#
Why do we need this file ?
--------------------------
Read the file which has the latest version stamped by the CICD process - this will tell us which version to pick and every other path will follow. The following envrionment variables are set
- $env:DEVOPS_VERSION -> The version string of the latest build , as produced by Azure Devops pipeline
- $env:PYTHON_SOURCE => The absolute path to the root of the latest build
- $env:PYTHON_EXE => The absolute path to the Python EXE under the VENV for the latest build


Where is this file created ?
----------------------------
At the parent folder of all build directories. By ensuring a fixed location, it becomes easy to invoke from Active Batch and initialize the critical environment variables
root
    |
    |---1.101
    |
    |---1.102
    |
    |---1.103
    |
    |---activabatchinit.ps1

When to invoke this file ?
--------------------------
The first line of every Active Batch job should have this. e.g.
C:\Petroineos\AzureDevops\ql-repository\$env:environment\artifact
#>
$LatestBuildVersionFileName = Join-Path -Path $PSScriptRoot -ChildPath "latestbuildversion.txt"
Write-Host "Going to read the file $LatestBuildVersionFileName to get the current build number"
$LatestBuildVersionValue =  Get-Content -Path $LatestBuildVersionFileName -Raw
$LatestBuildVersionValue = $LatestBuildVersionValue.Trim()
Write-Host "After reading the file, the current build number was found to be '$LatestBuildVersionValue'"

$SourceRootFolder = Join-Path -Path $PSScriptRoot -ChildPath $LatestBuildVersionValue
if ((Test-Path -Path $SourceRootFolder) -eq $false)
{
    Write-Error -Message "The source code folder $SourceRootFolder was not found"
}
Write-Host -Message "The source code folder $SourceRootFolder was  found"

$PythonExePath = Join-Path -Path $SourceRootFolder -ChildPath "venv\Scripts\Python.exe"
if ((Test-Path -Path $PythonExePath) -eq $false)
{
    Write-Error -Message "The Python EXE at $PythonExePath was not found"
}
Write-Host -Message "The Python EXE at $PythonExePath was found"

$env:DEVOPS_VERSION=$LatestBuildVersionValue
$env:PYTHON_SOURCE=$SourceRootFolder
$env:PYTHON_EXE=$PythonExePath

Write-Host "The environment variable  DEVOPS_VERSION was set to $env:DEVOPS_VERSION"
Write-Host "The environment variable PYTHON_EXE was set to $PythonExePath"
Write-Host "The environment variable  PYTHON_SOURCE was set to $env:PYTHON_SOURCE"
Write-Host "The environment variable  ENVIRONMENT was set to $env:ENVIRONMENT"
Write-Host "All Done"
