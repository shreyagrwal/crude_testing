$ErrorActionPreference="Stop"
<#
This script will delete the old builds.
Why is this important ?
-----------------------
Every build folder carries with itself, the .VENV folder which can easily exceed 300 MB. We do not want to run out of disk space on the server

How to run this script ?
------------------------
Schedule this via Active Batch to run every day after close of business
Create a Jon under ql-xxxx\dev and ql-xxx\prod so that all environments are taken care off 

#>
$MaxBuildsToRetain=10
$BuildsFolder=$env:DEVOPS_ROOT
if ($BuildsFolder -eq $null)
{
    Write-Error -Message "The environment variable DEVOPS_ROOT was not found"
}
if ((Test-Path -Path $BuildsFolder) -eq $false)
{
    Write-Host "The folder $BuildsFolder was not found"
    return
}
Write-Host "Going to delete build folders in $BuildsFolder. Only retain a max of $MaxBuildsToRetain" 
$allBuildFolders = Get-ChildItem -Path $BuildsFolder -Directory
$mostRecentFolders=$allBuildFolders | Sort-Object -Descending  -Property CreationTime 

$oldestFolders=$mostRecentFolders | Select-Object -Skip $MaxBuildsToRetain | Sort-Object -Property CreationTime

$oldestFolders=@($oldestFolders)
Write-Host "Found $($oldestFolders.Count) folder(s) that need to be deleted"
if ($oldestFolders.Count -eq 0)
{
    exit   
}
Write-Host "Displaying the $($oldestFolders.Count) selected folders in chronological order  which are beyond the folder retention limit count of $MaxBuildsToRetain "
foreach($folder in $oldestFolders)
{
    Write-Host ("{0}, {1}" -f $folder.FullName,$folder.CreationTime)
}
Write-Host "Going to delete these folders"

foreach($folder in $oldestFolders)
{
    Write-Host "Deleting  folder $($folder.FullName)"
    Remove-Item -Path $folder.FullName -Force -Recurse -ErrorAction Continue
    Write-Host "Deletion of folder $folder complete..."
}
Write-Host "all done last error = $LASTEXITCODE"
Write-Host "Compelete"
