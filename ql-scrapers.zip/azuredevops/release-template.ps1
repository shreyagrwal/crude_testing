param(
        [Parameter(Mandatory=$true)][string]$DownloadLocation, 
        [Parameter(Mandatory=$true)][string]$VenvFolderName, 
        [Parameter(Mandatory=$true)][string]$BasePythonInterpreter,
        [Parameter(Mandatory=$true)][string]$BuildNumber,
        [Parameter(Mandatory=$true)][string]$LatestBuildVersionFileName)
Set-StrictMode -Version "latest"
$ErrorActionPreference="Stop"

<#
Where is this called from ?
---------------------------
Invoked from the release YML file

What does this script accomplish ?
----------------------------------
- Initializes the VENV so that Python can work smoothly. Does not delete the VENV. Just the `python -m venv .venv` command to ensure Python works smoothly with a foreign venv
- Creates a file $LatestBuildVersionFileName at the parent of the root. This is stamped with the current build version and helps Active Batch in identifying which source code to pick
- We are not deleting the  old builds. The .venv folders are large ! We should be doing it. But, this was found to be taking too long a time and increasing the overall build time

#>

if (!(Test-Path -Path $DownloadLocation))
{
    Write-Error -Message "The download location $DownloadLocation was not found!!"
}
Write-Host "The download location $DownloadLocation was  found"

$venvAbsolutePath = Join-Path -Path $DownloadLocation -ChildPath $VenvFolderName
if (!(Test-Path -Path $venvAbsolutePath))
{
    Write-Error -Message "The VENV folder  $venvAbsolutePath was not found!!"
}
Write-Host "The VENV folder  $venvAbsolutePath was found"

if (!(Test-Path -Path $BasePythonInterpreter))
{
    Write-Error -Message "Path to base Python interpreter: $BasePythonInterpreter was not found!!"
}

<#
Create VENV 
This is a neccessary step even though the folder exists. Need to associate with base python interpreter
Note - We do not delete any of the PIP packages which came in from the Build stage. Just re-associate.
#>
Write-Host "Path to base Python interpreter: $BasePythonInterpreter was found"
Write-Host "Going to re-create VENV , "

& $BasePythonInterpreter -m venv $venvAbsolutePath
if ($LASTEXITCODE -ne 0)
{
    Write-Error -Message "Could not create VENV at $venvAbsolutePath using the base Python: $BasePythonInterpreter"
}
Write-Host "The command Pythonh -m venv '$venvAbsolutePath' completed successfully"

<#
Create the file $LatestBuildVersionFileName which will record the current Build number.
This will help Active Batch or any other PowerShell script to locate the correct folder
#>
$DevopsRoot = Join-Path -Path $DownloadLocation -ChildPath "..\" -Resolve
$DevopsVersionFile = Join-Path -Path $DevopsRoot  -ChildPath $LatestBuildVersionFileName
$BuildNumber | Out-File -FilePath $DevopsVersionFile
Write-Host "The BuildNumber $BuildNumber was written to the file $DevopsVersionFile"

$ParentFolder=Join-Path -Path $DownloadLocation  -ChildPath "..\" -Resolve
<#
Copy the file activebatinit.ps1 to the parent of all artifact folders
#>
$SourcePathActiveBatchInitFile = Join-Path -Path $PSScriptRoot -ChildPath "activebatchinit.ps1"
Copy-Item -Path $SourcePathActiveBatchInitFile -Destination $ParentFolder -Verbose
Write-Host "The file $SourcePathActiveBatchInitFile was copied over to $ParentFolder"
<#
Copy the file delete-old-builds.ps1 to the parent of all artifact folders
#>
$SourcePathDeleteOldbuildsFile=Join-Path -Path $PSScriptRoot -ChildPath "delete-old-builds.ps1"
Copy-Item -Path $SourcePathDeleteOldbuildsFile -Destination $ParentFolder -Verbose
Write-Host "The file $SourcePathDeleteOldbuildsFile was copied over to $ParentFolder"


Write-Host "all done last error = $LASTEXITCODE"
Write-Host "Compelete"