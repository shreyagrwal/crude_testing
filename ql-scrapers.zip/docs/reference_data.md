[[_TOC_]]
# About
This is an overview of reference data in the context of **ql-scrapers**. The concept of reference data is not confined to any specific vertical such as OIL, GAS or LNG.

---

# What is meaning of reference data/static data in the context of a database system ?

Reference data (also known as static data, code data, lookup data, or list data) in the context of a relational database management system refers to data that represents fixed information. This type of data doesn’t change frequently, if at all. Examples of reference data include abbreviations for US states (e.g., ME for Maine, MA for Massachusetts, NC for North Carolina), lists of guitar manufacturers, internal abbreviations for company departments, and names of countries in the European Union. Essentially, reference data provides a consistent set of values that other transactional data can reference12.

(from ChatGPT)

---

# What problem are we trying to solve ?

Imagine scraping data frequent weather data from an external web site which has references to various countries. E.g. United States of America, Great Britain ,etc.

On some days, the web site lists the country as **Great Britain** and on some days as **United Kingdom**. In both cases, the data refers to the same country. These are not 2 seprate countries.

## Data on Jan 1


Date | Rainfall | Country
---------|----------|---------
 | 1-Jan-2024 | 20 | United Kingdom
 | 1-Jan-2024 | 55 | France
 | 1-Jan-2024 | 120| Germany


## Data on Jan 2

Date | Rainfall | Country
---------|----------|---------
 | 2-Jan-2024 | 20 | Great Britain
 | 2-Jan-2024 | 55 | France
 | 2-Jan-2024 | 120| Germany


You want your scraper to produce consistent data  - so that the translation to the actual country can be safely done without having to re-write the Python code.

Instead of storing the full country name repetitively in the customer table (e.g., United Kingdom” or "Greate Britain"), it’s more efficient to create a separate countries table with an ID for each country. The customer table can then reference the appropriate country ID whenever needed. While new countries may occasionally be added (e.g., Southern Sudan), the overall list remains fairly static over time.

In the above example, if we store our weather data against the Country code as opposed to Country name - then the data becomes more resilient to changes. 

This comes with the slightly added effort that our Python scraper has to take the responsiblity of translating "**Great Britain**" and "**United Kingdom**" to the country code **GB**.

---

# What problem we are not trying to solve ?

In the above example, the reference table **CountryCodes** does not magically help us to automatically parse our raw data in Python. The Python code has to handle dirty data. E.g. spaces, punctuations , case variations

Example:

1. Great Britain
1. Great britain.
2. United Kingdom
3. UK


---

# ER diagram

## Raw weather data (before ingestion)

![ppt_reference_transformed_raw_weather_data.png](images/ppt_reference_transformed_raw_weather_data.png)

## Transformed data (after ingestion)
![ppt_reference_transformed_raw_weather_data.png](images/ppt_reference_transformed_raw_weather_data.png)

---

# How does the end user query change ?

The query should do a join.  In the case of the hypothetical weather data, the hypothetical SQL would be:

```sql
SELECT w.Date, w.RainFall, w.CountryCode, c.Name as Country FROM WeatherData w INNER JOIN CountryCode c 
ON w.CountryCode=c.CountryCode
```

---

# Managing the reference data in GIT and ingesting into BO

## How it works ?
- The source of truth files are under **ql-scraper/src/reference_data/data_files** . Create a new CSV file here with the appropriate BO compliant name
- There is one and only Python file under **ql-scraper/src/reference_data/import_reference_files_runner.py** which is triggered by Active Batch at frequent intervals to move all CSV files from the source of truth folder to the standard BO pick up folder.

![ppt_reference_data_csv_files_location.png](images/ppt_reference_data_csv_files_location.png)

## How to ingest a new CSV ?

1. Create a new CSV file with a name which is BO compliant. This file should be added to GIT of **ql-scrapers** under the folder shown above
2. Raise a PR and let the files get depoyed. Run the Active Batch job (under **ql-scraper** folder) manually or let it run as per schedule

---


# How to configure the BO meta-data for ingesting reference/static data

There are a few important settings in BlueOcean portal which should be implemented to have a clean and trustworthy refernce data table. Refer the [CPDP Product Code table in BlueOcean](https://blueocean.petroineos.co.uk/jobs/1052).

Some of the important configuration parameters to bear in mind (as of May 2024)
- **Write Mode** under **Destinations** should be set to **Overwrite**. We want the CSV data from GIT to be the source of truth
- Avoid curation tasks like **Dedup** because GIT is our source of trust and we are overwriting the database with out version of truth from GIT.
- Have a schedule which is fairly frequent

---

# Responsibilities for the Scraper developer
Having central reference data tables is one of the challenges we are solving .  But, this is not enough. The analyst developing the scraper should purify their files and replace verbose text with reference data look up codes.

**Example:**  If the incoming data has the possibility of having "**United Kindgdom**"  or **Great Britain** as a Country attribute, then replace the Countr text with the country code **GBP**. 