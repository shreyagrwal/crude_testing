[[_TOC_]]

# Which is the web site ?
https://www.cpdp.org/donnees-statistiques/

---

# List of tables and SQL query  
  
## cpdp_product_codes
This is reference data that provides the product description against every unique product code. The source CSV can be found in this repo (src/reference_data/data_files/)
```sql
SELECT ProductCode,description from workspace.saurabhdasgupta.cpdp_product_codes
```

## cpdp_subproduct_codes
This is reference data that provides the subproduct description against every unique subproduct code. The source CSV can be found in this repo (src/reference_data/data_files/)
```sql
SELECT SubProductCode,description from workspace.saurabhdasgupta.cpdp_subproduct_codes
```


## cpdp_consumption

Querying the table without any joins:

```sql
SELECT 	DDate,ProductCode,SubProductCode,Density,Volume,Mass,YoYVariationPct,ProductOriginal,SubProductOriginal FROM workspace.saurabhdasgupta.cpdp_consumption
```

Joining with `ProductCodes` and `SubProductCodes` table:

```sql
SELECT 	
    txn.LoadTimeStamp,DDate,
    txn.ProductCode, pcodes.Description as Product,
    txn.SubProductCode, scodes.Description as SubProduct,
    Density,DensityUnits,
    Volume,VolumeUnits,
    Mass,MassUnits,
    YoYVariationPct ,ProductOriginal,SubProductOriginal
FROM workspace.saurabhdasgupta.cpdp_consumption txn
LEFT JOIN workspace.saurabhdasgupta.cpdp_product_codes pcodes ON txn.ProductCode = pcodes.ProductCode
LEFT JOIN workspace.saurabhdasgupta.cpdp_subproduct_codes scodes ON txn.SubProductCode = scodes.SubProductCode
ORDER BY txn.LoadTimeStamp

```
 
## cpdp_stock_distribution_at_end_of_month

Querying the table without any joins:

```sql
SELECT ddate, ProductCode, SubProductCode, Stock, Unit, ProductOriginal, SubProductOriginal FROM workspace.saurabhdasgupta.cpdp_stock_distribution_at_end_of_month 
WHERE SubProductOriginal
ORDER by SubProductOriginal,ddate
```

Joining with `ProductCodes` and `SubProductCodes` table:

```sql
SELECT txn.LoadTimeStamp,Ddate,txn.ProductCode,pcodes.Description as Product,txn.SubProductCode,scodes.Description as SubProduct,Unit,Stock,ProductOriginal,SubProductOriginal FROM workspace.saurabhdasgupta.cpdp_stock_distribution_at_end_of_month  AS txn 
LEFT JOIN  workspace.saurabhdasgupta.cpdp_product_codes AS Pcodes ON txn.ProductCode = pcodes.ProductCode
LEFT JOIN  workspace.saurabhdasgupta.cpdp_subproduct_codes scodes ON txn.SubProductCode = scodes.SubProductCode
ORDER BY DDate 

```

## cpdp_ten_day_estimate_for_deliveries

```sql
SELECT DDate,Product,Decade,DaysInCurrentDecade,MoMChangePercentage,MomDaysInDecade,YoYChangePercentage,YoYDaysInDecade,ProductOriginal FROM workspace.saurabhdasgupta.cpdp_ten_day_estimate_for_deliveries
```

## cpdp_cumulative_decadely_estimate_for_deliveries

```sql
SELECT DDate, Product, NumberOfMeasuredDecades,NumberOfWorkingDaysInCurrentMeasurementPeriod, NumberOfWorkingDaysInPreviousMonth,NumberOfWorkingDaysInPreviousYear, MoMChangePercentage,YoYChangePercentage, ProductOriginal   FROM workspace.saurabhdasgupta.cpdp_cumulative_ten_day_estimate_for_deliveries limit 100
```

---

# Browser sequence - Getting to the source for the tables ?

## Basic login sequence
- Accept the cookies
- Login with email and password

![](C:\Users\saurabhdasgupta\source\repos-devops\DataAnalysisAllRepos\ql-scrapers\docs\images\cpdp_login.png)

## Getting to the table cpdp_consumption
![Livraisons et stocks](images/cpdp_stocks.png)


## Getting to the table cpdp_stock_distribution_at_end_of_month
Follow the same sequence as the table **cpdp_consumption** . Same Excel document but different work sheet.

## Getting to the table cpdp_ten_day_estimate_for_deliveries
![Estimate of deliveries](images/cpdp_decade_estimte_of_deliveries.png)


## Getting to the table cpdp_cumulative_decadely_estimate_for_deliveries

The Excel is the same as `cpdp_ten_day_estimate_for_deliveries`

---

# Parsing data out of each of the Excel files

## cpdp_consumption
**Page 1** of the downloaded excel is scraped. The columns are obtained as follows:

- DDate - This is obtained from the _Febraury 2024_ text at the very top of the Excel
- Product - This is header above each line items. E.g. Carburants Routiers
- SubProduct - The line items below each Product with Density, Volume and Tonnes cells in Excel
- Density - The values under Densites cell
- Volume - The values under m3 cell
- Mass	- The values under tonnes cell
- YoYVariationPct - The values under Variation cell
- ProductOriginal - The French text of Product
- SubProductOriginal - The French text of SubProduct
  

![title comes here](images/cpdp_excel_cpdp_consumption_table.png)

## cpdp_stock_distribution_at_end_of_month
**Page 4** of the downloaded excel. The columns are obtained as follows:

- DDate - This is obtained from Fevrier 2024 at the very bottom of the Excel (Fevrier 2024)
- Product - This is header above each line items. E.g. Carburants Routiers . The blank row indentified below is to be treated as **Diesel/GasOil**
- SubProduct - The line item below each Product with Unit and Stock values
- Unit - The values under Unite cell (m3, tonnes)
- Stock - The values under Stock cell (hyphens are treated as zeros)
- ProductOriginal - The French text of Product
- SubProductOriginal - The French text of SubProduct


![title comes here](images/cpdp_excel_cpdp_stock_distribution_at_end_of_month.png)

## cpdp_ten_day_estimate_for_deliveries

This Excel has only 1 sheet. The columns are obtained as follows:

- DDate - This is obtained from the text at the top of the Excel (Mois: Mars 2024)
- Product - The values under Produit column
- Decade - The value parsed from the top row (3 values , one each from the columns with text 1 ere decade, 2 decade, 3 decade)
- DaysInCurrentDecade - The day value parsed from the cell under current Decade column (6 jours ouvres, 8 jours ouvres, 7 jours ouvres)
- MoMChangePercentage - The percentage values under each of the m-1 columns under the 3 Decade columns
- MomDaysInDecade - The value parsed from the "x jours ouvres" under the m-1 columns (7 jours ouvres) for each of the products
- YoYChangePercentage - The percentage values under each of the m-12 columns under the 3 Decade columns
- YoYDaysInDecade - The day value parsed from the cell immediately under current Decade column (6 jours ouvres, 8 jours ouvres, 7 jours ouvres) for each of the products
- ProductOriginal - The French text of Product

![title comes here](images/cpdp_excel_cpdp_ten_day_estimate_for_deliveries.png)

## cpdp_cumulative_decadely_estimate_for_deliveries

The Excel is the same as `cpdp_ten_day_estimate_for_deliveries`

- **DDate** - This is obtained from the text at the top of the Excel (Mois: Mars 2024)
- **Product** - The values under Produit column
- **NumberOfMeasuredDecades** - This is parsed from the text `cumul des 3 decades`
- **NumberOfWorkingDaysInCurrentMeasurementPeriod** - This is parsed from the text `21 jours ouvres` above the text `cumul des 3 decades`
- **NumberOfWorkingDaysInPreviousMonth** - This is parsed from the text `21 jours ouvres` below `m-1` under `cumul des 3 decades`
- **NumberOfWorkingDaysInPreviousYear** - This is parsed from the text `21 jours ouvres` below `m-12` under `cumul des 3 decades`
- **MoMChangePercentage** - The percentage values in the cell which is under the `m-1` columns and intersects with the **Product** line
- **YoYChangePercentage** - The percentage values in the cell which is under the `m-12` column and intersects with the **Product** line


![cpdp_excel_cummaltive_cpdp_ten_day_estimate_for_deliveries.png
](images/cpdp_cumulative_ten_day_estimate_for_deliveries.pptx.png)

---

# Implementation details

## Scraping approach
- Use selenium to get to the speific Excel download link web page
- Initiate the document download
- Read the Excel via Pandas 


## Source folder
[Click here to jump to the source folder](../src/oil/cpdp)


---

# Where can I see a sample Excel file?
See the accompanying **.XLS** document(s) in the [tests](../src/oil/cpdp/tests/) folder. 

---

# Language translation
We are using a simple mapping file which has a 1-1 mapping from French to English. See the file [product_code_language_map.csv](../src/oil/cpdp/lib/product_code_language_map.csv)
This is a simple CSV which does one-one translation.

```csv
french,english
Carburants routiers,Road fuels
Carburants alternatifs (b),Alternative fuels (B)
Carburants alternatifs,Alternative fuels
Carburants aériens,Aviation fuels
Autres produits,Others products
```

# Historic files
## Where are the files ?
The XL files are located in [this folder](../src/oil/cpdp/historic_files) of this repository.

## How are we parsing the historic files ?
Same modules that are being used for the live files but different runner scripts. 
