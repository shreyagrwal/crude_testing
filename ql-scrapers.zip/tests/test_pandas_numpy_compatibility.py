import logging
import numpy as np
import pandas as pd


def test_compatibility():
    logging.info("This is a test to check for compatibility of pandas with numpy")