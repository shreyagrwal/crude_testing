import logging
from unittest import TestCase


class TestScrape_and_upload(TestCase):
    def test_scrape_and_upload(self):
        logging.info("This is a dummy test")
        assert 1==1
