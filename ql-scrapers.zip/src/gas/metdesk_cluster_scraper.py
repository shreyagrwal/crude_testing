import os
import sys
import time
import argparse
import numpy as np
import pandas as pd
from datetime import datetime
from selenium import webdriver

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment

login = 'DongX1'
password = 'PetroChinaDX1'

format_datetime = '%y%m%d%H%M%S'

url_login = 'https://www.metdesk.com/tradingweather/auth'
url_cluster = 'https://www.metdesk.com/tradingweather/?dashboard=cluster-tables'
appFolder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Scrapers\MetDesk\Cluster'
bulk_uploader_folder = se.ingestion_folder
filename = 'Upload_Gas_Cluster'
timesleep = 30


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": appFolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser


def get_cluster_tables(browser, url_login, url_cluster, element):

    browser.get(url_login)
    time.sleep(5)
    browser.find_element('xpath', '//*[@id="login"]/form/fieldset/p[1]/input').send_keys(login)
    time.sleep(1)
    browser.find_element('xpath', '//*[@id="login"]/form/fieldset/p[2]/input').send_keys(password)
    time.sleep(1)
    browser.find_element('xpath', '//*[@id="login"]/form/fieldset/p[6]/input').click()
    time.sleep(1)
    browser.get(url_cluster)
    time.sleep(timesleep)

    if element == 'all':  # 100mWind, 2mTemp, SolarPower, WindPower
        get_100mwind_cluster(browser, '100mWind')

        browser.find_element('xpath', '//*[@id="sections1items0items0items0items0"]/div[1]/div/div/div/div/div[1]/div[2]/div[7]/button').click()
        get_2mtemp_cluster(browser, '2mTemp')

        browser.find_element('xpath', '//*[@id="sections1items0items0items0items0"]/div[1]/div/div/div/div/div[1]/div[2]/div[7]/button').click()
        get_solarpower_cluster(browser, 'SolarPower')

        browser.find_element('xpath', '//*[@id="sections1items0items0items0items0"]/div[1]/div/div/div/div/div[1]/div[2]/div[7]/button').click()
        get_windpower_cluster(browser, 'WindPower')
    elif element == '100mWind':  # 100mWind, 2mTemp, SolarPower, WindPower
        get_100mwind_cluster(browser, element)
    elif element == '2mTemp':  # 100mWind, 2mTemp, SolarPower, WindPower
        get_2mtemp_cluster(browser, element)
    elif element == 'SolarPower':  # 100mWind, 2mTemp, SolarPower, WindPower
        get_solarpower_cluster(browser, element)
    elif element == 'WindPower':  # '100mWind' 2mTemp, SolarPower, WindPower
        get_windpower_cluster(browser, element)
    else:
        log.debug('element parameter missing: 100mWind, 2mTemp, SolarPower, WindPower or all')
        exit(1)

    exit(0)


def get_100mwind_cluster(browser, element):
    browser.find_element('xpath', '//*[@id="sections1items0items0items0items0"]/div[1]/div/div/div/div/div[2]/div[2]/div[1]/button').click()
    time.sleep(timesleep)
    wait_for_page_load(browser)
    areas = list(range(1, 17))  # areas = list(range(1, 17))
    df = get_cluster_data(areas, browser, element, 'm/s')
    df['delta_from_climate'] = df['delta_from_climate'].replace(r'^\s*$', np.nan, regex=True).astype(float) / 100
    df = df.rename(columns={'delta_from_climate': 'delta_from_climate_pctg'})
    filefullname = os.path.join(bulk_uploader_folder, filename + element + '-' + datetime.today().strftime(format_datetime) + ".csv")
    log.debug('start writing to csv - ' + element)

    # Upload to database
    su.upload_to_database(df, filename)
    del df


def get_2mtemp_cluster(browser, element):
    browser.find_element('xpath', '//*[@id="sections1items0items0items0items0"]/div[1]/div/div/div/div/div[2]/div[2]/div[3]/button').click()
    time.sleep(timesleep)
    browser.find_element('xpath', '//*[@id="sections1items0items0items0items0"]/div[1]/div/div/div/div/div[2]/div[2]/div[2]/button').click()
    time.sleep(timesleep)
    wait_for_page_load(browser)
    areas = list(range(1, 17))  # areas = list(range(1, 17))
    df = get_cluster_data(areas, browser, element, '°C')
    df['delta_from_climate'] = df['delta_from_climate'].replace(r'^\s*$', np.nan, regex=True).astype(float)
    log.debug('start writing to csv - ' + element)

    # Upload to database
    su.upload_to_database(df, filename)

    del df


def get_solarpower_cluster(browser, element):
    browser.find_element('xpath', '//*[@id="sections1items0items0items0items0"]/div[1]/div/div/div/div/div[2]/div[2]/div[3]/button').click()
    time.sleep(timesleep)
    wait_for_page_load(browser)
    areas = list(range(1, 8))  # areas = list(range(1, 8))
    df = get_cluster_data(areas, browser, element, 'MW')
    df['delta_from_climate'] = df['delta_from_climate'].str.rstrip('%').replace(r'^\s*$', np.nan, regex=True).astype(float) / 100
    df = df.rename(columns={'delta_from_climate': 'delta_from_climate_pctg'})
    log.debug('start writing to csv - ' + element)
    # Upload to database
    su.upload_to_database(df, filename)
    del df


def get_windpower_cluster(browser, element):
    browser.find_element('xpath', '//*[@id="sections1items0items0items0items0"]/div[1]/div/div/div/div/div[2]/div[2]/div[4]/button').click()
    time.sleep(timesleep)
    wait_for_page_load(browser)
    areas = list(range(1, 8))  # areas = list(range(1, 8))
    df = get_cluster_data(areas, browser, element, 'MW')
    df['delta_from_climate'] = df['delta_from_climate'].str.rstrip('%').replace(r'^\s*$', np.nan, regex=True).astype(float) / 100
    df = df.rename(columns={'delta_from_climate': 'delta_from_climate_pctg'})
    log.debug('start writing to csv - ' + element)
    # Upload to database
    su.upload_to_database(df, filename)
    del df


def get_cluster_data(areas, browser, element, unit):
    region_previous = 'United Kingdom'
    df = pd.DataFrame()
    for area in areas:
        browser.find_element('xpath', '//*[@id="sections1items0items0items0items0"]/div[1]/div/div/div/div/div[1]/div[2]/div[' + str(area) + ']/button').click()
        time.sleep(timesleep)
        wait_for_page_load(browser)

        dfs = pd.read_html(browser.page_source, thousands=';')
        region = dfs[3].columns[0].split(' — ')[0].split(',')[-1]

        while region == region_previous:
            browser.find_element('xpath', '//*[@id="sections1items0items0items0items0"]/div[1]/div/div/div/div/div[1]/div[2]/div[' + str(area) + ']/button').click()
            time.sleep(timesleep)
            wait_for_page_load(browser)

            dfs = pd.read_html(browser.page_source, thousands=';')
            region = dfs[3].columns[0].split(' — ')[0].split(',')[-1]

        df_ECEPS = get_model_table(dfs[3], 'EC EPS', region, element, unit)
        df_GFSENS = get_model_table(dfs[4], 'GFS ENS', region, element, unit)
        if element == '100mWind' or element == '2mTemp':
            df_EC46 = get_model_table(dfs[5], 'EC46', region, element, unit)
            df_region = pd.concat([df_ECEPS, df_GFSENS, df_EC46], ignore_index=True)
        else:
            df_region = pd.concat([df_ECEPS, df_GFSENS], ignore_index=True)
        df = pd.concat([df, df_region], ignore_index=True)
        region_previous = region
    return df


def wait_for_page_load(browser):
    count = 0
    while len(pd.read_html(browser.page_source, thousands=';')) < 5:
        count += 1
        time.sleep(5)
        if count > 10:
            log.debug('Loading time overrun. Programme stopped')
            exit(1)


def get_model_table(df_model_table_raw, model, region, element, unit):

    # Process EC EPS Table
    title_split = df_model_table_raw.columns[0].split(' — ')
    pdate = datetime.strptime(title_split[1].split(',', 1)[-1], ' %B %d, %Y, %H:%M')

    # Get EC EPS RAW Table Period Info
    df_model_table_raw.rename(columns={list(df_model_table_raw)[0]: 'period'}, inplace=True)
    df_model_table_raw['period_from'] = df_model_table_raw.period.str.split(' — ', expand=True)[0]
    df_model_table_raw['period_from'] = df_model_table_raw.period_from.apply(lambda x: str(pdate.year) + x.split(',', 1)[-1])
    df_model_table_raw['period_from'] = pd.to_datetime(df_model_table_raw['period_from'], format='%Y %b %d, %H:%M')
    df_model_table_raw['period_to'] = df_model_table_raw.period_from + pd.DateOffset(days=7)

    # Get average case
    df_avg_case = df_model_table_raw.iloc[:, 0:3]
    df_avg_case['metdeskprob'] = ''
    df_avg_case['memberprob'] = ''
    df_avg_case['members'] = ''
    df_avg_case.columns = ['period', 'avg', 'delta_from_climate', 'metdeskprob', 'memberprob', 'members']
    df_avg_case['period'] = df_avg_case.period.str.replace(',', '')
    df_avg_case['cluster'] = 'avg'
    df_avg_case['period_from'] = df_model_table_raw['period_from'].values
    df_avg_case['period_to'] = df_model_table_raw['period_to'].values
    df_avg_case['delta_from_climate'] = df_avg_case.delta_from_climate.astype(str).str.replace('°C', '').str.replace('+', '')
    df_avg_case['avg'] = df_avg_case.avg.astype(str).str.replace('°C', '').str.replace('+', '')
    df_avg_case = df_avg_case[
        ['period', 'period_from', 'period_to', 'cluster', 'avg', 'delta_from_climate', 'metdeskprob',
         'memberprob', 'members']]
    df = df_avg_case.copy()

    # Get cluster case members
    # df_ECEPS_members = get_ECEPS_members(browser, df_2m_temp_avg)

    # Get cluster cases
    range_list = [range(3, 8), range(8, 13), range(13, 18), range(18, 23), range(23, 28), range(28, 33)]
    cluster_list = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6']
    for r, c in zip(range_list, cluster_list):
        df = pd.concat([df, get_cluster_cases(df_model_table_raw, r, c)], ignore_index=True)
    df['region'] = region
    df['model'] = model
    df['pdate'] = pdate
    df['unit'] = unit
    df['avg'] = df['avg'].replace(r'^\s*$', np.nan, regex=True).astype(float)
    df['metdeskprob'] = df['metdeskprob'].str.rstrip('%').replace(r'^\s*$', np.nan, regex=True).astype(float)/100
    df['memberprob'] = df['memberprob'].str.rstrip('%').replace(r'^\s*$', np.nan, regex=True).astype(float)/100
    log.debug(element + ' Data -' + region + ': ' + model)
    return df


def get_members(browser, df_ECEPS_avg):
    lists_members = []
    for r in list(range(1, 10, 1)):
        row_list = []
        for c in list(range(8, 34, 5)):
            row_list.append(browser.find_element('xpath', '//*[@id="sections1items0items0items1items0"]/div[1]/div[2]/table[1]/tbody/tr[' + str(r) + ']/td[' + str(c) + ']').text)
        lists_members.append(row_list)
    cols_members = ['c1_members', 'c2_members', 'c3_members', 'c4_members', 'c5_members', 'c6_members']
    df_members = pd.DataFrame(lists_members, index=df_ECEPS_avg.period, columns=cols_members)
    df_members = df_members.reset_index()
    return df_members


def get_cluster_cases(df_metdesk_raw, cluster_range, cluster):
    df_cluster = df_metdesk_raw.iloc[:, [0] + list(cluster_range)]
    df_cluster.columns = ['period', 'delta_from_climate', 'avg', 'metdeskprob', 'memberprob', 'members']
    df_cluster['period'] = df_cluster.period.str.replace(',', '')
    df_cluster['cluster'] = cluster
    df_cluster['period_from'] = df_metdesk_raw['period_from'].values
    df_cluster['period_to'] = df_metdesk_raw['period_to'].values
    df_cluster['avg'] = df_cluster.avg.astype(str).str.replace('°C', '').str.replace('+', '')
    df_cluster['delta_from_climate'] = df_cluster.delta_from_climate.astype(str).str.replace('°C', '').str.replace('+', '')
    df_cluster['members'] = df_cluster.members.astype(str).str.replace(',', '-')
    df_cluster = df_cluster[[
        'period', 'period_from', 'period_to', 'cluster', 'avg', 'delta_from_climate', 'metdeskprob', 'memberprob',
        'members'
    ]]
    return df_cluster


def main(argv):

    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('-element',action='store', dest='element',default='none',
                            help='select element: 100mWind, 2mTemp, SolarPower, WindPower or all')

        args = parser.parse_args(argv)

        if args.element == 'none':
            log.debug('Element input required, Python script stopped.')
            exit(1)

        element = args.element

        # Initiate Chrome Driver
        log.debug("Initiate Chrome Driver.")
        browser = load_chrome_settings()

        log.debug("Getting clustering data.")
        # Start Scraping
        get_cluster_tables(browser, url_login, url_cluster, element)

        log.error(sys.exc_info()[0])
        # close and close chrone webdriver
        browser.close()
        browser.quit()
        log.debug("Done")
        exit(0)
    except Exception as e:
        log.error(e)
        exit(1)


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main(sys.argv[1:]))
