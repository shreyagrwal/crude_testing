import os
import sys
from os import path
import pandas as pd
from datetime import datetime, date

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment

as_of_date = date.today()

log = ag_log.get_log()

appDir = r'\\petroineos.local\dfs\Department Shared Folders\~Gas Power and Emission Department\Weather\Chris McLeish\Russian Flows'
filename = 'Upload_GAS_RussianFlow-'

log.debug("Env:"+env)
csvFolder = se.ingestion_folder

log.debug("Data File Folder:{0}".format(csvFolder))
df = pd.read_excel(path.join(appDir, 'NS2 Flow Forecast.xlsx'), sheet_name='NS2 Start Date', skiprows=3, nrows=5000 - 3, usecols='A,T:V')  #.dropna(subset=['Date'])

df = df.round(3)
df_melt = pd.melt(df, id_vars=['Date'], value_vars=df.columns[1:],  var_name='StartDates', value_name='Value')
df_melt['Date'] = pd.to_datetime(df_melt['Date']).dt.date
df_melt['StartDates'] = pd.to_datetime(df_melt['StartDates']).dt.date
df_melt['PipeLine'] = 'NS2'
df_melt['DataType'] = 'Assumed'
df_melt['Unit'] = 'mcm/d'
df_melt['Pdate'] = as_of_date
df_melt = df_melt[['Date', 'PipeLine', 'DataType', 'StartDates', 'Value', 'Unit', 'Pdate']]

log.debug("File Processing:{0}".format('NS2 Flow Forecast.xlsx'))
filename = path.join(csvFolder, filename + datetime.today().strftime('%y%m%d%H%M%S') + '.csv')
su.upload_to_database(df_melt, filename)

log.debug("CSV File Saved to: {0}".format(filename))
log.debug('Job Completed.')