import os, sys
sys.path.append(os.getcwd())
from selenium import webdriver
import requests
import time
import os
from datetime import datetime, date, timedelta
import pandas as pd
import numpy as np
import warnings
import sys
import random
import shutil
import glob as gb

from ag_log import ag_log
from scraper_utils import scraper_environment as se
from ag_data_access import blueocean_access as bo

env = se.environment

backfill = False
_today = date.today()

start_year = 2011 if backfill else _today.year - 1
url = 'https://www.theice.com/publicdocs/futures/COTHist'

format_datetime = '%y%m%d%H%M%S'
appFolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\ICEcotCFTC'
# bulk_uploader_folder = se.ingestion_folder
filename = 'Upload_Gas_CotICECFTC-'

dict_name = {
    'Market_and_Exchange_Names': 'MarketProduct',
    'As_of_Date_In_Form_YYMMDD': 'Ddate',
    'CFTC_Market_Code': 'VenueIdentifier',
    'CFTC_Region_Code': 'RegionCode',
    'CFTC_Commodity_Code': 'VenueProductCode',
    'FutOnly_or_Combined': 'DataType',
    'Contract_Units': 'ContractUnits'
}


def load_chrome_settings(downloadFolder):
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
#        chrome_options.add_argument('--headless')  # Otherwise headless Chrome
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": downloadFolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser


def split_the_ticker(ticker):
    if 'Positions' in ticker:
        tradertype, b = ticker.split('_Positions_')
        grouptype = 'Positions'
        positiontype = b.split('_')
    elif 'Pct_of_OI_' in ticker:
        ticker = ticker.replace('Pct_of_OI_', '')
    else:
        print(ticker)
        pass

    return tradertype, grouptype, positiontype


def process_and_save(downloadFolder, excel):
    pdate = excel.replace('.csv', '')[-4:]
    df = pd.read_csv(os.path.join(downloadFolder, excel), sep=',', skipfooter=1, encoding='cp1252')

    # Melt and rename the table
    df = df.drop(columns=['As_of_Date_Form_MM/DD/YYYY', 'CFTC_Contract_Market_Code'])
    id_vars = list(dict_name.keys())
    value_vars = [x for x in df.columns.tolist() if (x not in id_vars)]
    df = pd.melt(df, id_vars=id_vars, value_vars=value_vars, var_name='Ticker', value_name='Value')
    df = df.rename(columns=dict_name)

    # Split the Ticker into multi-columns
    df['Ddate'] = pd.to_datetime(df['Ddate'], format='%y%m%d')
    df['ContractUnits'] = df['ContractUnits'].apply(lambda x: x.replace(',', '').replace('(CONTRACTS OF ', '').replace(')', ''))
    df[['ProductName', 'Venue']] = df['MarketProduct'].str.split(' - ', 1, expand=True)
    df['ProductName'] = df['ProductName'].apply(lambda x: x.replace('ICE ', '').replace(' Futures', ''))
    df['Value'] = df['Value'].replace('', np.nan).replace(' ', np.nan).replace('#VALUE!', np.nan)
    df = df.drop(columns=['MarketProduct'])
    df = df.dropna(subset=['Value'])
    df_open_interest = df[(df['Ticker']=='Open_Interest_All')|(df['Ticker']=='Open_Interest_Old')|(df['Ticker']=='Pct_of_Open_Interest_All')]
    df_position = df[(df['Ticker']!='Open_Interest_All')&(df['Ticker']!='Open_Interest_Old')&(df['Ticker']!='Pct_of_Open_Interest_All')]

    ## todo: split the ticker
    df_position[['1', '2', '3']] = df_position['Ticker'].apply(lambda x: split_the_ticker(x))

    time.sleep(1)


def main():
    try:
        log.debug("Env:" + env)

        # Initiate Chrome Driver
        log.debug("Initialising Chrome.")
        downloadFolder = os.path.join(appFolder, '_download')
        archiveFolder = os.path.join(appFolder, '_archive')
        browser = load_chrome_settings(downloadFolder)

        # Calculate list of Fridays
        list_of_years = list(range(start_year, _today.year + 1))
        print(list_of_years)

        # #Remove Temp File
        # delete_temp_files(downloadFolder)

        # Scraping CSV files.
        log.debug("Scraping CSV files...")
        for year in list_of_years:
            # Download ICE Futures Europe csv
            get_csv_file(browser, url, year)
            time.sleep(random.uniform(3, 7))


        # Close and quit chrome webdriver
        browser.close()
        browser.quit()

        # # todo: process downloaded file and split the ticker
        # # Process the downloaded files
        log.error("Time log: " + datetime.today().strftime("%Y-%m-%d"))
        log.debug("Process Downloaded Data Files.")
        os.chdir(downloadFolder)
        file_list = gb.glob("*.csv")
        for excel in file_list:
            if not '~' in excel:
                log.debug("Processing File: " + excel)
                try:
                    process_and_save(downloadFolder, excel)
                    shutil.move(downloadFolder + "\\" + excel, archiveFolder + "\\" + excel)
                except Exception as e:
                    log.error(e)
                time.sleep(1)
        log.debug("Data Files Process Completed.")
        return 0

    except Exception as e:
        log.error(e)
        log.debug("Scraper stopped with error.")
        return 1


def get_csv_file(browser, url, year):
    log.debug("Get CSV file: " + str(year))
    url_full = url + str(year) + '.csv'
    log.debug("File url: " + url_full)
    try:
        browser.get(url_full)
    except:
        log.debug("Report not available: " + url_full + ', Pass.')


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())

