import os
import sys
import time
import shutil
import glob as gb
from os import path
import pandas as pd
from datetime import datetime
from selenium import webdriver
from xml.etree import ElementTree
from datetime import date, timedelta

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulk_uploader_folder = se.ingestion_folder
# appFolder = r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Scrapers\ESIOS"
appFolder = r"\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\ESIOS"

def Initialise():
    global url, browser
    url = 'https://api.esios.ree.es/archives/107/download?date_type=datos&end_date=<DATE>T23%3A59%3A59%2B00%3A00&locale=es&start_date=<DATE>T00%3A00%3A00%2B00%3A00'
    # Initiate Driver
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
#        chrome_options.add_argument('--headless')  # Otherwise headless Chrome
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": appFolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)


def ScrapeHistory():
    this_date = date.today()
    while (True):
        time.sleep(10)
        ScrapeOneDay(this_date)
        this_date = this_date - timedelta(days=1)


def ScrapeOneDay(this_date):
    log.debug("Scrape for " + str(this_date))
    this_date_str = this_date.strftime("%Y-%m-%d")
    this_url = url.replace("<DATE>", this_date_str)
    browser.get(this_url)


def ScrapeToday():
    ScrapeOneDay(date.today())


def Upload():
    os.chdir(appFolder)
    for xmlFile in gb.glob("*.xml"):
        try:
            log.debug("Upload file:"+xmlFile)
            tree = ElementTree.parse(path.join(appFolder, xmlFile))
            root = tree.getroot()

            df = pd.DataFrame(columns=('powerplantunit', 'generationtype', 'fueltype', 'period', 'hour', 'capacity'))
            index = 0
            unitDays = root.findall(
                '{http://sujetos.esios.ree.es/schemas/2007/03/07/P48Cierre-esios-MP/}SeriesTemporales')
            generationtype = 'UPSalida'
            for unitday in unitDays:
                unit = unitday.find('{http://sujetos.esios.ree.es/schemas/2007/03/07/P48Cierre-esios-MP/}UPSalida')
                if unit is None:
                    unit = unitday.find('{http://sujetos.esios.ree.es/schemas/2007/03/07/P48Cierre-esios-MP/}UPEntrada')
                    if unit is None:
                        continue
                    generationtype = 'UPEntrada'
                else:
                    generationtype = 'UPSalida'
                powerplantunit = unit.get('v')
                fueltype = unitday.find(
                    '{http://sujetos.esios.ree.es/schemas/2007/03/07/P48Cierre-esios-MP/}TipoNegocio').get('v')
                unitperiod = unitday.find('{http://sujetos.esios.ree.es/schemas/2007/03/07/P48Cierre-esios-MP/}Periodo')
                period = unitperiod.find(
                    '{http://sujetos.esios.ree.es/schemas/2007/03/07/P48Cierre-esios-MP/}IntervaloTiempo').get('v')
                for unithour in unitperiod.findall(
                        '{http://sujetos.esios.ree.es/schemas/2007/03/07/P48Cierre-esios-MP/}Intervalo'):
                    hour = unithour.find('{http://sujetos.esios.ree.es/schemas/2007/03/07/P48Cierre-esios-MP/}Pos').get(
                        'v')
                    capacity = unithour.find(
                        '{http://sujetos.esios.ree.es/schemas/2007/03/07/P48Cierre-esios-MP/}Ctd').get('v')
                    df.loc[index] = {'powerplantunit': powerplantunit, 'fueltype': fueltype, 'period': period,
                                     'hour': hour, 'capacity': capacity, 'generationtype': generationtype}
                    index = index + 1

            filename = path.join(bulk_uploader_folder, 'Upload_LNG_SpanishPowerProduction-' + datetime.today().strftime('%y%m%d%H%M%S') + '.csv')
            log.info(f'Exporting file: {filename}')
            su.upload_to_database(df, 'Upload_LNG_SpanishPowerProduction-')
            shutil.move(path.join(appFolder, xmlFile), path.join(path.join(appFolder, "archive"), xmlFile))
        except Exception as e:
            log.debug(df.head(10))
            log.error(e)
            shutil.move(path.join(appFolder, xmlFile), path.join(path.join(appFolder, "error"), xmlFile))


log = ag_log.get_log()

log.debug("Initliase scraper...")
Initialise()
log.debug("Scrape today's spanish power data...")
ScrapeToday()
log.debug("Upload data to ADI.")
Upload()

