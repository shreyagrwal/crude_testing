import logging
import os
from typing import Optional

import dotenv
import pandas as pd
from ag_log import ag_log
from src.gas.CEtools.CEtools import CElink
from ag_data_access import data_upload as du

dotenv.load_dotenv(override=True)
ce: Optional[CElink] = None
CE_DATE_FORMAT = "%d-%b-%Y"
"""
The date returned by CE outages is 1-Jun-2022 (as an example). When handling a series, the default format of pd.to_datetime() method is 1-June-2022.
This does not work with the default date handling format of Pandas to_datetime
 Therefore, 1-Jun-2022 fails and hence the need to specify the format  

"""


def get_raw_production_outages(assets: str):
    meta_data = ce.eugasout(assets=assets, getByCol='True', meta=True)
    meta_data = meta_data.iloc[:, 2:]
    outages = ce.eugasout(assets=assets, getByCol=True)
    outages.rename(columns={outages.columns[1]: 'DDate'}, inplace=True)
    outages.index = outages['DDate']
    outages.index = pd.to_datetime(outages.index, format=CE_DATE_FORMAT)
    outages = outages.iloc[:, 2:]
    return outages, meta_data


def melt_outages(outages: pd.DataFrame, meta_data: pd.DataFrame):
    column_names = ['AssetName', 'Type', 'Market', 'Variable', 'CapacityType', 'PlannedType', 'Source', 'Units']
    combined_frames = list()
    for col_idx in range(len(meta_data.columns)):
        static_frame = pd.DataFrame(
            {col: [item] * len(outages) for item, col in zip(list(meta_data.iloc[:, col_idx].values.T), column_names)})
        static_frame.index = outages.index
        timeseries = outages.iloc[:, col_idx]
        timeseries.name = 'Value'
        combined_frame = pd.concat([timeseries.to_frame(), static_frame], axis=1)
        combined_frames.append(combined_frame)
    return pd.concat(combined_frames)


def get_production_outages(assets: str):
    outages, meta_data = get_raw_production_outages(assets)
    production_outages = melt_outages(outages, meta_data)
    return production_outages


OUTPUT_MAPPING = {'NO': ['NO_pro']}


def main():
    production_outages_list = list()
    for region, assets in OUTPUT_MAPPING.items():
        for asset in assets:
            production_outages = get_production_outages(asset)
            production_outages_list.append(production_outages)
    production_outages_frame = pd.concat(production_outages_list)
    du.upload_to_database(production_outages_frame, 'Upload_GAS_CommodityEssentialProductionOutages-',
                          env=os.environ["environment"].upper(), index=True)
    logging.info(f"Upload complete")
    pass


if __name__ == '__main__':
    log = ag_log.get_log()
    ce = CElink.create_using_secret_client()
    logging.info(f"Created instance of CELink using SecretsClient")
    main()
    logging.info("Complete")