import os
import sys
import time
import random
import pandas as pd
from pathlib import Path
from datetime import datetime
from selenium import webdriver

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_email import ag_email_helper as aeh
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

env = se.environment
Dev_Mode = False

format_datetime = '%y%m%d%H%M%S'
_today = datetime.today().strftime('%Y-%m-%d')

filename = 'Upload_Gas_GasscoFlow' + '-'
filenamelatest = 'Upload_Gas_GasscoFlowLatest' + '-'
bulk_uploader_folder = se.ingestion_folder
temp_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\Gassco'


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
#        chrome_options.add_argument('--headless')  # Otherwise headless Chrome
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": r"c:\temp\\",
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser


def color_negative_red(value):
    if value < 0:
        color = 'red'
    elif value > 0:
        color = 'green'
    else:
        color = 'black'
    return 'color: %s' % color


def get_last_published():
    query = '''
        SELECT Max(published)
        FROM dataengineering.gas_pipeline_gasscoflowlatest
        WHERE IsActive = True
    '''
    return bo.get_data(query)


def get_latest_published(df_list):
    timestamp_new = []
    for this_df in df_list:
        if not this_df.empty:
            this_df.iloc[:, 5] = this_df.iloc[:, 5].astype(str).str[:-5]
            this_df.iloc[:, 6] = this_df.iloc[:, 6].astype(str).str[:-5]
            this_df.iloc[:, 7] = this_df.iloc[:, 7].astype(str).str[:-5]
            max_date = pd.to_datetime(this_df.iloc[:, 5]).max()
            if not timestamp_new:
                timestamp_new = max_date
            elif timestamp_new < max_date:
                timestamp_new = max_date
    return timestamp_new


def get_data_from_db(date, date_type):
    if date_type == 'after':
        symbol = '>'
    else:
        symbol = '='
    query = '''
        SELECT pdate, 
               event_id, 
               asset_affected, 
               type_of_unavailability,
               revision, 
               published, 
               event_start,
               event_end,
               capacity_technical, 
               capacity_available, 
               capacity_unavailable, 
               type_of_event,      
               reason_for_the_unavailability, 
               remarks,  
               asset_type                                                                                        
        FROM dataengineering.gas_pipeline_gasscoflowlatest
        WHERE  published ''' + symbol + " '" + str(date) + "'" + ''' 
        AND IsActive = True
        ORDER  BY event_id 
    '''
    return bo.get_data(query)


def find_between(s, first, last):
    try:
        start = s.index(first) + len(first)
        end = s.index(last, start)
        return s[start:end]
    except ValueError:
        return ""


def df_to_string(element):
    string = ""
    for element in element:
        string += element+", "
    string = string[:-1]
    return string


def accept_disclaimer(browser, url, xpath):
    browser.get(url)
    time.sleep(random.uniform(5, 10))

    login_button = browser.find_element('xpath', xpath)
    login_button.send_keys("\n")
    time.sleep(random.uniform(5, 15))


def save_timestamp(timestamp_output, timestamp_path):
    timestamp_file = open(timestamp_path, "w")
    toFile = str(timestamp_output)
    timestamp_file.write(toFile)
    timestamp_file.close()
    log.debug("Timestamp saved: " + timestamp_path)


def save_event_table(df, pdate, asset_type):
    df.columns = [
        'event_id', 'asset_affected', 'event_status', 'type_of_unavailability', 'type_of_event', 'published',
        'event_start', 'event_end', 'unit', 'capacity_technical', 'capacity_available', 'capacity_unavailable',
        'reason_for_the_unavailability', 'remarks', 'balancing_zone', 'market_participant', 'market_participant_code',
        'affected_asset_or_unit_EIC_code'
    ]
    df['revision'] = df['event_id'].str.strip().str[-3:].astype(int)
    df['event_id'] = df['event_id'].str.split('__', expand=True)[0]

    df['capacity_unavailable'] = df['capacity_unavailable'].apply(lambda x: float(x)*-1)
    df['asset_type'] = asset_type
    df['remarks'] = df['remarks'].astype(str).str.replace(",", "")
    df['pdate'] = pdate
    del df['event_status']

    su.upload_to_database(df, filename)
    su.upload_to_database(df, filenamelatest)


def send_upload_fail_warning(email_from, emails, pdate_new, pdate_existing, count):

    sub = "Gassco Flow database update FAILED"
    body = "<b>Gassco Flow database upload failed after " + str(count) + " attemps</b>" \
           + "<br>" \
           + "<br>" \
           + "<b>Latest data pulished timestamp in database: " + pdate_existing + "</b>" \
           + "<br>" \
           + "<br>" \
           + "<b>Latest data pulished timestamp on Gassco Flow website: " + pdate_new.strftime("%Y-%m-%d, %H:%M:%S") + "</b>" \
           + "<br>" \

    imgList = []

    email_sender = aeh.AgEmailHelper()
    email_sender.send_mail_with_embedded_images(email_from, emails, sub, body, imgList)


def send_updates_report(email_from, emails, table_updates, updated_time):

    sub = "Gassco Flow updates found: (" + updated_time.strftime("%Y-%m-%d, %H:%M:%S") + ")"
    body = "<b><font size='+2'> Gassco Flow Table updated:</font></b>" \
           + "<br>" \
           + "<b>" + table_updates + "</b>" \
           + "<br>" \
           + "<b>The latest updated on :" + updated_time.strftime("%Y-%m-%d, %H:%M:%S") + " as marked on Gassco Flow website</b>" \
           + "<br>" \

    imgList = []

    email_sender = aeh.AgEmailHelper()
    email_sender.send_mail_with_embedded_images(email_from, emails, sub, body, imgList)


def send_notification(pdate_new, pdate_existing):
    # wait for batchuploader
    count = 0
    if Dev_Mode:
        sleeping_time = 1
    else:
        sleeping_time = 60

    while count < 5:
        log.debug("Wait for {} sec to allow new data to be uploaded to database, this is {} wait.".format(sleeping_time, count+1))
        time.sleep(sleeping_time)
        if pdate_new == pd.to_datetime(get_last_published().iloc[0, 0]):
            log.debug("Database update completed.")
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            log.debug("Sending out update notification email.")
            df_updated = get_data_from_db(pdate_existing, 'after').sort_values(by=['asset_type', 'event_id'])
            df_existing = get_data_from_db(pdate_existing, 'existing').sort_values(by=['asset_type', 'event_id'])
            df_updated = df_updated[['pdate', 'event_id', 'asset_type', 'asset_affected', 'type_of_unavailability',
                                     'revision', 'published', 'event_start', 'event_end',
                                     'capacity_technical', 'capacity_available', 'capacity_unavailable',
                                     'type_of_event', 'reason_for_the_unavailability', 'remarks']]
            html = (
                df_updated.style.format({
                    'event_start': lambda x: "{}".format(pd.to_datetime(x).strftime('%Y-%m-%d')),
                    'event_end': lambda x: "{}".format(pd.to_datetime(x).strftime('%Y-%m-%d')),
                    'capacity_technical': lambda x: "{:.0f}".format(x),
                    'capacity_available': lambda x: "{:.0f}".format(x),
                    'capacity_unavailable': lambda x: "{:.0f}".format(x)
                }).hide_index().set_properties(**{
                    'font-size': '14pt', 'background-color': 'white', 'border-color': 'black',
                    'border-style': 'solid', 'border-width': '1px', 'border-collapse': 'collapse',
                    'text-align': 'center', 'min-width': '1000'}).render()
            )

            send_updates_report("Chales.Cai@petroineos.com", "dong.xia@petroineos.com;rossmcvey@petroineos.co.uk;bobby.hemming@petroineos.co.uk", html, pdate_new)
            log.debug("Scraping Job Completed.")
            break
        else:
            count += 1

    if count >= 5:
        log.debug("Database update FAILED!")
        log.debug("Sending Out Warning Email.")
        log.debug("Scraping Job FAILED!")
        send_upload_fail_warning("dong.xia@petroineos.com", "dong.xia@petroineos.com", pdate_new, pdate_existing, count)


def get_event_tables(browser, url):
    disclaimer_xpath = '//*[@id="wrapper-primary"]/div/div/div/form/input[1]'
    accept_disclaimer(browser, url, disclaimer_xpath)

    counting = 0
    while browser.current_url != 'https://umm.gassco.no/':
        if counting <= 20:
            counting += 1
            log.debug("~~~Failed to pass disclaimer, retrying: " + str(counting))
            accept_disclaimer(browser, url, disclaimer_xpath)
        else:
            log.debug("Maximum retry reached, failed to pass disclaimer")
            log.debug("Scarper Stopped.")
            sys.exit(1)

    df_list = pd.read_html(browser.page_source)
    # get the latest published date among 3 tables as pdate
    df_field = df_list[3].drop_duplicates(keep='first').iloc[4:, :18]
    df_terminal = df_list[6].drop_duplicates(keep='first').iloc[4:, :18]
    df_other = df_list[9].drop_duplicates(keep='first').iloc[4:, :18]
    df_list = [df_field, df_terminal, df_other]
    timestamp_new = get_latest_published(df_list)
    del df_list

    # check against previous published date in temp folder
    publication_timestamp_path = os.path.join(temp_path, '_temp', 'publication_timestamp.txt')
    scraper_run_datestamp_path = os.path.join(temp_path, '_temp', 'scraper_run_datestamp.txt')
    publication_timestamp_file = Path(publication_timestamp_path)
    scraper_run_datestamp_file = Path(scraper_run_datestamp_path)

    if scraper_run_datestamp_file.is_file():
        pass
    else:
        save_timestamp(_today, scraper_run_datestamp_path)

    if publication_timestamp_file.is_file():
        log.debug('Gassco Publication Timestamp file found, start to compare')
        publication_timestamp_existing = open(publication_timestamp_path, "r").read()
        scraper_run_datestamp_existing = open(scraper_run_datestamp_path, "r").read()

        if str(timestamp_new) == publication_timestamp_existing:
            if str(_today) == scraper_run_datestamp_existing:
                log.debug('No new update found, scraper stops')
                browser.close()
                browser.quit()
                sys.exit(0)
            else:
                log.debug('Scraper Run Check Dates mismatched.')
                log.debug('Previous Scraper Run Check Dates: ' + str(scraper_run_datestamp_existing))
                log.debug('Scraping all data to update modified datetime in database anyway.')
                update_notification = False
        else:
            log.debug('New update detected, start to download the files')
            log.debug('New latest publish timestamp: ' + str(timestamp_new))
            update_notification = True

    else:
        publication_timestamp_existing = datetime(2000, 1, 1)
        log.debug('No timestamp file found, start to download the files')
        log.debug('Latest publish timestamp: ' + str(timestamp_new))
        if Dev_Mode:
            update_notification = True
        else:
            update_notification = False

    # Save datatable as csv
    # pdate_new = datetime.today().strftime('%Y-%m-%d %H:%m')
    pdate_new = timestamp_new

    # FIELDS AND PROCESSING PLANTS
    if df_field.empty or df_field.iloc[0, 0] == '---':
        print('No fields and processing plants events found')
    else:
        print('Scraping fields and processing plants events')
        save_event_table(df_field, pdate_new, 'fields')
        time.sleep(1)

    # EXIT TERMINALS
    if df_terminal.empty or df_terminal.iloc[0, 0] == '---':
        print('No exit terminals events found')
    else:
        print('Scraping exit terminals events')
        save_event_table(df_terminal, pdate_new, 'terminals')
        time.sleep(1)

    # OTHER
    if df_other.empty or df_other.iloc[0, 0] == '---':
        print('No other events found')
    else:
        print('Scraping other events')
        save_event_table(df_other, pdate_new, 'other')
        time.sleep(1)

    # update published date in temp folder
    save_timestamp(timestamp_new, publication_timestamp_path)
    save_timestamp(_today, scraper_run_datestamp_path)

    return timestamp_new, publication_timestamp_existing, update_notification


def main():
    log.debug("Env:" + env)
    # individual_event_list_url = 'https://flow.gassco.no/atom.xml'
    event_tables_url = 'https://umm.gassco.no/'
    log.debug("Event Table URL:" + event_tables_url)

    # Initiate Chrome Driver
    log.debug("Initialising Chrome.")
    browser = load_chrome_settings()

    # Start Scraping - get event table from main page
    log.debug("Getting event table.")
    pdate_new, pdate_existing, update_notification = get_event_tables(browser, event_tables_url)

    # Send Notification Email
    if update_notification:
        log.debug("Sending notification emails")
        send_notification(pdate_new, pdate_existing)

    # close and close chrome webdriver
    browser.close()
    browser.quit()
    return 0


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())
