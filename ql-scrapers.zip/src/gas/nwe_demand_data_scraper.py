import logging
import os
from typing import Optional

import dotenv
import pandas as pd

from ag_log import ag_log
from src.gas.CEtools.CEtools import CElink
from ag_data_access import data_upload as du

filename = 'Upload_GAS_CommodityEssentialDemand-'

# Commodity Essentials API
ce: Optional[CElink] = None

ids = '25848, 25663, 25789, 20792, 20786, 20795, 25982, 57744, 57746, 57748, 57745, 19909, 19924, 19903, 18903, 18881, 18946, 18801, 18804, 26193, 25316, 61421'


def main():
    try:
        headers = ce.eugasseries(id=ids, meta=True).iloc[:, 1:]
        df_nwe_dem = ce.eugasseries(id=ids).iloc[:, 1:]
        df_nwe_dem.columns = ['Ddate'] + (headers.iloc[0] + ' ' + headers.iloc[7]).tolist()[1:]
        df_nwe_dem['Ddate'] = pd.to_datetime(df_nwe_dem['Ddate'], format='%d-%b-%Y')

        df_nwe_dem_melt = pd.melt(df_nwe_dem, id_vars='Ddate', value_vars=df_nwe_dem.columns.tolist()[1:],
                                  var_name='Region', value_name='Value')
        df_nwe_dem_melt[['Region', 'Flow']] = df_nwe_dem_melt['Region'].str.split(', ', n=1, expand=True)
        df_nwe_dem_melt['Flow'] = df_nwe_dem_melt['Flow'].apply(
            lambda x: x.replace(', ', ' ').replace('Demand ', ' ').replace('Dem ', ' ').replace('- ', '').strip())
        df_nwe_dem_melt = df_nwe_dem_melt.dropna(how='any')

        log.info(df_nwe_dem.tail())
        du.upload_to_database(df_nwe_dem_melt, filename, env=os.environ["environment"].upper(), index=False)

        logging.info("Complete")

    except Exception as e:
        log.error(e)
        return 1


if __name__ == "__main__":
    dotenv.load_dotenv(override=True)
    log = ag_log.get_log()
    ce = CElink.create_using_secret_client()
    exit(main())
