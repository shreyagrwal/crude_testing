import os
import sys
import time
import shutil
import glob as gb
import pandas as pd
from datetime import date
from selenium import webdriver

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment

format_datetime = '%y%m%d%H%M%S'
as_of_date = date.today()

url = 'https://mip-prd-web.azurewebsites.net/ReportExplorer'
appFolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\NationalGridDailyNomination\download'
bulkUploaderFolder = se.ingestion_folder
filename = 'Upload_Gas_NationalGridNomination-'

sleeping_long = 15
sleeping_medium = 5
sleeping_short = 2


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    #if sys.gettrace() is None:  # Check if it's in Debug model
        #chrome_options.add_argument('--headless')
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": appFolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser


def get_daily_nomination_report(browser, url):

    # Get to Data Item Explorer and Demand Folder
    log.debug("Get to Report Explorer...")
    browser.get(url)
    time.sleep(sleeping_medium)

    log.debug("Get to Daily Summary Report (DSR)...")
    browser.find_element('xpath', '//*[@id="reportExplorerTreeContainer"]/ul/li/ul/li[1]/span/span[3]').click()
    time.sleep(sleeping_medium)

    log.debug("Switch to New Tab in Chrome...")
    window_before = browser.window_handles[0]
    window_after = browser.window_handles[1]
    browser.switch_to.window(window_after)

    # 1. Daily Summary Report (DSR)
    log.debug("Download the Daily Summary Report in csv...")
    browser.find_element('xpath', '//*[@id="imgCSV"]/img').click()
    time.sleep(sleeping_long)


def delete_temp_files(appFolder):
    for filename in os.listdir(appFolder):
        file_path = os.path.join(appFolder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            log.error('Failed to delete %s. Reason: %s' % (file_path, e))


def process_csv_files():
    os.chdir(appFolder)
    for excel in gb.glob("*.csv"):
        if not '~' in excel:
            df = pd.read_csv(os.path.join(appFolder, excel))#.fillna(0)
            df.columns = df.columns.str.replace(' ', '_')
            df['Applicable_At'] = pd.to_datetime(df['Applicable_At'], format='%d/%m/%Y %H:%M:%S')
            df['Applicable_For'] = pd.to_datetime(df['Applicable_For'], format='%d/%m/%Y')
            df['Generated_Time'] = pd.to_datetime(df['Applicable_At'], format='%d/%m/%Y %H:%M:%S')
            df['Data_Item'] = df['Data_Item'].str.replace(',', '')

            df = df.rename({'Applicable_For': 'Ddate', 'Applicable_At':'Pdate'}, axis='columns')
            df['Ddate'] = df['Ddate'].dt.date
            df['Unit'] = ''#'mcm'

            su.upload_to_database(df, filename)
            time.sleep(1)


def main():
    try:
        # Delete Files in Temp folder
        delete_temp_files(appFolder)
        log.debug("Env:"+env)

        # Initiate Chrome Driver
        log.debug("Initiate Chrome Driver.")
        browser = load_chrome_settings()

        # Start Scraping
        log.debug("Getting NG Daily Nomination Report~~~~~")
        get_daily_nomination_report(browser, url)

        # close and close chrone webdriver
        browser.close()
        browser.quit()

        # Process Downloaded file
        log.debug("Processing downloaded csv file.")
        process_csv_files()

        # Finishing the Job
        log.debug("csv file exported.")
        return 0
    except Exception as e:
        log.error(e)
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())