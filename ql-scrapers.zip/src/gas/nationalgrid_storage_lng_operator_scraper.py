import os
import sys
import time
import shutil
import glob as gb
import pandas as pd
from selenium import webdriver
from datetime import datetime, date

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se


env = se.environment

format_datetime = '%y%m%d%H%M%S'

url_data = 'https://www.nationalgrid.com/uk/gas-transmission/data-and-operations/transmission-operational-data'
appFolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\NationalGridDailyStorage&Lng'
bulkUploaderFolder = se.ingestion_folder
filename = 'Upload_GAS_NationalGridDailyStorageLngOperator-'

sleeping_long = 15
sleeping_medium = 5
sleeping_short = 2


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    # Debug mode disabled
    #if sys.gettrace() is None:  # Check if it's in Debug model
        #chrome_options.add_argument('--headless')
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": appFolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)
    return browser


def get_storage_and_lng(browser, url_data_item):

    # Go to the website
    log.debug("Get to Transmission operational data and Daily Storage & LNG Operation information...")
    browser.get(url_data_item)
    time.sleep(sleeping_medium)

    try:
        # Accept the use of cookies
        browser.find_element('xpath', '//*[@id="cky-btn-accept"]').click()
        time.sleep(sleeping_medium)
    except Exception as e:
        log.error(e)

    # Get to Supplementary reports and Daily Storage & LNG Operation information
    log.debug("Daily storage and LNG operator information...")

    button = browser.find_element('xpath', '/html/body/div[6]/div/div[2]/section/main/section[11]/div/div/div/header/nav/div/a[7]')
    # button = browser.find_element('xpath', '/html/body/div[6]/div/div[2]/section/main/section[10]/div/div/div/header/nav/div/a[4]')
    browser.execute_script("arguments[0].click();", button)
    time.sleep(sleeping_short)

    # Download Daily storage and LNG operator information file
    # button2 = browser.find_element('xpath', '/html/body/div[6]/div/div[2]/section/main/section[10]/div/div/div/main/div[4]/div/div/div[1]/table/tbody/tr/td/a')
    button2 = browser.find_element('xpath', '/html/body/div[6]/div/div[2]/section/main/section[11]/div/div/div/main/div[7]/div/div/div[1]/table/tbody/tr[1]/td[2]/a/span')
    browser.execute_script("arguments[0].click();", button2)
    time.sleep(sleeping_medium)


def delete_temp_files(appFolder):
    for filename in os.listdir(appFolder):
        file_path = os.path.join(appFolder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))


def process_excel_files():
    os.chdir(appFolder)
    for excel in gb.glob("*.xls"):
        if not '~' in excel:
            xls = pd.ExcelFile(os.path.join(appFolder, excel))
            df = pd.read_excel(xls, 'Today').dropna(how='all')
            df.columns = df.columns.str.replace(' ', '_')
            df.drop(df.index[(df["Gasday"] == "All units are in kWh")], axis=0, inplace=True)
            df["Gasday"] = pd.to_datetime(df["Gasday"]).dt.strftime("%Y-%m-%d")
            df = df.rename({'Gasday': 'Ddate'}, axis='columns')
            df['Pdate'] = date.today().strftime(format='%F')

            su.upload_to_database(df, filename)
            time.sleep(1)


def main():
    try:
        # Delete Files in Temp folder
        delete_temp_files(appFolder)

        # Initiate Chrome Driver
        log.debug("Initiate Chrome Driver.")
        browser = load_chrome_settings()

        # Start Scraping
        log.debug("Getting Daily Storage and LNG Operator Information Data~~~~~")
        get_storage_and_lng(browser, url_data)

        # close and close chrome webdriver
        browser.close()
        browser.quit()

        # Process Downloaded file
        log.debug("Processing downloaded csv file.")
        process_excel_files()

        # Finishing the Job
        log.debug("csv file exported.")
        return 0
    except Exception as e:
        log.error(e)
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())

