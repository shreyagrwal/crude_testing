import os
import sys
import time
import random
import shutil
import glob as gb
import pandas as pd
import numpy as np
from selenium import webdriver
from datetime import datetime, date, timedelta

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment

backfill = False
_today = date.today()
weeks = 6 if backfill else 3

url_Futures = 'https://www.theice.com/marketdata/publicdocs/mifid/commitment_of_traders/IFEU_FUT_'
url_Endex = 'https://www.theice.com/marketdata/publicdocs/mifid/commitment_of_traders/NDEX_FUT_'

format_datetime = '%y%m%d%H%M%S'
appFolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\ICEcotMiFIDII'
bulk_uploader_folder = se.ingestion_folder
filename = 'Upload_Gas_CotICEMiFIDII-'

dict_name = {
    'Name_of_Trading_Venue': 'Venue',
    'Trading_Venue_Identifier': 'VenueIdentifier',
    'Date_of_which_the_weekly_report_refers': 'Ddate',
    'Date_and_time_of_the_publication': 'Pdate',
    'Name_of_Commodity_Contract_or_Emission_Allowance': 'ProductName',
    'Venue_Product_Code': 'VenueProductCode',
    'Report_Status': 'ReportStatus',
    'NotationofthePositionQuantity': 'PositionQuantityNotation'
}


def load_chrome_settings(downloadFolder):
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
#        chrome_options.add_argument('--headless')  # Otherwise headless Chrome
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": downloadFolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)
    return browser


def get_list_of_weekdays(weekday, weeks):
    weekday_as_int = time.strptime(weekday, "%A").tm_wday
    start_date = _today - timedelta(weeks=weeks)
    dates = pd.to_datetime([start_date, _today])
    list_of_dates = pd.date_range(dates[0], dates[1], freq='1d')
    list_of_dates = list_of_dates[list_of_dates.dayofweek == weekday_as_int]
    list_of_dates = list(list_of_dates)[::-1]
    return list_of_dates


def split_the_ticker(df, splitter):
    if splitter != 'Combined':
        df[['TraderType', 'ActivityType']] = df['TraderType'].str.split('_' + splitter + '_', 1, expand=True)
        df = df.dropna(subset=['ActivityType'])
    else:
        df[['TraderType', 'ActivityType']] = df['TraderType'].str.rsplit('_', 1, expand=True)
        df = df[df['ActivityType'] == splitter]
    df['PositionType'] = splitter
    return df


def process_and_save(downloadFolder, excel):
    pdate = datetime.strptime(excel.replace('.csv', '')[-8:], "%Y%m%d").date()
    df = pd.read_csv(os.path.join(downloadFolder, excel), sep=',', skipfooter=1, encoding='cp1252')

    # Melt and rename the table
    id_vars = list(dict_name.keys())
    value_vars = [x for x in df.columns.tolist() if (x not in id_vars)]
    df = pd.melt(df, id_vars=id_vars, value_vars=value_vars, var_name='Ticker', value_name='Value')
    df = df.rename(columns=dict_name)

    # Split the Ticker into multi-columns
    df[['DataCategory', 'TraderType']] = df['Ticker'].str.split('_', 1, expand=True)
    df_long = split_the_ticker(df, 'Long')
    df_short = split_the_ticker(df, 'Short')
    df_combined = split_the_ticker(df, 'Combined')
    df_splitted = pd.concat([df_long, df_short, df_combined])
    df_splitted = df_splitted.drop(columns='Ticker')
    df_splitted['PositionQuantityNotation'] = df_splitted['PositionQuantityNotation'].apply(lambda x: x.replace('OTHER/', ''))
    df_splitted['ProductName'] = df['ProductName'].apply(lambda x: x.replace(',', ''))
    df_splitted['Value'] = df['Value'].replace('.', np.nan)
    df_splitted['Pdate'] = pdate
    df_splitted['DataSource'] = 'Scraper'

    # Save to csv
    filefullname = os.path.join(bulk_uploader_folder, filename + datetime.today().strftime('%y%m%d%H%M%S') + '.csv')
    log.debug("File Exported:" + filefullname)
    su.upload_to_database(df_splitted, filename)
    time.sleep(1)


def main():
    try:
        log.debug("Env:" + env)

        # Initiate Chrome Driver
        log.debug("Initialising Chrome.")
        downloadFolder = os.path.join(appFolder, '_download')
        archiveFolder = os.path.join(appFolder, '_archive')
        browser = load_chrome_settings(downloadFolder)

        # Calculate list of Fridays
        list_of_fridays = get_list_of_weekdays('Friday', weeks)
        print(list_of_fridays)

        # #Remove Temp File
        # Scraping CSV files.
        log.debug("Scraping CSV files...")
        for friday in list_of_fridays:
            # Download ICE Futures Europe csv
            get_csv_file(browser, url_Futures, friday)
            time.sleep(random.uniform(3, 7))

            # Download ICE Endex csv
            get_csv_file(browser, url_Endex, friday)
            time.sleep(random.uniform(5, 10))

        # Close and quit chrome webdriver
        browser.close()
        browser.quit()

        # Process the downloaded files
        log.error("Time log: " + datetime.today().strftime("%Y-%m-%d"))
        log.debug("Process Downloaded Data Files.")
        os.chdir(downloadFolder)
        file_list = gb.glob("*.csv")
        for excel in file_list:
            if not '~' in excel:
                log.debug("Processing File: " + excel)
                try:
                    process_and_save(downloadFolder, excel)
                    shutil.move(downloadFolder + "\\" + excel, archiveFolder + "\\" + excel)
                except Exception as e:
                    log.error(e)
                time.sleep(1)
        log.debug("Data Files Process Completed.")
        return 0

    except Exception as e:
        log.error(e)
        log.debug("Scraper stopped with error.")
        return 1


def get_csv_file(browser, url, friday):
    log.debug("Get CSV file: " + friday.strftime("%Y-%m-%d"))
    url_full = url + friday.strftime('%Y%m%d') + '.csv'
    log.debug("File url: " + url_full)
    try:
        browser.get(url_full)
    except:
        log.debug("Report not available: " + url_full + ', Pass.')


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())

