import os
import sys
import time
import shutil
import glob as gb
import pandas as pd
from datetime import datetime
from selenium import webdriver

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder
appFolder = r"\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\OpenTable"


def Initialise():
    global url, browser
    url = 'https://www.opentable.com/state-of-industry'
    # Initiate Driver
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": appFolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)


def delete_temp_files(appFolder):
    for filename in os.listdir(appFolder):
        file_path = os.path.join(appFolder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))


def download_file():
    browser.get(url)
    element = browser.find_element('xpath', '//*[@id="mainContent"]/main/section[2]/div[4]/div[1]/button/div')
    browser.execute_script("arguments[0].click();", element)
    time.sleep(15)


def process_and_save(df_raw):
    i = 0
    column_list = list(df_raw.columns.values)
    column_list.remove('Type')
    column_list.remove('Name')

    df_result = pd.DataFrame(columns=['DDate', 'RegionType', 'Region', 'Rate'])
    for index, row in df_raw.iterrows():
        region_type = row['Type']
        region_name = row['Name']
        log.info(region_type + '-' + region_name)

        for c in column_list:
            if '/' in c:
                year, month, day = c.split('/')
                ddate = year + '-' + month + '-' + day
                value = row[c]
                df_result.loc[i] = [ddate, region_type, region_name, value]
                i = i + 1

    df_result['Rate'] = df_result.Rate.astype(str).str.replace('%', '').replace('nan', '', regex=True)
    su.upload_to_database(df_result, 'Upload_GAS_RestaurantBookingRate-')
    time.sleep(1)


log = ag_log.get_log()
log.debug("Clear Download SubFolder.")
log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
delete_temp_files(appFolder)
try:
    log.debug("ENV "+ env)
    log.debug("Initialised for scraper")
    Initialise()
    # log.debug("House keeping")
    # house_keeping()
    log.debug("Download file")
    download_file()
    browser.close()
    browser.quit()

    log.debug("Processing data file")
    os.chdir(appFolder)
    file_list = gb.glob("*.csv")
    for excel in file_list:
        if not '~' in excel:
            log.debug("Import Downloaded Data.")
            log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
            df = pd.read_csv(os.path.join(appFolder, excel))
            log.debug("Retrieved total records:"+str(len(df)))
            process_and_save(df)

    log.debug("Done")
    del browser
    exit(0)
except Exception as e:
    log.error(e)
    exit(1)
