import os
import sys
import time
import shutil
import glob as gb
import numpy as np
import pandas as pd
from selenium import webdriver
from datetime import datetime, timedelta, date

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

env = se.environment

backfill = False
backfill_start_date = '2018-01-01'

format_datetime = '%y%m%d%H%M%S'

days_interval = 5
as_of_date = date.today()
end_date = date.today() + timedelta(days=days_interval)

url_data = 'https://mip-prd-web.azurewebsites.net/DataItemExplorer/Index'

appFolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\NationalGridIUKBBL'
bulkUploaderFolder = se.ingestion_folder
filename = 'Upload_GAS_NationalSupplyIUKBBL-'


if backfill == False:
    start_date = as_of_date - timedelta(days=days_interval)
    list_of_dates_list = [[start_date, end_date]]
    sleeping_long = 15
    sleeping_medium = 5
    sleeping_short = 2
    del start_date
else:
    days_interval = 7
    start_date = backfill_start_date
    dates = pd.Series(pd.date_range(start=start_date, end=end_date))
    df_dates = dates.groupby(np.arange(len(dates)) // days_interval).agg(['first', 'last'])
    df_dates['first'] = df_dates['first'].apply(str)
    df_dates['last'] = df_dates['last'].apply(str)
    list_of_dates_list_str = df_dates.values.tolist()
    list_of_dates_list = []
    for dates_list in list_of_dates_list_str:
        dates_list = [datetime.strptime(x, '%Y-%m-%d %H:%M:%S') for x in dates_list]
        if list_of_dates_list == []:
            list_of_dates_list = [dates_list]
        else:
            list_of_dates_list.append(dates_list)
    sleeping_long = 3
    sleeping_medium = 2
    sleeping_short = 1

    del dates, df_dates, start_date, list_of_dates_list_str


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    # Debug mode disabled
    #if sys.gettrace() is None:  # Check if it's in Debug model
        #chrome_options.add_argument('--headless')
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": appFolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)
    return browser


def get_supply_actual_iuk_bbl(browser, url_data_item, list_of_dates_list):

    # Get to Data Item Explorer
    log.debug("Get to Data Item Explorer...")
    browser.get(url_data_item)
    time.sleep(sleeping_medium)

    # Supplies Folder
    log.debug("Supplies Folder...")
    browser.find_element('xpath', '//*[@id="dataItemTreeContainer"]/ul/li[17]/span/span[1]').click()
    time.sleep(sleeping_medium)

    # Daily Actual (Commercial) Folder
    log.debug("Daily Actual (Commercial) Folder...")
    browser.find_element('xpath', '//*[@id="dataItemTreeContainer"]/ul/li[17]/ul/li[1]/span/span[1]').click()
    time.sleep(sleeping_medium)

    # Volume Folder
    log.debug("Volume Folder...")
    browser.find_element('xpath', '//*[@id="dataItemTreeContainer"]/ul/li[17]/ul/li[1]/ul/li[3]/span/span[1]').click()
    time.sleep(sleeping_medium)

    # LDZ Forecast
    log.debug("BBL D+2 & IUK D+2...")
    browser.find_element('xpath', '//*[@id="dataItemTreeContainer"]/ul/li[17]/ul/li[1]/ul/li[3]/ul/li[5]/span/span[2]').click()
    time.sleep(sleeping_medium)
    browser.find_element('xpath', '//*[@id="dataItemTreeContainer"]/ul/li[17]/ul/li[1]/ul/li[3]/ul/li[13]/span/span[2]').click()
    time.sleep(sleeping_medium)

    # Pick Latest Values and Applicable For
    log.debug("Pick Latest Values and Applicable For...")
    browser.find_element('xpath', '//*[@id="LatestValue"]').click()
    time.sleep(sleeping_medium)
    browser.find_element('xpath', '//*[@id="applicableForRadioButton"]').click()
    time.sleep(sleeping_medium)

    # Inputs - Dates
    log.debug("Inputs - Dates...")
    for dates_list in list_of_dates_list:

        [start, end] = dates_list
        print('End Date: ' + end.strftime('%y%m%d%H%M%S'))
        browser.find_element('xpath', '//*[@id="FromDateTime"]').clear()
        time.sleep(sleeping_short)
        browser.find_element('xpath', '//*[@id="FromDateTime"]').send_keys(start.strftime('%d/%m/%Y'))
        time.sleep(sleeping_short)
        browser.find_element('xpath', '//*[@id="ToDateTime"]').clear()
        time.sleep(sleeping_short)
        browser.find_element('xpath', '//*[@id="ToDateTime"]').send_keys(end.strftime('%d/%m/%Y'))
        time.sleep(sleeping_short)

        # Download the file
        log.debug("Download the file...")
        browser.find_element('xpath', '//*[@id="imgCSV"]/img').click()
        time.sleep(sleeping_long)


def delete_temp_files(appFolder):
    for filename in os.listdir(appFolder):
        file_path = os.path.join(appFolder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))


def process_csv_files():
    os.chdir(appFolder)
    for excel in gb.glob("*.csv"):
        if not '~' in excel:
            log.debug("Import downloaded data.")
            df = pd.read_csv(os.path.join(appFolder, excel))
            df.columns = df.columns.str.replace(' ', '_')
            df['Applicable_At'] = pd.to_datetime(df['Applicable_At'], format='%d/%m/%Y %H:%M:%S')
            df['Applicable_For'] = pd.to_datetime(df['Applicable_For'], format='%d/%m/%Y')
            df['Generated_Time'] = pd.to_datetime(df['Generated_Time'], format='%d/%m/%Y %H:%M:%S')

            df[['Supply_Type', 'Supply_Location', 'Period']] = df['Data_Item'].str.split(', ', expand=True)
            df['Supply_Location'] = df['Supply_Location'].str.replace(' - ', ' ')
            df[['Supply_Location', 'Supply_Pipeline']] = df['Supply_Location'].str.split(' ', expand=True)
            df = df.drop(columns='Data_Item')

            df['Pdate'] = as_of_date.strftime('%Y-%m-%d')
            df = df.rename({'Applicable_For': 'Ddate'}, axis='columns')
            df['Ddate'] = df['Ddate'].dt.date
            df['Unit'] = 'mcm'

            su.upload_to_database(df, filename)
            time.sleep(1)


def main():
    try:
        # Delete Files in Temp folder
        delete_temp_files(appFolder)

        # Initiate Chrome Driver
        log.debug("Initiate Chrome Driver.")
        browser = load_chrome_settings()

        # Start Scraping
        log.debug("Getting NG Supplies - Daily Actual - IUK & BBL~~~~~")
        get_supply_actual_iuk_bbl(browser, url_data, list_of_dates_list)

        # close and close chrome webdriver
        browser.close()
        browser.quit()

        # Process Downloaded file
        log.debug("Processing downloaded csv file.")
        process_csv_files()

        # Finishing the Job
        log.debug("csv file exported.")
        return 0
    except Exception as e:
        log.error(e)
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())