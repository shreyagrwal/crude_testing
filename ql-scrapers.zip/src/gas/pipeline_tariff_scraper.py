import os
import sys
import numpy as np
import pandas as pd
import xlwings as xw
from datetime import datetime as dt

sys.path.append(os.getcwd())
from scraper_utils import scraper_upload as su


title_cells = {
        'A': 'B',
        'O': 'P',
        'AC': 'AD',
        'AQ': 'AR'
    }

pipe_ranges = {
    'forwardFlow': {
        'country_exit': ['A', 'M'],
        'pipeline_entry': ['O', 'AA'],
        'pipeline_exit': ['AC', 'AO'],
        'country_entry': ['AQ', 'BC']
    },
    'reverseFlow': {
        'country_exit': ['AQ', 'BC'],
        'pipeline_entry': ['AC', 'AO'],
        'pipeline_exit': ['O', 'AA'],
        'country_entry': ['A', 'M']
    }
}


class Singleton(type):

    def __init__(cls, name, bases, attrs, **kwargs):
        super().__init__(name, bases, attrs)
        cls._instance = None

    def __call__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__call__(*args, **kwargs)
        return cls._instance


class ExcelUtil(metaclass=Singleton):
    _wb = None
    open = True

    def read_excel_range(self, wb, sht, range_name, open=True):
        if open:
            wb_ = self.open_book(wb)
        else:
            wb_ = xw.Book(wb)
        sht_ = wb_.sheets[sht]
        df_ = sht_.range(range_name).options(pd.DataFrame).value
        return df_

    def read_cell_value(self, wb, sht, row, col, open=True):
        if open:
            wb_ = self.open_book(wb)
        else:
            wb_ = xw.Book(wb)
        sht_ = wb_.sheets[sht]
        value = sht_[f'{col}{row}'].value
        return value

    def open_book(self, wb):
        if not self._wb:
            app = xw.App(add_book=False)
            app.display_alerts = False
            app.books.api.Open(wb, UpdateLinks=False)
            self._wb = app.books.active
        return self._wb

    def close_book(self, wb):
        if self._wb:
            wb_ = xw.Book(wb)
            wb_.close()


def get_pipline_capacity_cost_units(wb: str, sheet: str, row: int, col: str):
    value = ExcelUtil().read_cell_value(wb, sheet, row, col)
    value = value.split(' ')[-1].replace('(', '').replace(')', '')
    return value


def get_pipeline_meta_data(wb: str, sheet: str, range_name: str, flow_direction, booking_tso_type, variable_cost,
                           variable_curve_second=False):
    meta = ExcelUtil().read_excel_range(wb, sheet, range_name)

    regions = [meta.loc['RegionExit', 'Value'], meta.loc['RegionEntry', 'Value']]
    # Reverse the order of the regions when we are not forward flowing
    regions = regions if flow_direction == 'forwardFlow' else list(reversed(regions))

    booking_direction = booking_tso_type.split('_')[1]  # This will be Entry or Exit
    # If the flow direction (forward or reverse) is reversed we need to change which TSO is ENTRY and which id EXIT
    # e.g.for Forward Flow-- Exit TSO: National Grid, Entry TSO: Belgium ..... Reverse Flow-- Exit TSO: Belgium, Entry TSO: NationalGrid

    def find(options, i):
        return options[i == options[0]]

    booking_direction_altered = booking_direction if flow_direction == 'forwardFlow' else find(['entry', 'exit'], booking_direction)
    booking_tso_indicator = booking_tso_type if flow_direction == 'forwardFlow' else booking_tso_type.split('_')[0] + '_' + booking_direction_altered
    booking_tso_grabber = {   # This dictionary allows us to grab the correct property from the metadata sheet in Excel
        'country_exit': 'CountryTSOExit',
        'pipeline_entry': 'PipelineName',
        'pipeline_exit': 'PipelineName',
        'country_entry': 'CountryTSOEntry'
    }
    if booking_tso_type in ['pipeline_entry', 'pipeline_exit']:
        variable_curve_indicator = 'VariableCurveExit'
    else:
        variable_curve_indicator = 'VariableCurve' + booking_direction_altered.capitalize() \
            if flow_direction == 'forwardFlow' else 'VariableCurve' + booking_direction_altered.capitalize()
    if variable_curve_second:
        variable_curve_indicator = variable_curve_indicator + 'Second'

    variable_curve_value = meta.loc[variable_curve_indicator, 'Value'] if variable_cost else None
    if variable_curve_second and 'pipeline' in booking_tso_type:
        variable_curve_value = ''

    meta_data = {
        'RegionExit': meta.loc['RegionExit', 'Value'],
        'RegionEntry': meta.loc['RegionEntry', 'Value'],
        'Variable': flow_direction,
        'BookingTSO': meta.loc[booking_tso_grabber[booking_tso_indicator], 'Value'],
        'BookingDirection': booking_direction.capitalize(),
        'BookingTSOType': booking_tso_type,
        'VariableCost': variable_cost,
        'VariableCurve': variable_curve_value
    }
    return meta_data


# MELT DATA
def melt_capacity_costs(costs: pd.DataFrame, static_data: dict):
    column_names = ['Year', 'Month', 'Value', 'Units', 'RegionExit', 'RegionEntry', 'Variable', 'BookingTenure',
                    'BookingTSO', 'BookingDirection', 'BookingTSOType', 'VariableCost', 'VariableCurve']

    costs = pd.melt(costs.reset_index(), id_vars='index')
    costs.rename(columns={'index': 'Year', 'variable': 'Month', 'value': 'Value'}, inplace=True)
    costs['Year'] = costs['Year'].astype(int)
    costs['Month'] = costs['Month'].astype(int)
    costs.dropna(inplace=True)

    for col_name, col_val in static_data.items():
        costs[col_name] = col_val

    return costs[column_names]


# READ EXCEL DATA RANGE & MELT DATA
def get_capacity_costs(wb: str, sheet: str, range_name: str, static_data: dict):
    costs = ExcelUtil().read_excel_range(wb, sheet, range_name)  # get_raw_capacity_costs
    costs_melt = melt_capacity_costs(costs, static_data)
    return costs_melt


def engineer_capacity_costs_dataframe(flow_direction, variable_cost=False):
    sheet_name = flow_direction
    print('\n', flow_direction, 'VariableCost:', variable_cost)
    period_ranges = {
        'cost': {
            'D': [8, 19],
            'M': [23, 34],
            'Q': [38, 49],
            'S': [53, 64],
            'A': [68, 79]
        },
        'variable_cost': {
            'VCost': [83, 94],
            'VMultiplier': [98, 109],
            'VMultiplierSecond': [113, 124]
        }
    }

    roi = 'variable_cost' if variable_cost else 'cost'
    frames = []
    for pipe_range in pipe_ranges[flow_direction]:
        for period_range in period_ranges[roi]:
            # Select the appropriate range to collect data from e.g., A7:M19
            start_col, stop_col = pipe_ranges[flow_direction][pipe_range][0], pipe_ranges[flow_direction][pipe_range][1]
            start_row, stop_row = period_ranges[roi][period_range][0], period_ranges[roi][period_range][1]

            data_range_name_ = f'{start_col}{start_row}:{stop_col}{stop_row}'

            # Build meta data values e.g., BookingTSO, BookingTSOType etc. Note: some are dependent on flow direction
            meta_data_pipe = get_pipeline_meta_data(
                WB,
                'meta',
                'A1:B12',
                flow_direction,
                pipe_range,
                variable_cost=variable_cost,
                variable_curve_second=True if 'Second' in period_range else False
            )
            meta_data_pipe['BookingTenure'] = period_range
            meta_data_pipe['Units'] = get_pipline_capacity_cost_units(WB, sheet_name, row=start_row-1, col=title_cells[start_col])
            print(meta_data_pipe)

            capacity_costs = get_capacity_costs(WB, sheet_name, data_range_name_, meta_data_pipe)
            if period_range == 'VMultiplier' or period_range == 'VMultiplierSecond':
                capacity_costs['Value'] = capacity_costs['Value']*100
            frames.append(capacity_costs)

    frames = pd.concat(frames)
    frames['PDate'] = dt.now().date().strftime('%Y-%m-%d')
    # frames.to_csv(r'S:\~Analysis Department\Bobby\Natural Gas\IUK Supply\Upload_IUKTariffs.csv', index=False, encoding='utf-8-sig')
    # su.upload_to_database(frames, 'Upload_gas_pipeline_tariffs-', index=False)
    return frames


if __name__ == '__main__':
    WB = r'S:\~Analysis Department\Bobby\Natural Gas\BBL Supply\Upload_BBLTariffs.xlsx'

    all_costs = [
        engineer_capacity_costs_dataframe('forwardFlow', False),
        engineer_capacity_costs_dataframe('forwardFlow', variable_cost=True),
        engineer_capacity_costs_dataframe('reverseFlow', False),
        engineer_capacity_costs_dataframe('reverseFlow', variable_cost=True)
    ]

    all_costs = pd.concat(all_costs)
    su.upload_to_database(all_costs, 'Upload_gas_pipeline_tariffs-', index=False)
    ExcelUtil().close_book(WB)


