import os
import sys

sys.path.append(os.getcwd())
from scraper_utils.webpage_monitor import WebsiteMonitor


config_file = r'\\petroineos.local\dfs\Department Private Folders\Analysis Department\Gas\Scraper\WebMonitor\Websites_gas.xlsx'

monitor = WebsiteMonitor('dong.xia@petroineos.com;bobby.hemming@petroineos.co.uk', True)
# monitor.run_monitor(config_file)
monitor.monitor_once(config_file)

