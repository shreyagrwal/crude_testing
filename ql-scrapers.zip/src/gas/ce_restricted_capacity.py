import logging
import os
from typing import Optional

import dotenv
import pandas as pd
from ag_data_access import data_upload as du
from ag_log import ag_log
from src.gas.CEtools.CEtools import CElink

dotenv.load_dotenv(override=True)
ce: Optional[CElink] = None

def get_raw_restricted_capacity(assets: int, variable: str):
    meta_data = ce.eugasout(assets=assets, variable=variable, capType='restricted', getByCol='True',
                            dateFrom='20220101', meta=True)
    meta_data = meta_data[['assetId', str(assets)]]
    capacity = ce.eugasout(assets=assets, variable=variable, capType='restricted', dateFrom='20220101', getByCol='True')
    capacity.rename(columns={capacity.columns[1]: 'Date'}, inplace=True)
    capacity.index = pd.to_datetime(capacity['Date'])
    capacity = capacity[str(assets)].squeeze()
    capacity.index.name = 'DDate'
    capacity.name = 'Value'
    return capacity, meta_data


def melt_capacity(capacity: pd.DataFrame, meta_data: pd.DataFrame, region_exit, region_entry):
    column_names = ['RegionExit', 'RegionEntry', 'AssetName', 'Type', 'Market', 'Variable', 'CapacityType',
                    'PlannedType', 'Source', 'Units']

    static_frame = pd.DataFrame({col: [item] * len(capacity) for item, col in
                                 zip([region_exit, region_entry] + list(meta_data.iloc[:, 1]), column_names)})
    static_frame.index = capacity.index
    combined_frame = pd.concat([capacity.to_frame(), static_frame], axis=1)
    return combined_frame


def get_restricted_capacity(assets: int, variable: str, region_exit: str, region_entry: str):
    capacity, meta_data = get_raw_restricted_capacity(assets, variable)
    restricted_capacity = melt_capacity(capacity, meta_data, region_exit, region_entry)
    return restricted_capacity


OUTPUT_MAPPING = {
    'NO => BE': {'forwardFlow': [16], 'reverseFlow': [16]},
    'NO => DE': {'forwardFlow': [20, 264], 'reverseFlow': [20]},
    'NO => DK': {'forwardFlow': [3148], 'reverseFlow': []},
    'NO => FR': {'forwardFlow': [15], 'reverseFlow': []},
    'NO => GB': {'forwardFlow': [17, 18, 23], 'reverseFlow': []},
    'GB => BE': {'forwardFlow': [47], 'reverseFlow': [47]},
    'NL => GB': {'forwardFlow': [48], 'reverseFlow': [48]},
    'FR => ES': {'forwardFlow': [180], 'reverseFlow': [180]},
    'FR => CH': {'forwardFlow': [179, 176], 'reverseFlow': [176]},
    'CH => IT': {'forwardFlow': [1784], 'reverseFlow': [1784]},
}


def main():
    logging.info(f"Start of {__file__}")
    restricted_capacity_list = list()
    for pipe_key, pipe_data in OUTPUT_MAPPING.items():
        region_exit = pipe_key.split(' => ')[0]
        region_entry = pipe_key.split(' => ')[1]
        for flow in ['forwardFlow', 'reverseFlow']:
            for asset in pipe_data[flow]:
                restricted_capacity = get_restricted_capacity(asset, flow, region_exit, region_entry)
                restricted_capacity_list.append(restricted_capacity)
    restricted_capacity_frame = pd.concat(restricted_capacity_list)
    du.upload_to_database(restricted_capacity_frame, 'Upload_GAS_CommodityEssentialRestrictedCapacity-',
                          env=os.environ["environment"].upper(), index=True)
    logging.info(f"Upload complete")
    pass


if __name__ == '__main__':
    log = ag_log.get_log()
    ce = CElink.create_using_secret_client()
    logging.info(f"Created instance of CELink using SecretsClient")
    main()
    logging.info("Complete")
