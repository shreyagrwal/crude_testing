import os
import sys
import time
import shutil
import glob as gb
import pandas as pd
import xlwings as xw
from datetime import datetime

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment

market = ''
log = ag_log.get_log()

appDir = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\Scrapers\Trayport'
filename = 'Upload_GAS_TrayportTrades-'
AzurebulkUploaderFolder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\AzureDataUploader\GAS'
Azurefilename = 'GAS-trayport-TrayportTrades-'

csvFolder = se.ingestion_folder
os.chdir(appDir)

log.debug("Env:{0}".format(env))
log.debug("Data File Folder:{0}".format(csvFolder))

col_dict = {
    'Trade ID': 'TradeID',
    'Date/Time': 'TradeDateTime',
    'Broker Code': 'BrokerCode',
    'Paid/Given': 'PaidGiven',
    'EndDate': 'InitiatorTrader',
    'Initiator Trader': 'InitiatorTrader',
    'Initiator Action': 'InitiatorAction',
    'Initiator Company': 'InitiatorCompany',
    'Aggressor Action': 'AggressorAction',
    'Aggressor Company': 'AggressorCompany',
    'Aggressor Trader': 'AggressorTrader'
}


def remove_special_symbols(df_col):
    df_col = remo_spec_symb(df_col, "'")
    df_col = remo_spec_symb(df_col, '"')
    df_col = remo_spec_symb(df_col, ',')
    return df_col


def remo_spec_symb(df_col, symb):
    try:
        df_col = df_col.str.replace(symb, '')
    except:
        df_col = df_col
    return df_col


def obj_to_int(obj):
    if type(obj) == float:
        obj = str(int(obj))
    else:
        obj = str(obj)
    return obj


def get_yearly_contract(date):
    temp = datetime(1899, 12, 30)
    delta = date - temp
    return float(delta.days) + (float(delta.seconds)/86400)


def validate_month_contract(date_text):
    try:
        if date_text.date().year < 2000:
            # yearly contract rather than date
            date_text = int(get_yearly_contract(date_text))
        else:
            date_text = date_text.date()
    except:
        date_text = date_text
    return date_text


def scrape_trayport(wb, reportDate):
    try:
        sht = wb.sheets["Sheet1"]
        df = sht.range("A1:O120001").options(pd.DataFrame, index=False).value
    except:
        sht = wb.sheets["Sheet2"]
        df = sht.range("A1:O120001").options(pd.DataFrame, index=False).value

    df = df.rename(columns=col_dict)
    df = df.dropna(how='all')

    df['TradeID'] = df['TradeID'].apply(lambda x: obj_to_int(x))
    df['Period'] = df['Period'].apply(lambda x: validate_month_contract(x))

    if market != '':
        df = df[df['Product'].str.contains(market)]

    cols = ['TradeID', 'Venue', 'Product', 'BrokerCode', 'InitiatorTrader', 'InitiatorCompany', 'AggressorCompany', 'AggressorTrader']

    for col in cols:
        df[col] = remove_special_symbols(df[col])

    # filefullname = os.path.join(csvFolder, filename + str(reportDate) + market + ".csv")
    # df.to_csv(path_or_buf=filefullname, header=True, index=False)
    # print('Batchuploader File Exported.')
    # Azurefilefullname = os.path.join(AzurebulkUploaderFolder, Azurefilename + str(reportDate) + market + ".csv")
    # df.to_csv(path_or_buf=Azurefilefullname, header=True, index=False)
    # print('Azure Uploader File Exported.')
    su.upload_to_database(df, filename + str(reportDate) + market)


def scrape(appDir, file):
    app = xw.App(add_book=False, visible=False)
    app.display_alerts = False
    app.books.api.Open(appDir + "\\" + file, UpdateLinks=False)

    wb = app.books[0]
    strReportDate = file[-13:].strip(".xlsb")
    reportDate = datetime.strptime(strReportDate, '%Y%m%d').date()
    scrape_trayport(wb, strReportDate)

    wb.app.quit()
    app.quit()
    time.sleep(10)


for excel in gb.glob("*.xlsb"):
    print(excel)
    if not '~' in excel:
        try:
            if excel.find("Trayport") != -1:
                log.debug("Found a file to scrape: {0}".format(excel))
                scrape(appDir, excel)
                shutil.move(appDir + "\\" + excel, appDir + "\\archive\\" + excel)
            log.debug('File Completed: {0}.'.format(excel))
        except Exception as e:
            log.error(e)
            if xw:
                wb = xw.books[0]
                wb.app.quit()
            time.sleep(5)
            shutil.move(appDir + "\\" + excel, appDir + "\\error\\" + excel)
            exit(1)

