import logging
import os
import sys
from datetime import date
from typing import Optional

import dotenv
import pandas as pd
from ag_data_access import data_upload as du
from ag_log import ag_log

from src.gas.CEtools.CEtools import CElink

sys.path.append(os.getcwd())

ce: Optional[CElink] = None

as_of_date = date.today()
today_date_str = as_of_date.strftime("%Y-%m-%d")


def get_raw_capacity_bookings(assets: int, variable: str):
    meta_data = ce.eugascapbooking(assets=assets, variable=variable, getByCol=True, getDir=True, unit='mcm', meta=True)
    meta_data = meta_data.iloc[:, 2:]
    bookings = ce.eugascapbooking(assets=assets, variable=variable, getByCol=True, getDir=True, unit='mcm')
    bookings.rename(columns={bookings.columns[1]: 'PDate'}, inplace=True)
    bookings.index = bookings['PDate']
    bookings.index = pd.to_datetime(bookings.index)
    bookings = bookings.iloc[:, 2:]
    return bookings, meta_data


def melt_bookings(bookings: pd.DataFrame, meta_data: pd.DataFrame, region_exit, region_entry):
    column_names = ['RegionExit', 'RegionEntry', 'AssetName', 'Type', 'Market', 'Variable', 'CapacityType',
                    'BookingStatus', 'BookingTenure', 'BookingTSO', 'BookingDirection', 'Source', 'Units']

    combined_frames = list()
    for col_idx in range(len(meta_data.columns)):
        static_frame = pd.DataFrame(
            {col: [item] * len(bookings) for item, col in
             zip([region_exit, region_entry] + list(meta_data.iloc[:, col_idx].values.T), column_names)}
        )
        static_frame.index = bookings.index
        timeseries = bookings.iloc[:, col_idx]
        timeseries.name = 'Value'

        combined_frame = pd.concat([timeseries.to_frame(), static_frame], axis=1)
        combined_frames.append(combined_frame)

    return pd.concat(combined_frames)


def get_capacity_bookings(assets: int, variable: str, region_exit: str, region_entry: str):
    bookings, meta_data = get_raw_capacity_bookings(assets, variable)
    capacity_bookings = melt_bookings(bookings, meta_data, region_exit, region_entry)
    capacity_bookings['DDate'] = capacity_bookings.index
    capacity_bookings['PDate'] = today_date_str
    format_columns = [
        'PDate', 'DDate', 'Value', 'RegionExit', 'RegionEntry', 'AssetName', 'Type', 'Market',
        'Variable', 'CapacityType', 'BookingStatus', 'BookingTenure',
        'BookingTSO', 'BookingDirection', 'Source', 'Units'
    ]
    return capacity_bookings[format_columns]


def main():
    filename = 'Upload_GAS_CommodityEssential_IUK_CapacityBookings-'

    capacity_bookings = get_capacity_bookings(47, 'forwardFlow', 'GB', 'BE')
    # capacity_bookings.to_csv('output/IUKCapacityBookingsForwardFlowUKSide.csv')
    du.upload_to_database(capacity_bookings, filename + 'ForwardFlowUKSide-', env=os.environ["environment"].upper(),
                          index=False)

    capacity_bookings = get_capacity_bookings(2724, 'forwardFlow', 'GB', 'BE')
    # capacity_bookings.to_csv('output/IUKCapacityBookingsForwardFlowBelgiumSide.csv')
    du.upload_to_database(capacity_bookings, filename + 'ForwardFlowBelgiumSide-',
                          env=os.environ["environment"].upper(), index=False)

    capacity_bookings = get_capacity_bookings(47, 'reverseFlow', 'GB', 'BE')
    # capacity_bookings.to_csv('output/IUKCapacityBookingsReverseFlowUKSide.csv')
    du.upload_to_database(capacity_bookings, filename + 'ReverseFlowUKSide-', env=os.environ["environment"].upper(),
                          index=False)

    capacity_bookings = get_capacity_bookings(2724, 'reverseFlow', 'GB', 'BE')
    # capacity_bookings.to_csv('output/IUKCapacityBookingsReverseFlowBelgiumSide.csv')
    du.upload_to_database(capacity_bookings, filename + 'ReverseFlowBelgiumSide-',
                          env=os.environ["environment"].upper(), index=False)

    capacity_bookings = get_capacity_bookings(48, 'forwardFlow', 'NL', 'GB')
    du.upload_to_database(capacity_bookings, filename + 'ForwardFlowNL-GB-', env=os.environ["environment"].upper(),
                          index=False)

    capacity_bookings = get_capacity_bookings(48, 'reverseFlow', 'NL', 'GB')
    du.upload_to_database(capacity_bookings, filename + 'ReverseFlowNL-GB-', env=os.environ["environment"].upper(),
                          index=False)

    # BBL -> NL -> UK

    pass


if __name__ == '__main__':
    dotenv.load_dotenv(override=True)
    log = ag_log.get_log()
    ce = CElink.create_using_secret_client()
    logging.info(f"Created instance of CELink using SecretsClient")
    main()
    logging.info("Complete")
    pass
