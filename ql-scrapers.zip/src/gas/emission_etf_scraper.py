import os
import sys
import time
import random
import shutil
import argparse
import glob as gb
import pandas as pd
from selenium import webdriver
from datetime import datetime, date
from pandas.tseries.offsets import BDay

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment

backfill = False
as_of_date = date.today()

format_datetime = '%y%m%d%H%M%S'
appFolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\EmissionETF'
bulk_uploader_folder = se.ingestion_folder

if backfill:
    start_date = datetime(2023, 2, 10)
else:
    start_date = as_of_date - BDay(2)


def load_chrome_settings(downloadFolder):
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
    #     chrome_options.add_argument('--headless')  # Otherwise headless Chrome
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": downloadFolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")

    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser


def delete_temp_files(appFolder):
    for filename in os.listdir(appFolder):
        file_path = os.path.join(appFolder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))


def process_and_save(downloadFolder, excel, filename):
    pdate = datetime.strptime(excel[0:10], "%m_%d_%Y").date()
    df = pd.read_csv(os.path.join(downloadFolder, excel), lineterminator='\n', skiprows=1)
    df = df[['Rank', 'Company Name', '% of Net Assets', 'Ticker', 'Identifier', 'Type', 'Shares Held', 'Market Value($)', 'Notional Value($)']]
    df = df.rename(columns={'Company Name': 'Name',
                            '% of Net Assets': 'NetAssetPctg',
                            'Type': 'AssetType',
                            'Shares Held': 'Position',
                            'Market Value($)': 'MarketValue',
                            'Notional Value($)': 'NotionalValue'})
    df.columns = df.columns.str.replace(' ', '')
    df['Position'] = pd.to_numeric(df['Position'].apply(lambda x: x.replace(',', '')))
    df['MarketValue'] = pd.to_numeric(df['MarketValue'].apply(lambda x: x.replace(',', '')))
    df['NotionalValue'] = pd.to_numeric(df['NotionalValue'].apply(lambda x: x.replace(',', '')))
    df = df.replace('–', '')
    df['Ticker'] = df['Ticker'].apply(lambda x: str(x).replace('CTIZ', 'ZCAZ').replace('LUDZ', 'ZCAZ').replace('WQCZ', 'ZRDZ'))
    df['Currency'] = 'USD'
    df['Pdate'] = pdate

    # Upload file to database
    su.upload_to_database(df, filename)
    log.debug("File Exported:" + os.path.join(se.ingestion_folder, filename + pdate.strftime('%y%m%d%H%M%S') + '.csv'))
    time.sleep(1)


def main(argv):
    try:
        log.debug("Env:" + env)
        parser = argparse.ArgumentParser()
        parser.add_argument('-etfticker', action='store', dest='etfticker', default='none', help='select etf ticker: krbn or keua')
        args = parser.parse_args(argv)
        etf_ticker = args.etfticker

        if etf_ticker == 'none':
            log.debug('ETF ticker input required, Python script stopped.')
            exit(1)
        else:
            filename = 'Upload_Gas_CarbonETF' + etf_ticker + '-'
            log.debug("ETF Ticker:" + etf_ticker.upper())

        # Initiate Chrome Driver
        log.debug("Initialising Chrome.")
        downloadFolder = os.path.join(appFolder, '_download', etf_ticker)
        browser = load_chrome_settings(downloadFolder)

        # Calculate list of dates
        list_of_dates = pd.date_range(start_date, as_of_date, freq=BDay()).tolist()
        print(list_of_dates)

        # Remove Temp File
        delete_temp_files(downloadFolder)

        # Scraping CSV files.
        log.debug("Scraping CSV files...")
        for date in list_of_dates:
            log.debug("Get CSV file: " + date.strftime("%Y-%m-%d"))
            url_csv = 'https://kraneshares.com/csv/' + date.strftime("%m_%d_%Y") + '_' + etf_ticker + '_holdings.csv'
            log.debug("File url: " + url_csv)
            browser.get(url_csv)
            time.sleep(random.uniform(5, 10))

        # Close and quit chrome webdriver
        browser.close()
        browser.quit()

        # Process the downloaded files
        log.error("Time log: " + datetime.today().strftime("%m_%d_%Y"))
        log.debug("Process Downloaded Data Files.")
        os.chdir(downloadFolder)
        file_list = gb.glob("*.csv")
        for excel in file_list:
            if not '~' in excel:
                log.debug("Processing File: " + excel)
                try:
                    process_and_save(downloadFolder, excel, filename)
                except Exception as e:
                    log.error(e)
                time.sleep(1)
        log.debug("Data Files Process Completed.")
        return 0

    except Exception as e:
        log.error(e)
        log.debug("Scraper stopped with error.")
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main(sys.argv[1:]))
