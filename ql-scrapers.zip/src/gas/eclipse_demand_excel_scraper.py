import os
import sys

sys.path.append(os.getcwd())
import time
import glob as gb
import numpy as np
import pandas as pd
from os import path
from datetime import datetime

from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
log = ag_log.get_log()

appDir = r'\\petroineos.local\dfs\Department Shared Folders\~Gas Power and Emission Department\Weather\eclipse_'
days_back = 42

log.debug("Env:"+env)
csvFolder = se.ingestion_folder
os.chdir(appDir)
log.debug("Data File Folder:{0}".format(csvFolder))
log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

excel_json = {
           "eclipse_austria_country_overview_apr2015.xlsx":[
              {
                 "region": "Austria",
                 "page":  "Sheet1",
                 "usecols":  "A:T",
                 "skiprows":  0
              }
           ],
           "eclipse_baltics_country_overview_apr2015.xlsx":[
              {
                 "region": "Poland",
                 "page":  "poland",
                 "usecols":  "A:AD",
                 "skiprows":  0
              },
              {
                 "region": "Estonia",
                 "page":  "estonia",
                 "usecols":  "A:I",
                 "skiprows":  0
              },
              {
                 "region": "Lithuania",
                 "page":  "lithuania",
                 "usecols":  "A:D",
                 "skiprows":  0
              },
              {
                 "region": "Finland",
                 "page":  "finland",
                 "usecols":  "A:C",
                 "skiprows":  0
              }
           ],
           "eclipse_belgium_country_overview_apr2015.xlsx":[
              {
                 "region": "Belgium",
                 "page":  "from 2015",
                 "usecols":  "A:AB",
                 "skiprows":  6
              }
           ],
           "eclipse_czech_country_overview_apr2015.xlsx":[
              {
                 "region": "Czech",
                 "page":  "Sheet1",
                 "usecols":  "A:O",
                 "skiprows":  0
              }
           ],
           "eclipse_denmark_country_overview_apr2015.xlsx":[
              {
                 "region": "Denmark",
                 "page":  "Sheet1",
                 "usecols":  "A:G",
                 "skiprows":  0
              }
           ],
           "eclipse_france_country_overview_apr2015.xlsx":[
              {
                 "region": "France",
                 "page":  "download",
                 "usecols":  "A:AO",
                 "skiprows":  0
              }
           ],
           "eclipse_germany_country_overview_apr2015.xlsx":[
              {
                 "region": "Germany",
                 "page":  "download",
                 "usecols":  "A:EN",
                 "skiprows":  0
              }
           ],
           "eclipse_hungary&slovenia_country_overview_apr2015.xlsx":[
              {
                 "region": "Hungary",
                 "page":  "Hungary",
                 "usecols":  "A:K",
                 "skiprows":  0
              },
              {
                 "region": "Slovenia",
                 "page":  "Slovenia",
                 "usecols":  "A:E",
                 "skiprows":  0
              }
           ],
           "eclipse_italy_country_overview_apr2015.xlsx":[
              {
                 "region": "Italy",
                 "page":  "download",
                 "usecols":  "A:W",
                 "skiprows":  0
              }
           ],
           "eclipse_netherlands_country_overview_apr2015.xlsx":[
              {
                 "region": "Netherlands",
                 "page":  "data",
                 "usecols":  "A:AX",
                 "skiprows":  0
              }
           ],
           "eclipse_norway_country_overview_apr2015.xlsx":[
              {
                 "region": "Norway",
                 "page":  "Sheet1",
                 "usecols":  "A:P",
                 "skiprows":  0
              }
           ],
           "eclipse_SEEurope_country_overview_apr2015.xlsx":[
              {
                 "region": "Turkey",
                 "page":  "turkey",
                 "usecols":  "A:V",
                 "skiprows":  0
              },
              {
                 "region": "Greece",
                 "page":  "greece",
                 "usecols":  "A:D",
                 "skiprows":  0
              },
              {
                 "region": "Bulgaria",
                 "page":  "bulgaria",
                 "usecols":  "A:M",
                 "skiprows":  0
              },
              {
                 "region": "Romania",
                 "page":  "romania",
                 "usecols":  "A:V",
                 "skiprows":  0
              }
           ],
           "eclipse_slovakia_country_overview_apr2015.xlsx":[
              {
                 "region": "Slovakia",
                 "page":  "Sheet1",
                 "usecols":  "A:K",
                 "skiprows":  0
              }
           ],
           "eclipse_spain_country_overview_apr2015.xlsx":[
              {
                 "region": "Spain",
                 "page":  "Sheet1",
                 "usecols":  "A:R",
                 "skiprows":  0
              }
           ],
           "eclipse_ukraine_country_overview_apr2015.xlsx":[
              {
                 "region": "Ukraine",
                 "page":  "download",
                 "usecols":  "A:AA",
                 "skiprows":  0
              }
           ],
           "eclipse_ukraine_imports_jan2019.xlsx":[
              {
                 "region": "Ukraine Imports",
                 "page":  "download",
                 "usecols":  "A:Z",
                 "skiprows":  0
              }
           ],
           "eclipse_ukraine_nominations_oct18.xlsx":[
              {
                 "region": "Ukraine Nominations",
                 "page":  "Sheet1",
                 "usecols":  "A:G",
                 "skiprows":  0
              }
           ],
           "eclipse_uk_country_overview_apr2015.xlsx":[
              {
                 "region": "United Kingdom",
                 "page":  "download",
                 "usecols":  "A:DN",
                 "skiprows":  0
              }
           ]
        }


def scrape(appDir, excel, region, page, usecols, skiprows, nomination_ticker):
    if not nomination_ticker:
        df = pd.read_excel(path.join(appDir, excel), header=list(range(0, 7)) + list(range(8, 12)), sheet_name=page, skiprows=skiprows, usecols=usecols).dropna(how='all')

        df = df.loc['2018-01-01':]
        df = df.stack(list(range(0, 11))).reset_index()
        df = df.replace('Unnamed:.*$', np.nan, regex=True)
        cols = ['DDate', 'MainFlowType', 'SecondaryFlowType', 'DetailedFlowType', 'FromCountry', 'ToSystemOperator',
                'FromSystemOperator', 'Location', 'GasType', 'Source', 'Direction', 'UnitMeasure', 'Value']
        df.columns = cols
        df['PDate'] = datetime.fromtimestamp(os.path.getmtime(path.join(appDir, excel)))
        df['PDate'] = df['PDate'].dt.round('1d')
        df['Region'] = region
        df['ToCountry'] = ''
        df['Summable'] = ''
        df['Nomination'] = ''
    else:
        df = pd.read_excel(path.join(appDir, excel), header=list(range(0, 8)) + list(range(9, 15)), sheet_name=page, skiprows=skiprows, usecols=usecols).dropna(how='all')
        df = df.loc['2018-01-01':'2020-01-01']
        df = df.stack(list(range(0, 14))).reset_index()
        df = df.replace('Unnamed:.*$', np.nan, regex=True)
        cols = ['DDate', 'MainFlowType', 'SecondaryFlowType', 'DetailedFlowType', 'FromCountry', 'FromSystemOperator',
                'ToCountry', 'ToSystemOperator', 'Location', 'GasType', 'Source', 'Summable', 'Direction',
                'UnitMeasure', 'Nomination', 'Value']
        df.columns = cols
        df['PDate'] = datetime.fromtimestamp(os.path.getmtime(path.join(appDir, excel)))
        df['PDate'] = df['PDate'].dt.round('1d')
        df['Region'] = region

    filename = 'Upload_GAS_ActualDemandEclipse-'
    su.upload_to_database(df, filename)

    filefullname = path.join(csvFolder, filename + datetime.today().strftime('%y%m%d%H%M%S') + '.csv')
    log.debug("CSV File Saved to: {0}.".format(filefullname))


for excel in gb.glob("*.xlsx"):
    if not '~' in excel:
        if excel.find("eclipse_") == 0:
            log.debug("File Processing:{0}".format(excel))
            excel_params = excel_json[excel]
            for excel_param in excel_params:
                region = excel_param['region']
                page = excel_param['page']
                usecols = excel_param['usecols']
                skiprows = excel_param['skiprows']
                log.debug("Region Processing: {0}".format(region))
                if excel == 'eclipse_ukraine_nominations_oct18.xlsx':
                    nomination_ticker = True
                else:
                    nomination_ticker = False

                scrape(appDir, excel, region, page, usecols, skiprows, nomination_ticker)
                log.debug("Region Processing: {0} Completed.".format(region))
                time.sleep(1)
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
