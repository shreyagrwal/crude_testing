import os
import sys
import time
from pathlib import Path
from datetime import datetime
from selenium import webdriver

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se


url_cftc = 'https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm'
ArchiveFolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\CFTC'
format_date = '%Y-%m-%d'
dict_html_urls = {
    'Current Disaggregated Reports': {
        'Agriculture':
            [
                'https://www.cftc.gov/dea/futures/ag_lf.htm',
                'https://www.cftc.gov/dea/futures/ag_sf.htm',
                'https://www.cftc.gov/dea/options/ag_lof.htm',
                'https://www.cftc.gov/dea/options/ag_sof.htm'
            ],
        'Petroleum and Products':
            [
                'https://www.cftc.gov/dea/futures/petroleum_lf.htm',
                'https://www.cftc.gov/dea/futures/petroleum_sf.htm',
                'https://www.cftc.gov/dea/options/petroleum_lof.htm',
                'https://www.cftc.gov/dea/options/petroleum_sof.htm'
            ],
        'Natural Gas and Products':
            [
                'https://www.cftc.gov/dea/futures/nat_gas_lf.htm',
                'https://www.cftc.gov/dea/futures/nat_gas_sf.htm',
                'https://www.cftc.gov/dea/options/nat_gas_lof.htm',
                'https://www.cftc.gov/dea/options/nat_gas_sof.htm'
            ],
        'Electricity':
            [
                'https://www.cftc.gov/dea/futures/electricity_lf.htm',
                'https://www.cftc.gov/dea/futures/electricity_sf.htm',
                'https://www.cftc.gov/dea/options/electricity_lof.htm',
                'https://www.cftc.gov/dea/options/electricity_sof.htm'
            ],
        'Metals and Other':
            [
                'https://www.cftc.gov/dea/futures/other_lf.htm',
                'https://www.cftc.gov/dea/futures/other_sf.htm',
                'https://www.cftc.gov/dea/options/other_lof.htm',
                'https://www.cftc.gov/dea/options/other_sof.htm'
            ]
        },
    'Current Traders in Financial Futures Reports':
        {
            'Financial':
                [
                    'https://www.cftc.gov/dea/futures/financial_lf.htm',
                    'https://www.cftc.gov/dea/options/financial_lof.htm'
                ]
        },
    'Current Legacy Reports':
        {
            'Chicago Board of Trade':
                [
                    'https://www.cftc.gov/dea/futures/deacbtlf.htm',
                    'https://www.cftc.gov/dea/futures/deacbtsf.htm',
                    'https://www.cftc.gov/dea/options/deacbtlof.htm',
                    'https://www.cftc.gov/dea/options/deacbtsof.htm'
                ],
            'Chicago Mercantile Exchange':
                [
                    'https://www.cftc.gov/dea/futures/deacmelf.htm',
                    'https://www.cftc.gov/dea/futures/deacmesf.htm',
                    'https://www.cftc.gov/dea/options/deacmelof.htm',
                    'https://www.cftc.gov/dea/options/deacmesof.htm'
                ],
            'Chicago Board Options Exchange':
                [
                    'https://www.cftc.gov/dea/futures/deacboelf.htm',
                    'https://www.cftc.gov/dea/futures/deacboesf.htm',
                    'https://www.cftc.gov/dea/options/deacboelof.htm',
                    'https://www.cftc.gov/dea/options/deacboesof.htm'
                ],
            'Minneapolis Grain Exchange':
                [
                    'https://www.cftc.gov/dea/futures/deamgelf.htm',
                    'https://www.cftc.gov/dea/futures/deamgesf.htm',
                    'https://www.cftc.gov/dea/options/deamgelof.htm',
                    'https://www.cftc.gov/dea/options/deamgesof.htm'
                ],
            'Commodity Exchange Incorporated':
                [
                    'https://www.cftc.gov/dea/futures/deacmxlf.htm',
                    'https://www.cftc.gov/dea/futures/deacmxsf.htm',
                    'https://www.cftc.gov/dea/options/deacmxlof.htm',
                    'https://www.cftc.gov/dea/options/deacmxsof.htm'
                ],
            'ICE Futures U.S.':
                [
                    'https://www.cftc.gov/dea/futures/deanybtlf.htm',
                    'https://www.cftc.gov/dea/futures/deanybtsf.htm',
                    'https://www.cftc.gov/dea/options/deanybtlof.htm',
                    'https://www.cftc.gov/dea/options/deanybtsof.htm'
                ],
            'ICE Futures Europe':
                [
                    'https://www.cftc.gov/dea/futures/deaiceulf.htm',
                    'https://www.cftc.gov/dea/futures/deaiceusf.htm',
                    'https://www.cftc.gov/dea/options/deaiceulof.htm',
                    'https://www.cftc.gov/dea/options/deaiceusof.htm'
                ],
            'ICE - Futures Energy':
                [
                    'https://www.cftc.gov/dea/futures/deaifedlf.htm',
                    'https://www.cftc.gov/dea/futures/deaifedsf.htm',
                    'https://www.cftc.gov/dea/options/deaifedlof.htm',
                    'https://www.cftc.gov/dea/options/deaifedsof.htm'
                ],
            'New York Mercantile Exchange':
                [
                    'https://www.cftc.gov/dea/futures/deanymelf.htm',
                    'https://www.cftc.gov/dea/futures/deanymesf.htm',
                    'https://www.cftc.gov/dea/options/deanymelof.htm',
                    'https://www.cftc.gov/dea/options/deanymesof.htm'
                ],
            'NODAL Exchange':
                [
                    'https://www.cftc.gov/dea/futures/deanodxlf.htm',
                    'https://www.cftc.gov/dea/futures/deanodxsf.htm',
                    'https://www.cftc.gov/dea/options/deanodxlof.htm',
                    'https://www.cftc.gov/dea/options/deanodxsof.htm'
                ],
            'Supplemental Commodity Index':
                [
                    'https://www.cftc.gov/dea/options/deaviewcit.htm'
                ]
        },
    }

dict_txt_urls = {'Other Available Formats':
                 {'Futures-Only Commitments of Traders Comma Delimited':
                      ['https://www.cftc.gov/dea/newcot/deafut.txt'],
                    'Options and Futures Commitments of Traders Comma Delimited':
                      ['https://www.cftc.gov/dea/newcot/deacom.txt'],
                    'Supplement: Commodity Index Report Comma Delimited':
                      ['https://www.cftc.gov/dea/newcot/deacit.txt'],
                  },
             }


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    # Debug mode disabled
    # if sys.gettrace() is None:  # Check if it's in Debug model
        # chrome_options.add_argument('--headless')
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": r"c:\temp\\",
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)
    return browser


def get_timestamp(browser):
    # //*[@id="content-container"]/section/div/article/div/div/h3[2]/strong
    # /html/body/div[2]/div/div/section/div/article/div/div/div/h3[3]
    # //*[@id="content-container"]/section/div/article/div/div/div/h3[3]/strong
    try:
        timestamp_new = browser.find_element('xpath',  '//*[@id="content-container"]/section/div/article/div/div/div/h3[3]/strong').get_attribute("innerHTML")
    except Exception as e:
        timestamp_new = browser.find_element('xpath', '//*[@id="content-container"]/section/div/article/div/div/h3[2]/strong').get_attribute("innerHTML")
    timestamp_new = timestamp_new.replace('Reports Dated ', '').replace('&nbsp;', ' ').split(' -')[0]
    timestamp_new = datetime.strptime(timestamp_new, '%B %d, %Y')
    time.sleep(5)
    return timestamp_new


def managefolders(folder):
    if not os.path.exists(folder):
        os.makedirs(folder)


def save_timestamp(timestamp_output, timestamp_path):
    timestamp_file = open(timestamp_path, "w")
    toFile = str(timestamp_output)
    timestamp_file.write(toFile)
    timestamp_file.close()
    log.debug("Timestamp saved")


def main():
    try:
        log.debug("Initiate Chrome Driver.")
        browser = load_chrome_settings()

        log.debug("Get the latest Timestamp.")
        browser.get(url_cftc)
        timestamp_new = get_timestamp(browser)

        log.debug("Compare with timestamp in temp file.")
        timestamp_path = os.path.join(ArchiveFolder, 'timestamp.txt')
        my_file = Path(timestamp_path)
        if my_file.is_file():
            log.debug('Timestamp file found, start to compare')
            timestamp_output_existing = open(timestamp_path, "r").read()

            if str(timestamp_new) == timestamp_output_existing:
                log.debug('No new update found, scraper stops')
                browser.close()
                browser.quit()
                return 0

            log.debug('New update detected, start to download the files')
            log.debug('Timestamp: ' + str(timestamp_new))
        else:
            log.debug('No timestamp file found, start to download the files')
            log.debug('Timestamp: ' + str(timestamp_new))

        log.debug("Archive CFTC Reports - HTML.")
        for report_type, values in dict_html_urls.items():
            log.info(report_type)
            dict_report = dict_html_urls[report_type]
            for category, values in dict_report.items():
                log.info('  ' + category)
                list_of_report = dict_report[category]
                print(list_of_report)
                for url in list_of_report:
                    log.info('  ' + url)
                    browser.get(url)
                    html_name = url.split('/')[-1]
                    archive_link = os.path.join(ArchiveFolder, timestamp_new.strftime(format_date), report_type, category)
                    managefolders(archive_link)
                    with open(os.path.join(archive_link, html_name), 'w+') as f:
                        f.write(browser.page_source)

        log.debug("Archive CFTC Reports - Other Available Formats.")
        for report_type, values in dict_txt_urls.items():
            log.info(report_type)
            dict_txt = dict_txt_urls[report_type]
            for category, values in dict_txt.items():
                log.info('  ' + category)
                list_of_report = dict_txt[category]
                for url in list_of_report:
                    log.info('  ' + url)
                    browser.get(url)
                    html_name = url.split('/')[-1]
                    archive_link = os.path.join(ArchiveFolder, timestamp_new.strftime(format_date), report_type, category).replace(':', '')
                    managefolders(archive_link)
                    with open(os.path.join(archive_link, html_name), 'w+') as f:
                        f.write(browser.page_source)

        # close and close chrone webdriver
        browser.close()
        browser.quit()

        log.debug("Save the Latest timestamp.")
        save_timestamp(timestamp_new, timestamp_path)

        # Finishing the Job
        log.debug("CFTC reports archived.")
        return 0
    except Exception as e:
        log.error(e)
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())

