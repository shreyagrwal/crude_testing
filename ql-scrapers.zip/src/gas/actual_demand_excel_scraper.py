import os
import sys
sys.path.append(os.getcwd())
import pandas as pd
from datetime import datetime
from os import path
from ag_log import ag_log
from scraper_utils import scraper_environment as se
from scraper_utils import scraper_upload as su


def scrape_and_upload():
    global filename, df
    files = []
    appDir = r'\\petroineos.local\dfs\Department Shared Folders\~Gas Power and Emission Department\Weather'
    filename = 'Upload_GAS_ActualDemand-'
    filename_prefix = filename
    log.debug("Env:" + env)
    log.debug("Data File Folder:{0}".format(upload_folder))
    df = pd.read_excel(path.join(appDir, 'EU_Temperature_Forecasts.xlsm'), sheet_name='Actual_Demand', skiprows=1, nrows=(3000-1), usecols='A:J').dropna(subset=['Date'])
    log.debug("File Processing:{0}".format('EU_Temperature_Forecasts.xlsm'))
    df = pd.melt(df, id_vars='Date', value_vars=df.columns[1:]).dropna()
    df.columns = ['Date', 'Region', 'Value']
    filename = path.join(upload_folder, filename + datetime.today().strftime('%y%m%d%H%M%S') + '.csv')
    files.append(filename)
    su.upload_to_database(df, filename_prefix)


if __name__ == '__main__':
    env = se.environment
    upload_folder = se.ingestion_folder
    log = ag_log.get_log()
    scrape_and_upload()
    log.debug("CSV File Saved to: {0}".format(filename))
    log.debug('Job Completed.')
