import logging
import os
from typing import Optional

import dotenv

import pandas as pd
from ag_log import ag_log
from src.gas.CEtools.CEtools import CElink
from ag_data_access import data_upload as du

dotenv.load_dotenv(override=True)
ce: Optional[CElink] = None


def get_raw_capacity_flows(series_id: int):
    meta_data = ce.eugasseries(id=series_id, meta=True)
    meta_data = meta_data[['seriesId', str(series_id)]]
    capacity = ce.eugasseries(id=series_id)
    capacity.rename(columns={capacity.columns[1]: 'Date'}, inplace=True)
    capacity.index = pd.to_datetime(capacity['Date'])
    capacity = capacity[str(series_id)].squeeze()
    capacity.index.name = 'DDate'
    capacity.name = 'Value'
    return capacity, meta_data


def melt_capacity(capacity: pd.DataFrame, meta_data: pd.DataFrame, region_exit, region_entry):
    column_names = ['RegionExit', 'RegionEntry', 'Name', 'AssetId', 'Type', 'Subtype', 'Level', 'Direction', 'Source',
                    'Variable', 'Status', 'Units']
    static_frame = pd.DataFrame({col: [item] * len(capacity) for item, col in
                                 zip([region_exit, region_entry] + list(meta_data.iloc[:, 1]), column_names)})
    static_frame.index = capacity.index
    combined_frame = pd.concat([capacity.to_frame(), static_frame], axis=1)
    return combined_frame


def get_capacity_flows(series_id: int, region_exit: str, region_entry: str):
    capacity, meta_data = get_raw_capacity_flows(series_id)
    capacity_flows = melt_capacity(capacity, meta_data, region_exit, region_entry)
    return capacity_flows


OUTPUT_MAPPING = {
    'FR => NO': [23854],
    'BE => NO': [23857],
    'NL => NO': [23865],
    'DE => NO': [23862],
    'GB => NO': [23859],
    'DK => NO': [60328],
    'ALL => NO': [23868],
}


def main():
    capacity_flows_list = list()
    for region, series_ids in OUTPUT_MAPPING.items():
        region_exit = region.split(' => ')[0]
        region_entry = region.split(' => ')[1]
        for series_id in series_ids:
            capacity_flows = get_capacity_flows(series_id, region_exit, region_entry)
            capacity_flows_list.append(capacity_flows)
    capacity_flows_frame = pd.concat(capacity_flows_list)
    du.upload_to_database(capacity_flows_frame, 'Upload_GAS_CommodityEssentialCapacityFlows-',
                          env=os.environ["environment"].upper(), index=True)
    logging.info(f"Upload complete")
    pass


if __name__ == '__main__':
    log = ag_log.get_log()
    ce = CElink.create_using_secret_client()
    logging.info(f"Created instance of CELink using SecretsClient")
    main()
    logging.info("Complete")
