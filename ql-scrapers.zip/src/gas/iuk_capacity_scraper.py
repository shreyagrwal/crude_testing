import os
import sys
import time
import shutil
import pandas as pd
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment

temp_filename = 'FlowsCapacity.csv'
format_datetime = '%y%m%d%H%M%S'

url = 'https://gasdata.iuk.gsmartsuite.com'
end_date = datetime(datetime.today().year + 2, 12, 31).strftime('%d/%m/%Y')

filename = 'Upload_Gas_IUKCapacityDaily' + '-'
filenamelatest = 'Upload_Gas_IUKCapacityDailyLatest' + '-'
temp_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\IUKCapacity\download'
bulk_uploader_folder = se.ingestion_folder


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
    #     chrome_options.add_argument('--headless')  # Otherwise headless Chrome
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": temp_path,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser


def rebuild_download_folder(temp_path):
    if os.path.exists(temp_path):
        shutil.rmtree(temp_path)
        time.sleep(2)
        os.makedirs(temp_path)
    else:
        os.makedirs(temp_path)


def get_capacity_file(browser, url, end_date):
    browser.get(url)

    # Go to Capacity Flow page
    transmission_button = browser.find_element('xpath', '//*[@id="nav"]/ul/li/a')
    transmission_button.click()
    time.sleep(2)

    menu_button = browser.find_element('xpath', '//*[@id="side-nav"]/div/div[2]/a')
    menu_button.click()
    time.sleep(2)

    iuk_button = browser.find_element('xpath', '//*[@id="side-nav"]/div/div[1]/div[1]/header/a')
    iuk_button.click()
    time.sleep(2)

    capacity_button = browser.find_element('xpath', '//*[@id="main-content"]/table/tbody/tr[1]/td[1]/section/article/h2')
    capacity_button.click()
    time.sleep(2)

    # setup download parameter:
    select_all_button = browser.find_element('xpath', '//*[@id="SelectAllAnchor"]')
    select_all_button.click()
    time.sleep(1)

    # clear date field
    browser.find_element('xpath', '//*[@id="ctl00_ctl00_Content_ChildContentLeft_PeriodControl_PeriodToDatePicker"]').clear()

    # Date input Method 1
    browser.find_element('xpath', '//*[@id="ctl00_ctl00_Content_ChildContentLeft_PeriodControl_PeriodToDatePicker"]').send_keys(end_date)
    time.sleep(1)

    time_done_button = browser.find_element('xpath', '//*[@id="ui-datepicker-div"]/div[2]/button[2]')
    time_done_button.click()
    time.sleep(1)

    browser.find_element(By.CSS_SELECTOR, "input[type='radio'][value='D']").click()
    time.sleep(1)

    load_data_button = browser.find_element('xpath', '//*[@id="ctl00_ctl00_Content_LoadDataButton1"]')
    load_data_button.click()
    time.sleep(30)

    file_save_button = browser.find_element('xpath', '//*[@id="ctl00_ctl00_Content_ReportViewerControl_ctl05_ctl04_ctl00_ButtonImg"]')
    file_save_button.click()
    time.sleep(2)

    save_csv_button = browser.find_element('xpath', '//*[@id="ctl00_ctl00_Content_ReportViewerControl_ctl05_ctl04_ctl00_Menu"]/div[7]/a')
    save_csv_button.click()
    time.sleep(30)
    log.debug("Temp CSV File Downloaded.")


def import_temp_file(temp_path, temp_filename):
    temp_file = os.path.join(temp_path, temp_filename)
    df = pd.read_csv(temp_file)
    df['GasDays'] = pd.to_datetime(df['GasDays'], format='%d/%m/%Y', dayfirst=True).map(lambda x: x.strftime("%Y-%m-%d"))
    df = df[df['Category_Amount'].notnull()]
    df['Category_Amount'] = df['Category_Amount'].str.replace(' ', '').replace(' ', '')
    df['Category_Amount'] = df['Category_Amount'].apply(lambda x: float(x.replace('\xa0', '')))
    df['pdate'] = datetime.today().strftime('%Y-%m-%d')
    return df


def main():
    log.debug("Env:" + env)
    scrapenew = True
    log.debug("Scrape New: {0}.".format(scrapenew))

    if scrapenew:
        log.debug("Start to Scrape New File.")
        rebuild_download_folder(temp_path)
        log.debug("Initialising Chrome.")
    # Initiate Chrome Driver
        browser = load_chrome_settings()

        try:
            log.debug("Getting capacity data.")
            # Start Scraping
            get_capacity_file(browser, url, end_date)

        except:
            log.error(sys.exc_info()[0])

        # close and close chrone webdriver
        browser.close()
        browser.quit()
    else:
        log.debug("Scraping Skipped.")

    # Read into DataFrame
    log.debug("Reading Temp File into DataFrame.")
    df = import_temp_file(temp_path, temp_filename)

    # Export to BatchUploader
    log.debug("Exporting DataFrame to BatchUploader.")
    su.upload_to_database(df, filename)
    su.upload_to_database(df, filenamelatest)


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())
