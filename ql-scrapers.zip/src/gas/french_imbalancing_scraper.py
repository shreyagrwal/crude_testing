import os
import sys
import time
import shutil
import zipfile
import glob as gb
import pandas as pd
from selenium import webdriver
from datetime import datetime, timedelta, date

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder

login_email = 'bingye.wu@petroineos.com'
login_password = 'PePower666!'

backfill = False
format_datetime = '%y%m%d%H%M%S'
_today = date.today()

url_login = 'https://www.services-rte.com/en/home.html'
url_price = 'https://www.services-rte.com/en/download-data-published-by-rte.html?category=market&type=balancing_energy&subType=prices'
url_isp = 'https://www.services-rte.com/en/download-data-published-by-rte.html?category=market&type=balancing_energy&subType=imbalance_data'

srt_year_price = 2016
srt_year_isp = 2003

yrs_price = _today.year - srt_year_price + 1 if backfill==True else 1
yrs_isp = _today.year - srt_year_isp + 1 if backfill==True else 1

dict_isp = {
    'dates': 'Ddate',
    'Heure de dÃ©but': 'PeriodStart',
    'Heure de fin': 'PeriodEnd',
    'DÃ©sÃ©quilibre(MWh)': 'Imbalance',
    'Informations par pas demi-horaires': 'ImbalanceHalfHour',
    'Prix de RÃ¨glements des Ecarts NÃ©gatifs (Euros/MWh)': 'PositiveSettlementPrice',
    'Prix de RÃ¨glements des Ecarts Positifs (Euros/MWh)': 'NegativeSettlementPrice'
}

appFolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\RTE'
bulkUploaderFolder = se.ingestion_folder
filename_isp = 'Upload_Gas_rteFrenchImbalancePrice-'


def load_chrome_settings(folder):
    chrome_options = webdriver.ChromeOptions()
    # Debug mode disabled
    # if sys.gettrace() is None:  # Check if it's in Debug model
    #     chrome_options.add_argument('--headless')
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": folder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser


def delete_temp_files(appFolder):
    for filename in os.listdir(appFolder):
        file_path = os.path.join(appFolder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            log.error('Failed to delete %s. Reason: %s' % (file_path, e))


def download_data(url, yrs, folder):
    temp_folder = os.path.join(appFolder, folder)
    delete_temp_files(temp_folder)
    # Initiate Chrome Driver
    log.debug("Initiate Chrome Driver.")
    browser = load_chrome_settings(temp_folder)
    log.debug("Try to Login...")
    try:
        browser.get(url_login)
        time.sleep(2)
        browser.find_element('xpath', '/html/body/div/header/div[2]/div[1]/div[3]/div[2]/button/span[2]').click()
        time.sleep(2)
        username = browser.find_element('xpath', '//*[@id="username"]')
        password = browser.find_element('xpath', '//*[@id="password"]')
        username.send_keys(login_email)
        password.send_keys(login_password)
        browser.find_element('xpath', '//*[@id="main-header"]/login-register/div/div/div[1]/form/rte-button/button/span/span[2]').click()
    except:
        log.debug('No login required. Scraper Continue.')
    time.sleep(2)
    browser.get(url)
    time.sleep(2)
    try:
        browser.find_element('xpath', '/html/body/div/rte-cookie-consent-banner/div[1]/div/button[3]').click()
    except:
        log.debug('No cookies required.')
    time.sleep(2)
    for i in range(1, yrs + 1):
        print('Year ' + str(_today.year - i + 1))
        url = '//*[@id="wrapper"]/div/div/div[1]/div[3]/rte-history-data-management/ng-include/div/div/rte-data-table/ng-transclude/rte-row-card[' + str(
            i) + ']/div/div[2]/div[2]/rte-button/button/span/span/span'
        browser.find_element('xpath', url).click()
        time.sleep(10)
    browser.get(url_isp)
    time.sleep(2)
    # close and close chrone webdriver
    browser.close()
    browser.quit()


def unzipall():
    os.chdir(os.path.join(appFolder, 'pricezips'))
    for f in gb.glob("*.zip"):
        try:
            log.debug("Try to unzip file: " + f)
            unzip(os.path.join(appFolder, 'pricezips'), f, os.path.join(appFolder, 'price'))
            shutil.move(appFolder + "\\pricezips\\" + f, appFolder + "\\ZipArchive\\" + f)
            log.debug('Upzip OK.')
        except Exception as e:
            log.debug(e)
            shutil.move(appFolder + "\\pricezips\\" + f, appFolder + "\\Error\\" + f)
            log.debug("Upzip Failed, File {} Moved to Error Folder.".format(f))


def unzip(sfolder, filename, dfolder):
    if os.path.isfile(os.path.join(sfolder, filename)):
        if filename.endswith(".zip"):
            with zipfile.ZipFile(os.path.join(sfolder, filename), 'r') as zip_ref:
                zip_ref.extractall(dfolder)
            log.debug("unzip file {} complete".format(filename))
        else:
            log.debug("No .zip file found")


def remove_outliner(df, outliner):
    df = df.reset_index(drop=True)
    try:
        row = df.ix[df["dates"].str.startswith(outliner)].index.tolist()
        df = df.drop(df.index[row])
    except Exception as e:
        log.debug(e)
        pass
    return df


def scrape_price(file):

    df = pd.read_csv(file, encoding="ISO-8859-1", engine='python', skiprows=5, sep='\t', index_col=False)
    ur_row1 = df.ix[df["Heure de début"] == 'N/A : Valeurs non disponibles'].index.tolist()
    ur_row2 = df.ix[df["Heure de début"].str.startswith('Données mises')].index.tolist()


def scrape_isp(file):
    if int(file.split('.csv')[0][-4:]) > 2016:
        df = pd.read_csv(file, encoding="ISO-8859-1", engine='python', skiprows=1, sep=';')  # , index_col=None)
        df = df.rename(columns=dict_isp)
        df['Ddate'] = pd.to_datetime(df['PeriodStart'], format='%d/%m/%Y %H:%M').dt.date
        df['PeriodStart'] = pd.to_datetime(df['PeriodStart'], format='%d/%m/%Y %H:%M').dt.time
        df['PeriodEnd'] = pd.to_datetime(df['PeriodEnd'], format='%d/%m/%Y %H:%M').dt.time
    else:
        df = pd.read_csv(file, encoding = "ISO-8859-1", engine='python', skiprows=5, sep='\t')#, index_col=None)
        cols = df.columns
        df = df.reset_index().iloc[:, :-1]
        df.columns = cols

        df = remove_outliner(df, 'Donn')
        df = remove_outliner(df, 'Attention')
        df = remove_outliner(df, 'Avertissement')

        df = df.rename(columns=dict_isp)
        df["Ddate"] = pd.to_datetime(df["Ddate"]).dt.strftime('%Y-%m-%d')
        df['ImbalanceHalfHour'] = df['ImbalanceHalfHour'].apply(lambda x: x.replace('h', ':'))
        df[['PeriodStart', 'PeriodEnd']] = df['ImbalanceHalfHour'].str.split(' - ', 1, expand=True)
        df['PeriodEnd'] = df['PeriodEnd'].apply(lambda x: x.replace('24:00', '00:00'))
        df['PeriodStart'] = pd.to_datetime(df['PeriodStart'],format='%H:%M').dt.time
        df['PeriodEnd'] = pd.to_datetime(df['PeriodEnd'],format='%H:%M').dt.time
        df = df.drop(['ImbalanceHalfHour'], axis=1)
        df['Imbalance'] = ''
        df['Tendance'] = ''
    df['Unit'] = 'Euros/MWh'

    # Upload to database
    su.upload_to_database(df, filename_isp)
    time.sleep(1)


def main():
    try:
        # Delete Files in Temp folder
        log.debug("Env:"+env)

        download_data(url_price, yrs_price, 'pricezips')
        download_data(url_isp, yrs_isp, 'isp')

        os.chdir(appFolder)
        unzipall()

        folder = os.path.join(appFolder, 'isp')
        os.chdir(folder)

        for excel in gb.glob("*.csv"):
            if not '~' in excel:
                try:
                    if excel.find("MMA") != -1:
                        log.debug("Found a file to scrape: {0}".format(excel))
                        if excel != 'MMA_HECAR_2016.csv':
                            scrape_isp(os.path.join(folder, excel))
                        shutil.move(appFolder + "\\isp\\" + excel, appFolder + "\\archive\\" + excel)
                    log.debug('File Completed: {0}.'.format(excel))
                except Exception as e:
                    log.error(e)
                    time.sleep(5)
                    shutil.move(appFolder + "\\isp\\" + excel, appFolder + "\\error\\" + excel)
                    exit(1)

        return 0
    except Exception as e:
        log.error(e)
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())

