__doc__ = f""" 
RBP region Capacity Booking Scraper

:param Developer: Dong.Xia (+bobby.hemming@petroineos.com)
:param Owner: Eavan Collins (eavan.collins@petroineos.com)
:param DatabaseTable: [hive_metastore.dataengineering.gas_rbp_regionalbookingplatformrussian]
:param ActiveBatchJob: _rbp_regional_booking_scraper
:param Server: AP3
:param Schedule: Multiple 
:param Notes: 
      1. Check Active Batch Logs
      2. Watch out for holidays that may change the schedule
"""

import os
import sys
import time
import shutil
import argparse
import glob as gb
import pandas as pd
from selenium import webdriver
from datetime import datetime, timedelta, date
from selenium.webdriver.common.keys import Keys

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_email import ag_email_helper as aeh
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

# Note: Unit are different for different terminal. Please check and update the capacity calculation for new terminals
# Mallnow: MWh/h -> formula: /kWh_to_mcm * 24
# Velke: cm/day -> formula: /1000000

env = se.environment

as_of_date = date.today() + timedelta(days=-1)
as_of_date_utc = datetime.utcnow()  #  For UTC auction
# instrument = as_of_date + timedelta(days=1)

url = 'https://ipnew.rbp.eu/Rbp.eu/#/capacityauction-list'

appFolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\RBP'
bulkUploaderFolder = se.ingestion_folder
filename = 'Upload_GAS_RegionalBookingPlatformRussian-'

format_datetime = '%y%m%d%H%M%S'
kWh_to_mcm = 11000000

sleeping_medium = 3
sleeping_long = 7

parameters_list = {
    "Mallnow-WD": {
        "Terminal": "Mallnow",
        "ProductType": "Within Day",
        "EICCode": "Mallnow GAZ-SYSTEM/GASCADE",
        "EntryTSOName": "GASCADE Gastransport GmbH",
        "OpeningDate": (as_of_date_utc + timedelta(days=0)).strftime("%d/%m/%Y"),
        "OpeningTime": as_of_date_utc.replace(minute=0).strftime("%H:%M"),
        "ValidityStartDate": "Not Required for WD Auction..."
    },
    "Mallnow-DA": {
        "Terminal": "Mallnow",
        "ProductType": "Day Ahead",
        "EICCode": "Mallnow GAZ-SYSTEM/GASCADE",
        "EntryTSOName": "GASCADE Gastransport GmbH",
        "OpeningDate": (as_of_date + timedelta(days=0)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date + timedelta(days=1)).strftime("%d/%m/%Y")
    },
    "Mallnow-MA": {
        "Terminal": "Mallnow",
        "ProductType": "Monthly",
        "EICCode": "Mallnow GAZ-SYSTEM/GASCADE",
        "EntryTSOName": "GASCADE Gastransport GmbH",
        "OpeningDate": (as_of_date + timedelta(days=-1)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date.replace(day=1) + timedelta(days=32)).replace(day=1).strftime("%d/%m/%Y")
    },
    "Velke-WD": {
        "Terminal": "Velké",
        "ProductType": "Within Day",
        "EICCode": "Uzhgorod / Velke Kapusany",
        "EntryTSOName": "eustream, a.s.",
        "OpeningDate": (as_of_date_utc + timedelta(days=0)).strftime("%d/%m/%Y"),
        "OpeningTime": as_of_date_utc.replace(minute=0).strftime("%H:%M"),
        "ValidityStartDate": "Not Required for WD Auction..."
    },
    "Velke-DA": {
        "Terminal": "Velké",
        "ProductType": "Day Ahead",
        "EICCode": "Uzhgorod / Velke Kapusany",
        "EntryTSOName": "eustream, a.s.",
        "OpeningDate": (as_of_date + timedelta(days=0)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date + timedelta(days=1)).strftime("%d/%m/%Y")
    },
    "Velke-MA": {
        "Terminal": "Velké",
        "ProductType": "Monthly",
        "EICCode": "Uzhgorod / Velke Kapusany",
        "EntryTSOName": "eustream, a.s.",
        "OpeningDate": (as_of_date + timedelta(days=-1)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date.replace(day=1) + timedelta(days=32)).replace(day=1).strftime("%d/%m/%Y")
    },
    "Budince-WD": {
        "Terminal": "Budince",
        "ProductType": "Within Day",
        "EICCode": "21Z000000000357E",
        "EntryTSOName": "eustream, a.s.",
        "ExitTSOName": "FIRM",
        "OpeningDate": (as_of_date_utc + timedelta(days=0)).strftime("%d/%m/%Y"),
        "OpeningTime": as_of_date_utc.replace(minute=0).strftime("%H:%M"),
        "ValidityStartDate": "Not Required for WD Auction..."
    },
    "Budince-DA": {
        "Terminal": "Budince",
        "ProductType": "Day Ahead",
        "EICCode": "21Z000000000357E",
        "EntryTSOName": "eustream, a.s.",
        "ExitTSOName": "FIRM",
        "OpeningDate": (as_of_date + timedelta(days=0)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date + timedelta(days=1)).strftime("%d/%m/%Y")
    },
    "Budince-MA": {
        "Terminal": "Budince",
        "ProductType": "Monthly",
        "EICCode": "21Z000000000357E",
        "EntryTSOName": "eustream, a.s.",
        "ExitTSOName": "FIRM",
        "OpeningDate": (as_of_date + timedelta(days=-1)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date.replace(day=1) + timedelta(days=32)).replace(day=1).strftime("%d/%m/%Y")
    },
    "Budince-QA": {
        "Terminal": "Budince",
        "ProductType": "Quarterly",
        "EICCode": "21Z000000000357E",
        "EntryTSOName": "eustream, a.s.",
        "ExitTSOName": "FIRM",
        "OpeningDate": (as_of_date + timedelta(days=-1)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date.replace(day=1) + timedelta(days=62)).replace(day=1).strftime("%d/%m/%Y")
    },
    "Budince-YA": {
        "Terminal": "Budince",
        "ProductType": "Yearly",
        "EICCode": "21Z000000000357E",
        "EntryTSOName": "eustream, a.s.",
        "ExitTSOName": "FIRM",
        "OpeningDate": (as_of_date + timedelta(days=-1)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date.replace(day=1) + timedelta(days=365)).replace(day=1).strftime("%d/%m/%Y")
    },
    "Budince-Reversed-WD": {
        "Terminal": "Budince",
        "ProductType": "Within Day",
        "EICCode": "21Z000000000357E",
        "EntryTSOName": "Gas TSO of Ukraine LLC",
        "ExitTSOName": "eustream, a.s.",
        "OpeningDate": (as_of_date + timedelta(days=0)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date + timedelta(days=1)).strftime("%d/%m/%Y")
    },
    "Budince-Reversed-DA": {
        "Terminal": "Budince-Reversed",
        "ProductType": "Day Ahead",
        "EICCode": "21Z000000000357E",
        "EntryTSOName": "Gas TSO of Ukraine LLC",
        "ExitTSOName": "eustream, a.s.",
        "OpeningDate": (as_of_date + timedelta(days=0)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date + timedelta(days=1)).strftime("%d/%m/%Y")
    },
    "Budince-Reversed-MA": {        # Is this the same as Velke forward? -> this could be causing the issue
        "Terminal": "Budince-Reversed",
        "ProductType": "Monthly",
        "EICCode": "21Z000000000357E",
        "EntryTSOName": "Gas TSO of Ukraine LLC",
        "ExitTSOName": "eustream, a.s.",
        "OpeningDate": (as_of_date + timedelta(days=-1)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date.replace(day=1) + timedelta(days=32)).replace(day=1).strftime("%d/%m/%Y")
    },
    "Budince-Reversed-QA": {
        "Terminal": "Budince-Reversed",
        "ProductType": "Quarterly",
        "EICCode": "21Z000000000357E",
        "EntryTSOName": "Gas TSO of Ukraine LLC",
        "ExitTSOName": "eustream, a.s.",
        "OpeningDate": (as_of_date + timedelta(days=-1)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date.replace(day=1) + timedelta(days=62)).replace(day=1).strftime("%d/%m/%Y")
    },
    "Budince-Reversed-YA": {
        "Terminal": "Budince-Reversed",
        "ProductType": "Yearly",
        "EICCode": "21Z000000000357E",
        "EntryTSOName": "Gas TSO of Ukraine LLC",
        "ExitTSOName": "eustream, a.s.",
        "OpeningDate": (as_of_date + timedelta(days=-1)).strftime("%d/%m/%Y"),
        "OpeningTime": "00:00",
        "ValidityStartDate": (as_of_date.replace(day=1) + timedelta(days=365)).replace(day=1).strftime("%d/%m/%Y")
    },
    "Mallnow-MA-test": {
        "Terminal": "Mallnow",
        "ProductType": "Monthly",
        "EICCode": "Mallnow GAZ-SYSTEM/GASCADE",
        "EntryTSOName": "GASCADE Gastransport GmbH",
        "OpeningDate": '20/02/2023',
        "OpeningTime": "00:00",
        "ValidityStartDate": (pd.to_datetime('01/02/2023', format="%d/%m/%Y").replace(day=1) + timedelta(days=32)).replace(day=1).strftime("%d/%m/%Y")
    },
    "Budince-MA-test": {
        "Terminal": "Budince",
        "ProductType": "Quarterly",
        "EICCode": "21Z000000000357E",
        "EntryTSOName": "eustream, a.s.",
        "ExitTSOName": "FIRM",
        "OpeningDate": '06/02/2023',
        "OpeningTime": "00:00",
        "ValidityStartDate": (pd.to_datetime('06/02/2023', format="%d/%m/%Y").replace(day=1) + timedelta(days=62)).replace(day=1).strftime("%d/%m/%Y")
    },
    "Budince-Reversed-MA-test": {
        "Terminal": "Uzhgorod",
        "ProductType": "Monthly",
        "EICCode": "21Z000000000357E",
        "EntryTSOName": "Gas TSO of Ukraine LLC",
        "ExitTSOName": "eustream, a.s.",
        "OpeningDate": '17/04/2023',
        "OpeningTime": "00:00",
        "ValidityStartDate":  (pd.to_datetime('17/04/2023', format="%d/%m/%Y").replace(day=1) + timedelta(days=32)).replace(day=1).strftime("%d/%m/%Y")
    },
}


def load_chrome_settings(downloadFolder):
    chrome_options = webdriver.ChromeOptions()
    # Debug mode disabled
    # if sys.gettrace() is None:  # Check if it's in Debug model
    #     chrome_options.add_argument('--headless')
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": downloadFolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser


def send_report(email_from, emails, df, capacities, terminal, producttype, instrument, wd_no_allocation):
    df_html = df.to_html()
    capacity_offered = capacities[0]
    capacity_allocated = capacities[1]
    imgList = []

    if wd_no_allocation:
        sub = "Auction Updates: " + terminal + " - " + producttype + " - Capacity Allocated: " + str(capacity_allocated)
    else:
        sub = "Auction Updates: " + terminal + " - " + producttype + " (" + str(instrument) + ") - Capacity Allocated: " + str(capacity_allocated) #" (" + _today.strftime(format_datetime) + ")"

    body = "Total Capacities Offered: " + str(capacity_offered) \
            + "<br>" \
            + "Capacities Allocated: " + str(capacity_allocated) \
            + "<br>" \
            + "<br>" \
            + "<font size='+2'><b>Auction Events Details:</b></font>" \
            + "<br>" \
            + df_html \
            + "<br>" \
            + "<b>Published at " + as_of_date.strftime("%Y-%m-%d") + " on Regional Booking Platform (RBP) website</b>" \
            + "<br>" \

    email_sender = aeh.AgEmailHelper()
    email_sender.send_mail_with_embedded_images(email_from, emails, sub, body, imgList)


def delete_temp_files(appFolder):
    for filename in os.listdir(appFolder):
        file_path = os.path.join(appFolder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))


def get_auction_capacity(browser, url, parameters):

    # Get to Data Item Explorer and Demand Folder
    log.debug("Get to Regional Booking Platform Website...")
    log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
    browser.get(url)
    time.sleep(sleeping_long)

    # Fill EIC Code / Network Point/Route Input
    log.debug("Fill Network EIC Code / Point/Route Input...")
    log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
    try:
        xpath_eic = '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[1]/div[1]/div[4]/span/p-autocomplete/span/input'
        browser.find_element('xpath', xpath_eic).clear()
        browser.find_element('xpath', xpath_eic).send_keys(parameters['EICCode'])
        time.sleep(sleeping_medium)
        browser.find_element('xpath', '//*[@id="pr_id_3_list"]/li[1]/span[1]').click()
        time.sleep(sleeping_medium)
    except:
        log.debug("No EIC Code Input... Move to Next Input")

    # Fill Product Type Input
    log.debug("Fill Product Type Input...")
    log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
    try:
        xpath_product = '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[1]/div[1]/div[5]/span/p-multiselect/div/div[2]'
        browser.find_element('xpath', xpath_product).click()
        browser.find_element('xpath', '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[1]/div[1]/div[5]/span/p-multiselect/div/div[4]/div[1]/div[2]/input').send_keys(parameters['ProductType'])
        time.sleep(0.5)
        browser.find_element('xpath', '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[1]/div[1]/div[5]/span/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem/li/span[1]').click()
        time.sleep(0.5)
        browser.find_element('xpath', xpath_product).click()
        time.sleep(sleeping_medium)
    except:
        log.debug("No Product Type Input... Move to Next Input")

    # Fill TSO Input
    log.debug("Fill Entry TSO Name Input...")
    log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
    try:
        xpath_tso = '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[1]/div[1]/div[2]/span/p-multiselect/div/div[2]'
        browser.find_element('xpath', xpath_tso).click()
        browser.find_element('xpath', '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[1]/div[1]/div[2]/span/p-multiselect/div/div[4]/div[1]/div[2]/input').send_keys(parameters['EntryTSOName'])
        time.sleep(0.5)
        browser.find_element('xpath', '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[1]/div[1]/div[2]/span/p-multiselect/div/div[4]/div[1]/div[1]/div[2]').click()
        time.sleep(0.5)
        browser.find_element('xpath', xpath_tso).click()
        time.sleep(sleeping_medium)
    except:
        log.debug("No Entry TSO Name Input Input... Move to Next Input")

    if 'ExitTSOName' in parameters.keys():
        # Fill TSO Input
        log.debug("Fill Exit TSO Name Input...")
        log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        try:
            xpath_tso = '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[1]/div[1]/div[6]/span/p-multiselect/div/div[2]'
            browser.find_element('xpath', xpath_tso).click()
            browser.find_element('xpath', '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[1]/div[1]/div[6]/span/p-multiselect/div/div[4]/div[1]/div[2]/input').send_keys(parameters['ExitTSOName'])
            time.sleep(0.5)
            browser.find_element('xpath', '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[1]/div[1]/div[6]/span/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem[1]/li/div/div').click()
            time.sleep(0.5)
            browser.find_element('xpath', xpath_tso).click()
            time.sleep(sleeping_medium)
        except:
            log.debug("No Entry TSO Name Input Input... Move to Next Input")

    # Fill Opening Time Input
    log.debug("Fill Opening Date Input...")
    log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
    try:
        xpath_opening_date = '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[3]/div[1]/div[2]/p-calendar[1]/span/input'
        xpath_opening_time = '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[3]/div[1]/div[2]/p-calendar[2]/span/input'
        time.sleep(1)

        browser.find_element('xpath', xpath_opening_date).send_keys(Keys.CONTROL,"a");
        browser.find_element('xpath', xpath_opening_date).send_keys(Keys.DELETE);
        time.sleep(1)
        browser.find_element('xpath', xpath_opening_date).send_keys(parameters['OpeningDate'])
        browser.find_element('xpath', '//*[@id="float-input"]').click()
        time.sleep(1)
        browser.find_element('xpath', xpath_opening_time).send_keys(Keys.CONTROL,"a");
        browser.find_element('xpath', xpath_opening_time).send_keys(Keys.DELETE);
        time.sleep(1)
        browser.find_element('xpath', xpath_opening_time).send_keys(parameters['OpeningTime'])
        browser.find_element('xpath', xpath_opening_time).click()
        browser.find_element('xpath', '//*[@id="float-input"]').click()
        time.sleep(sleeping_medium)
    except:
        log.debug("No Opening Date Input... Move to Next Input")

    if parameters['ProductType'] == "Within Day":
        log.debug("ProductType: " + parameters['ValidityStartDate'])
        log.debug("Skipped...")
    else:
        # Fill Validity Start Time Input
        log.debug("ProductType: " + parameters['ProductType'])
        log.debug("Fill Validity Start Time Input...")
        log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        try:
            xpath_validate_date = '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[3]/div[3]/div[2]/p-calendar[1]/span/input'
            xpath_validate_time = '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/div[1]/dm-filter/div/div[3]/div[3]/div[2]/p-calendar[2]/span/input'
            print(parameters['ValidityStartDate'])
            time.sleep(1)

            browser.find_element('xpath', xpath_validate_date).send_keys(Keys.CONTROL,"a");
            browser.find_element('xpath', xpath_validate_date).send_keys(Keys.DELETE);
            time.sleep(1)
            browser.find_element('xpath', xpath_validate_date).send_keys(parameters['ValidityStartDate'])
            browser.find_element('xpath', '//*[@id="float-input"]').click()
            time.sleep(1)
            browser.find_element('xpath', xpath_validate_time).send_keys(Keys.CONTROL,"a");
            browser.find_element('xpath', xpath_validate_time).send_keys(Keys.DELETE);
            time.sleep(1)
            browser.find_element('xpath', xpath_validate_time).send_keys("00:00")
            browser.find_element('xpath', xpath_validate_time).click()
            browser.find_element('xpath', '//*[@id="float-input"]').click()
            time.sleep(sleeping_medium)
        except:
            log.debug("No Validity Start Time Input... Move to Next Input")

    # Click an empty input cell
    log.debug("Parameter Inputs Completed...")
    log.debug("Click an Empty Cell to Implement the Inputs...")
    log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
    browser.find_element('xpath', '//*[@id="integeronly"]').clear()
    time.sleep(sleeping_medium)

    # Test if Data is available and the Status is Set
    try:
        df_test_list = pd.read_html(browser.page_source)
        df_test = pd.concat(df_test_list)
        df_test = df_test[df_test['Status'] == 'Closed']
        if df_test.empty == True:
            log.error("No Closed Status Auction Data...")
            log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
            return False
    except Exception as e:
        log.error(e)
        log.error("Auction Data is not Available Yet...")
        log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        return False

    # Download the file...
    log.debug("Closed Auction Events Found...")
    log.debug("Download the file...")
    log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
    xpath_download = '//*[@id="pr_id_2"]/p-paginator/div/div/button/span[1]'
    xpath_download = '/html/body/app-root/app-main/div/div/div[2]/ng-component/div/app-arrow-base/div/div[2]/div/p-table/div/p-paginator/div/div/button/span[1]'
    browser.find_element('xpath', xpath_download).click()
    time.sleep(sleeping_long * 2)
    log.debug("Download Completed...")
    log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))

    return True


def process_excel_files(downloadFolder, terminal):
    os.chdir(downloadFolder)

    # Check if the list is not empty, else wait for 1 second before recheck
    count = 1
    while count <= 120:
        log.debug("Checking Downloaded Excel File.")
        log.debug("This is " + str(count) + " Check.")
        log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        file_list = gb.glob("*.xlsx")

        if not file_list:
            log.debug("Excel File is not Ready.")
            log.debug("Wait 1 Second before Recheck.")
            log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            time.sleep(1)
            count +=1
        else:
            log.debug("Excel File Detected in Download Folder.")
            log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
            break
    else:
        log.debug("Unable to Find Downloaded File.")
        log.debug("Scraper Stoped With Error!!!.")
        exit(1)

    for excel in file_list:
        if not '~' in excel:
            log.debug("Import Downloaded Data.")
            log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
            df = pd.read_excel(os.path.join(downloadFolder, excel))

            log.debug("Excel File Import Completed.")
            log.debug("Cleansing the Downloaded Datatable.")
            df.columns = df.columns.str.replace(' ', '_')
            df.columns = df.columns.str.replace('(', '')
            df.columns = df.columns.str.replace(')', '')
            df.columns = df.columns.str.replace('/', '')
            df.columns = df.columns.str.replace('__', '_')

            df['Reserve_Prices'] = df['Reserve_Prices'].replace(',', '.', regex=True)
            df = df.replace(',', ';', regex=True)
            # too much unnecessary information in Additional Text Column, thus removed
            df = df.drop(columns=['Additional_Text'])
            try:
                log.debug("Try to Format Instrument for Day Ahead...")
                log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
                df['Instrument'] = pd.to_datetime(df['Instrument'], format='%Y.%m.%d.').dt.date
            except:
                log.debug("Instrument Formatting Failed, Cleansing Continues...")
                log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))

            df['Opening_Time'] = pd.to_datetime(df['Opening_Time'], format='%Y-%m-%d %H:%M:%S')
            df['Closing_Time'] = pd.to_datetime(df['Closing_Time'], format='%Y-%m-%d %H:%M:%S')
            df['Capacity_Valid_From'] = pd.to_datetime(df['Capacity_Valid_From'], format='%Y-%m-%d %H:%M:%S')
            df['Capacity_Valid_To'] = pd.to_datetime(df['Capacity_Valid_To'], format='%Y-%m-%d %H:%M:%S')
            df['Pdate'] = as_of_date.strftime("%Y-%m-%d")

            log.debug("Calculate Simplified Datatable.")
            log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
            df_simplified = df[['Product_Type', 'Instrument', 'Status', 'Auction_Name', 'Auction_Characteristics', 'Exit_TSO_Name', 'Quality_Exit_TSO', 'Entry_TSO_Name', 'Offered_Capacity', 'Allocated_capacity']]
            df_simplified['Allocated_capacity'] = df_simplified['Allocated_capacity'].fillna(0)
            if terminal == 'Mallnow':
                df_simplified['Offered_Capacity'] = (df_simplified['Offered_Capacity']/kWh_to_mcm * 24).round(1)
                df_simplified['Allocated_capacity'] = (df_simplified['Allocated_capacity']/kWh_to_mcm * 24).round(1)
            else:
                df_simplified['Offered_Capacity'] = (df_simplified['Offered_Capacity']/1000000).round(1)
                df_simplified['Allocated_capacity'] = (df_simplified['Allocated_capacity']/1000000).round(1)
            df_simplified['Unit'] = 'mcm/d'
            instrument = df_simplified['Instrument'].unique()[0]

            log.debug("Calculate Summary Datatable.")
            log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))

            df_summary = df_simplified[['Product_Type', 'Instrument', 'Status', 'Exit_TSO_Name', 'Quality_Exit_TSO', 'Entry_TSO_Name', 'Offered_Capacity', 'Allocated_capacity', 'Unit']]
            df_summary = df_summary[df_summary['Status'] == 'Closed']
            df_summary = df_summary.drop(columns=['Status'])
            capacities = [round(df_summary['Offered_Capacity'].sum(), 1), round(df_summary['Allocated_capacity'].sum(), 1)]
            log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
            return df, df_simplified, capacities, instrument


def save_to_csv(df):
    filefullname = os.path.join(bulkUploaderFolder, filename + datetime.today().strftime('%y%m%d%H%M%S') + '.csv')
    log.info(f'Exporting file: {filefullname}')
    su.upload_to_database(df, filename)
    time.sleep(1)


def generate_and_send_report(df_simplified, capacities, terminal, producttype, instrument, wd_no_allocation):
    if wd_no_allocation:
        sender = "charles.cai@petroineos.com"
        recipient = "bobby.hemming@petroineos.co.uk;jessicagervais@petroineos.co.uk"
    else:
        if env == 'UAT':
            sender = "bobby.hemming@petroineos.co.uk"
            recipient = "bobby.hemming@petroineos.co.uk"
        else:
            sender = "charles.cai@petroineos.com"
            recipient = "Rishi.Ruparelia@petrochinaintl.co.uk;Matthew.Morris@petrochinaintl.co.uk;" \
                        "Dylan.King@petrochinaintl.co.uk;Yining.Sun@petroineos.com;giam-kiahwei@petrochina.com.sg;" \
                        "Oliver.Maddox@petrochinaintl.co.uk;Ross.McVey@petrochinaintl.co.uk;" \
                        "You.Lidong@petrochinaintl.co.uk;Rodrigo.Ruiz-Castro@petrochinaintl.co.uk;" \
                        "Eavan.Collins@petrochinaintl.co.uk;charles.cai@petroineos.com;bobby.hemming@petroineos.co.uk;" \
                        "jessicagervais@petroineos.co.uk"
    send_report(sender, recipient, df_simplified, capacities, terminal, producttype, instrument, wd_no_allocation)


def main(argv):
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('-producttype', action='store', dest='producttype', default='none',
                            help='select element: DA or MA')

        args = parser.parse_args(argv)
        product_type = args.producttype

        if product_type == 'none':
            log.debug('Element input required, Python script stopped.')
            exit(1)

        downloadFolder = os.path.join(appFolder, product_type)

        if not os.path.isdir(downloadFolder):
            os.makedirs(downloadFolder)

        log.debug('Parameter Set: ' + product_type)
        parameters = parameters_list[product_type]
        terminal = parameters['Terminal']
        producttype = parameters['ProductType']

        log.debug("Env: " + env)
        log.debug("Machine Local Date: " + as_of_date.strftime("%Y-%m-%d"))
        log.debug("Auction UTC Time: " + as_of_date_utc.strftime("%Y-%m-%d %H:%M"))
        log.debug("Terminal: " + str(terminal))
        log.debug("Product Type: " + str(producttype))
        log.debug("EIC Code: " + str(parameters['EICCode']))
        log.debug("Entry TSO Name: " + str(parameters['EntryTSOName']))
        log.debug("Validity Start Time: " + str(parameters['ValidityStartDate']))


        # Delete Files in Temp folder
        log.debug("Clear Download SubFolder.")
        log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        delete_temp_files(downloadFolder)

        success = False
        count = 1

        while count <= 5:
            # Initiate Chrome Driver
            log.debug("Initiate Chrome Driver.")
            log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
            browser = load_chrome_settings(downloadFolder)

            # Start Scraping
            log.debug("Getting Capacity Auction Table on RBP Website~~~~~")
            log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
            success = get_auction_capacity(browser, url, parameters)

            # close and close chrome webdriver
            browser.close()
            browser.quit()
            log.error("Counts: " + str(count))

            if success:
                log.error("Download Succeed, Continue to Process the Download File.")
                break
            count += 1
            log.error("Waiting for Retry...")
            log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
            time.sleep(sleeping_medium)
        else:
            log.error("Maximum Counting Exceeded...")
            log.error("Scraper stopped...")
            log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
            return 1

        # Process Downloaded file
        log.debug("Processing downloaded Excel file.")
        log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        df_db, df_simplified, capacities, instrument = process_excel_files(downloadFolder, terminal)

        # Send Notification Email
        log.debug("Send Notification Email.")
        log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        # If no capacity allocated in WD auction, email servers as testing and send to UAT only
        if int(capacities[1]) == 0 and parameters['ProductType'] == 'Within Day':
            log.debug("No capacity allocated in WD auction, email servers as testing and send to UAT only.")
            generate_and_send_report(df_simplified, capacities, terminal, producttype, instrument, True)
        else:
            generate_and_send_report(df_simplified, capacities, terminal, producttype, instrument, False)
        log.debug("Notification Email Sent.")

        # Finishing the Job
        save_to_csv(df_db)
        log.debug("csv file exported.")
        log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
        return 0

    except Exception as e:
        log.error(e)
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    log.error("Scraper Started.")
    log.error("Time log: " + datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
    exit(main(sys.argv[1:]))