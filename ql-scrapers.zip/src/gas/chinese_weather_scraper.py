from selenium import webdriver
import os
from datetime import datetime, date, timedelta
import dateutil.relativedelta
import pandas as pd
import sys
import re

sys.path.append(os.getcwd())
from ag_log import ag_log

as_of_date = date.today()

url = 'https://www.guowaitianqi.com/'
format_datetime = '%y%m%d%H%M%S'
gas_folder = r'\\petroineos.local\dfs\Department Shared Folders\~Gas Power and Emission Department\Weather\_datafeed\ChineseWeather'
# env = se.environment
# upload_folder = se.ingestion_folder


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
#        chrome_options.add_argument('--headless')  # Otherwise headless Chrome
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": True,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path="..\\tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser


def get_weather_forecast(city, filefullname):
    list_weather = []
    list_yearmonth = check_if_existing_city(city, filefullname)
    browser = load_chrome_settings()
    for yearmonth in list_yearmonth:
        url_historic = url + 'h/' + city + '-' + yearmonth + '.html'
        log.info(city + ' ' + yearmonth + ' url:  ' + url_historic)
        try:
            browser.get(url_historic)
            for j in range(1, 32):
                try:
                    weather_full = browser.find_element('xpath', '/html/body/div/div/section[1]/p[' + str(j) + ']/a').get_attribute("innerHTML").split('   ')[0]
                    list_weather.append([weather_full])
                except:
                    pass
        except:
            log.info(city + ' ' + yearmonth + ' url:  ' + url_historic + ' does not exist')
            pass
    browser.close()
    browser.quit()
    df = pd.DataFrame(list_weather).rename(columns={0: 'WeatherFull'})
    return df


def check_if_existing_city(city, filefullname):
    if not os.path.isfile(filefullname):
        print('File not found: ' + city + ".csv")
        print('Start backfilling.')
        srt_date = date(2017, 10, 1)
    else:
        print('File exists: ' + city + ".csv")
        print('Scrape the last 2 months data.')
        srt_date = as_of_date.replace(day=1) + dateutil.relativedelta.relativedelta(months=-1)
    end_date = as_of_date.replace(day=1) + dateutil.relativedelta.relativedelta(months=1)
    list_yearmonth = [d.strftime('%Y%m') for d in pd.date_range(srt_date, end_date, freq='MS')]
    return list_yearmonth


def weather_data_cleansing(df, country, city):
    df[['Ddate', 'Weather']] = df['WeatherFull'].str.split('：', expand=True)
    df['Ddate'] = pd.to_datetime(df['Ddate'], format='%Y-%m-%d')
    df[['Weather', 'Temperature', 'Wind']] = df['Weather'].str.split('，', expand=True)
    df['Temperature'] = df['Temperature'].apply(lambda x: x.replace('℃', ''))
    df[['WindDirection', 'WindScaleDescription']] = df['Wind'].str.split('级', expand=True)
    df['WindBeaufortScale'] = df['Wind'].apply(lambda x: int(re.search(r'\d+', x).group()))
    df['WindDirection'] = df['WindDirection'].apply(lambda x: x.replace(re.search(r'\d+', x).group(), ''))
    df['WeatherDataType'] = ''
    df['WeatherDataType'][df['Ddate'] <= pd.to_datetime(as_of_date)] = 'Historical'
    df['WeatherDataType'][df['Ddate'] > pd.to_datetime(as_of_date)] = 'Forecast'
    df['Country'] = country
    df['City'] = city
    df = df.drop(columns=['WeatherFull', 'Wind'])
    df = df.drop(columns=['Weather', 'WindDirection', 'WindScaleDescription'])
    return df


def merge_existing_data(df, filefullname):
    df_exist = pd.read_csv(filefullname, delimiter=',')  # , index_col='Ddate')
    df_exist['Ddate'] = pd.to_datetime(df_exist['Ddate'])
    df_exist = df_exist[~df_exist['Ddate'].isin(df['Ddate'])]
    df = pd.concat([df_exist, df])
    return df


def main():
    try:
        # Get Control csv File
        df_cities = pd.read_csv(os.path.join(gas_folder, '_ScraperCityControl.csv'))
        for i in df_cities.index:
            city = df_cities['City'][i]
            country = df_cities['Country'][i]
            if df_cities['Active'][i]:
                log.info(country + ' - ' + city)
                filefullname = os.path.join(gas_folder, city + ".csv")
                # Check if city csv file exist
                # if the csv file exists, scrape the last 2 months, otherwise from Oct.2017
                df = get_weather_forecast(city, filefullname)
                # Data cleansing
                if df.shape[0] != 0:
                    df = weather_data_cleansing(df, country, city)
                    # Merge with existing csv file, if any
                    if os.path.isfile(filefullname):
                        df = merge_existing_data(df, filefullname)
                    # Export to csv file
                    df = df[['Ddate', 'Country', 'City', 'Temperature', 'WindBeaufortScale', 'WeatherDataType']]
                    df.to_csv(filefullname, index=False, encoding='utf-8-sig')


        log.debug("Data Files Process Completed.")
        return 0

    except Exception as e:
        print(e)
        log.error(e)
        log.debug("Scraper stopped with error.")
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())