import os
import time
import sys
import argparse
import pandas as pd
from datetime import datetime
from bs4 import BeautifulSoup
from selenium import webdriver
import chromedriver_autoinstaller
from selenium.webdriver.common.by import By

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder
chromedriver_autoinstaller.install()

log = ag_log.get_log()


def load_chrome_settings(temp_path):
    """
    Setting up selenium settings
    :return:
    """
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
    #     chrome_options.add_argument('--headless')  # Otherwise headless Chrome  # Bloomberg does not like headless
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": temp_path,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--ignore-ssl-errors=yes")
    chrome_options.add_argument("--ignore-certificate-errors")

    chromedriver_autoinstaller.install()
    # browser = webdriver.Chrome(executable_path="C:\\Public\\Tools\\chromedriver.exe", chrome_options=chrome_options)
    browser = webdriver.Chrome(chrome_options=chrome_options)
    return browser


def convert_html_to_df(html_str):
    """
    Converts a HTML dump from the website and extracts the table stored in div elements.
    :param html_str:
    :return:
    """
    soup = BeautifulSoup(html_str,"html.parser")
    div = soup.find('div', {'class': 'Table__container'})

    location_list = []
    week_row_content_list = []
    week_row_list = []

    for row in div.findAll('div',{'class':'Location__cell'}):
        location_list.append(row.text)

    for row in div.findAll('div',{'class':'Week__row'}):
        week_row_list.append(row)

    for row in week_row_list:
        row_content_list = []
        for row_content in row.findAll('div',{'class':'Week__cell'}):
            row_content_list.append(row_content.text)
        week_row_content_list.append(row_content_list)

    df = pd.DataFrame(week_row_content_list)
    df.index = location_list
    df = df.reset_index()
    df = df.replace({'\n': ''}, regex=True)

    headers = df.iloc[0].values
    df.columns = headers
    df = df.drop(index=0, axis=0)
    df.columns = df.columns.str.strip()

    id_vars = ['city','Country']
    id_vars = [x for x in id_vars if x in df.columns]
    value_vars = [x for x in df.columns if x not in id_vars]
    df = df.reset_index(inplace=False)
    df = pd.melt(
        df, id_vars=id_vars,
        value_vars=value_vars,
        var_name='date', value_name='value_percent'
    )

    df.value_percent = df.value_percent.str.replace("%", "")
    df.value_percent = df.value_percent.str.replace("+", "")

    return df


def change_dropdown(driver,locations = 'CITIES', periods='MoM'):
    """
    Manipulate the different dropdown options on the website
    :param driver:
    :param locations:
    :param periods:
    :return:
    """
    dropdown = driver.find_element(By.XPATH, "//*[contains(@id, '-locations')]")
    dropdown.click()
    dropdown_option = driver.find_element(By.XPATH, "//*[@data-value='{}']".format(locations))
    dropdown_option.click()

    time.sleep(5)
    dropdown = driver.find_element(By.XPATH, "//*[contains(@id, '-periods')]")
    dropdown.click()
    dropdown_option = driver.find_element(By.XPATH, "//*[@data-value='{}']".format(periods))
    dropdown_option.click()
    return driver


def get_table(driver, locations = 'COUNTRIES', periods='YoY'):
    """
    Manipulates the website to show the right table, and downloads and parses the website to return a pandas table
    :param driver:
    :param locations:
    :param periods:
    :return:
    """
    log.info("Getting table for {} and {}".format(locations, periods))
    change_dropdown(driver=driver,locations = 'CITIES', periods='MoM')
    time.sleep(5)
    html = driver.page_source
    # print(html)
    table = convert_html_to_df(html_str = html)

    table['locations'] = locations
    table['periods'] = periods

    return table


def download_latest_table(temp_path):
    """
    Download the latest table from kayak accross both country and city, for each time period.
    Four tables in total
    :return:
    """
    log.debug("Initialising Chrome.")
    # Initiate Chrome Driver
    driver = load_chrome_settings(temp_path)

    driver.get("https://www.kayak.co.uk/flight-trends")
    print('browser',driver)
    time.sleep(5)
    driver.find_element(By.CLASS_NAME,"Iqt3-button-content").click()  # remove cookie popup

    # dropdown = driver.find_element(By.ID,"c_kWl-periods")
    # dropdown = driver.find_element(By.XPATH,"//*[text()='Year over three years']")
    df_list = []
    for locations in ['COUNTRIES','CITIES']:
        for periods in ['MoM', 'YoY']:
            df = get_table(driver=driver,locations = locations, periods=periods)
            df_list.append(df)

    df = pd.concat(df_list)

    log.debug("Download and parsing Completed.")
    return df


def download_and_process_kayak_flight_search_table(upload_folder, output_folder, format_datetime, format_datetime_name):
    """
    Download the latest kayak flight search tables from Bloomberg and save the table as a CSV to disk
    :param upload_folder:
    :param format_datetime:
    :param format_datetime_name:
    :return:
    """
    df = download_latest_table(temp_path=output_folder)

    pdate = datetime.today().strftime(format_datetime)
    pdate_name = datetime.today().strftime(format_datetime_name)
    df['pdate'] = pdate

    file_output_path = os.path.join(upload_folder, "oil-macro-kayak_flight_search_trends-{}.csv".format(pdate_name))
    df.to_csv(file_output_path, index=False)

    return df


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--output_folder", help="Local folder to store the downloaded files",default=r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Scrapers\macro")
    parser.add_argument("--upload_folder", help="Local folder to save the cleaned CSV files",default=r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\AzureDataUploader\OIL")

    args = parser.parse_args()
    output_folder = args.output_folder
    upload_folder = args.upload_folder

    format_datetime = '%Y-%m-%d'
    format_datetime_name = '%Y%m%d'

    download_and_process_kayak_flight_search_table(upload_folder=upload_folder,output_folder=output_folder,format_datetime=format_datetime, format_datetime_name=format_datetime_name)