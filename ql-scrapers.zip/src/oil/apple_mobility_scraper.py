import os
import sys
import copy
import time
import pandas as pd
from selenium import webdriver
from datetime import datetime, timedelta

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

log = ag_log.get_log()

env = se.environment
bulkUploaderFolder = se.ingestion_folder


def Initialise():
    # Initiate Driver
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
#        chrome_options.add_argument('--headless')  # Otherwise headless Chrome
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": ".",
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    browser = webdriver.Chrome(executable_path="..\\tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser


def scrape_apple_mobility_data(browser):
    browser.get("https://www.apple.com/covid19/mobility")
    time.sleep(10)
    anchor = browser.find_element('xpath', '//*[@id="download-card"]/div[2]/a')
    csv_online = anchor.get_attribute("href")

    df = pd.read_csv(csv_online)
    browser.close()
    del browser
    return df


def map(city):
    if city in city_map_dict.keys():
        return city_map_dict[city]
    else:
        return city


def get_city_map():
    query = '''
        SELECT 
            Source, SourceValue, DestValue
        FROM 
            dataengineering.oil_mapping_countryregionmap
        WHERE 
            Source = 'Apple' AND IsActive = True
    '''
    df_map = bo.get_data(query)
    city_map = {}
    for index, row in df_map.iterrows():
        city_map[row['SourceValue']] = row['DestValue']
    return city_map


log.debug("Env:" + env)
log.debug("Initialising Chrome.")
browser = Initialise()

log.debug("Getting Apple Mobility Table.")
df_raw = scrape_apple_mobility_data(browser)

log.debug("Getting Mapping Data from Database.")
city_map_dict = get_city_map()

log.debug("Processing Downloaded Data File.")
result = []

for index, row in df_raw.iterrows():
    d = {}
    for column in df_raw.columns:
        if not column.startswith('202'):
            if column == 'country' and pd.isnull(row[column]):
                d[column] = row['region']
            elif column == 'region' and row['country'] == 'United States' and row['geo_type'] == 'geo_type':
                d[column] = map(row[column])
            else:
                d[column] = row[column]
    for column in df_raw.columns:
        if column.startswith('202'):
            # this is a data column
            last_week = datetime.today() + timedelta(days=-7);
            from_day = last_week.strftime("%Y-%m-%d")
            if column < from_day:
                continue
            if pd.isnull(row[column]):
                continue
            d2 = copy.deepcopy(d)
            d2['PDate'] = column
            d2['Value'] = row[column]
            result.append(d2)

df_result = pd.DataFrame(result)
df_result.rename(columns={'geo_type':'geotype', 'sub-region':'subregion'}, inplace=True)
df_result = df_result[['PDate','geotype','region','transportation_type','subregion','country','Value']]
df_result = df_result.replace({"'": ''}, regex=True)

log.debug("Export the Data into CSV File.")
bulk_uploader_folder = bulkUploaderFolder
filename = 'Upload_OIL_AppleMobility-'
format_datetime = '%y%m%d%H%M%S'
# full_filename = bulk_uploader_folder + "\\" + filename + datetime.now().strftime(format_datetime) + ".csv"

su.upload_to_database(df_result, filename)
log.debug("Job Completed.")



