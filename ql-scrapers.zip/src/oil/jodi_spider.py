# -*- coding: utf-8 -*-
import os
import sys
import time
import scrapy
import pandas
import shutil
import zipfile
import datetime
import requests
import urllib.parse
from scrapy import cmdline
from datetime import timedelta

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_email import ag_email_helper as aeh
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

bulkUploaderFolder = se.trigger_ingestion_folder


class JodispiderSpider(scrapy.Spider):
    env = se.environment
    log = ag_log.get_log()
    time_stamp = datetime.datetime.now().strftime("%y%m%d%H%M%S")
    upload_names = [
        'Upload_Oil_JodiCrude-',
        'Upload_Oil_JodiProduct-'
    ]
    upload_names_latest = [
        'Upload_Oil_JodiCrudeLatest-',
        'Upload_Oil_JodiProductLatest-'
    ]

    # leave first element empty for looping
    name = 'jodispider'
    allowed_domains = ['www.jodidata.org']
    start_urls = ['https://www.jodidata.org/oil/database/data-downloads.aspx']
    temp_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\JODI'
    saturn_datafeed = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\JODI\saturn_dirct_datafeed\JODI'
    uploader_path = bulkUploaderFolder

    def parse(self, response):
        try:
            print("env: " + self.env)
            primary = response.xpath('//*[@id="maincontent"]/ul/li[1]/a[1]/@href')[0].extract()
            secondary = response.xpath('//*[@id="maincontent"]/ul/li[1]/a[2]/@href')[0].extract()
            urllist = [primary, secondary]
            stamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            pdate = datetime.datetime.now().strftime("%Y-%m-%d")
            process = os.path.join(self.temp_path, "processing")
            out = os.path.join(self.temp_path, "output")
            archive = os.path.join(self.temp_path, "archive")
            uploader = self.uploader_path
            pre = os.path.join(process, "pre")
            folderlist = [process, out, archive, pre]

            self.managefolders(folderlist)
            self.archivefile(out, archive, stamp)

            for link in urllist:
                self.log.debug("URL link: " + link)
                fullurl = urllib.parse.urljoin(response.url, link.strip())
                file = requests.get(fullurl)
                filename = fullurl.split('/')[-1].split('?')[0]
                self.log.debug("file name {}".format(filename))
                open(os.path.join(self.temp_path, filename), 'wb').write(file.content)
                self.unzip(self.temp_path, filename, process)

            csv_files = [ filename for filename in os.listdir(process) if filename.endswith('.csv') ]
            for f, upload_name, upload_name_latest in zip(csv_files, self.upload_names, self.upload_names_latest):
                if os.path.isfile(os.path.join(process, f)):
                    print('filename = ',f)
                    self.compare_and_output(process, pre, f, out, pdate, upload_name, upload_name_latest, uploader)
        except Exception as e:
            self.log.error(e)
            exit(1)

    def managefolders(self, folderlist):
        for f in folderlist:
            if not os.path.exists(f):
                os.makedirs(f)

    def archivefile(self, outfolder, archive, stamp):
        files = os.listdir(outfolder)
        if len(files) > 0:
            for f in files:
                ext = f.split('.')[-1]
                newname = f.split('.')[-2] + '-' + stamp + '.' + ext
                shutil.move(os.path.join(outfolder, f), os.path.join(archive, newname))
                self.log.debug("moving file {} complete".format(f))

    def unzip(self, sfolder, filename, dfolder):
        if os.path.isfile(os.path.join(sfolder, filename)):
            if filename.endswith(".zip"):
                with zipfile.ZipFile(os.path.join(sfolder, filename), 'r') as zip_ref:
                    zip_ref.extractall(dfolder)
                self.log.debug("unzip file {} complete".format(filename))
            else:
                self.log.debug("No .zip file found")

    def send_updates_report(self, email_from, emails, updated_time):
        sub = "JODI updates found: (" + updated_time + ")"
        body = "<b> New JODI data detected </b>" \
               + "<br>" \
               + "<b>Last Updated: " + updated_time + "</b>" \
               + "<br>" \
               + "<br>" \
               + "<b> Scraping completed </b>" \
               + "<br>" \
               + "<b> Please wait to allow data upload to database</b>" \
               + "<br>"
        imgList = []

        email_sender = aeh.AgEmailHelper()
        email_sender.send_mail_with_embedded_images(email_from, emails, sub, body, imgList)

    def compare_and_output(self, sfolder, prefolder, filename, outfolder, Pdate, upload_name, upload_name_latest,
                           uploaderfolder):
        print(f'-> Environment is set to {self.env}')
        self.log.debug("Starting Compare and generate output for file {}".format(filename))
        currentfiledf = pandas.read_csv(os.path.join(sfolder, filename), na_values=['x', 'X'])
        last_year = datetime.datetime.today() - timedelta(days=366)
        currentfiledf = currentfiledf[currentfiledf['TIME_PERIOD'] >= last_year.strftime("%Y-%m")]
        currentfiledf['TIME_PERIOD'] = currentfiledf['TIME_PERIOD'] + '-01'
        if filename in os.listdir(prefolder):
            self.log.debug("File {} found in Pre-Folder".format(filename))
            prefile = pandas.read_csv(os.path.join(prefolder, filename), na_values=['x', 'X'])
            prefile = prefile[prefile['TIME_PERIOD'] >= last_year.strftime("%Y-%m")]
            prefile['TIME_PERIOD'] = prefile['TIME_PERIOD'] + '-01'
            compare = currentfiledf.merge(prefile, indicator=True, how='outer')
            compare = compare[compare['_merge'] == 'left_only'].drop(columns='_merge')
            if len(compare) > 0:
                compare['PDate'] = Pdate
                compare.to_csv(os.path.join(outfolder, filename), index=False)
                compare.to_csv(os.path.join(self.saturn_datafeed, filename), index=False)

                su.upload_to_database(compare, upload_name, upload_destination='TRIGGER')
                su.upload_to_database(compare, upload_name_latest, upload_destination='TRIGGER')
                time.sleep(1)

                # Comment out Output for Pdatelatest Table
                pdate_type = upload_name[0: upload_name.find("-")].replace("Upload_Oil_Jodi", "")
                pdate_latest = compare[['TIME_PERIOD', 'REF_AREA', 'ENERGY_PRODUCT', 'FLOW_BREAKDOWN', 'PDate']]
                pdate_latest['TYPE'] = pdate_type

                su.upload_to_database(pdate_latest, "Upload_Oil_JodiLatest-", upload_destination='TRIGGER')
                if self.env == 'UAT':
                    self.send_updates_report("Chales.Cai@petroineos.com", "behzadhosseini@petroineos.co.uk", Pdate)
                elif self.env == 'PROD':
                    self.send_updates_report("charles.cai@petroineos.com", "John.VonStackelberg@petroineos.com;MohammedHasan@petroineos.co.uk;Syed.Ahmad@petroineos.com;Charles.Cai@petroineos.com;behzadhosseini@petroineos.co.uk", Pdate)
                else:
                    print('Please choose the envirment as PROD or UAT (for testing)')
            else:
                self.log.debug("no difference found for {}".format(filename))
            self.log.debug("Moving file {} to pre folder".format((filename)))
            if os.path.isfile(os.path.join(prefolder, filename)):
                os.remove(os.path.join(prefolder, filename))
            shutil.move(os.path.join(sfolder, filename), os.path.join(prefolder,filename))
        else:
            currentfiledf['PDate'] = Pdate
            # currentfiledf.to_csv(os.path.join(outfolder, filename), index=False)
            currentfiledf.to_csv(os.path.join(uploaderfolder, upload_name), index=False)
            su.upload_to_database(currentfiledf, upload_name, upload_destination='TRIGGER')
            time.sleep(1)
            # currentfiledf.to_csv(os.path.join(uploaderfolder, upload_name_latest), index=False)
            su.upload_to_database(currentfiledf, upload_name_latest, upload_destination='TRIGGER')
            # Comment out Output for Pdatelatest Table
            pdate_type = upload_name[0: upload_name.find("-")].replace("Upload_Oil_Jodi", "")
            pdate_latest = currentfiledf[['TIME_PERIOD', 'REF_AREA', 'ENERGY_PRODUCT', 'FLOW_BREAKDOWN', 'PDate']]
            pdate_latest['TYPE'] = pdate_type
            su.upload_to_database(pdate_latest, "Upload_Oil_JodiLatest-", upload_destination='TRIGGER')
            self.log.debug("Moving file {} to pre folder".format((filename)))
            if os.path.isfile(os.path.join(prefolder, filename)):
                os.remove(os.path.join(prefolder, filename))
            shutil.move(os.path.join(sfolder, filename), os.path.join(prefolder, filename))
            if self.env == 'UAT':
                self.send_updates_report("Chales.Cai@petroineos.com", "behzadhosseini@petroineos.co.uk", Pdate)
            elif self.env == 'PROD':
                self.send_updates_report("charles.cai@petroineos.com", "John.VonStackelberg@petroineos.com;MohammedHasan@petroineos.co.uk;Syed.Ahmad@petroineos.com;Charles.Cai@petroineos.com;behzadhosseini@petroineos.co.uk", Pdate)
            else:
                print('Please choose the envirment as PROD or UAT (for testing)')
        self.log.debug("Generate output file {} in BatchUploader folder complete".format(upload_name))


cmdline.execute("scrapy runspider oil/jodi_spider.py".split())
