import os
import sys
import time
import shutil
import warnings
import requests
import numpy as np
import pandas as pd
from selenium import webdriver
from datetime import datetime, timedelta
from selenium.webdriver.common.keys import Keys

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder

format_datetime = '%y%m%d%H%M%S'

url_cases = 'https://covid.cdc.gov/covid-data-tracker/#cases_casesper100klast7days'
url_vaccinations = 'https://covid.cdc.gov/covid-data-tracker/#vaccinations'

filename_cases = 'united_states_covid19_cases_deaths_and_testing_by_state.csv'
filename_vaccinations = 'covid19_vaccinations_in_the_united_states.csv'

appFolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\CDC_Covid\temp'
bulk_uploader_folder = bulkUploaderFolder
vaccinations_archive_folder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\CDC_Covid\archive\Vaccine'

if env == 'PROD':
    folders = [bulk_uploader_folder, vaccinations_archive_folder]
else:
    folders = [bulk_uploader_folder, bulk_uploader_folder]


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
    #     chrome_options.add_argument('--headless')  # Otherwise headless Chrome@id="sections1items0items0items0items0"]/div[1]/div/div/div/div/div[2]/div[2]
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": appFolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser


def delete_temp_files():
    for filename in os.listdir(appFolder):
        file_path = os.path.join(appFolder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            log.error('Failed to delete %s. Reason: %s' % (file_path, e))
    log.debug("Deleted all temp files.")


def get_cdc_data(browser, url_cases, url_vaccinations):

    log.debug("Scraping cdc data...")
    log.debug("URL:"+url_cases)
    browser.get(url_cases)
    time.sleep(5)

    # try:
    #     log.debug("Navigate to Case Data Page...")
    #     button = browser.find_element('xpath', '//*[@id="us-cases-table-toggle"]')
    #     button.send_keys(Keys.SPACE)
    #     time.sleep(10)
    # except:
    #     log.debug("Expand Left Handside Menu...")
    #     # button = browser.find_element('xpath', '//*[@id="status-cases-30-day"]/svg')
    #     # button.send_keys(Keys.SPACE)
    #     browser.find_element('xpath', '//*[@id="status-cases-30-day"]').click()
    #     time.sleep(5)
    #     browser.get(url_cases)
    #     time.sleep(5)
    #     log.debug("Navigate to Case Data Page...")
    #     button = browser.find_element('xpath', '//*[@id="us-cases-table-toggle"]')
    #     button.send_keys(Keys.SPACE)
    #     time.sleep(10)

    log.debug("Expand Left Handside Menu...")
    # button = browser.find_element('xpath', '//*[@id="status-cases-30-day"]/svg')
    # button.send_keys(Keys.SPACE)
    close_feedback(browser)
    # browser.find_element('xpath', '//*[@id="status-cases-30-day"]').click()
    element = browser.find_element('xpath', '//*[@id="status-cases-30-day"]')
    browser.execute_script("arguments[0].click();", element)
    time.sleep(5)
    browser.get(url_cases)
    time.sleep(5)
    # log.debug("Navigate to Case Data Page...")
    # button = browser.find_element('xpath', '//*[@id="us-cases-table-toggle"]')
    # button.send_keys(Keys.SPACE)
    # time.sleep(10)

    log.debug("Start to Download Cases File...")
    pdate_cases = browser.find_element('xpath', '//*[@id="number-card-note"]').get_attribute("innerHTML").split('Posted: ')[1].replace('</div>\n', '').replace(' ', '')
    print(str(pdate_cases))#.splitlines()[0]#.split("day, ", 1)[1]
    pdate_cases = datetime.strptime(pdate_cases, '%B%d,%Y')
    close_feedback(browser)
    # browser.find_element('xpath', '//*[@id="us-cases-table-title"]').click()
    element = browser.find_element('xpath', '//*[@id="us-cases-table-title"]')
    browser.execute_script("arguments[0].click();", element)
    time.sleep(2)
    close_feedback(browser)
    # browser.find_element('xpath', '//*[@id="btnUSTableExport"]').click()
    element = browser.find_element('xpath', '//*[@id="btnUSTableExport"]')
    browser.execute_script("arguments[0].click();", element)
    time.sleep(1)
    time.sleep(15)

    browser.get(url_vaccinations)
    time.sleep(5)
    browser.refresh()
    time.sleep(2)
    close_feedback(browser)
    # browser.find_element('xpath', '//*[@id="vaccinations-table-title"]').click()
    element = browser.find_element('xpath', '//*[@id="vaccinations-table-title"]')
    browser.execute_script("arguments[0].click();", element)
    time.sleep(1)
    pdate_vaccinations = browser.find_element('xpath', '//*[@id="table-note"]').text.split('Posted: ')[1].replace('</div>\n', '').replace(' ', '')
    pdate_vaccinations = datetime.strptime(pdate_vaccinations, '%B%d,%Y')
    close_feedback(browser)
    # browser.find_element('xpath', '//*[@id="btnVaccinationsExport"]').click()
    element = browser.find_element('xpath', '//*[@id="btnVaccinationsExport"]')
    browser.execute_script("arguments[0].click();", element)
    time.sleep(1)
    time.sleep(15)
    # //*[@id="btnVaccinationsExport"]
    return pdate_cases, pdate_vaccinations


def close_feedback(browser):
    time.sleep(1)
    try:
        browser.find_element('xpath', '//*[@id="fsrFocusFirst"]').click()
        log.debug("Feedback Window Closed....")
    except:
        pass


def process_csv_files(tablename, filename_temp, pdate, folder):

    log.debug("Process csv files...")
    log.debug("Tablename:" + tablename)
    log.debug("filename_temp:"+filename_temp)
    time.sleep(15)
    log.debug("pdate: " + str(pdate))

    if tablename == 'Vaccine':
        skiprows = 4
    else:
        skiprows = 2
    df = pd.read_csv(os.path.join(appFolder, filename_temp), skiprows=skiprows).fillna(0)

    df.rename(columns={'State/Territory/Federal Entity': 'StateTerritory'}, inplace=True)
    df.columns = df.columns.str.replace(' ', '_')
    df.columns = df.columns.str.replace('/', '')
    df.columns = df.columns.str.replace('\\', '')
    df.columns = df.columns.str.replace('-', '_')
    df.columns = df.columns.str.replace('+', '')
    df.columns = df.columns.str.replace('1_Doses', 'minimum_1_Doses')
    df.columns = df.columns.str.replace('7', 'Seven')
    df.columns = df.columns.str.replace('18', 'Adult')
    df.columns = df.columns.str.replace('12', 'Age_12_plus')
    df.columns = df.columns.str.replace('65', 'Age_65_plus')
    df.columns = df.columns.str.replace('%', 'Pctg')
    df.columns = df.columns.str.replace('#_', '')
    df.columns = df.columns.str.replace('&', '')
    df.columns = df.columns.str.replace('_5_', '_Age_5_plus_')
    df.columns = df.columns.str.replace('5_Doses', 'Age_5_plus_Doses')
    df.columns = df.columns.str.replace('__', '_')

    try:
        df['Confirmed_Deaths'] = df['Confirmed_Deaths'].astype(int)
        df['Probable_Deaths'] = df['Probable_Deaths'].astype(int)
    except:
        pass

    df['PDate'] = pdate
    df['DDate'] = pdate.date() + timedelta(days=-1)
    filename = 'Upload_OIL_CovidUS' + tablename
    filefullname = os.path.join(folder, filename + '-' + datetime.today().strftime(format_datetime) + ".csv")
    log.debug("Wrting to csv file: "+filefullname)
    # df.to_csv(path_or_buf=filefullname, header=True, index=False)
    su.upload_to_database(df,  filename + '-', header=True, index=False)


def main():

    try:
        # Delete Files in Temp folder
        log.debug("Delete temp files.")
        delete_temp_files()

        # Initiate Chrome Driver
        log.debug("Env:" + env)
        log.debug("Initiate Chrome Driver.")
        browser = load_chrome_settings()

        # Start Scraping
        log.debug("Getting CDC Covid data.")
        pdate_cases, pdate_vaccinations = get_cdc_data(browser, url_cases, url_vaccinations)

        # close and close chrone webdriver
        browser.close()
        browser.quit()

        # Processing csv file
        log.debug("Processing csv file.")
        process_csv_files('Cases', filename_cases, pdate_cases, folders[0])
        process_csv_files('Vaccine', filename_vaccinations, pdate_vaccinations, folders[1])

        log.error(sys.exc_info()[0])
        log.debug("Job Completed.")
        return 0
    except Exception as e:
        log.error(e)
        log.debug("Job Ended with Error!!!")
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())


# schema_16 = [
#     StateTerritory,
#     Total_Cases,
#     New_Cases_in_Past_Week,
#     Case_Rate_per_100000,
#     Total_Deaths,
#     New_Deaths_in_Past_Week,
#     Death_Rate_per_100000,
#     Weekly_Cases_Rate_per_100000,
#     Weekly_Death_Rate_per_100000,
#     Total_Pctg_Positive,
#     Pctg_Positive_Last_30_Days,
#     Pctg_Positive_Last_Seven_Days,
#     Tests_per_100K,
#     Total_Tests,
#     Tests_per_100K_Last_Seven_Days,
#     Total_Tests_Last_Seven_Days,
#     Tests_per_100K_Last_30_Days,
#     Total_Tests_Last_30_Days,
#     PDate,
#     DDate
# ]
#
# schema_20 = [
#     Jurisdiction_(StateTerritory)_or_Federal_Entity,
#     Total_doses_distributed,
#     Doses_distributed_per_100K_pop,
#     Doses_distributed_by_jurisdiction_per_100K_of_Adult_pop,
#     Total_doses_administered_by_jurisdiction,
#     Doses_administered_by_jurisdiction_per_100K_pop,
#     Doses_administered_by_jurisdiction_to_Adult_pop,
#     Doses_administered_by_jurisdiction_per_100K_of_Adult_pop,
#     Residents_with_at_least_one_dose,
#     Percent_of_total_pop_with_at_least_one_dose,
#     Residents_Adult_with_at_least_one_dose,
#     Percent_of_Adult_pop_with_at_least_one_dose,
#     Residents_with_a_completed_primary_series,
#     Percent_of_total_pop_with_a_completed_primary_series,
#     Residents_Adult_with_a_completed_primary_series,
#     Percent_of_Adult_pop_with_a_completed_primary_series,
#     Total_number_of_original_Pfizer_doses_distributed,
#     Total_number_of_Pfizer_updated_booster_doses_distributed,
#     Total_number_of_original_Moderna_doses_distributed,
#     Total_number_of_Moderna_updated_booster_doses_distributed,
#     Total_number_of_Janssen_doses_distributed,
#     Total_number_of_Novavax_doses_distributed,
#     Total_number_of_doses_from_other_manufacturer_distributed,
#     Total_number_of_Janssen_doses_administered,
#     Total_number_of_original_Moderna_doses_administered,
#     Total_number_of_Moderna_updated_booster_doses_administered,
#     Total_number_of_original_Pfizer_doses_administered,
#     Total_number_of_Pfizer_updated_booster_doses_administered,
#     Total_number_of_Novavax_doses_administered,
#     Total_number_of_doses_from_other_manufacturer_administered,
#     Residents_Age_65_plus_with_at_least_one_dose,
#     Percent_of_Age_65_plus_pop_with_at_least_one_dose,
#     Residents_Age_65_plus_with_a_completed_primary_series,
#     Percent_of_Age_65_plus_pop_with_a_completed_primary_series,
#     Doses_administered_by_jurisdiction_to_Age_65_plus_pop,
#     Doses_administered_by_jurisdiction_per_100K_of_Age_65_plus_pop,
#     Doses_distributed_by_jurisdiction_per_100K_of_Age_65_plus_pop,
#     Residents_Age_12_plus_with_at_least_one_dose,
#     Percent_of_Age_12_plus_pop_with_at_least_one_dose,
#     Residents_Age_12_plus_with_a_completed_primary_series,
#     Percent_of_Age_12_plus_pop_with_a_completed_primary_series,
#     Doses_administered_by_jurisdiction_to_Age_12_plus_pop_,
#     Doses_administered_by_jurisdiction_per_100K_of_Age_12_plus_pop,
#     Doses_distributed_by_jurisdiction_per_100K_of_Age_12_plus_pop,
#     Residents_Age_5_plus_with_at_least_one_dose,
#     Percent_of_Age_5_plus_pop_with_at_least_one_dose,
#     Residents_Age_5_plus_with_a_completed_primary_series,
#     Percent_of_Age_5_plus_pop_with_a_completed_primary_series,
#     Doses_administered_by_jurisdiction_to_Age_5_plus_pop,
#     Doses_administered_by_jurisdiction_per_100K_of_Age_5_plus_pop,
#     Doses_distributed_by_jurisdiction_per_100K_of_Age_5_plus_pop,
#     Residents_with_an_updated_(bivalent)_booster_dose,
#     Percent_of_pop_with_an_updated_(bivalent)_booster_dose,
#     Residents_Age_5_plus_with_an_updated_(bivalent)_booster_dose,
#     Percent_of_Age_5_plus_pop_with_an_updated_(bivalent)_booster_dose,
#     Residents_Age_12_plus_with_an_updated_(bivalent)_booster_dose,
#     Percent_of_Age_12_plus_pop_with_an_updated_(bivalent)_booster_dose,
#     Residents_Adult_with_an_updated_(bivalent)_booster_dose,
#     Percent_of_Adult_pop_with_an_updated_(bivalent)_booster_dose,
#     Residents_Age_65_plus_with_an_updated_(bivalent)_booster_dose,
#     Percent_of_Age_65_plus_pop_with_an_updated_(bivalent)_booster_dose,
#     Children_<5_with_at_least_one_dose,
#     Total_number_of_updated_(bivalent)_booster_doses_administered,
#     PDate,
#     DDate
# ]

