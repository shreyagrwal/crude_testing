import os
import sys
import pysftp
import shutil
import zipfile
import numpy as np
import pandas as pd
from datetime import datetime

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

log = ag_log.get_log()
env = se.environment
bulkUploaderFolder = se.ingestion_folder


def get_max_pdate():
    query = '''
    SELECT MAX(PDate) AS PDate FROM hive_metastore.dataengineering.oil_rystad_rystadproduction where IsActive = True
    '''
    pdates = bo.get_data(query)['PDate']

    return pdates[0]


def ftp_download():
    host = "ftp.rystadenergy.com"
    password = "5tgb%TGB1qaz!QAZ"
    username = "ftppetroineosuser01"
    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None
    with pysftp.Connection(host, username=username, password=password, cnopts=cnopts ) as sftp:
        sftp.get(remotepath='/OilMarketCube/OilMarketCube.zip', localpath=temp_path+'OilMarketCube.zip')


def get_rystad_data(dataset):
    filename = dataset + '.csv'
    df = pd.read_csv(os.path.join(unzipped_path, filename), sep='|', encoding='cp1252')
    return df


def unzip(sfolder, filename, dfolder):
    if (os.path.isfile(os.path.join(sfolder, filename))):
        if (filename.endswith(".zip")):
            with zipfile.ZipFile(os.path.join(sfolder, filename), 'r') as zip_ref:
                zip_ref.extractall(dfolder)
            log.debug("unzip file {} complete".format(filename))
        else:
            log.debug("No .zip file found")


def process_production_data():
    # Get Production File
    df_production = get_rystad_data('Production')
    df_production.set_index('Id')
    log.debug(df_production.columns)
    # Meta Data
    df_metadata = get_rystad_data('Metadata')
    df_production = pd.merge(df_production, df_metadata, left_on='FK_Metadata', right_on='Id', how='left')
    del df_metadata
    # Timeline
    df_timeline = get_rystad_data('Timeline')
    df_production = pd.merge(df_production, df_timeline, left_on='FK_TimeLine', right_on='Id', how='left')
    del df_timeline
    # Location
    # all fields at this point in df_production
    # Id_x,FK_Asset_x,FK_OtherParameters,FK_CrudeStream,FK_DataQuality,FK_AssetLifeCycle,FK_LifeCycleTS,FK_OilAndGasType,FK_Outage,FK_AssetCompany,FK_Sulphur,FK_TimeLine,FK_OilOilAndGas,Production,Production wo Seasonality,FK_Metadata,Id_y,Asset Type,Asset,Discovery Decade,Discovery Five Year,Discovery Year,Facility Category,Facility Group,Field Size Category,Field Size Group,Field Type Category,Field Type Detail,Operator Segment,Operator,Start Up Five Year,Supply Segment Group,Water Depth Category ft,Water Depth Category,Water Depth Group ft,Water Depth Group,Fiscal Regime Group,Project,Unconventional Category,Unconventional Detail,Unconventional Group,EIA DPR Region,EIA Refining District,RE ID,Shale plays,Start-Up Year,Startup Date,FK_Geography,Well Direction,OnOffshore,APIValue,SulphurValue,Oil Classification Group,Basin,SubBasin,Id_x,Crude Export Market,Crude Grade,Crude Stream Category,Crude Stream ID,Id_y,Sulphur Category,Sulphur Detail,Sulphur Group,Id_x,FK_Asset_y,FK_Company,Operator Non-operator,Id_y,Outage Category,Outage Group,Outage Detail,Id,Last Changed,Last Updated,History vs Forecast
    # Selecting interested fields
    df_production = df_production[[
        'Production', 'Year Month', 'Production wo Seasonality', 'FK_Asset', 'FK_OtherParameters', 'FK_CrudeStream',
        'FK_DataQuality', 'FK_AssetLifeCycle', 'FK_LifeCycleTS', 'FK_OilAndGasType', 'FK_Outage', 'FK_AssetCompany',
        'FK_Sulphur', 'FK_TimeLine', 'FK_OilOilAndGas', 'FK_Metadata', 'Last Updated', 'History vs Forecast']]
    df_production.reset_index(inplace=True)
    df_production.rename(columns={'index': 'ProductionId', 'Year Month': 'DDate', 'Production': 'Production',
                                  'Production wo Seasonality': 'Prod_WO_Seasonality', 'Asset Type': 'Asset_Type',
                                  'Asset': 'Asset', 'EIA DPR Region': 'EIA_DPR_Region',
                                  'EIA Refining District': 'EIA_Refining_District', 'RE ID': 'RE_ID',
                                  'Shale plays': 'Shale_Plays', 'Start-Up Year': 'Start_Up_Year',
                                  'Startup Date': 'Startup_Date', 'OnOffshore': 'OnOffshore', 'APIValue': 'APIValue',
                                  'SulphurValue': 'SulphurValue',
                                  'Oil Classification Group': 'Oil_Classification_Group', 'Basin': 'Basin',
                                  'SubBasin': 'SubBasin', 'Crude Export Market': 'Crude_Export_Market',
                                  'Crude Grade': 'Crude_Grade', 'Crude Stream Category': 'Crude_Stream_Category',
                                  'Crude Stream ID': 'Crude_Stream_ID', 'Sulphur Category': 'Sulphur_Category',
                                  'Sulphur Detail': 'Sulphur_Detail', 'Sulphur Group': 'Sulphur_Group',
                                  'Operator Non-operator': 'Operator_Non_operator',
                                  'Outage Category': 'Outage_Category', 'Outage Group': 'Outage_Group',
                                  'Outage Detail': 'Outage_Detail', 'Last Changed': 'Last_Changed',
                                  'Last Updated': 'PDate', 'History vs Forecast': 'History_vs_Forecast',
                                  'OPEC NON-OPEC': 'OPEC_NON_OPEC', 'EIA PADD District': 'EIA_PADD_District'}, inplace=True)

    # Write To File
    log.debug(df_production)

    df_production['DDate'] = df_production['DDate'] + '-01'

    # todo: Create logic to get most recent changes.
    df_production['PDate'] = pd.to_datetime(df_production['PDate'])
    last_pdate = get_max_pdate()
    df_production = df_production[df_production['PDate'] > last_pdate]

    assets = pd.unique(df_production['FK_Asset'])

    for asset in assets:
        result_production_filefullname = os.path.join(bulk_uploader_folder,
                                                      result_production_file + "-" + str(asset) + "-" + datetime.today().strftime(
                                                          format_datetime) + ".csv")

        # df_production[df_production['FK_Asset']==asset].to_csv(path_or_buf=result_production_filefullname, header=True, index=False, float_format='%.6f')
        su.upload_to_database(df_production[df_production['FK_Asset'] == asset], result_production_file + "-" + str(asset) + "-", float_format='%.6f')


def process_demand_data():
    df_demand = get_rystad_data('Demand')
    df_demand.set_index('Id')
    log.debug(df_demand.columns)
    # Enrich Demand Data
    # Timeline
    df_timeline = get_rystad_data('Timeline')
    df_demand = pd.merge(df_demand, df_timeline, left_on='FK_Timeline', right_on='Id', how='left')
    del df_timeline
    # Product
    # Sector
    # Meta Data
    df_metadata = get_rystad_data('Metadata')
    df_demand = pd.merge(df_demand, df_metadata, left_on='FK_Metadata', right_on='Id', how='left')
    del df_metadata
    # Location

    df_demand = df_demand[[
        'FK_Location', 'FK_Timeline', 'FK_Product', 'FK_Sector',
        'FK_Metadata', 'Demand_BaseCase', 'Demand_HighCase', 'Demand_LowCase',
        'Demand_Additional_case_1', 'Demand_Additional_case_2',
        'Demand_Additional_case_3', 'Demand_Additional_case_4','Year Month']]
    df_demand.reset_index(inplace=True)
    df_demand.rename(columns={'index': 'DemandId', 'Year Month': 'DDate', 'Production': 'Production',
                              'Production wo Seasonality': 'Prod_WO_Seasonality', 'Asset Type': 'Asset_Type',
                              'Asset': 'Asset', 'EIA DPR Region': 'EIA_DPR_Region',
                              'EIA Refining District': 'EIA_Refining_District', 'RE ID': 'RE_ID',
                              'Shale plays': 'Shale_Plays', 'Start-Up Year': 'Start_Up_Year',
                              'Startup Date': 'Startup_Date', 'OnOffshore': 'OnOffshore', 'APIValue': 'APIValue',
                              'SulphurValue': 'SulphurValue',
                              'Oil Classification Group': 'Oil_Classification_Group', 'Basin': 'Basin',
                              'SubBasin': 'SubBasin', 'Crude Export Market': 'Crude_Export_Market',
                              'Crude Grade': 'Crude_Grade', 'Crude Stream Category': 'Crude_Stream_Category',
                              'Crude Stream ID': 'Crude_Stream_ID', 'Sulphur Category': 'Sulphur_Category',
                              'Sulphur Detail': 'Sulphur_Detail', 'Sulphur Group': 'Sulphur_Group',
                              'Operator Non-operator': 'Operator_Non_operator',
                              'Outage Category': 'Outage_Category', 'Outage Group': 'Outage_Group',
                              'Outage Detail': 'Outage_Detail', 'Last Changed': 'Last_Changed',
                              'Last Updated': 'Last_Updated', 'History vs Forecast': 'History_vs_Forecast',
                              'OPEC NON-OPEC': 'OPEC_NON_OPEC', 'EIA PADD District': 'EIA_PADD_District',
                              }, inplace=True)
    df_demand['PDate'] = datetime.today().strftime("%Y-%m-%d")
    df_demand['DDate'] = df_demand['DDate'] + '-01'
    locations = pd.unique(df_demand['FK_Location'])

    for l in locations:
        result_demand_filefullname = os.path.join(bulk_uploader_folder, result_demand_file + "-" + str(l) + "-" + datetime.today().strftime(format_datetime) + ".csv")
        # df_demand[df_demand['FK_Location']==l].to_csv(path_or_buf=result_demand_filefullname, header=True, index=False, float_format='%.6f')
        su.upload_to_database(df_demand[df_demand['FK_Location'] == l], result_demand_file + "-" + str(l) + "-", float_format='%.6f')


def unzipfile():
    if os.path.exists(unzipped_path):
        shutil.rmtree(unzipped_path)
    unzip(temp_path, rystad_zipfile_name, unzipped_path)


# Getting static data out
def ExtractToCsv(name):
    df_geography = get_rystad_data(name)
    result_file = 'Upload_oil_rystad'+name+'-'
    result_full_filename = os.path.join(bulk_uploader_folder,
                                        result_file + datetime.today().strftime(format_datetime) + ".csv")
    # df_geography.to_csv(path_or_buf=result_full_filename, header=True, index=False, float_format='%.6f')
    su.upload_to_database(df_geography, result_file, header=True, index=False, float_format='%.6f')


# Archive

def archive():
    shutil.move(temp_path + "\\" + rystad_zipfile_name,
                temp_path + "\\archive\\" + rystad_zipfile_name + '.' + datetime.today().strftime(format_datetime))

# Processing


def process_opeccut():
    global df_opeccut
    opec_name = "OPECCut"
    df_opeccut = get_rystad_data(opec_name)
    df_opeccut.columns = df_opeccut.columns.str.replace(" ", "_")
    result_file = 'Upload_OIL_' + opec_name + '-'
    result_full_filename = os.path.join(bulk_uploader_folder, result_file + datetime.today().strftime(format_datetime) + ".csv")
    # df_opeccut.to_csv(path_or_buf=result_full_filename, header=True, index=False, float_format='%.6f')
    su.upload_to_database(df_opeccut, result_file, header=True, index=False, float_format='%.6f')


def process_production_country_data():
    ####################Get Production File
    df_production = get_rystad_data('Production')
    df_production.set_index('Id')
    #df_production = df_production.head(1000)
    #log.debug(df_production.columns)
    ######################Enrich Production File#########################
    ##### Crude Stream ###################
    df_crudestream = get_rystad_data('CrudeStream')[['Id','Crude Grade']]
    df_production = pd.merge(df_production, df_crudestream, left_on='FK_CrudeStream', right_on='Id', how='left')
    del df_crudestream
    ##### OilAndGas ###################
    df_oilandgas = get_rystad_data('OilAndGas')[['Id','API Group']]
    df_production = pd.merge(df_production, df_oilandgas, left_on='FK_OilOilAndGas', right_on='Id', how='left')
    del df_oilandgas
    ##### Sulphur ##############
    df_sulphur = get_rystad_data('Sulphur')[['Id','Sulphur Group']]
    df_production = pd.merge(df_production, df_sulphur, left_on='FK_Sulphur', right_on='Id', how='left')
    del df_sulphur
    #########Asset############
    df_asset = get_rystad_data('Asset')[['Id', 'FK_Geography']]
    df_production = pd.merge(df_production, df_asset, left_on='FK_Asset', right_on='Id', how='left')
    del df_asset
    #######Outage##############
    df_outage = get_rystad_data('Outage')[['Id', 'Outage Group', 'Outage Detail']]
    df_production = pd.merge(df_production, df_outage, left_on='FK_Outage', right_on='Id', how='left')
    del df_outage
    #######Meta Data##############
    df_metadata = get_rystad_data('Metadata')[['Id', 'Last Updated']]
    df_production = pd.merge(df_production, df_metadata, left_on='FK_Metadata', right_on='Id', how='left')
    del df_metadata
    #######Timeline##############
    df_timeline = get_rystad_data('Timeline')[['Id','Year Month']]
    df_production = pd.merge(df_production, df_timeline, left_on='FK_TimeLine', right_on='Id', how='left')
    del df_timeline
    #######Location##############
    df_location = get_rystad_data('Geography')[['Id','Country']]
    df_production = pd.merge(df_production, df_location, left_on='FK_Geography', right_on='Id', how='left')
    del df_location
    ##################################################################################
    # all fields at this point in df_production
    # Id_x,FK_Asset_x,FK_OtherParameters,FK_CrudeStream,FK_DataQuality,FK_AssetLifeCycle,FK_LifeCycleTS,FK_OilAndGasType,FK_Outage,FK_AssetCompany,FK_Sulphur,FK_TimeLine,FK_OilOilAndGas,Production,Production wo Seasonality,FK_Metadata,Id_y,Asset Type,Asset,Discovery Decade,Discovery Five Year,Discovery Year,Facility Category,Facility Group,Field Size Category,Field Size Group,Field Type Category,Field Type Detail,Operator Segment,Operator,Start Up Five Year,Supply Segment Group,Water Depth Category ft,Water Depth Category,Water Depth Group ft,Water Depth Group,Fiscal Regime Group,Project,Unconventional Category,Unconventional Detail,Unconventional Group,EIA DPR Region,EIA Refining District,RE ID,Shale plays,Start-Up Year,Startup Date,FK_Geography,Well Direction,OnOffshore,APIValue,SulphurValue,Oil Classification Group,Basin,SubBasin,Id_x,Crude Export Market,Crude Grade,Crude Stream Category,Crude Stream ID,Id_y,Sulphur Category,Sulphur Detail,Sulphur Group,Id_x,FK_Asset_y,FK_Company,Operator Non-operator,Id_y,Outage Category,Outage Group,Outage Detail,Id,Last Changed,Last Updated,History vs Forecast
    # Selecting interested fields
    df_production = df_production[
        ['Last Updated', 'Year Month', 'Production','Production wo Seasonality', 'Country', 'Sulphur Group', 'Outage Group',
       'Outage Detail', 'Crude Grade', 'API Group']]
    log.debug(df_production.columns)
    df_production.reset_index(inplace=True)
    df_production.rename(columns={'index': 'ProductionId', 'Year Month': 'DDate', 'Production': 'Production',
                                  'Production wo Seasonality': 'Prod_WO_Seasonality', 'Asset Type': 'Asset_Type',
                                  'Asset': 'Asset', 'EIA DPR Region': 'EIA_DPR_Region',
                                  'EIA Refining District': 'EIA_Refining_District', 'RE ID': 'RE_ID',
                                  'Shale plays': 'Shale_Plays', 'Start-Up Year': 'Start_Up_Year',
                                  'Startup Date': 'Startup_Date', 'OnOffshore': 'OnOffshore', 'APIValue': 'APIValue',
                                  'SulphurValue': 'SulphurValue',
                                  'Oil Classification Group': 'Oil_Classification_Group', 'Basin': 'Basin',
                                  'SubBasin': 'SubBasin', 'Crude Export Market': 'Crude_Export_Market',
                                  'Crude Grade': 'Crude_Grade', 'Crude Stream Category': 'Crude_Stream_Category',
                                  'Crude Stream ID': 'Crude_Stream_ID', 'Sulphur Category': 'Sulphur_Category',
                                  'Sulphur Detail': 'Sulphur_Detail', 'Sulphur Group': 'Sulphur_Group',
                                  'Operator Non-operator': 'Operator_Non_operator',
                                  'Outage Category': 'Outage_Category', 'Outage Group': 'Outage_Group',
                                  'Outage Detail': 'Outage_Detail', 'Last Changed': 'Last_Changed',
                                  'Last Updated': 'PDate', 'History vs Forecast': 'History_vs_Forecast',
                                  'OPEC NON-OPEC': 'OPEC_NON_OPEC', 'EIA PADD District': 'EIA_PADD_District',
                                  'Outage Detail':'Outage_Detail', 'Crude Grade':'Crude_Grade','Sulphur_Group':'Sulphur Group',
                                  'API Group':'API_Group', 'OUTAGE_GROUP':'OUTAGE GROUP','Country':'Country'}, inplace=True)
    # df_production['DDate'] = pd.to_datetime(df_production['DDate'], format='%Y%m%d')
    ###########Write To File##########################################################

    df_production['DDate'] = df_production['DDate'] + '-01'
    df_production['Country'] = df_production['Country'].str.replace(',', ';').replace('"', '').replace("'", '')
    df_production['Outage_Detail'] = df_production['Outage_Detail'].str.replace(',', ';').replace('"', '').replace("'", '')

    # todo: Create logic to get most recent changes.
    df_production['PDate'] = pd.to_datetime(df_production['PDate'])
    last_pdate = get_max_pdate()
    df_production = df_production[df_production['PDate'] > last_pdate]

    df_production = pd.pivot_table(df_production, index=['PDate', 'DDate', 'Country', 'Sulphur_Group', 'Outage_Group', 'Outage_Detail', 'Crude_Grade', 'API_Group'], values=['Production','Prod_WO_Seasonality'], aggfunc=np.sum)
    df_production.reset_index(inplace=True)

    countries = pd.unique(df_production['Country'])

    for country in countries:
        country = country.replace("/", '').replace(" ",'')
        result_production_filefullname = os.path.join(bulk_uploader_folder,
                                                      'Upload_OIL_RystadProductionCountry' + "-" + str(country) + "-" + datetime.today().strftime(
                                                          format_datetime) + ".csv")

        # df_production[df_production['Country'] == country].to_csv(path_or_buf=result_production_filefullname, header=True, index=False, float_format='%.6f')
        su.upload_to_database(df_production[df_production['Country'] == country], 'Upload_OIL_RystadProductionCountry' + "-" + str(country) + "-",  float_format='%.6f')


def process_demand_country_data():
    df_demand = get_rystad_data('Demand')
    #df_demand = df_demand.head(100)
    df_demand.set_index('Id')
    log.debug(df_demand.columns)
    ######################Enrich Demand Data#########################
    ###### Timeline #################
    df_timeline = get_rystad_data('Timeline')[['Id','Year Month']]
    df_demand = pd.merge(df_demand, df_timeline, left_on='FK_Timeline', right_on='Id', how='left')
    del df_timeline
    #########Product####################
    df_product = get_rystad_data('Product')[['Id','ProductCategory']]
    df_demand = pd.merge(df_demand, df_product, left_on='FK_Product', right_on='Id', how='left')
    del df_product
    #########Sector####################
    df_sector = get_rystad_data('Sector')[['Id', 'SectorGroup']]
    df_demand = pd.merge(df_demand, df_sector, left_on='FK_Sector', right_on='Id', how='left')
    del df_sector
    #######Meta Data##############
    df_metadata = get_rystad_data('Metadata')[['Id', 'Last Updated']]
    df_demand = pd.merge(df_demand, df_metadata, left_on='FK_Metadata', right_on='Id', how='left')
    del df_metadata
    #######Location##############
    df_location = get_rystad_data('Geography')[['Id','Country']]
    df_demand = pd.merge(df_demand, df_location, left_on='FK_Location', right_on='Id', how='left')
    del df_location
    ###################################################################
    df_demand = df_demand[
        ['Country', 'ProductCategory', 'SectorGroup',
       'Demand_BaseCase', 'Demand_HighCase', 'Demand_LowCase',
       'Demand_Additional_case_1', 'Demand_Additional_case_2',
       'Demand_Additional_case_3', 'Demand_Additional_case_4','Year Month']]
    df_demand.reset_index(inplace=True)
    df_demand.rename(columns={'index': 'DemandId', 'Year Month': 'DDate', 'Production': 'Production',
                              'Production wo Seasonality': 'Prod_WO_Seasonality', 'Asset Type': 'Asset_Type',
                              'Asset': 'Asset', 'EIA DPR Region': 'EIA_DPR_Region',
                              'EIA Refining District': 'EIA_Refining_District', 'RE ID': 'RE_ID',
                              'Shale plays': 'Shale_Plays', 'Start-Up Year': 'Start_Up_Year',
                              'Startup Date': 'Startup_Date', 'OnOffshore': 'OnOffshore', 'APIValue': 'APIValue',
                              'SulphurValue': 'SulphurValue',
                              'Oil Classification Group': 'Oil_Classification_Group', 'Basin': 'Basin',
                              'SubBasin': 'SubBasin', 'Crude Export Market': 'Crude_Export_Market',
                              'Crude Grade': 'Crude_Grade', 'Crude Stream Category': 'Crude_Stream_Category',
                              'Crude Stream ID': 'Crude_Stream_ID', 'Sulphur Category': 'Sulphur_Category',
                              'Sulphur Detail': 'Sulphur_Detail', 'Sulphur Group': 'Sulphur_Group',
                              'Operator Non-operator': 'Operator_Non_operator',
                              'Outage Category': 'Outage_Category', 'Outage Group': 'Outage_Group',
                              'Outage Detail': 'Outage_Detail', 'Last Changed': 'Last_Changed',
                              'Last Updated': 'Last_Updated', 'History vs Forecast': 'History_vs_Forecast',
                              'OPEC NON-OPEC': 'OPEC_NON_OPEC', 'EIA PADD District': 'EIA_PADD_District',
                              }, inplace=True)
    df_demand['PDate'] = datetime.today().strftime("%Y-%m-%d")
    df_demand['DDate'] = df_demand['DDate'] + '-01'
    df_demand['Country'] = df_demand['Country'].str.replace(',', ';').replace('"', '').replace("'", '')

    df_demand = pd.pivot_table(df_demand, index=['Country', 'ProductCategory', 'SectorGroup', 'PDate','DDate'], values=['Demand_BaseCase', 'Demand_HighCase', 'Demand_LowCase', 'Demand_Additional_case_1', 'Demand_Additional_case_2', 'Demand_Additional_case_3', 'Demand_Additional_case_4'], aggfunc=np.sum)
    df_demand.reset_index(inplace=True)

    locations = pd.unique(df_demand['Country'])

    for l in locations:
        l = l.replace("/", '').replace(" ", '')
        result_demand_filefullname = os.path.join(bulk_uploader_folder,
                                                  'Upload_OIL_RystadDemandCountry' + "-" + str(l) + "-" + datetime.today().strftime(format_datetime) + ".csv")
        # df_demand[df_demand['Country']==l].to_csv(path_or_buf=result_demand_filefullname, header=True, index=False, float_format='%.6f')
        su.upload_to_database(df_demand[df_demand['Country'] == l], 'Upload_OIL_RystadDemandCountry' + "-" + str(l) + "-", float_format='%.6f')


log.debug("Env:" + env)
temp_path = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RystadOilProduction\\'

# Input
unzipped_path = os.path.join(temp_path, "unzipped")
rystad_zipfile_name = 'OilMarketCube.zip'
production_filename = 'Production.csv'
demand_file_name = 'Demand.csv'


###############Output######################################
result_production_file = 'Upload_oil_rystadproduction-'
result_demand_file = 'Upload_oil_rystaddemand-'
format_datetime = '%y%m%d%H%M%S'
bulk_uploader_folder = bulkUploaderFolder


###################Unzip##################################


try:
    log.debug('download new file from sftp server')
    ftp_download()
    log.debug('unzip file')
    unzipfile()
    log.debug('processing production data')
    process_production_data()
    log.debug('processing demand data')
    process_demand_data()
    log.debug('Process production country data')
    process_production_country_data()
    log.debug('Process demand country data')
    process_demand_country_data()
    #log.debug('only use it for static data extraction')
    #ExtractToCsv('Production')
    log.debug('Process OPEC Cut')
    process_opeccut()
    log.debug('Archive data')
    archive()
except Exception as e:
    log.debug(e)
