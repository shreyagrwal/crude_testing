import logging
import os
import dotenv
from kpler.sdk import Platform
from datetime import datetime as dt
from kpler.sdk.resources.trades import Trades
from dateutil.relativedelta import relativedelta
from kpler.sdk.configuration import Configuration

from ag_log import ag_log
from ag_data_access import data_upload as du
from ag_secrets import SecretsClient


dotenv.load_dotenv(override=True)
log = ag_log.get_log()
logging.info("Start...")
env = os.environ["environment"]

if env == 'PROD':
    path = 'OIL'
else:
    # path = 'OILUAT'
    path = 'OIL'
threshold = dt.today().replace(day=1) - relativedelta(months=3)

short_cols = [
    'trade_id',
    'shipment_id',
    'status',
    'vessel_imo',
    "vessel_name",
    'vessel_name_2',
    'vessel_name_3',
    'closest_ancestor_group',
    "closest_ancestor_product",
    "closest_ancestor_grade",
    'closest_ancestor_grade_api',
    'closest_ancestor_grade_sulfur',
    'cargo_origin_barrels_split_by_product',
    "start",
    "end",
    "origin_location_name",
    'installation_origin_name',
    'origin_country_name',
    'zone_origin_name',
    'origin_subcontinent_name',
    'continent_origin_name',
    'initial_seller_name',
    'charterer_name',
    "destination_location_name",
    'installation_destination_name',
    'destination_country_name',
    'zone_destination_name',
    'destination_subcontinent_name',
    'continent_destination_name',
    'final_buyer_name',
    'origin_eta_source',
    'destination_eta_source',
    'cargo_sources'
]

logging.info("Configuration File.")
client = SecretsClient()
kpler_credential=client.get_secret(name="kpler_oil")
logging.info("Going to connect")
config = Configuration(Platform.Liquids, kpler_credential.username, kpler_credential.password, log_level="INFO")
logging.info('connection successful')

trades_client = Trades(config)

all_cargoes = trades_client.get(
    with_forecast=True,
    with_intra_country=False,
    start_date=threshold,
    columns=short_cols
)

logging.info('API call successful')
logging.info('duplicates deleted')

all_cargoes = all_cargoes.replace(',','_', regex=True)
all_cargoes = all_cargoes.replace("'"," ", regex=True)

all_cargoes.rename(columns={'start':'voyage_start', 'end':'voyage_end'}, inplace=True)
today = dt.now().date().strftime('%y-%m-%d')

du.upload_to_database(data=all_cargoes, filename_prefix='Upload_'+path+'_KplerTrades-', env=os.environ["environment"].upper(), index=False)
logging.info('CSV updated')
logging.info("All done")