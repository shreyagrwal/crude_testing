import os
import sys
import pandas as pd
from datetime import datetime, timedelta

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder
log = ag_log.get_log()

log.debug("Env:" + env)

log.debug("Read CSV file from Website.")
df = pd.read_csv('https://raw.githubusercontent.com/OxCGRT/covid-policy-tracker/master/data/OxCGRT_latest.csv')

log.debug("Cleansing the CSV file")
df.columns = df.columns.str.replace(' ', '_')
df.columns = df.columns.str.replace('/', '')
df.columns = df.columns.str.replace('\\', '')
df.columns = df.columns.str.replace('(', '')
df.columns = df.columns.str.replace(')', '')
df.columns = df.columns.str.replace('-', '')
df.columns = df.columns.str.replace('__', '_')
df = df.rename(columns={'Date':'PDate'})
df['CountryName'] = df['CountryName'].str.replace("'", "").replace('"', "")
df['PDate'] = pd.to_datetime(df['PDate'], format='%Y%m%d')
df = df[df['PDate'] > datetime.today() + timedelta(days=-7)]


bulk_uploader_folder = bulkUploaderFolder

filename = 'Upload_OIL_StringencyIndex-'
format_datetime = '%y%m%d%H%M%S'

filefullname = os.path.join(bulk_uploader_folder, filename+ datetime.today().strftime(format_datetime)+".csv")

log.debug("CSV File Saved to: {0}.".format(filefullname))
# df.to_csv(path_or_buf=filefullname,header=True,index=False)
su.upload_to_database(df, filename)
