__doc__ = f""" 
OAG Flight Schedule URL Scraper

Before this job can be triggered, the email rule 'OAG Analyser - Run Script' must be run, to generate report URLs
which are then scraper and process.

TODO: find out how the OAG email script is saved and run

:param Developer: Charles Cai (Charles.Cai@pPetroIneos.com)
:param Owner: Charles Cai (Charles.Cai@pPetroIneos.com)
:param DatabaseTable: [hive_metastore.dataengineering.oil_jet_flightscheduleoagmonthly2, hive_metastore.dataengineering.oil_jet_flightscheduleoagweekly, hive_metastore.dataengineering.oil_jet_genericmappingsoag
:param ActiveBatchJob: Oag Flight Schedule File Scraper
:param Server: AP3
:param Schedule: Monday Mornings (before midday)
:param Notes: Steps to complete checks for Flight Radar ->
      1. Go to AP2
      2. Go to outlook, and ensure all 24 emails from OAG have arrived.
      3. Go to Outlook, Rules, Manage Rules and Alerts, run Rules Now..
      4. Select 'OAG Analyser - Run Script' and click run
      5. Go to the folder: '\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\Oag'
      6. Go inside the folder 'Urls', each of the 24 text files should contain a URL
      7. (Optional) Trigger the OAG Active Batch Job 
      8. Note - correct run time is approximately 20 minutes
"""

import os
import sys
import time
import shutil
import zipfile
import datetime
import requests
import warnings
import glob as gb
import pandas as pd
from selenium import webdriver
from calendar import monthrange
from selenium.webdriver.chrome.service import Service

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder

appfolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\Oag'


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    # Debug mode disabled
    # if sys.gettrace() is None:  # Check if it's in Debug model
        # chrome_options.add_argument('--headless')
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": appfolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")
    #browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)
    service = Service(executable_path='.\\tools\\chromedriver.exe')
    browser = webdriver.Chrome(service=service, options=chrome_options)
    return browser


def unzip(sfolder, filename, dfolder):
    if (os.path.isfile(os.path.join(sfolder, filename))):
        if (filename.endswith(".zip")):
            with zipfile.ZipFile(os.path.join(sfolder, filename), 'r') as zip_ref:
                zip_ref.extractall(dfolder)
            log.debug("unzip file {} complete".format(filename))
        else:
            log.debug("No .zip file found")


def unzipall():
    for f in gb.glob("*.zip"):
        try:
            log.debug("Try to unzip file: " + f)
            unzip(appfolder, f, appfolder)
            shutil.move(appfolder + "\\" + f, appfolder + "\\ZipArchive\\" + f)
            log.debug('Upzip OK.')
        except Exception as e:
            log.debug(e)
            shutil.move(appfolder + "\\" + f, appfolder + "\\Error\\" + f)
            log.debug("Upzip Failed, File {} Moved to Error Folder.".format(f))


def upload(csvfile, tenor):

    bulk_uploader_folder = r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\BatchUploader\PROD"
    cloud_uploader_folder = bulkUploaderFolder
    # cloud_uploader_folder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\AzureDataUploader\OIL'

    filename = 'Upload_OIL_FlightScheduleOagWeekly-'
    # cloud_filename = 'OIL-Jet-FlightScheduleOagWeekly-'
    cloud_filename = 'Upload_OIL_FlightScheduleOagWeekly-'

    if tenor == "monthly":
        filename = 'Upload_OIL_FlightScheduleOagMonthly2-'
        # cloud_filename = 'OIL-Jet-FlightScheduleOagMonthly-'
        cloud_filename = 'Upload_OIL_FlightScheduleOagMonthly2-'

    format_datetime = '%y%m%d%H%M%S'
    full_filename = bulk_uploader_folder + "\\" + filename + datetime.datetime.now().strftime(format_datetime) + ".csv"
    cloud_filename = cloud_uploader_folder + "\\" + cloud_filename + datetime.datetime.now().strftime(format_datetime) + ".csv"

    log.debug('Cleansing File: ' + full_filename)
    file_day = datetime.datetime.fromtimestamp(os.stat(csvfile).st_mtime)

    df = pd.read_csv(csvfile)
    df.columns = [
        'DepAirport', 'DepAirportName', 'DepCityName', 'DepIATACtry', 'DepIATACtryName', 'DepReg', 'DepRegName',
        'DepState', 'DepStateName', 'ArrAirportName', 'ArrCityName', 'ArrIATACtry', 'ArrIATACtryName', 'ArrReg',
        'ArrRegName', 'ArrState', 'ArrStateName', 'ArrAirport', 'InternationalDomestic', 'GeneralAcft',
        'GeneralAcftName', 'DistKm', 'Service', 'Carrier1', 'FlyingTime (Minutes)', 'Frequency', 'Time series'
    ]
    if tenor == "monthly":
        df['Time series'] = df['Time series'] + '-01'
    df['PDate'] = file_day - datetime.timedelta(days=file_day.weekday())

    df = df.replace(',', '', regex=True)
    df = df.replace("'", '', regex=True)
    df['ArrIATACtry'] = df['ArrIATACtry'].apply(lambda x: 'NA' if not x else x)
    df = df.fillna('NA')

    df = df.rename(columns={
        'DepAirport': 'DepAirportCode', 'DepAirportName': 'DepAirportName', 'DepCityName': 'DepCityName',
        'DepIATACtry': 'DepCountryCode', 'DepIATACtryName': 'DepCountryName', 'DepReg': 'DepRegionCode',
        'DepRegName': 'DepRegionName', 'DepState': 'DepStateCode', 'DepStateName': 'DepStateName',
        'ArrAirportName': 'ArrAirportName', 'ArrCityName': 'ArrCityName', 'ArrIATACtry': 'ArrCountryCode',
        'ArrIATACtryName': 'ArrCountryName', 'ArrReg': 'ArrRegionCode', 'ArrRegName': 'ArrRegionName',
        'ArrState': 'ArrStateCode', 'ArrStateName': 'ArrStateName', 'ArrAirport': 'ArrAirportCode',
        'InternationalDomestic': 'InternationalDomestic', 'GeneralAcft': 'GeneralAircraftCode',
        'GeneralAcftName': 'GeneralAircraftName', 'DistKm': 'GCD', 'Carrier1': 'Carrier', 'Service': 'ServiceType',
        'FlyingTime (Minutes)': 'FlyingTime', 'Time series': 'DDate'
    })

    log.debug("CSV File Saved to: {0}.".format(full_filename))
    su.upload_to_database(df, filename)

    df_cloud = df
    df_cloud["Created"] = datetime.datetime.now()
    df_cloud["Modified"] = datetime.datetime.now()
    log.debug("Cloud CSV File Saved to: {0}.".format(cloud_filename))
    # df_cloud.to_csv(cloud_filename, index=False)
    del df_cloud

    if tenor == "monthly":
        log.debug("Generate Demand File for Monthly Data.")
        generate_demand_file(df)


def get_aircraft_fuel_consumption():
    query = '''
        SELECT OagAircraftName, FuelConsumptionKgh
        FROM hive_metastore.dataengineering.oil_jet_aircraftfuelconsumption
        where IsActive = True
    '''
    return bo.get_data(query)


def get_benchmark_params(benchmark):
    if benchmark == 'IEA':
        query = '''
            WITH 
            CM AS
                (
                SELECT SourceValue AS OagCountry, DestValue AS Ieacountry
                FROM hive_metastore.dataengineering.oil_jet_genericmappingsoag
                WHERE Source = 'oag'
                AND IsActive = True
                AND SourceQualifier = 'countrycode'
                AND Dest = 'IEACountry'
                )
            SELECT  cm.OagCountry, p.a, p.b
            FROM cm
            LEFT JOIN hive_metastore.dataengineering.oil_jet_jetfueldemandparams AS P
            ON P.BenchmarkRegion = cm.Ieacountry
            WHERE IsActive = True
            AND P.Benchmark = ''' + "'" + benchmark + "'"
    elif benchmark == 'JODI':
        query = '''
            SELECT  p.BenchmarkRegion as OagCountry, p.a, p.b
            FROM hive_metastore.dataengineering.oil_jet_jetfueldemandparams AS P
            WHERE P.Benchmark = 'JODI' 
            AND IsActive = True
        '''
    elif benchmark == 'EnergyAspect':
        query = '''
            WITH 
                CM AS 
                    (
                    SELECT SourceValue AS OagCountry, DestValue AS EnergyAspectCountry
                    FROM hive_metastore.dataengineering.oil_jet_genericmappingsoag
                    WHERE	Source = 'oag'
                    AND IsActive = True
                    AND	SourceQualifier = 'countrycode'
                    AND	Dest = 'EnergyAspectCountry'
                    )
                SELECT cm.OagCountry, p.a, p.b
                FROM cm
                LEFT JOIN hive_metastore.dataengineering.oil_jet_jetfueldemandparams AS P
                ON P.BenchmarkRegion = cm.EnergyAspectCountry
                WHERE P.Benchmark = 'EnergyAspect'
                AND IsActive = True
        '''
    else:
        raise Exception
    return bo.get_data(query)


def get_day_count_of_month(date_str):
    date = datetime.datetime.strptime(date_str, '%Y-%m-%d')
    weekday_of_first_day, day_count = monthrange(date.year, date.month)
    return day_count


def generate_demand_file(df_oag):

    log.debug("Remove Russia outside of EU2")
    df_oag = df_oag.loc[~((df_oag['DepCountryCode'] == 'RU') & (df_oag['DepRegionCode'] != 'EU2'))]

    log.debug("Getting Aircraft Fuel Consumption.")
    df_aircraft_fuel_consumption = get_aircraft_fuel_consumption()

    df_oag = pd.merge(df_oag, df_aircraft_fuel_consumption, how='left', left_on='GeneralAircraftName', right_on='OagAircraftName')
    # df_oag.to_csv(r"C:\Public\Test\data.csv", index=False)
    df_oag['MonthlyConsumptionMt'] = df_oag.apply(lambda x: (x['FlyingTime'] * x['FuelConsumptionKgh'])/60, axis = 1)
    df_oag['MonthlyConsumptionKBD'] = df_oag.apply(lambda x: (x['FlyingTime'] * x['FuelConsumptionKgh'])/get_day_count_of_month(x['DDate']), axis=1)

    del df_aircraft_fuel_consumption

    df_sum = df_oag.groupby(['PDate', 'DDate', 'DepCountryName', 'DepCountryCode'])['MonthlyConsumptionMt','MonthlyConsumptionKBD'].sum().reset_index()
    df_sum['MonthlyConsumptionMt'] = df_sum['MonthlyConsumptionMt'] / 1000000.0
    df_sum['MonthlyConsumptionKBD'] = df_sum['MonthlyConsumptionKBD'] / 1000000.0

    df_sum_region = df_oag.groupby(['PDate', 'DDate', 'DepRegionName', 'DepRegionCode'])['MonthlyConsumptionMt','MonthlyConsumptionKBD'].sum().reset_index()
    df_sum_region['MonthlyConsumptionMt'] = df_sum_region['MonthlyConsumptionMt'] / 1000000.0
    df_sum_region['MonthlyConsumptionKBD'] = df_sum_region['MonthlyConsumptionKBD'] / 1000000.0

    del df_oag

    # generate all IEA forecast
    log.debug("Generating All IEA Forecast.")
    log.debug("Benchmark IEA.")
    df_iea = benchmark(df_sum, 'IEA')
    log.debug("Benchmark JODI.")
    df_jodi = benchmark(df_sum, 'JODI')
    log.debug("Benchmark Energy Aspect.")
    df_energyaspecit = benchmark(df_sum, 'EnergyAspect')

    df_forecast = pd.concat([df_iea,df_jodi,df_energyaspecit])

    # Only process EU1 at the moment
    log.debug("Calculating Total Region Consumption - EU1.")
    df_eu1 = df_sum_region[df_sum_region['DepRegionCode'] == 'EU1']
    if not df_eu1.empty:
        df_eu1_forecast = benchmark_iea_region(df_eu1)
        df_forecast = pd.concat([df_forecast, df_eu1_forecast])

    bulk_uploader_folder = bulkUploaderFolder
    filename = 'Upload_OIL_JetFuelDemand2-'

    format_datetime = '%y%m%d%H%M%S'
    full_filename = bulk_uploader_folder + "\\" + filename + datetime.datetime.now().strftime(format_datetime) + ".csv"
    log.debug("CSV File Saved to: {0}.".format(full_filename))
    # df_forecast.to_csv(full_filename, index=False)
    su.upload_to_database(df_forecast, filename)


def benchmark_iea_region(df):
    vendor = 'IEA'
    df_iea_params = get_benchmark_params(vendor)
    df_result = pd.merge(df, df_iea_params, how='left', left_on=['DepRegionCode'], right_on=['OagCountry'])
    del df_iea_params
    df_result = df_result[df_result['a'].isnull() == False]
    df_result['DemandForecast'] = df_result.apply(lambda x: x['MonthlyConsumptionMt'] * x['a'] + x['b'], axis=1)
    # generate all jodi forecast
    df_result = df_result[['PDate', 'DDate', 'DepRegionName', 'DemandForecast']].rename(columns={'DepRegionName': 'Region'})
    df_result['Benchmark'] = vendor
    df_result['UnitMeasure'] = 'MTons'
    return df_result


def benchmark(df, vendor):
    if vendor == 'IEA':
        column_monthly = 'MonthlyConsumptionMt'
    else:
        column_monthly = 'MonthlyConsumptionKBD'
    df_iea_params = get_benchmark_params(vendor)
    df_result = pd.merge(df, df_iea_params, how='left', left_on=['DepCountryCode'], right_on=['OagCountry'])
    del df_iea_params
    df_result = df_result[df_result['a'].isnull() == False]
    if not df_result.empty:
        df_result['DemandForecast'] = df_result.apply(lambda x: x[column_monthly] * x['a'] + x['b'], axis=1)
        # generate all jodi forecast
        df_result = df_result[['PDate', 'DDate', 'DepCountryName', 'DemandForecast']].rename(columns={'DepCountryName': 'Region'})
        df_result['Benchmark'] = vendor
        if vendor == 'IEA':
            df_result['UnitMeasure'] = 'MTons'
        else:
            df_result['UnitMeasure'] = 'KBD'
        return df_result
    else:
        return pd.DataFrame()


def process_all_files():
    for f in gb.glob("*.csv"):
        log.debug("Process File: " + f)
        time.sleep(2)
        try:
            log.debug("Try to Process File: " + f)
            if f.upper().startswith("MONTHLY"):
                upload(f, "monthly")
            else:
                upload(f, "weekly")
            shutil.move(appfolder + "\\" + f, appfolder + "\\Archive\\" + f)
            log.debug('File Process OK')
        except Exception as e:
            log.debug(e)
            shutil.move(appfolder + "\\" + f, appfolder + "\\\\" + f)
            log.debug("Process Failed, File {} Moved to Error Folder.".format(f))


def download_zip_files(browser):
    os.chdir(appfolder + '\\Urls')
    count = 1
    for txt in gb.glob("*.txt"):
        if not '~' in txt:
            try:
                url = open(txt, "r").read()
                browser.get(url)
                shutil.move(appfolder + '\\Urls\\' + txt, appfolder + '\\Urls\\archive\\' + txt)
                log.debug('File Completed: {0}-{1}.'.format(str(count), txt))
                count += 1
                time.sleep(2)
            except Exception as e:
                log.error(e)
                exit(1)


def main():
    try:
        log.debug("Env: " + env)

        # Initiate Chrome Driver
        log.debug("Initiate Chrome Driver.")
        browser = load_chrome_settings()

        # Initiate Chrome Driver
        log.debug('Start to Download File via urls')
        download_zip_files(browser)

        # close and close chrone webdriver
        log.debug('Close and Quit Chrone Webdriver')
        browser.close()
        browser.quit()

        log.debug("Upzip All the Files.")
        os.chdir(appfolder)
        unzipall()

        log.debug("Process All Files.")
        os.chdir(appfolder)
        process_all_files()
        return 0
    except Exception as e:
        log.error(e)
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())