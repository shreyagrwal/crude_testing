import os
import sys
import time
import random
import pandas as pd
from pathlib import Path
from datetime import datetime
from selenium import webdriver
from time import sleep

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_environment as se
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service

env = se.environment
Dev_Mode = False

format_datetime = '%y%m%d%H%M%S'
_today = datetime.today().strftime('%Y-%m-%d')

filename = 'Upload_Gas_GasscoFlow' + '-'
filenamelatest = 'Upload_Gas_GasscoFlowLatest' + '-'
bulk_uploader_folder = se.ingestion_folder
temp_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\Scrapers\oilchem'


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--ignore-ssl-errors=yes")
    chrome_options.add_argument("--ignore-certificate-errors")
    print(os.getcwd())
    service = Service(executable_path='..\\tools\\chromedriver.exe')
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver


def login(browser):
    url_feedstock_prices = 'https://oil.oilchem.net/oil/biodiesel.shtml'
    browser.get(url_feedstock_prices)

    browser.find_element(By.XPATH, '//*[@id="header_menu_top_login"]/a[1]').click()
    browser.find_element(By.NAME, 'username').send_keys('CharlesCai001')
    browser.find_element(By.NAME, 'password').send_keys('CharlesCai001')
    sleep(10)
    browser.find_element(By.XPATH, '//*[@id="smsValid"]').click()
    sleep(10)


def get_all_gutteroil_links(browser):
    df_gutteroil_links = pd.DataFrame(columns=['hyperlink', 'PDate'])
    cache_file_fullname = os.path.join(temp_path, 'gutteroil_links', 'gutteroil_links.csv')

    if os.path.exists(cache_file_fullname):
        return pd.read_csv(cache_file_fullname)

    row_index = 0
    for i in range(1, 36):

        url_feedstock_prices = 'https://list.oilchem.net/4178/49648/' + str(i) + '.html'
        browser.get(url_feedstock_prices)

        report_hyperlinks = browser.find_elements(By.XPATH, '//li[@data-id="0"]')

        for element in report_hyperlinks:
            anchor = element.find_element(by=By.TAG_NAME, value='a')
            href = anchor.get_attribute("href")
            timestamp = element.find_element(by=By.TAG_NAME, value="span").text.replace("[", "").replace("]", "")
            df_gutteroil_links.loc[row_index] = [href, timestamp]
            row_index = row_index + 1
    df_gutteroil_links.to_csv(cache_file_fullname, index=False)
    return df_gutteroil_links


def get_gutoil_prices(browser, df_links):
    df_all = pd.DataFrame()
    for index, row in df_links.iterrows():
        browser.get(row['hyperlink'])
        price_table_element = browser.find_element(By.XPATH, '//*[@id="content"]')
        df_prices = pd.read_html(price_table_element.get_attribute('innerHTML'))[0]
        df_prices['PDate'] = row['PDate']
        df_all = df_all.append(df_prices)
    gutteroil_prices_file_fullname = os.path.join(temp_path, 'gutteroil_prices.csv')
    df_all.to_csv(gutteroil_prices_file_fullname, index=False)


def get_all_biodiesel_links(browser):
    df_biodiesel_links = pd.DataFrame(columns=['hyperlink', 'PDate'])
    cache_file_fullname = os.path.join(temp_path, 'biodiesel_links.csv')

    if os.path.exists(cache_file_fullname):
        return pd.read_csv(cache_file_fullname)

    row_index = 0
    for i in range(1, 94):

        url_feedstock_prices = 'https://list.oilchem.net/4178/49645/' + str(i) + '.html'
        browser.get(url_feedstock_prices)

        report_hyperlinks = browser.find_elements(By.XPATH, '//li[@data-id="0"]')

        for element in report_hyperlinks:
            anchor = element.find_element(by=By.TAG_NAME, value='a')
            href = anchor.get_attribute("href")
            timestamp = element.find_element(by=By.TAG_NAME, value="span").text.replace("[", "").replace("]", "")
            df_biodiesel_links.loc[row_index] = [href, timestamp]
            row_index = row_index + 1
    df_biodiesel_links.to_csv(cache_file_fullname, index=False)
    return df_biodiesel_links


def get_biodiesel_prices(browser, df_links):
    df_all = pd.DataFrame()
    try:
        for index, row in df_links.iterrows():
            browser.get(row['hyperlink'])
            price_table_element = browser.find_element(By.XPATH, '//*[@id="content"]')
            df_prices = pd.read_html(price_table_element.get_attribute('innerHTML'))[0]
            df_prices['PDate'] = row['PDate']
            df_all = df_all.append(df_prices)
    except:
        print('Warning: Scraper interrupted! Find the last completed place and start again.')

    gutteroil_prices_file_fullname = os.path.join(temp_path, 'biodiesel_prices.csv')
    df_all.to_csv(gutteroil_prices_file_fullname, index=False)



def main():
    log.debug("Env:" + env)

    # Initiate Chrome Driver
    log.debug("Initialising Chrome.")
    browser = load_chrome_settings()

    login(browser)
    #df_links = get_all_gutteroil_links(browser)
    #get_gutoil_prices(browser, df_links)

    df_links = get_all_biodiesel_links(browser)
    get_biodiesel_prices(browser, df_links)

    # close and close chrome webdriver
    browser.close()
    browser.quit()
    return 0


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())
