import os
import sys
import blpapi
import datetime
import pandas as pd
import numpy as np

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se
env = se.environment

bulkUploaderFolder = se.ingestion_folder
tickers = [
    'MPMIATMA Index', 'MPMIATMU Index', 'MPMIBRCA Index', 'MPMIBRMA Index', 'MPMIBRMU Index', 'MPMIBRSA Index',
    'MPMIBRSU Index', 'MPMICAMA Index', 'MPMICAMU Index', 'MPMICNCA Index', 'MPMICNMA Index', 'MPMICNMU Index',
    'MPMICNSA Index', 'MPMICNSU Index', 'MPMICZMA Index', 'MPMICZMU Index', 'MPMIDMMA Index', 'MPMIDMSA Index',
    'MPMIDMCA Index', 'MPMIEGWA Index', 'MPMIEGWU Index', 'MPMIEMCA Index', 'MPMIEMMA Index', 'MPMIEMSA Index',
    'MPMIEUCA Index', 'MPMIEUMA Index', 'MPMIEUSA Index', 'MPMIEZCA Index', 'MPMIEZMA Index', 'MPMIEZSA Index',
    'MPMIEZXA Index', 'MPMIFRCA Index', 'MPMIFRMA Index', 'MPMIFRMU Index', 'MPMIFRSA Index', 'MPMIFRSU Index',
    'MPMIFRXA Index', 'MPMIFRXU Index', 'MPMIDECA Index', 'MPMIDEMA Index', 'MPMIDEMU Index', 'MPMIDESA Index',
    'MPMIDESU Index', 'MPMIDEXA Index', 'MPMIDEXU Index', 'MPMIGRMA Index', 'MPMIGRMU Index', 'MPMIHKWA Index',
    'MPMIHKWU Index', 'MPMIINCA Index', 'MPMIINMA Index', 'MPMIINMU Index', 'MPMIINSA Index', 'MPMIINSU Index',
    'MPMIIDMA Index', 'MPMIIDMU Index', 'MPMIIECA Index', 'MPMIIEMA Index', 'MPMIIEMU Index', 'MPMIIESA Index',
    'MPMIIESU Index', 'MPMIIEXA Index', 'MPMIIEXU Index', 'MPMIITCA Index', 'MPMIITMA Index', 'MPMIITMU Index',
    'MPMIITSA Index', 'MPMIITSU Index', 'MPMIITXA Index', 'MPMIITXU Index', 'MPMIJPCA Index', 'MPMIJPMA Index',
    'MPMIJPMU Index', 'MPMIJPSA Index', 'MPMIJPSU Index', 'MPMIKEWA Index', 'MPMIKEWU Index', 'MPMILBWA Index',
    'MPMILBWU Index', 'MPMIMXMA Index', 'MPMIMXMU Index', 'MPMINLMA Index', 'MPMINLMU Index', 'MPMIPLMA Index',
    'MPMIPLMU Index', 'MPMIRUCA Index', 'MPMIRUMA Index', 'MPMIRUMU Index', 'MPMISAWA Index', 'MPMISAWU Index',
    'MPMIZAWA Index', 'MPMIZAWU Index', 'MPMIKRMA Index', 'MPMIKRMU Index', 'MPMIESCA Index', 'MPMIESMA Index',
    'MPMIESMU Index', 'MPMIESSA Index', 'MPMIESSU Index', 'MPMITWMA Index', 'MPMITWMU Index', 'MPMITRMA Index',
    'MPMITRMU Index', 'MPMIAEWA Index', 'MPMIAEWU Index', 'MPMIGBCA Index', 'MPMIGBMA Index', 'MPMIGBMU Index',
    'MPMIGBSA Index', 'MPMIGBSU Index', 'MPMIGBXA Index', 'MPMIGBXU Index', 'MPMIUSMA Index', 'MPMIUSMU Index',
    'MPMIUSSA Index', 'MPMIUSSU Index', 'MPMIUSCA Index', 'MPMIVNMA Index', 'MPMIVNMU Index', 'MPMIGLCA Index',
    'MPMIGLMA Index', 'MPMIGLSA Index'
]

dict_iso = {
    'AT': 'Austria', 'BR': 'Brazil', 'CA': 'Canada', 'CN': 'China', 'CZ': 'Czech Republic',
    'DV': 'Developed Markets', 'EG': 'Egypt', 'EM': 'Emerging Markets', 'EU': 'European Union',
    'XE': 'Eurozone', 'FR': 'France', 'DE': 'Germany', 'GR': 'Greece', 'HK': 'Hong Kong',
    'IN': 'India', 'ID': 'Indonesia', 'IE': 'Ireland', 'IT': 'Italy', 'JP': 'Japan', 'KE': 'Kenya',
    'LB': 'Lebanon', 'MX': 'Mexico', 'NL': 'Netherlands', 'PL': 'Poland', 'RU': 'Russia',
    'SA': 'Saudi Arabia', 'ZA': 'South Africa', 'KR': 'South Korea', 'ES': 'Spain',
    'TW': 'Taiwan', 'TR': 'Turkey', 'AE': 'United Arab Emirates', 'GB': 'United Kingdom',
    'US': 'United States', 'VN': 'Vietnam', 'WD': 'World'
}

srt_date = datetime.date(2019, 1, 1)
end_date = datetime.date.today()
fields_hist = ['PX_LAST']
fields_ref = ['SECURITY_NAME', 'LONG_COMP_NAME']
period = 'DAILY'

format_datetime = '%y%m%d%H%M%S'
filename = 'oil-macro-monthly_pmi-'
folder = bulkUploaderFolder


def get_bbg_hist_data(tickers, srt_date, end_date, fields, period):

    # Array for efficient data processing
    ar = []
    # Dictionary to hold single line of data
    security_data = {}
    # 1. Establish a connection
    # 1.1 Session init
    session = blpapi.Session()
    # 1.2 Start a Session
    if not session.start():
        print("Failed to start session.")
        exit(0)
    # 2. Open service
    if not session.openService("//blp/refdata"):
        print("Failed to open //blp/refdata")
    # 3. Get service
    refDataService = session.getService("//blp/refdata")
    # 4. Set request
    request = refDataService.createRequest("HistoricalDataRequest")
    # 4.1 Tickers
    for value in tickers:
        request.getElement("securities").appendValue(value)
    # 4.2 Fields
    for value in fields:
        request.getElement("fields").appendValue(value)
    # 4.3 Start and end date
    request.set("startDate", srt_date.strftime("%Y%m%d"))
    request.set("endDate", end_date.strftime("%Y%m%d"))
    # 4.4 Period
    request.set("periodicitySelection", period)
    # #5. Send request
    # print("Sending Request:\n", request)
    session.sendRequest(request)
    # 6. Print data
    # Process received events
    while (True):
        ev = session.nextEvent(500)
        if ev.eventType() == blpapi.Event.RESPONSE or ev.eventType() == blpapi.Event.PARTIAL_RESPONSE:
            for msg in ev:
                security = msg.getElement("securityData").getElement("security").getValue()
                field_data = msg.getElement("securityData").getElement("fieldData")

                for i in range(0, field_data.numValues()):
                    elements = field_data.getValue(i).elements()
                    security_data = {str(element.name()): element.getValue() for element in elements}
                    security_data['Ticker'] = security

                    # Append the data to list
                    ar.append(security_data.copy())

        if ev.eventType() == blpapi.Event.RESPONSE:
            break
    # 7. Stop the session
    session.stop()
    # 8. print(ar)
    df = pd.DataFrame(ar, columns=[*fields, "date", "Ticker"]).set_index(['Ticker', 'date'])
    df_sum = pd.DataFrame([])
    for i_ticker in tickers:
        if i_ticker in df.index.get_level_values(0):
            df1 = df.loc[i_ticker]
        else:
            tmp = df.loc[tickers[0]]
            tmp.loc[:, :] = np.nan
            df1 = tmp
        df_sum = pd.concat([df_sum, df1], axis=1, sort=False)
    multi_col = pd.MultiIndex.from_product([tickers, fields], names=['Tickers', 'Fields'])
    df_sum.columns = multi_col
    del ar
    del security_data

    return df


def get_bbg_ref_data(tickers, fields):

    # Array for efficient data processing
    ar = []
    # Dictionary to hold single line of data
    security_data = {}
    # 1. Establish a connection
    # 1.1 Session init
    session = blpapi.Session()
    # 1.2 Start a Session
    if not session.start():
        print("Failed to start session.")
        exit(0)
    # 2. Open service
    if not session.openService("//blp/refdata"):
        print("Failed to open //blp/refdata")
        exit(0)
    # 3. Get service
    refDataService = session.getService("//blp/refdata")
    # 4. Set request
    request = refDataService.createRequest("ReferenceDataRequest")
    # 4.1 Tickers
    for value in tickers:
        request.getElement("securities").appendValue(value)
    # 4.2 Fields
    for value in fields:
        request.getElement("fields").appendValue(value)
    # 5. Send request
    cid = session.sendRequest(request)
    # 6. Print data
    # Process received events
    while (True):
        ev = session.nextEvent(500)
        if ev.eventType() == blpapi.Event.RESPONSE or ev.eventType() == blpapi.Event.PARTIAL_RESPONSE:
            for msg in ev:
                if cid in msg.correlationIds():
                    security_arr = msg.getElement("securityData")
                    for security in security_arr.values():
                        security_data = {}
                        # Ticker name
                        security_name = security.getElement("security").getValue()
                        # Fields Data
                        field_arr = security.getElement("fieldData").elements()
                        for field in field_arr:
                            # print({str(field.name()) :field.getValueAsString() })
                            if str(field.name()) == 'VOLUME':
                                security_data[str(field.name())] = field.getValueAsInteger()
                            else:
                                security_data[str(field.name())] = field.getValueAsString()
                        # security_data  = {str(field.name()) :field.getValueAsString() for field in field_arr}
                        security_data['Ticker'] = security_name
                        ar.append(security_data.copy())
                else:
                    pass
        if ev.eventType() == blpapi.Event.RESPONSE:
            break
    # 7. Stop the session
    session.stop()
    # 8. print(ar)
    df = pd.DataFrame(ar, columns=[*fields, "Ticker"]).set_index(['Ticker'])
    del ar
    del security_data

    return df


df_hist = get_bbg_hist_data(tickers, srt_date, end_date, fields_hist, period)
df_hist = df_hist.reset_index()
df_hist = df_hist.rename(columns={'PX_LAST': 'index', 'date': 'ddate', 'Ticker': 'bloomberg_ticker'})

df_ref = get_bbg_ref_data(tickers, fields_ref)
df_ref = df_ref.reset_index()

df_ref['SECURITY_NAME'] = df_ref['SECURITY_NAME'].apply(lambda x: x if x[-1]=='U' else x + '\\')
df_ref[['PMI', 'iso_code', 'category_sector', 'drop1', 'drop2', 'drop3']] = df_ref['SECURITY_NAME'].str.split('\\', expand=True)
df_ref['iso_code'] = df_ref['iso_code'].replace('GL', 'WD').replace('GL', 'WD').replace('EZ', 'XE').replace('DM', 'DV').replace('EMM', 'EM')
df_ref['seasonality'] = df_ref['LONG_COMP_NAME'].str.split(' ').str[-1]
df_ref['country_region'] = df_ref['iso_code'].map(dict_iso)
df_ref = df_ref.drop(columns=['PMI', 'drop1', 'drop2', 'drop3', 'SECURITY_NAME'])
df_ref = df_ref.rename(columns={'LONG_COMP_NAME': 'name', 'Ticker': 'bloomberg_ticker'})

df = df_hist.merge(df_ref, on='bloomberg_ticker', how='left')
df['pdate'] = datetime.date.today()
dfx = df[df['country_region'].isnull()]

# filefullname = os.path.join(folder, filename + datetime.datetime.today().strftime(format_datetime) + ".csv")
su.upload_to_database(df, filename)

