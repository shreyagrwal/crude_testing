import logging

import pandas as pd
import requests
import datetime
import shutil
from datetime import datetime as dt
from datetime import timedelta as td
import os
from ag_secrets import SecretsClient
from ag_log import ag_log

#endpoint = "https://braemarmarkets.com/Braemar/iws/getPositions?fromDate=2022-01-01&toDate=2022-05-01"
client = SecretsClient()
braemar_credential = client.get_secret(name="braemar")
creds = {"email": braemar_credential.username, "password": braemar_credential.password}

login_url = "https://braemarmarkets.com/Braemar/iws/login"

def login(session, login_url, creds):
    response = session.post(url=login_url, data=creds)
    token = response.json()['loginToken']
    return token, session

def get_position(session, start: dt, end: dt) -> pd.DataFrame:
    endpoint = f"https://braemarmarkets.com/Braemar/iws/getPositions?fromDate={start:%Y-%m-%d}&toDate={end:%Y-%m-%d}"
    response = session.get(endpoint)
    data = pd.DataFrame.from_records(response.json())
    return data.object.apply(pd.Series)

def get_fixture(token):
    payload = {'loginToken': token}
    fixtures = f"https://braemarmarkets.com/Braemar/iws/getFTPFixtureJSONFile?loginToken={token}"
    response = requests.get(fixtures, data=payload)
    data = pd.DataFrame.from_records(response.json())
    return data.object.apply(pd.Series)

def static_data(file):
    if os.path.exists(file) == True:
        df = pd.read_excel(file, sheet_name='Total Clean Positions')
        date = max(df['openDate'])
        return date, df

def main():
    foldername = r"\\petroineos\\dfs\\Department Private Folders\\Analysis Department\\Products\\Freight\\Vortexa Data\\Braemar Fixtures\\"
    filename = r"Braemar Api Fixture Data.csv"
    fix = pd.read_csv(os.path.join(foldername, filename), encoding='unicode_escape')
    fix.charterer = fix.charterer.str.replace(r'(^.*Musket Corp.*$)', 'Musket Corp.', regex=True)
    fix.chartererGroup = fix.chartererGroup.str.replace(r'(^.*Musket Corp.*$)', 'Musket Corp.', regex=True)
    fix.commercialOwnerGroup = fix.commercialOwnerGroup.str.replace(r'(^.*NAVIERA TRANSOCE.*$)', 'NAVIERA TRANSOCE', regex=True)
    fix = fix[~((fix['cargoSize']=='Unknown') | (fix['cargoSize'].isnull()==True))]
    with requests.Session() as sess:
        token, sess = login(sess, login_url, creds)
        if not token:
            raise RuntimeError(f"Could not acquire token using {braemar_credential.username}")
        logging.info(f"Got the token {token[:3]}*****")
        to_date = dt.today() + td(days=21)
        logging.info(f"Begin-Going to get fixture")
        fixtures = get_fixture(token)
        logging.info(f"End-Going to get fixture {len(fixtures)} rows")
        fixtures.charterer = fixtures.charterer.str.replace(r'(^.*Musket Corp.*$)', 'Musket Corp.', regex=True)
        fixtures.chartererGroup = fixtures.chartererGroup.str.replace(r'(^.*Musket Corp.*$)', 'Musket Corp.', regex=True)
        fixtures.commercialOwnerGroup = fixtures.commercialOwnerGroup.str.replace(r'(^.*NAVIERA TRANSOCE.*$)', 'NAVIERA TRANSOCE', regex=True)
        logging.info(f"After string replacements")
        logging.info(f"Begin-get positions")
        positions = get_position(sess, dt(2022, 1, 1), to_date)
        logging.info(f"End-get positions {len(positions)} rows")
        positions['openDate'] = pd.to_datetime(positions['openDate']).dt.date
        positions['insertedDate'] = pd.to_datetime(positions['insertedDate']).dt.date
        UKC = positions.loc[(positions.zone == 'CONT') & (positions.cleanDirty == 'C')]
        USG = positions.loc[(positions.zone == 'USG') & (positions.cleanDirty == 'C')]
        positions_clean = positions.loc[(positions.cleanDirty == 'C')]
        positions_dirty = positions.loc[(positions.cleanDirty == 'D')]
        Date = datetime.date.today()
        fixtures = pd.concat([fix,fixtures], axis=0)
        fixtures = fixtures.drop_duplicates(keep='last')
        logging.info(f'fixtures are \n{fixtures}')
        archivegolder = os.path.join(foldername, "Archive")
        if os.path.isfile(os.path.join(archivegolder, filename)):
            os.remove(os.path.join(archivegolder, filename))
        shutil.move(os.path.join(foldername, filename), os.path.join(archivegolder, filename))
        fixtures.to_csv(fr"\\petroineos\dfs\Department Private Folders\Analysis Department\Products\Freight\Vortexa Data\Braemar Fixtures\Braemar Api Fixture Data.csv",index=False)
        logging.info(f"Exported CSV to S:\Products\Freight\Vortexa Data\Braemar Fixtures\Braemar Api Fixture Data.csv")

if __name__ == '__main__':
    ag_log.get_log()
    logging.info("Begin...")
    main()
    logging.info("All done")
