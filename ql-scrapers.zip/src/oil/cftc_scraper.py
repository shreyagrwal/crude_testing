import os
import sys
import time
import random
import shutil
import zipfile
from datetime import datetime
import requests
import warnings
import glob as gb
import pandas as pd
from selenium import webdriver
from calendar import monthrange
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_environment as se
from scraper_utils import scraper_upload as su

appfolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\CFTC_files\\'

class CFTC:

    def load_chrome_settings(self):
        chrome_options = webdriver.ChromeOptions()
        # Debug mode disabled
        # if sys.gettrace() is None:  # Check if it's in Debug model
            # chrome_options.add_argument('--headless')
        chrome_options.add_experimental_option("useAutomationExtension", False)
        chrome_options.add_experimental_option("prefs", {
            "download.default_directory": appfolder,
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "safebrowsing.enabled": True
        })
        chrome_options.add_argument("test-type")
        chrome_options.add_argument("start-maximized")
        chrome_options.add_argument("--js-flags=--expose-gc")
        chrome_options.add_argument("--enable-precise-memory-info")
        chrome_options.add_argument("--disable-popup-blocking")
        chrome_options.add_argument("--disable-default-apps")
        chrome_options.add_argument("--enable-automation")
        chrome_options.add_argument("test-type=browser")
        chrome_options.add_argument("disable-infobars")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--disable-extensions")
        #browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", chrome_options=chrome_options)
        service = Service(executable_path='.\\tools\\chromedriver.exe')
        self.browser = webdriver.Chrome(service=service, options=chrome_options)

    def get_links(self):
        href_list = []
        url = 'https://www.cftc.gov/MarketReports/CommitmentsofTraders/HistoricalCompressed/index.htm'
        self.browser.get(url)
        container = self.browser.find_elements(By.XPATH, '/html/body/div[2]/div/div/section/div/article/div/div/table[1]/tbody/tr/td/a')
        for result in container:
            link = result.get_attribute("href")
            if link is not None and 'xls' in link:
                href_list.append(link)
        container = self.browser.find_elements(By.XPATH, '/html/body/div[2]/div/div/section/div/article/div/div/table[2]/tbody/tr/td/a')
        for result in container:
            link = result.get_attribute("href")
            if link is not None and 'xls' in link:
                href_list.append(link)
        return href_list

    def download_zip_files(self, zip_list):
        os.chdir(appfolder + '\\ZipFiles')
        current_year = datetime.now().year
        for link in zip_list:
            if str(current_year) in link:
                print(appfolder + "\\" + link.split('/')[-1])
                self.browser.get(link)
                time.sleep(30)
                shutil.move(appfolder + "\\" + link.split('/')[-1], appfolder + "\\ZipFiles\\" + link.split('/')[-1])
            else:
                pass

    def unzip(self, sfolder, filename, dfolder):
        if (os.path.isfile(os.path.join(sfolder, filename))):
            if (filename.endswith(".zip")):
                with zipfile.ZipFile(os.path.join(sfolder, filename), 'r') as zip_ref:
                    zip_ref.extractall(dfolder)
                print("unzip file {} complete".format(filename))
            else:
                print("No .zip file found")

    def unzipall(self):
        for f in  os.listdir(appfolder + '\\ZipFiles'):
            try:
                print("Try to unzip file: " + f)
                self.unzip(appfolder + '\\ZipFiles\\', f, appfolder)
                if f.startswith("fut"):
                    shutil.move(appfolder + "\\" + 'f_year.xls', appfolder + 'process\\' + f[:-4]+ '.xls')
                elif f.startswith("com"):
                    shutil.move(appfolder + "\\" + 'c_year.xls', appfolder + 'process\\' + f[:-4]+ '.xls')
                else:
                    print(f'file {f} is unknown')
                print('Upzip OK.')
            except Exception as e:
                print(e)
                shutil.move(appfolder + "\\" + f, appfolder + "\\Error\\" + f)
                print("Upzip Failed, File {} Moved to Error Folder.".format(f))
            os.remove(appfolder + '\\ZipFiles\\' + f)

    def process(self):
        
        log.debug("Env:" + env)
        log.debug("Data File Folder:{0}".format(upload_folder))

        for f in os.listdir(appfolder + '\\process'):
            print(f)
           # if 'fut_disagg_xls_2023' in f:
            df = pd.read_excel(appfolder + 'process\\' + f)
            df['As_of_Date_In_Form_YYMMDD'] = pd.to_datetime(df['As_of_Date_In_Form_YYMMDD'],format='%y%m%d')
            filename_prefix = "Update_OIL_ftcp_data-"
            su.upload_to_database(df, filename_prefix)

            exact_upload_date_time: str = datetime.today().strftime('%y%m%d%H%M%S')
            shutil.move(appfolder + "\\process\\" + f, appfolder + "\\Archive\\" + f + exact_upload_date_time)

    def main(self):

        self.load_chrome_settings()
        links = self.get_links()
        self.download_zip_files(links)
        self.unzipall()
        self.process()

if __name__ == '__main__':

    env = se.environment
    upload_folder = se.ingestion_folder
    log = ag_log.get_log()

    cftc = CFTC()
    cftc.main()