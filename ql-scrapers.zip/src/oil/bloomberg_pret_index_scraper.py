import os
import re
import sys
import time
import argparse
import pandas as pd
from datetime import datetime
from selenium import webdriver
import chromedriver_autoinstaller

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

log = ag_log.get_log()
chromedriver_autoinstaller.install()

env = se.environment
bulkUploaderFolder = se.ingestion_folder


def load_chrome_settings(temp_path):
    """
    Setting up selenium settings
    :return:
    """
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
    #     chrome_options.add_argument('--headless')  # Otherwise headless Chrome  # Bloomberg does not like headless
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": temp_path,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--ignore-ssl-errors=yes")
    chrome_options.add_argument("--ignore-certificate-errors")

    chromedriver_autoinstaller.install()
    # browser = webdriver.Chrome(executable_path="C:\\Public\\Tools\\chromedriver.exe", chrome_options=chrome_options)
    browser = webdriver.Chrome(chrome_options=chrome_options)
    return browser


def parse_html(html_str):
    """
    Clean up the html str, and parse the table
    :param html_str:
    :return:
    """

    html_str = html_str.split('data-comp="LocTable"')[1]
    # print(html_str)
    table = extract_table_from_html_str(html_str)

    return table


def cleanhtml(raw_html):
    """ Remove HTML and return clean text"""
    CLEANR = re.compile('<.*?>')

    cleantext = re.sub(CLEANR, '', raw_html)
    cleantext = cleantext.replace('}','')
    cleantext = cleantext.replace('{','')
    return cleantext


def get_index_change(number_line, delimeter):
    """
    Get the index and change number from a str line
    :param number_line:
    :param delimeter:
    :return:
    """

    number_line_list = number_line.split(delimeter)
    index = number_line_list[0]
    change = number_line_list[1]
    return index, change


def get_update_date(line):
    """
    Get the last update date for the table
    :param line:
    :return:
    """
    
    log.info("Getting updated date from {}".format(line))

    current_year = datetime.now().year
    # the_line = line.replace('location index change','').replace('Weekly Pret Index: ','')
    the_line = line.split(":")[1]

    the_line = the_line.split()
    month = the_line[0]
    day = the_line[1]

    date_str = "{} {} {}".format(day, month, current_year)
    date_obj = datetime.strptime(date_str, '%d %B %Y')

    return date_obj


def extract_table_from_html_str(html_str):
    """
    extract and clean the table from the html str
    :param html_str:
    :return:
    """

    the_table = cleanhtml(html_str)
    print(the_table)

    row_list = []
    date = None
    for line in the_table.split('   '):
        try:
            if "Weekly Pret Index: " in line or "Pret Index as of:" in line:
                date = get_update_date(line)
            if date is None:
                log.info('Not yet started working on the table')
                continue
            # splitting when a number starts appearing
            line = re.split(r'(^[^\d]+)', line)[1:]
            location = line[0]
            number_line = line[1]
            index, change = None,None

            if "▲" in number_line:
                trend = 'rising'
                index, change = get_index_change(number_line, delimeter = "▲")
            elif "▼" in number_line:
                trend = 'sinking'
                index, change = get_index_change(number_line, delimeter = "▼")
                change = float(change) * -1 # turning value negative
            else:
                log.info("Failed to detect trend")
                trend = None

            if trend is not None:
                data_dict = {'location':location,
                             'index': index,
                             'change': change,
                             'trend':trend,
                             'ddate':date}
                row_list.append(data_dict)
            else:
                log.warning("No trend detected for {}, so this was most likely not a valid data point".format(line))

        except Exception as e:
            log.error(e)

    if len(row_list) < 1:
        error_msg = """Failed getting the PRET table, make sure the website has not been changed"""
        log.error(error_msg)
        raise ValueError(error_msg)

    return pd.DataFrame(row_list)


def download_latest_table(temp_path):
    """
    Download the latest table from bloomberg
    :return:
    """
    log.debug("Initialising Chrome.")
    try:
        # Initiate Chrome Driver
        browser = load_chrome_settings(temp_path)
        time.sleep(2)

        browser.get("https://www.bloomberg.com/graphics/pret-index/")
        html = browser.page_source
        table = parse_html(html)
        log.debug("Download and parsing Completed.")
        return table

    except Exception as e:
        log.error(e)
        log.error(sys.exc_info()[0])
        log.debug("Job Ended with Error!!!")
        return None


def clean_x(column):
    """
    Clean up column names to conform with our data standards
    :param column:
    :return:
    """
    column = column.lower()
    column = column.replace('%', "percent")
    column = re.sub(r'(?<=\[)[^]]+(?=\])', '', column)
    column = column.rstrip()
    column = column.lstrip()
    column = column.replace(']', "")
    column = column.replace('[', "")
    column = column.replace('(', "")
    column = column.replace(')', "")
    column = column.replace(' ', "_")
    column = column.replace(',', "")
    column = column.replace('/', "_")
    column = column.replace(':', "_")

    return column


def download_and_process_pret_table(upload_folder, output_folder, format_datetime, format_datetime_name):
    """
    Download the latest PRET index table from Bloomberg and save the table as a CSV to disk
    :param upload_folder:
    :param format_datetime:
    :param format_datetime_name:
    :return:
    """
    df = download_latest_table(temp_path=output_folder)

    pdate = datetime.today().strftime(format_datetime)
    pdate_name = datetime.today().strftime(format_datetime_name)
    df['pdate'] = pdate

    file_output_path = os.path.join(upload_folder, "oil-macro-pret_index-{}.csv".format(pdate_name))
    su.upload_to_database(df, "oil-macro-pret_index-")
    # df.to_csv(file_output_path, index=False)

    return df


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--output_folder", help="Local folder to store the downloaded files",default=r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Scrapers\macro")
    parser.add_argument("--upload_folder", help="Local folder to save the cleaned CSV files",default=r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\AzureDataUploader\OIL")

    args = parser.parse_args()

    output_folder = args.output_folder
    upload_folder = args.upload_folder

    format_datetime = '%Y-%m-%d'
    format_datetime_name = '%Y%m%d'

    download_and_process_pret_table(
        upload_folder=upload_folder,
        output_folder=output_folder,
        format_datetime=format_datetime,
        format_datetime_name=format_datetime_name
    )