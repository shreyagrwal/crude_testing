import os
import sys
import random
import pandas as pd
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from ag_datagenic_rest_client import DataGenic

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

import warnings
warnings.filterwarnings("ignore")

class PriceCharts:
    def __init__(self) -> None:
        self.dg = DataGenic.create_from_environment()

    def load_models(self):
        filepath = '\\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\Contracts_pricing_tool\DG_curve_price_models.xlsx'
        df = pd.read_excel(filepath)#,skiprows=1)
        df.dropna(how='all')
        df['Group'] = df['Group'].ffill()
        df_dgmodel = df[df['DG model'].notnull()==True]
        df_no_dgmodel = df[df['DG model'].notnull()==False]
        print('following models are not found:\n', df_no_dgmodel,'\n')
        return df_dgmodel

    def get_dg_prices(self, start_date, end_date):
        df_all = pd.DataFrame()
        df_models = self.load_models()
        for index, row in df_models.iterrows():
            print(row['Group'],row['Product'],row['DG model'])
            model = row['DG model']
            contract_month_flag = True
            for i in range(19):
                model_id = model + "/CURVE/M{:02d}/FINAL".format(i)
                try:
                    df_c = self.dg.get_time_series(model_url=model_id,from_date=start_date, to_date=end_date)
                    df_c['model_id'] = model_id
                    df_c = df_c.reset_index()
                    df_c = df_c[['Time', 'PRICE']]
                    df_c.rename(columns={'Time':'DDate'}, inplace=True)
                    df_c['DDate'] = pd.to_datetime(df_c['DDate'], format='%d-%m-%Y', errors='coerce')
                    df_c = df_c.sort_values(by=['DDate'], ascending=[True])
                    df_c.set_index('DDate', inplace=True)
                    df_c = df_c.resample('D').ffill().reset_index()
                    if contract_month_flag == True:
                        find_contract_date = pd.DataFrame(columns=['TempDate'])
                        find_contract_date['TempDate'] = df_c['DDate']
                        contract_month_flag = False
                    df_c['Product'] = row['Product']
                    df_c['Group'] = row['Group']
                    df_c['Tenor'] = "M{:02d}".format(i)
                    unit = row['Price unit']
                    if unit == '$/BBL':
                        df_c['dollar_bbl'] = df_c['PRICE']
                        df_c['dollar_mt'] = df_c['PRICE'] * 8.9
                        df_c['cent_gallon'] = df_c['PRICE'] / (42/100)
                    elif row['Price unit'] == '$/MT' or row['Price unit'] == '€/MT':
                        if row['Price unit'] == '€/MT':
                            from_date =  date.today() - relativedelta(days=+5)
                            to_date = date.today() 
                            df_eurusd = self.dg.get_time_series(model_url='model://ECB_FX/EU.FX.SPOT.ECB.CET.USD.EUR',from_date=from_date, to_date=to_date)
                            df_eurusd = df_eurusd.reset_index()
                            df_eurusd = df_eurusd[~df_eurusd['PRICE'].isna()]
                            conv_date = df_eurusd['Time'].to_list()[-1]
                            euro_conv_factor = df_eurusd['PRICE'].round(2).to_list()[-1]
                            print(f'euro_conv_factor for {conv_date} is -> {euro_conv_factor}')
                            df_c['PRICE'] = df_c['PRICE'] * euro_conv_factor
                        df_c['dollar_bbl'] = df_c['PRICE'] / 8.9
                        df_c['dollar_mt'] = df_c['PRICE'] 
                        df_c['cent_gallon'] = (df_c['PRICE'] / 8.9) / (42/100)
                    elif row['Price unit'] == '¢/GAL':
                        df_c['dollar_bbl'] = df_c['PRICE'] * (42/100)
                        df_c['dollar_mt'] = df_c['PRICE'] * (42/100) * 8.9
                        df_c['cent_gallon'] = df_c['PRICE'] 
                    else:
                        print(f'Unit {unit} is an unknown unit -> please check!')
                        pass
                    find_contract_date['Contract_month'] = find_contract_date.TempDate.dt.month
                    find_contract_date['Contract_year'] = find_contract_date.TempDate.dt.year
                    df_c = pd.concat([df_c,find_contract_date], axis=1)
                    df_c['tempdate'] = pd.to_datetime(df_c.Contract_year.astype(str) + '/' + df_c.Contract_month.astype(str) + '/01')
                    df_c['tempdate'] = df_c.tempdate.dt.to_period('M').dt.to_timestamp('M')
                    df_c['Days_to_expiry'] = (df_c['DDate'] - df_c['tempdate']).dt.days
                    df_c = df_c.drop(['TempDate', 'tempdate'], axis=1)
                    df_all = pd.concat([df_all, df_c], axis=0)
                    df_c = pd.DataFrame()
                    find_contract_date.TempDate = find_contract_date.TempDate + pd.DateOffset(months=1)
                    #print(df_c)
                except Exception as ex:
                    print(f'there is no M{i}')
                    #print(str(ex))
                    pass
        df_all = df_all.drop(['PRICE'], axis=1)
        df_all[['dollar_bbl', 'dollar_mt', 'cent_gallon']] = df_all[['dollar_bbl', 'dollar_mt', 'cent_gallon']].round(3)
        return df_all.reset_index(drop=True)

if __name__ == '__main__':

    env = se.environment
    upload_folder = se.ingestion_folder
    log = ag_log.get_log()

    pc = PriceCharts()
    today=datetime.today()
    #from_date = date(2016, 1, 1) # Please only use it for getting historical data
    from_date = today - timedelta(days=+8)
    to_date = today - timedelta(days=+1)
    df = pc.get_dg_prices(from_date, to_date)
    print('shape before melting: ', df.shape)
    df_all = df.melt(id_vars=['DDate', 'Product', 'Group', 'Tenor', 'Contract_month', 'Contract_year', 'Days_to_expiry'], 
         var_name="Unit", 
         value_name="Price")
    print('shape after melting: ', df_all.shape)
    
    filename_prefix = "fandamental_price_curves-"
    su.upload_to_database(df_all, filename_prefix)
    