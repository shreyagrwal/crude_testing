import argparse
import logging
import shutil
from datetime import datetime
import numpy as np
import requests
from bs4 import BeautifulSoup

from selenium import webdriver
import time
import os, sys
sys.path.append(os.getcwd())


from selenium.webdriver.common.by import By

from pidas.logging import factories
import pandas as pd
import chromedriver_autoinstaller
chromedriver_autoinstaller.install()

log = factories.LogFactory.create()


def get_file_name(link):
    """
    Extract filename from href link
    :param link:
    :return:
    """
    file_name = link.split('/')[-1]
    return file_name

def download_latest_excel(href_link,output_folder):
    """
    Download the latest spreadsheet from gov.uk
    :return:
    """

    file_name = get_file_name(href_link)

    full_file_path = os.path.join(output_folder, file_name)

    request = requests.get(href_link, stream=True)
    print(request)
    if request.ok:
        log.info("{} has been published and will be downloaded to {}".format(href_link, full_file_path))
        # time.sleep(5)
        with open(full_file_path, 'wb') as out_file:
            out_file.write(request.content)
    else:
        log.info("{} has not yet been published.".format(href_link))
        full_file_path = None

    return full_file_path


def clean_df_table(df_table, column_loc = 4, table_type = None):
    """
    Clean CPI table and extract the three relevant tables
    :param df_table:
    :param column_loc:
    :param table_type:
    :return:
    """
    df_table = df_table.copy()

    # cpi_type = df_table.iloc[1][1]


    df_table.columns = df_table.iloc[column_loc]
    df_table = df_table.iloc[column_loc+2:]

    df_table = df_table.replace('..',np.nan)
    df_table = df_table.replace(' -',np.nan)
    df_table = df_table.replace('-',np.nan)
    df_table=df_table.dropna(axis=1,how='all')

    new_columns = list(df_table.columns)

    new_columns[1] = 'year'
    new_columns[0] = 'table_name'
    new_columns = [x.replace(' ','').lower() for x in new_columns]
    df_table.columns = new_columns




    df_table.year = pd.to_numeric(df_table['year'], errors='coerce')
    df_table = df_table.dropna(subset =[ 'year', 'jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'],how='all')
    df_table.year = df_table.year.astype(int)

    id_vars = ['table_name', 'year']
    id_vars = [x for x in id_vars if x in df_table.columns]
    value_vars = [x for x in df_table.columns if x not in id_vars]
    df_table = df_table.reset_index(inplace=False)
    df_table = pd.melt(
        df_table, id_vars=id_vars,
        value_vars=value_vars,
        var_name='type', value_name='value'
    )

    df_table['ddate'] = df_table['year'].astype(str) + '-' + df_table['type']
    # df_table['ddate']
    df_table['ddate'] = pd.to_datetime(df_table['ddate'], format='%Y-%b', errors='coerce')

    df_table['ons_table_name'] = table_type
    df_table['country'] = 'United Kingdom'

    df_table = df_table.sort_values(by=['ddate'], inplace=False)


    print(new_columns)

    return df_table

def get_cpi_df(path):
    """
    Extract data from the CPI excel file and return back a clean table
    :param path:
    :return:
    """
    df = pd.read_excel(path, sheet_name = 'Table 20a, 20b, 20c')
    df_content = pd.read_excel(path, sheet_name = 'Contents')
    rdate = df_content.loc[0].values[0]
    rdate = rdate.split(': ')[1]
    print(rdate)

    vals = [' D7OE',' D7BT', ' D7G7']
    df.loc[df['Back to Contents'].isin(vals), 'Back to Contents'] = np.nan
    df['Back to Contents'] =  df['Back to Contents'].ffill()

    df_tbl_20a = df[df['Back to Contents'] == 'Table 20a']
    df_tbl_20b = df[df['Back to Contents'] == 'Table 20b']
    df_tbl_20c = df[df['Back to Contents'] == 'Table 20c']

    df_tbl1 = clean_df_table(df_tbl_20a, column_loc = 3, table_type = 'CPI All Items')
    df_tbl2 = clean_df_table(df_tbl_20b, column_loc = 4, table_type = 'percentage change over 12 months')
    df_tbl3 = clean_df_table(df_tbl_20c, column_loc = 3, table_type = 'percentage change over 1 month')


    df_tbl = pd.concat([df_tbl1, df_tbl2, df_tbl3])

    df_tbl['rdate'] = rdate
    df_tbl['rdate'] = pd.to_datetime(df_tbl['rdate'], format='%d %B %Y')


    return df_tbl,rdate





def download_and_process_ons_cpi_data(upload_folder, output_folder, format_datetime, format_datetime_name):
    """
    Download the latest CPI data as an excel file and extract relevant CPI data
    :param upload_folder:
    :param format_datetime:
    :param format_datetime_name:
    :return:
    """
    temp_folder = os.path.join(output_folder, 'tmp\\')
    os.makedirs(temp_folder, exist_ok=True)

    href_link = r'https://www.ons.gov.uk/file?uri=/economy/inflationandpriceindices/datasets/consumerpriceinflation/current/consumerpriceinflationdetailedreferencetables.xls'

    logging.info("Downloading Excel file from {}".format(href_link))
    full_file_path = download_latest_excel(href_link = href_link, output_folder=temp_folder)

    df,rdate = get_cpi_df(path=full_file_path)

    new_file_name = rdate.replace(" ",'') + '_'+ os.path.basename(full_file_path)
    new_output_path = os.path.join(output_folder,new_file_name)

    if os.path.exists(new_output_path):
        logging.info("{} already exists".format(new_output_path))
    else:
        logging.info("Moving Excel file to archive at {}".format(full_file_path))
        shutil.copy(full_file_path, new_output_path)

    # deleting the downloaded file from the tmp folder
    logging.info("Deleting the tmp file from {}".format(full_file_path))
    os.remove(full_file_path)


    pdate = datetime.today().strftime(format_datetime)
    pdate_name = datetime.today().strftime(format_datetime_name)
    df['pdate'] = pdate

    file_output_path = os.path.join(upload_folder,
                                    "oil-macro-uk_cpi-{}.csv".format(pdate_name))

    logging.info("Writing output to datalake {}".format(file_output_path))
    df.to_csv(file_output_path, index=False)

    return df




if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--output_folder", help="Local folder to store the downloaded files",default=r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Scrapers\macro")
    parser.add_argument("--upload_folder", help="Local folder to save the cleaned CSV files",default=r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\AzureDataUploader\OIL")
    #
    args = parser.parse_args()
    output_folder = args.output_folder
    upload_folder = args.upload_folder

    format_datetime = '%Y-%m-%d'
    format_datetime_name = '%Y%m%d'

    download_and_process_ons_cpi_data(upload_folder=upload_folder, output_folder=output_folder, format_datetime=format_datetime, format_datetime_name=format_datetime_name)
