import os
import sys
import time
import shutil
import glob as gb
import pandas as pd
import xlwings as xw
from datetime import datetime

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

log = ag_log.get_log()
env = se.environment
bulkUploaderFolder = se.ingestion_folder
appDir = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\Providers External\Bridgeton\TFR'

filename_summary = 'Upload_OIL_BrighetonDailyETFSummary-'
filename_orders = 'Upload_OIL_BrighetonDailyETFOrders-'

order_table_list = [
    'B2:D11', 'B13:D22', 'B24:D33',
    'G2:I11', 'G13:I22', 'G24:I33',
    'L2:N11', 'L13:N22', 'L24:N33',
    'Q2:S11', 'Q13:S22', 'Q24:S33',
    'V2:X11', 'V13:X22', 'V24:X33',
    'AA2:AC11', 'AA13:AC22', 'AA24:AC33',
    'AF2:AH11'
]

csvFolder = bulkUploaderFolder
os.chdir(appDir)

log.debug("Env:{0}".format(env))
log.debug("Data File Folder:{0}".format(csvFolder))


def scrape_brigheton(wb, strReportDate, reportDate):
    sht_summary = wb.sheets["Energy"]
    sht_order = wb.sheets["Energies Order Sheet"]

    # Scraping Energy Sheet
    log.debug("Scraping Energy Sheet.")
    df_summary = sht_summary.range("A1:M500").options(pd.DataFrame, index=False).value
    summary_cols = ['Markets', 'Order', 'EstimatedLots', 'Notional', 'pctg_ADV', 'CumuLongLots', 'CumuLongNotional',
                    'CumuShortLots', 'CumuShortNotional', 'HighPrice', 'LowPrice', 'LastPrice', 'DistHit']
    df_summary.columns = summary_cols
    df_summary = df_summary.dropna(how='all')

    df_summary[['Contract', 'Tenor']] = df_summary['Markets'].str.split(' - ', 1, expand=True)
    df_summary['Tenor'] = df_summary['Tenor'].str.split(' ', 1, expand=True)[0]
    df_summary[['BuySell', 'Price']] = df_summary['Order'].str.split(' - ', 1, expand=True)

    df_summary.index.names = ['ID']
    df_summary = df_summary.reset_index()

    df_summary = df_summary[['ID', 'Contract', 'Tenor', 'BuySell', 'Price', 'EstimatedLots', 'CumuLongLots', 'CumuShortLots', 'DistHit']]
    df_summary = df_summary.rename(columns={'EstimatedLots': 'Quantity'})
    df_summary['ReportDate'] = reportDate

    # Scraping Energies Order Sheet Sheet
    log.debug("Scraping Energies Order Sheet.")

    df_orders = pd.DataFrame()
    for table in order_table_list:
        df_order = sht_order.range(table).options(pd.DataFrame, index=False).value

        header = df_order.columns[0]
        [Contract, Tenor] = header.split(' - ')
        Tenor = Tenor.split(' ')[0]
        df_order.columns = ['Order', 'Alert', 'Quantity']

        df_order = df_order[df_order['Order'] != 'no order']
        df_order[['BuySell', 'Price']] = df_order['Order'].str.split(' - ', 1, expand=True)

        df_order['Contract'] = Contract
        df_order['Tenor'] = Tenor
        df_order['ReportDate'] = reportDate

        df_order = df_order[['ReportDate', 'Contract', 'Tenor', 'BuySell', 'Price', 'Quantity']]
        df_orders = df_orders.append(df_order)

    bulk_uploader_folder = bulkUploaderFolder

    filefullname_summary = os.path.join(bulk_uploader_folder, filename_summary + strReportDate + ".csv")
    su.upload_to_database(df_summary, filename_summary+strReportDate+'-')
    # df_summary.to_csv(path_or_buf=filefullname_summary, header=True, index=False)

    filefullname_orders = os.path.join(bulk_uploader_folder, filename_orders + strReportDate + ".csv")
    su.upload_to_database(df_orders, filename_orders + strReportDate + '-')
    # df_orders.to_csv(path_or_buf=filefullname_orders, header=True, index=False)


def scrape(appDir, file):
    app = xw.App(add_book=False, visible=False)
    app.display_alerts = False
    app.books.api.Open(appDir + "\\" + file, UpdateLinks=False)

    wb = app.books[0]
    strReportDate = file[:8].strip(".xlsm")
    reportDate = datetime.strptime(strReportDate, '%Y%m%d').date()

    scrape_brigheton(wb, strReportDate, reportDate)

    wb.app.quit()
    app.quit()
    time.sleep(10)


for excel in gb.glob("*.xlsm"):
    if not '~' in excel:
        try:
            if excel.find("_TFR V2 Monitor") != -1:
                log.debug("Found a file to scrape: {0}".format(excel))
                scrape(appDir, excel)
                shutil.move(appDir + "\\" + excel, appDir + "\\archive\\" + excel)
            log.debug('File Completed: {0}.'.format(excel))
            log.debug('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        except Exception as e:
            log.error(e)
            if xw:
                wb = xw.books[0]
                wb.app.quit()
            time.sleep(5)
            shutil.move(appDir + "\\" + excel, appDir + "\\error\\" + excel)
            exit(1)
    log.debug('Scraping Completed.')

