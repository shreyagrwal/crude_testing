import datetime
import os
import sys
import shutil
import numpy as np
import pandas as pd
from scraper_utils import scraper_environment as se

chinese_demand_files = [
    'China_Daily_Indicators.xlsx',
    'China_Weekly_Indicators.xlsx',
    'Congestion_Delay_Index_China.xlsx',
    'Metro_Passenger_Traffic_China.xlsx'
]


def unpivot(frame):
    n, k = frame.shape
    data = {
        "value": frame.to_numpy().ravel("F"),
        "city": np.asarray(frame.columns).repeat(n),
        "DDate": np.tile(np.asarray(frame.index), k),
    }
    return pd.DataFrame(data, columns=["DDate", "value", "city"])


def format_data(data, file_name):
    data = data.rename(columns={
        'Name': 'DDate'
    })
    data = data.set_index('DDate', drop=True)
    if file_name == 'Metro_Passenger_Traffic_China':
        df_metro_volume = data[[col for col in data.columns if 'Volume' in col]]
        df_metro_volume = unpivot(df_metro_volume).rename(columns={'value': 'Volume'})
        df_metro_volume['city'] = df_metro_volume['city'].apply(lambda x: x.replace('Metro Passenger Volume:', ''))
        df_metro_traffic = data[[col for col in data.columns if 'Traffic' in col]]
        df_metro_traffic = unpivot(df_metro_traffic).rename(columns={'value': 'Traffic'})
        df_metro_traffic['city'] = df_metro_traffic['city'].apply(lambda x: x.replace('Metro Passenger Traffic:', ''))
        return pd.merge(df_metro_traffic, df_metro_volume, how='outer', on=['DDate', 'city'])
    elif file_name == 'Congestion_Delay_Index_China':
        df_congestion = unpivot(data).rename(columns={'value': 'congestion_delay_index'})
        df_congestion['city'] = df_congestion['city'].apply(lambda x: x.replace('Congestion Delay Index:', ''))
        return df_congestion
    elif file_name == 'China_Daily_Indicators':
        data = data.drop(columns=['Yicai Research Institute: China Financial Condition Index (Daily).1'])
        # columns = [col.replace('(', '').replace(')', '') for col in data.columns]
        # data = data[columns]
        data['DDate'] = data.index
        return data
    else:
        data['DDate'] = data.index
        return data


def move_file_to_bo_batch_uploader(file_location):
    """This function should read a file from *file_location* location and reformat, and save to
    destination: "S:\~Analysis Department\ApplicationFolder\BlueOceanBlobDataUploader\{env}\incoming"
    folder where it will be uploaded to BlueOcean. The file must also be converted from
    .xlsx to .csv (important for BO ingestion). Renamed to "Upload_*file_name*" and reformatted for
    to fit in BO with best scalability"""

    destination_path = se.ingestion_folder

    file_name = file_location.split('\\')[-1].split('.')[0]
    today_date = datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d')
    new_file_name = 'Upload_' + file_name + '-' + today_date + '.csv'

    target_file = pd.read_excel(file_location, skiprows=1)  # skip top row as it contains call to WindFinancial API
    # reformat data for upload to BO database, note different files have different formats
    final_data = format_data(target_file, file_name)
    final_data.to_csv(os.path.join(destination_path, new_file_name), encoding='ISO-8859-1', index=False)
    pass


def move_china_datasets():
    location_folder_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\Scrapers\WindFinancial'
    for i, file in enumerate(os.listdir(location_folder_path)):
        if file in chinese_demand_files:
            print(file)
            file_path = os.path.join(location_folder_path, file)
            if os.path.isfile(file_path):
                if '.xlsx' in file:
                    move_file_to_bo_batch_uploader(file_path)
    pass


if __name__ == '__main__':
    move_china_datasets()

