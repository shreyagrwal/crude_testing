import requests
import bs4
import openpyxl
import datetime

res = requests.get('https://iacng.kz/?page_id=3410&lang=en')
res.raise_for_status()
noStarchSoup = bs4.BeautifulSoup(res.text, "html.parser")
type(noStarchSoup)

## Date
pElems = noStarchSoup.select('.bl-areas-title')
print(pElems)
mystr = str(pElems[0].getText()).strip().replace("Daily indicators of oil and gas treatment of the RK","")
mystr = mystr.strip()
print('Date: ' + mystr)

## Crude Production
pElems = noStarchSoup.select('.bl-areas-value')
prod = str(int(float(pElems[0].getText().replace(",", "."))*7.89))
print('Daily Crude and Condensate Production: ' + prod + ' kb')

## Refining Throughputs
pElems = noStarchSoup.select('.bl-areas-value')
runs = str(int(float(pElems[2].getText().replace(",", "."))*7.89))
print('Daily Refining Throughputs: ' + runs + ' kb')

## Gas Production
pElems = noStarchSoup.select('.bl-areas-value')
gas = str(int(float(pElems[1].getText().replace(",","."))))
print('Daily Gas Production: ' + gas + ' m3')


xls_name = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Scrapers\KazakScrape\KazakhProd.xlsm'
wb = openpyxl.load_workbook(xls_name, keep_vba=True)
sheet = wb['Test']

myint = (sheet.max_row+1)

## Time Stamp
sheet['A'+str(myint)] = datetime.datetime.now()
## Date Related
sheet['B'+str(myint)] = mystr
## Crude Prod
sheet['C' + str(myint)] = prod
## Refining
sheet['D' + str(myint)] = runs
## Gas Prod
sheet['E' + str(myint)] = gas

## save the file
wb.save(xls_name)
wb.close