import re, os
from datetime import datetime
from exchangelib import Credentials, Account

email_address = os.environ['Email']
password = os.environ['Password']
oag_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\Oag\Urls\\'

credentials = Credentials(email_address, password)
account = Account(email_address, credentials=credentials, autodiscover=True)

all_mails = account.inbox.filter(subject__startswith="OAG Analyser")

for item in all_mails[:40]:
    if 'OAG Analyser Scheduled Report' in item.subject and item.datetime_received.date() == datetime.today():
        print(f"{item.datetime_received.date()}_{item.subject.split(' - ')[-1]}")
        email_body=item.body
        url_pattern = r"https?://\S+"
        urls = re.findall(url_pattern, email_body)
        for url in urls:
            if '.zip' in url:
                with open(oag_path+f"{item.datetime_received.date()}_{item.subject.split(' - ')[-1]}.txt", 'w') as text_file:
                    text_file.write(url)
    else:
        print('OAG files not arrived yet!')