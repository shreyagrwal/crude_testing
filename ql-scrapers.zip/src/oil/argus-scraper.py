import os
import io
import sys
import requests
import pandas as pd
from pathlib import Path

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

env = se.environment


def get_publication_date(session, fileid):
    url_get_quote = 'https://direct.argusmedia.com/dataanddownloads/getfiles'
    print(fileid)
    print(requests.get(url_get_quote, cookies=session.cookies).content)
    exit()
    [print(x) for x in session.get(url_get_quote, cookies=session.cookies)]
    pdate = [pd.Timestamp(x['date']) for x in session.get(url_get_quote, cookies=session.cookies).json() if x['libraryFileId'] == fileid]
    if pdate:
        return pdate[0].floor('D')


def login(session, email, pwd):
    url_login = 'https://myaccount.argusmedia.com/api/login'
    payload = {"Email": email, "Password": pwd}
    session.post(url_login, data=payload)
    return session


def get_file_content(session, fileid):
    url = f'https://direct.argusmedia.com/DataAndDownloads/DownloadFile/{fileid}'
    return session.get(url).content


def get_euroilstock_inventories(email, pwd):
    with requests.Session() as session:
        euroilstock_id = 115012
        session = login(session, email, pwd)
        content = get_file_content(session, euroilstock_id)
        pdate = get_publication_date(session, euroilstock_id)
        with io.BytesIO(content) as content:
            data = pd.io.excel.read_excel(content, sheet_name=1, engine="openpyxl", header=4, usecols=range(8))
            cols = data.columns[1:]
            data['pdate'] = pdate
            data['date'] = pd.to_datetime(data.Month, format='%Y-%m-%d')
            data = data.set_index(['pdate', 'date'])[cols].stack().reset_index()
            data.columns = ['pdate', 'date', 'product', 'value']
            data['unit'] = 'mb'
    return pdate, data


def get_euroilstock_production(email, pwd):
    with requests.Session() as session:
        euroilstock_id = 115012
        _ = login(session, email, pwd)
        content = get_file_content(session, euroilstock_id)
        pdate = get_publication_date(session, euroilstock_id)
        with io.BytesIO(content) as content:
            data = pd.io.excel.read_excel(content, sheet_name=2, engine='openpyxl', header=4,usecols=range(7))
            cols = data.columns[1:]
            data['pdate'] = pdate
            data['date'] = pd.to_datetime(data.Month, format='%Y-%m-%d')
            data = data.set_index(['pdate', 'date'])[cols].stack().reset_index()
            data.columns = ['pdate', 'date', 'product', 'value']
            data['product'] = data['product'].str.strip().str.lower().str.replace(' ', '_')
            data['unit'] = 'mbd'
    return pdate, data


def write_csv(prefix: str, vintage: pd.Timestamp, data: pd.DataFrame) -> None:
    date_fmt = '%y%m%d%H%M%S'
    su.upload_to_database(data, f"{prefix}-{vintage.strftime(date_fmt)}-")


if __name__ == '__main__':
    PATH_APPLICATION_FOLDER = Path(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department')
    email, pwd = os.environ["argus_email"], os.environ["argus_password"]
    vintage, idata = get_euroilstock_inventories(email, pwd)
    write_csv('Upload_OIL_EuroilstockInventories', vintage, idata)

    vintage, pdata = get_euroilstock_production(email, pwd)
    write_csv('Upload_OIL_EuroilstockProduction', vintage, pdata)