import os 
import time
import shutil
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from tshistory.api import timeseries

class VortexaPortalSaturn:
    login_email = os.environ['Email'] 
    login_password = os.environ['Password']

    def __init__(self, url_name) -> None:
        self.url = url_name
        self.temp_path = "\\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\Vortexa\\"

    def setdriver(self):
        chrome_options = webdriver.ChromeOptions()
        prefs = {'download.default_directory' : self.temp_path}
        chrome_options.add_experimental_option('prefs', prefs)
        chrome_options.add_argument("test-type")
        chrome_options.add_argument("start-maximized")
        chrome_options.add_argument("--js-flags=--expose-gc")
        chrome_options.add_argument("--enable-precise-memory-info")
        chrome_options.add_argument("--disable-popup-blocking")
        chrome_options.add_argument("--disable-default-apps")
        chrome_options.add_argument("--enable-automation")
        chrome_options.add_argument("test-type=browser")
        chrome_options.add_argument("disable-infobars")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--ignore-ssl-errors=yes")
        chrome_options.add_argument("--ignore-certificate-errors")
        service = Service(executable_path='.\\tools\\chromedriver.exe')
        driver = webdriver.Chrome(service=service, options=chrome_options)
        return driver

    def __login(self, browser):
        browser.get(self.url)
        time.sleep(3)
        username = browser.find_element('xpath', '//*[@id="mui-1"]') 
        username.send_keys(self.login_email)
        time.sleep(1)
        submit = browser.find_element(By.XPATH, '//*[@id="mount"]/div[1]/div[2]/section/div[2]/button')
        submit.click()
        time.sleep(3)
        password = browser.find_element('xpath', '//*[@id="auth0-lock-container-1"]/div/div[2]/form/div/div/div/div/div[2]/div[2]/span/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/input')
        password.send_keys(self.login_password)
        time.sleep(3)
        login = browser.find_element(By.XPATH, '//*[@id="auth0-lock-container-1"]/div/div[2]/form/div/div/div/button')
        login.click()
        time.sleep(10)

    def download_data(self, browser):
        vortexa = browser.find_element(By.XPATH, '/html/body/div[1]/main/div[2]/div/div[1]/div[1]/div/div[1]/div/div/div[1]/div/div/div/div[4]')
        vortexa.click()
        time.sleep(10)

    def move_file_toArchive(self):
        archive_directory = self.temp_path + 'Archive'
        files = os.listdir(self.temp_path)
        for f in files:
            if f.startswith('Vortexa Flows'):
                if os.path.isfile(os.path.join(archive_directory, f)):
                    os.remove(os.path.join(archive_directory, f))
                shutil.move(os.path.join(self.temp_path, f), os.path.join(archive_directory, f))

    def get_files(self):
        files = os.listdir(self.temp_path)
        for f in files:
            if f.startswith('Vortexa Flows'):
                files_sat = f
            else:
                print(f'Unknown file of {f} detected in {files}')
        return self.temp_path + files_sat

    def get_data(self):
        file = self.get_files()
        df = pd.read_csv(file, encoding = "ISO-8859-1")
        df['Quantity'] = df['Quantity (t)'].fillna(0) + df['Quantity (t) - Future'].fillna(0)
        df = df[df['Quantity']!=0]
        df = df.drop(['From','Quantity (t)','Quantity (t) - Future', 'Unnamed: 4'],axis=1)
        df['To'] = pd.to_datetime(df['To']).dt.tz_localize(None)
        return df

    def ingest_to_saturn(self, df):
        tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
        ser = pd.Series(df['Quantity'].values / 1000, index=df['To'])
        print(ser)
        tsa.update('diesel.vortexa.portal.east_of_suez.oecd_europe.imports.kt.monthly', ser, author='behzad')

    def main(self):
        browser = self.setdriver()
        self.__login(browser)
        self.move_file_toArchive()
        self.download_data(browser)
        series = self.get_data()
        self.ingest_to_saturn(series)
        
if __name__ == '__main__':
    url = 'https://analytics.vortexa.com/?dateRange=all-available&from=%5B%22fc6694742ebce49ff955fffa066898c41686d460ab683ab5c44dc7b799aeac58%22%5D&intraMovementFilter=0&metric=t&movementEvent=unloading_start&page=Flows&products=%5B%22deda35eb9ca56b54e74f0ff370423f9a8c61cf6a3796fcb18eaeeb32a8c290bb%22%5D&sortField=unloading_start&tabId=d995496c-24ac-4b5a-96c6-00b0be202e8e&timeSeriesSeasonalToggle=0&to=%5B%22f39d455f5d38907394d6da3a91da4e391f9a34bd6a17e826d6042761067e88f4%22%5D&toExcluded=%5B%225b761850c1f3fe504690f0b458cd5e1e7167def6f19deb7de7571a00652f5fc5%22%2C%225f60288fa383ac8cbd2f3a3348f0d112f84e3ef3cd5182ef0379dfe515b2b13f%22%2C%225e4e7b5040b933b5a0f0d2357ed27ebec432c749b9d63ad395f059639a880253%22%2C%2280ccd59a719f2767156694923e74dcea96baa78e9220c697e1e8dddaeef7bd8f%22%2C%2277b8f4d1dca2d16da69b89d4d8f2af01d36b35d50caa58f803adc14de5de7989%22%2C%2280dd61da7ce1edccaa43d2d60207c482e397bdd7f7efe7ad2a222d35dde2bc8c%22%2C%229b8bc70a7157cb4ae8712a23476fd320e98bc25ed523de6443ab3e9611d7f583%22%2C%22536b9ac36d9adc0b472f5bc6762713bd3420de42ea899b0531e0f0a1de6146cf%22%2C%2290331f86a1a341b278a5c40c8f0cd76c1a5afffb9579d8db2221e9a9f4624bd9%22%2C%2265ab749279c8fbe6d2305db2141ed892e39a80a6823946aaf272414392720ad6%22%2C%2202c0b7bcc4d2aa75332fb32dadfd4eba09d1d351ca7215a94d20a12c40f4ebc9%22%2C%22a398152fa8e559b07ad69683d6f51a0e9cefad1d0e0c495642fe10b2e1170417%22%2C%22536326188b56c7f1da0345518c1eca5f5c97cc6d958611fe17cee6fb0fa989bc%22%2C%22d64020634ef61665444e23e74946dd02b6ab9961efc7aaf52d5c161f3f55a953%22%5D&v=2'
    vps = VortexaPortalSaturn(url)
    vps.main()
