import logging
import os
import shutil
import random
import pandas as pd
import numpy as np
from kpler.sdk import Platform
from datetime import datetime
from kpler.sdk.resources.trades import Trades
from kpler.sdk.configuration import Configuration
from kpler.sdk.resources.trades_snapshot import TradesSnapshot
from ag_log import ag_log
from ag_secrets import SecretsClient
import retry as retry

ag_log.get_log()


@retry.retry(delay=1.0, tries=5, backoff=2)
def get_cargoes(snapshot_client: TradesSnapshot) -> pd.DataFrame:
    all_cargoes = trades_snapshot_client.get(
        columns='all'
    )
    return all_cargoes


client = SecretsClient()
kpler_credential = client.get_secret(name="kpler_oil")
logging.info(f"Got the credential {kpler_credential}")
logging.debug('Configuration File.')
config = Configuration(Platform.Liquids, kpler_credential.username, kpler_credential.password, log_level='INFO')
logging.info('connection successful')

trades_client = Trades(config)
logging.info(f"Created Trades instances {trades_client}")

trades_snapshot_client = TradesSnapshot(config)
logging.info(f"Created instance of {trades_snapshot_client=}")
logging.info(f"Going to get cargoes")
all_cargoes = get_cargoes(snapshot_client=trades_snapshot_client)

logging.info(f"Got {len(all_cargoes)} rows ")

logging.info('API call successful')
logging.info("Going to replace , with _")
all_cargoes = all_cargoes.replace(',', '_', regex=True)
logging.info("After replacing , with _")

logging.info("Before replacing ' with  white space")
all_cargoes = all_cargoes.replace("'", " ", regex=True)
logging.info("After replacing ' with  white space")

kpler_tmp_path = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\Behzad\kpler_snapshot_temp\\'

number_of_chunks = 20
logging.info(f"Begin-Going to export {number_of_chunks=} files")
for idx, chunk in enumerate(np.array_split(all_cargoes, number_of_chunks)):
    index = False
    header = True
    float_format = None
    encoding: str = 'utf-8'

    ingestion_folder = kpler_tmp_path
    filename_prefix = "Upload_oil_kplertradesproducts-"
    save_file_path = os.path.join(ingestion_folder, f'{filename_prefix}{idx + 1}.csv')
    logging.info(f"Going to export frame with {len(chunk)} rows to {save_file_path}")
    chunk.to_csv(save_file_path, index=index, header=header, float_format=float_format, encoding=encoding,
                 date_format='%Y-%m-%d %H:%M:%S')
logging.info(f"End-Going to export {number_of_chunks=} files")
logging.info(f"{all_cargoes.shape=}")

env = os.environ["environment"].upper()
logging.info(f"Environment={env}")

for f in os.listdir(kpler_tmp_path):
    logging.info(f"Processing file: {f} in {kpler_tmp_path=}")
    exact_upload_date_time: str = datetime.today().strftime('%y%m%d%H%M%S')
    random_integer: str = str(random.randint(10000, 99999))

    ingestion_folder = ""
    if env == 'PROD':
        ingestion_folder = r'\\petroineos.local\dfs\BlueOcean\central\jobs\incoming'
    else:
        ingestion_folder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\BlueOceanBlobDataUploader\UAT\incoming'

    from_file_path = os.path.join(kpler_tmp_path, f)
    to_file_path = os.path.join(ingestion_folder, f'{f[:-4]}_{exact_upload_date_time}-{random_integer}.csv')
    logging.info(to_file_path)
    shutil.move(from_file_path, to_file_path)
    logging.info(f"Moved file from {from_file_path} to {to_file_path}")

logging.info("All done")
