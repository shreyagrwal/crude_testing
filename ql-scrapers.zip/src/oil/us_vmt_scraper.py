""" Download data on Traffic Volume Trends from the US Office of Highway Policy Information"""
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import warnings
import requests
import os, sys
sys.path.append(os.getcwd())
import pandas as pd
import logging


log_filename = "logs/usvmtscraper.log"
os.makedirs(os.path.dirname(log_filename), exist_ok=True)
handler = logging.FileHandler(log_filename)
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
handler.setFormatter(formatter)
root = logging.getLogger()
root.setLevel(os.environ.get("LOGLEVEL", "DEBUG"))
root.addHandler(handler)
root.addHandler(logging.StreamHandler())
log = logging.getLogger("usvmtscraper")

format_datetime = '%Y-%m-%d'
output_folder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Scrapers\USVMT'
upload_folder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\AzureDataUploader\OIL'
#output_folder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\AzureDataUploader\staging_area'


def ag_get_data(query):
    """
    Run a SQL query on the datalake
    :param query:
    :return:
    """
    warnings.simplefilter('ignore', requests.packages.urllib3.exceptions.InsecureRequestWarning)
    params = {"Database" : "BIGDATAOIL", "Query": query}
    resp = requests.post('https://TST-QDEV-AP7.petroineos.local:5001/genericdata/GetGenericData/', json=params, verify=False)
    json_result = resp.json()
    df = pd.DataFrame(json_result)
    return df

def get_latest_rdate_in_dl():
    """
    Get the latest injected rdate from the datalake
    :return:
    """
    try:
        query = """
         select max(rdate) as max_rdate FROM [oil].[dbo].[mobility_us_dot_vmt_monthly]
         """
        rdate_df = ag_get_data(query)
        max_rdate = rdate_df['max_rdate'].values[0]
        log.info('The last fetched rdate was {}'.format(max_rdate))
    except Exception as e:
        log.error('Unable to get the latest rdate from the datalake. Falling back to 2022-04-30')
        max_rdate = '2022-04-30'

    max_rdate = datetime.strptime(max_rdate, format_datetime)

    return max_rdate


def download_latest_excel(href_link):
    """
    Download the latest spreadsheet from gov.uk
    We are downloading the ods format due to issues with parsing the file using pandas/openpyxl
    This is a known problem when there is a chart in one of the tabs
    :return:
    """

    file_name = get_file_name(href_link)

    full_file_path = output_folder + file_name

    request = requests.get(href_link, stream=True)
    if request.status_code == 200:
        log.info("{} has been published and will be downloaded ".format(href_link))
        with open(full_file_path, 'wb') as out_file:
            out_file.write(request.content)
    else:
        log.info("{} has not yet been published.".format(href_link))
        full_file_path = None

    return full_file_path


def get_file_name(link):
    """
    Extract filename from href link
    :param link:
    :return:
    """
    file_name = link.split('/')[-1]
    return file_name


def extract_csv_files(excel_path, file_name):
    """
    Convert Excel tab to csv file and save to blob upload folder
    :param excel_path:
    :return:
    """

    filename_year = '20'+file_name[:2]
    filename_month = file_name[2:5].capitalize()

    name_part = file_name.split('.')[0]

    excel_name_date = "{}-{}".format(filename_year,filename_month)

    excel_name_date_obj = datetime.strptime(excel_name_date, '%Y-%b')
    publish_date = excel_name_date_obj.strftime(format_datetime)
    pdate = datetime.today().strftime(format_datetime)

    df = pd.read_excel(excel_path, sheet_name='SAVMT', skiprows=0, engine=None)
    df['pdate'] = pdate
    df['rdate'] = publish_date # reporting date

    file_output_path = os.path.join(upload_folder,
                                    "oil-mobility-us_dot_vmt_monthly-{}{}.csv".format(name_part, excel_name_date))
    df.to_csv(file_output_path, index=None)
    log.info("Completed conversion and upload to {}".format(file_output_path))

def get_date_range_list_since_last_rdate():
    """
    Generate a list of dates since the last publish date
    :return:
    """
    last_rdate = get_latest_rdate_in_dl()
    current_date = datetime.today()
    date_range = list(pd.date_range(last_rdate+relativedelta(months=1),current_date,freq='m'))
    date_range.append(current_date)
    return date_range


def generate_href_links():
    """ Generate a list of potential file download links """

    date_range = get_date_range_list_since_last_rdate()
    link_list = []
    for date_obj in date_range:
        year = date_obj.strftime('%y')
        month = date_obj.strftime('%b')
        href_link = r"""https://www.fhwa.dot.gov/policyinformation/travel_monitoring/{0}{1}tvt/{0}{1}tvt.xlsx""".format(year, month)
        link_list.append(href_link)

    return link_list

def download_and_process_us_vmt():
    """
    Orchestrate the data processing by downloading the latest Excel spreadsheet and uploading converted CSV files to blob
    :return:
    """
    href_list = generate_href_links()
    for href_link in href_list:
        full_file_path = download_latest_excel(href_link)

        if full_file_path is None:
            log.info("Download failed for {}".format(href_link))
            continue

        file_name = get_file_name(link=href_link)

        log.info("Filename {} at {}".format(file_name, full_file_path))
        extract_csv_files(excel_path=full_file_path, file_name = file_name)



if __name__ == "__main__":
    download_and_process_us_vmt()



