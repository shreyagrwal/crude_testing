import os
import sys
import time
import glob as gb
import pandas as pd
from datetime import datetime

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder


def process_files():
    processed = pd.read_csv(cache)
    for excel_file in gb.glob(folder + "\\" + "*.xlsx"):
        if not excel_file in processed['ProcessedFiles'].values:
            log.debug("Processing file: " + excel_file)
            #full_name = folder + "\\" + excel_file
            log.debug("Extract Refinery Operations")
            Extract(excel_file, 'Refinery Operations', 124, 'Upload_OIL_RefineryOperation-')
            log.debug("Extract OPEC+")
            Extract(excel_file, 'OPEC+', 75, 'Upload_OIL_OpecPlus-')
            log.debug("Extract Crude")
            Extract(excel_file, 'Crude', 93, 'Upload_OIL_Crude-')
            processed = processed.append({'ProcessedFiles':excel_file}, ignore_index=True)
    processed.to_csv(path_or_buf=cache, header=True, index=False)


def flatten(df_, key, values, var_name, value_name, attach_pdate=True, pdate = datetime.today().date()):
    """Melt Time Series"""

    df_.reset_index(inplace=True)
    df_ = pd.melt(
        df_, id_vars=key,
        value_vars=values,
        var_name=var_name, value_name=value_name)

    if attach_pdate:
        df_['Pdate'] = pdate

    return df_


def Extract(file_name, sheet, nrows, filename):
    df_ = pd.read_excel(io=file_name, sheet_name=sheet, index_col=0, skiprows=1, nrows=nrows)
    df_.reset_index(inplace=True)
    df_.rename(columns={'index': 'region'}, inplace=True)
    df = df_.fillna(method='ffill')
    df_flattened = flatten(df, df.columns[:2], df.columns[3:], 'DDate', 'Value')
    df_flattened = df_flattened.round(6)
    format_datetime = '%y%m%d%H%M%S'
    bulk_uploader_folder = bulkUploaderFolder
    filefullname = os.path.join(bulk_uploader_folder, filename + datetime.today().strftime(format_datetime) + ".csv")
    # df_flattened.to_csv(path_or_buf=filefullname, header=True, index=False)
    su.upload_to_database(df_flattened, filename)
    time.sleep(1)


log = ag_log.get_log()
log.debug("Starting extract crude oil barrell in Env: "+env)
folder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\Providers External\JBC\Crude Monthly'
cache = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\Providers External\JBC\Crude Monthly\Temp\processed.csv'
process_files()
log.debug("Job Completed.")