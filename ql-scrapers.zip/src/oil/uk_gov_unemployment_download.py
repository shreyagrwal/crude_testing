import argparse
import shutil
from datetime import datetime
from bs4 import BeautifulSoup

from selenium import webdriver
import time
import os, sys
sys.path.append(os.getcwd())


from selenium.webdriver.common.by import By

from pidas.logging import factories
import pandas as pd
import chromedriver_autoinstaller
chromedriver_autoinstaller.install()

log = factories.LogFactory.create()


def load_chrome_settings(temp_path):
    """
    Setting up selenium settings
    :return:
    """
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
    #     chrome_options.add_argument('--headless')  # Otherwise headless Chrome  # Bloomberg does not like headless
    chrome_options.add_experimental_option("useAutomationExtension", False);
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": temp_path,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type");
    chrome_options.add_argument("start-maximized");
    chrome_options.add_argument("--js-flags=--expose-gc");
    chrome_options.add_argument("--enable-precise-memory-info");
    chrome_options.add_argument("--disable-popup-blocking");
    chrome_options.add_argument("--disable-default-apps");
    chrome_options.add_argument("--enable-automation");
    chrome_options.add_argument("test-type=browser");
    chrome_options.add_argument("disable-infobars");
    chrome_options.add_argument("--disable-extensions");
    chrome_options.add_argument("--ignore-ssl-errors=yes");
    chrome_options.add_argument("--ignore-certificate-errors");

    chromedriver_autoinstaller.install()
    # browser = webdriver.Chrome(executable_path="C:\\Public\\Tools\\chromedriver.exe", chrome_options=chrome_options)
    browser = webdriver.Chrome(chrome_options=chrome_options)

    return browser


def download_latest_table(temp_path):
    """
    Download the latest table from kayak accross both country and city, for each time period.
    Four tables in total
    :return:
    """
    log.debug("Initialising Chrome.")
    # Initiate Chrome Driver
    driver = load_chrome_settings(temp_path)

    driver.get("https://www.ons.gov.uk/employmentandlabourmarket/peoplenotinwork/unemployment/timeseries/mgsx/lms/previous")
    print('browser',driver)
    # time.sleep(5)
    download_button = driver.find_element(By.XPATH,"//a[contains(@aria-label, 'Download the latest version as csv')]")

    download_button.click()
    time.sleep(5)



    log.debug("Download and parsing Completed.")
    return 0

def clean_df(df):
    """
Adds unit, rdate, year, period type, date in DD/MM/YYYY and pdate
    :param df: redundancy df
    :return: cleaned df for analysis
    """
    df_un = df.loc[8:]
    df_un.columns = ['date','rate']
    df_un = df_un.copy()
    df_un.rate = df_un.rate.astype(float)
    meta_info_df = df.loc[:7]
    meta_info_df.index = meta_info_df[0]
    meta_info_df = meta_info_df[[1]]
    meta_info_df = meta_info_df.T

    unit = meta_info_df['Unit'].values[0]
    release_date = meta_info_df['Release date'].values[0]
    pre_unit = meta_info_df['PreUnit'].values[0]

    df_un['unit'] = 'percentages'
    df_un['country'] = 'United Kingdom'
    df_un['rdate'] = datetime.strptime(release_date, "%d-%m-%Y").strftime("%Y-%m-%d")
    df_un[['year', 'quarter']] = df_un['date'].str.split(' ', 1, expand=True)
    df_un.quarter = df_un.quarter.str.replace('Q','')

    df_un.year = df_un.year.astype(int)

    df_un = df_un.sort_values(by=['year','quarter'], inplace=False)


    df_un.loc[df_un['quarter'].isna(), 'period'] = 'year'
    mask1 = (df_un['quarter'].str.len() == 1)
    mask2 = (df_un['quarter'].str.len() == 3)
    df_un.loc[mask1, 'period'] = 'quarter'
    df_un.loc[mask2, 'period'] = 'month'

    df_un['ddate'] = pd.to_datetime([
        '-'.join(x.split()[::1]) for x in df_un['date']]).date
    df_un['ddate'] = pd.to_datetime(df_un['ddate'], format = '%Y-%m-%d')
    # df_un['ddate'] = df_un['ddate'].astype(str)
    df_un = df_un.sort_values('ddate')
    df_un = df_un.drop(columns=['quarter'])


    return df_un



def download_and_process_ons_unemployment_data(upload_folder, output_folder, format_datetime, format_datetime_name):
    """
    :param upload_folder:
    :param format_datetime:
    :param format_datetime_name:
    :return:
    """
    temp_folder = os.path.join(output_folder, 'tmp\\')
    os.makedirs(temp_folder, exist_ok=True)
    df = download_latest_table(temp_path=temp_folder)
    # os.rmdir(temp_folder)

    file_list = os.listdir(temp_folder)

    for csv_file in file_list:
        print(csv_file)
        abs_csv_file = os.path.join(temp_folder,csv_file)
        df = pd.read_csv(abs_csv_file, header = None)
        df = clean_df(df)
        os.remove(abs_csv_file)
        break
    shutil.rmtree(temp_folder, ignore_errors = True)


    pdate = datetime.today().strftime(format_datetime)
    pdate_name = datetime.today().strftime(format_datetime_name)
    df['pdate'] = pdate

    file_output_path = os.path.join(upload_folder,
                                    "oil-macro-yearly_quarterly_monthly_unemployment-{}.csv".format(pdate_name))

    df.to_csv(file_output_path, index=False)

    return df




if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--output_folder", help="Local folder to store the downloaded files",default=r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Scrapers\macro")
    parser.add_argument("--upload_folder", help="Local folder to save the cleaned CSV files",default=r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\AzureDataUploader\OIL")

    format_datetime = '%Y-%m-%d'
    format_datetime_name = '%Y%m%d'
    args = parser.parse_args()
    output_folder = args.output_folder
    upload_folder = args.upload_folder


    download_and_process_ons_unemployment_data(upload_folder=upload_folder, output_folder=output_folder, format_datetime=format_datetime, format_datetime_name=format_datetime_name)