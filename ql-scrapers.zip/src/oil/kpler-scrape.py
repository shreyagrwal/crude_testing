import os
import sys
import time
import json
import argparse
import requests
import pandas as pd
from typing import List
from pathlib import Path
from selenium import webdriver
from datetime import datetime as dt
from selenium.webdriver.common.by import By
from tqdm.contrib.concurrent import thread_map

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se


VINTAGE = pd.Timestamp.now().floor(freq='D')


def authenticate(driver, email, password):
    email_xpath = '//*[@id="email"]'
    password_xpath = '//*[@id="password"]'
    click_xpath = '//*[@id="app"]/div/div/form/button'
    driver.get("https://terminal.kpler.com/")
    driver.find_element(by=By.XPATH, value=email_xpath).send_keys(email)
    driver.find_element(by=By.XPATH, value=password_xpath).send_keys(password)
    driver.find_element(by=By.XPATH, value=click_xpath).click()
    time.sleep(5) # seconds
    return driver


def get_json(driver, date, download_path):
    payload = {"exchangeType":"export","filters":{"product":[1328]},"flowDirection":"export","fromLocations":[],"locations":[],
    "players":[],"vessels":[],"granularity":"days","interIntra":"interintra","onlyRealized":False,"period":date.strftime('%Y-%m-%d'),
    "toLocations":[],"view":"kpler","withBetaVessels":False,"withForecasted":True,"withIncompleteTrades":True,
    "withIntraCountry":False,"withFreightView":False, "withProductEstimation":True,"splitValues":[],"splitValuesToExclude":[],
    "vesselClassifications":[],"from":0,"size":1_000}
    cookies = pd.DataFrame.from_records(driver.get_cookies()).set_index('name')['value'].to_dict()
    print(cookies)
    headers = {
    'Connection': 'keep-alive',
    'sec-ch-ua': '^\\^',
    'sec-ch-ua-mobile': '?0',
    'Authorization': f'Bearer {cookies["token"]}',
    'Content-Type': 'application/json',
    'Accept': 'application/json, text/plain, */*',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36',
    'x-web-application-version': 'v19.0.227',
    'sec-ch-ua-platform': '^\\^Windows^\\^',
    'Origin': 'https://terminal.kpler.com',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://terminal.kpler.com/analytics/flows/details/2022?granularity=years&dates=all&productEstimation=true',
    'Accept-Language': 'en-US,en;q=0.9',
    }
    response = requests.post('https://terminal.kpler.com/api/flows/trades', json=payload, headers=headers, cookies=cookies)
    jsonfile = response.json()
    load_date = date.strftime('%Y%m%d')
    if len(jsonfile):
        if jsonfile[0].get('generatedAt'): # Check response properly formed
            filename = download_path / f'products_{load_date}_{VINTAGE.strftime("%Y%m%d")}.json'
            with open(filename, 'w') as outfile:
                json.dump(jsonfile, outfile)
                print(f'JSON path: {filename}')


def format_json(download_path, csv_path):
    data = json.load(open(download_path / csv_path))
    vintage = pd.Timestamp(data[0]['generatedAt']).floor(freq='D')
    date = pd.Timestamp(data[0]['start']).floor(freq='D')
    zone_types = ['port', 'country', 'gulf', 'region', 'continent', 'subcontinent', 'zone']
    product_types = ['commodity', 'group', 'family']
    fields = [
        'imo',
        'vesselName',
        'vesselType',
        'flagName',
        'tradeId',
        'route',
        'cargoSources',
        'flowQuantityMass',
        'startdate',
        'enddate',
        'pdate',
        'charterer',
        'buyers',
        'sellers',
        'status',
        *[f'{z}Origin' for z in zone_types],
        *[f'{z}Destination' for z in zone_types],
        *[f'{p}Product' for p in product_types],
        'voyageId',
    ]

    def promote_fields(i, line):
        flow_quantities = line['flowQuantities'][0]
        product_dict = {x['type']: x['name'] for x in flow_quantities['ancestors'][::-1]}
        for p in product_types:
            line[f'{p}Product'] = product_dict.get(p)
            line[f'{p}Destination'] = product_dict.get(p)
        line['route'] = line['routeNameEnum']
        line['voyageId'] = int(line.get('voyageGroupId')) if line.get('voyageGroupId') else None
        line['tradeId'] = line['id']
        line['cargoSources'] = '_'.join(flow_quantities['cargoSources'])
        line['flowQuantityMass'] = flow_quantities['flowQuantity']['mass']
        line['startdate'] = pd.Timestamp(line['start']).floor(freq='D')
        line['enddate'] = pd.Timestamp(line['end']).floor(freq='D')
        line['pdate'] = VINTAGE
        org_specific_info = line['orgSpecificInfo']['default']
        charterer = org_specific_info.get('charterer')
        line['charterer'] = charterer.get('name') if charterer is not None else None
        line['buyers'] = '_'.join([x.get('name') for x in org_specific_info.get('confirmedBuyers') or {}])
        line['sellers'] = '_'.join([x.get('name') for x in org_specific_info.get('confirmedSellers') or {}])
        origin = line['forecastPortCallOrigin']
        if origin:
            origin_dict = {x['type']: x['name'] for x in origin['zone']['parentZones']}
            for t in zone_types:
                line[f'{t}Origin'] = origin_dict.get(t)
        destination = line['forecastPortCallDestination']
        if destination:
            destination_dict = {x['type']: x['name'] for x in destination['zone']['parentZones']}
            for t in zone_types:
                line[f'{t}Destination'] = destination_dict.get(t)
        vessels = line['vessels'][0]
        line['imo'] = int(vessels['imo'])
        line['vesselName'] = vessels['name']
        line['flagName'] = vessels['flagName']
        line['vesselType'] = vessels['vesselType']
        for l in line:
            if isinstance(line[l], str):
                line[l] = line[l].replace(',',';').replace('"','').replace("'","")
        return line

    data = pd.DataFrame.from_records(map(lambda x: promote_fields(*x), enumerate(data)))
    data = data.reindex(fields, axis=1)
    return vintage, date, data


def load_jsons(download_path, email, password, dates:List[pd.Timestamp]):
    chrome_options = webdriver.ChromeOptions()
    prefs = {'download.default_directory' : download_path.__str__()}
    chrome_options.add_experimental_option('prefs', prefs)
    driver = webdriver.Chrome(executable_path='chromedriver.exe', options=chrome_options)
    auth_driver = authenticate(driver, email, password)
    [get_json(auth_driver, date, download_path) for date in dates]
    auth_driver.close()


def write_csv(bulk_folder: str, prefix: str, vintage: pd.Timestamp, data: pd.DataFrame, date: pd.Timestamp) -> None:
    date_fmt = '%y%m%d%H%M%S'
    suffix = f"{prefix}-{date.strftime(date_fmt)}-{vintage.strftime(date_fmt)}.csv"
    filename = bulk_folder / suffix
    # data.to_csv(filename, index=False)
    su.upload_to_database(data, f'{prefix}-{date.strftime(date_fmt)}-{vintage.strftime(date_fmt)}-')
    print(f'CSV path: {filename}')


def main(backward_days, forward_days, reports):
    if reports is None:
        reports = backward_days + forward_days
    ENV = 'PROD'
    PATH_APPLICATION_FOLDER = Path(
        r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department')
    BULK_UPLOADER_FOLDER = PATH_APPLICATION_FOLDER / 'ApplicationFolder' / 'BatchUploader' / ENV
    download_path = PATH_APPLICATION_FOLDER / 'Providers External' / 'KplerProductsTrades'
    if backward_days + forward_days > 0:
        email = os.environ['kpler_email']
        password = os.environ['kpler_password']
        now = dt.utcnow()
        dates = pd.date_range(end=now + pd.DateOffset(days=forward_days), periods=reports, freq='D')
        load_jsons(download_path, email, password, dates)
    jsons = sorted(os.listdir(download_path), key=lambda x: os.path.getmtime(download_path / x))[-reports:]
    files_time = {filename: os.path.getmtime(download_path / filename) for filename in jsons}
    partial_format_json = lambda x: format_json(download_path, x[0])
    jsons = thread_map(partial_format_json, files_time.items())
    prefix = 'Upload_OIL_KplerProductTrades'
    partial_write_csv = lambda x: write_csv(BULK_UPLOADER_FOLDER, prefix, x[0], x[2], x[1])
    thread_map(partial_write_csv, jsons)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Kpler scraper')
    parser.add_argument('-d', '--days', type=int, required=True,
                        help='number of days back in time')
    parser.add_argument('-f', '--forward_days', type=int, required=True,
                        help='number of days forward in time')
    parser.add_argument('-r', '--reports', type=int, required=False,
                    help='number of reports to process')
    args = parser.parse_args()
    main(args.days, args.forward_days, args.reports)

