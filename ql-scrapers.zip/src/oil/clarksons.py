import os
import sys
import tabula
import argparse
import pandas as pd
import datetime as dt
from pathlib import Path

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

env = se.environment
log = ag_log.get_log()


def parse_date(date):
    now = pd.Timestamp.now()
    offset = [-1, 0, 1]
    month = dt.datetime.strptime(date.split('-')[1], '%b').month
    day = dt.datetime.strptime(date.split('-')[0], '%d').day

    candidates = [dt.datetime(year=now.year + o, month=month, day=day) for o in offset]
    closest_choice = [abs((c - now).days) for c in candidates]
    closest = min(closest_choice)
    return dict(zip(closest_choice, candidates))[closest]


def extract_clarksons(report_type, report_path, destinations_list):
    tables = tabula.io.read_pdf(report_path, pages="all", stream=True, multiple_tables=False)
    destinations = dict(zip(destinations_list, destinations_list))
    table = tables[0]

    vessel_column = [col for col in table.columns if 'VESSEL' in col][0]
    lc_column = [col for col in table.columns if 'LC' in col][0]

    table = table.assign(TRADING_REGION_DESTINATION=lambda x: x[vessel_column].map(destinations).ffill().dropna(axis=0))
    table = table.dropna(subset=[lc_column, 'DATE'])  # This is a NEW STEP to fix broken script
    print(sorted(list(table.columns)))
    print(table.head())

    table[lc_column] = table[lc_column].apply(parse_date)
    table.DATE = table.DATE.apply(parse_date)
    table['CARGO_TYPE'] = report_type
    table = table.rename(columns={'ETA/ATA': 'ETA_ATA', 'DATE': 'DISCHARGE_DATE', 'LOAD': 'LOADING_PORT'})
    return table


def write_csv(prefix: str, vintage: pd.Timestamp, data: pd.DataFrame) -> None:
    date_fmt = '%y%m%d%H%M%S'
    su.upload_to_database(data, f"{prefix}-{vintage.strftime(date_fmt)}-")


def process_pdfs(filters, destinations, product_name, report_prefix, n_reports):
    PATH_APPLICATION_FOLDER = Path(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department')
    download_path = PATH_APPLICATION_FOLDER / 'Providers External' / 'Clarksons'

    files = [x for x in os.listdir(download_path) if any([keyword for keyword in filters if keyword in x])]
    filtered_files = sorted(files, key=lambda x: os.path.getmtime(download_path / x))[-n_reports:]
    files_time = {filename: os.path.getmtime(os.path.join(download_path, filename)) for filename in filtered_files}
    try:
        for file, time in files_time.items():
            try:
                data = extract_clarksons(product_name, download_path / file, destinations)
                pdate = pd.Timestamp.fromtimestamp(time).floor('D')
                data['pdate'] = pd.Timestamp.fromtimestamp(time).floor('D')
                write_csv(report_prefix + f'-{product_name}', pdate, data)
            except ValueError as e:
                log.info(f'Download file: {file} with error {e}')
                pass
    except Exception as e:
        log.info(f'Job failed with exception {e}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Clarksons scraper')
    parser.add_argument('-r', '--reports', type=int, required=False, help='number of reports to process')
    args = parser.parse_args()
    report_prefix = 'Upload_OIL_ClarksonsCleanAGFixture'
    filters = ('ULSD', 'GO')
    product_name = 'ULSD_GO'
    destinations = ['MED/UKC', 'USA / CARIBS', 'SAM / WCSAM / WCCAM', 'WAF', 'EAST']
    process_pdfs(filters, destinations, product_name, report_prefix, args.reports or 4)
    filters = ('JET',)
    product_name = 'JET'
    destinations = ['MED/UKC', 'USA / CANADA / CARIBS', 'WCCAM / SAM / WAF']
    process_pdfs(filters, destinations, product_name, report_prefix, args.reports or 4)
