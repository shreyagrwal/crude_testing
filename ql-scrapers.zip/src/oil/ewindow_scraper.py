import logging
import os
import sys
import spgci as ci
import pandas as pd
from datetime import datetime, date, timedelta
import dotenv
from ag_log import ag_log
from ag_secrets import SecretsClient
from ag_data_access import data_upload as du

class Ewindow():

    def __init__(self) -> None:
        secrets_client = SecretsClient()
        ewindow_credentials = secrets_client.get_secret(name="eWindow")
        login_email = ewindow_credentials.username
        login_password = ewindow_credentials.password
        appkey = ewindow_credentials.token
        ci.set_credentials(login_email, login_password, appkey)
        self.ewmd = ci.EWindowMarketData()

    def datetime_fromat_str(self, time_string):
        if '.' not in str(time_string):
            time_string = str(time_string) + '.000' 
        return time_string

    def get_ewindow_hist_data(self, year, month, start_day, end_day):
        first = datetime(year, month, start_day).date()
        last = datetime(year, month, end_day).date()
        df = self.ewmd.get_botes(order_time_gte=first, order_time_lte=last, paginate=True)
        return df

    def get_data(self, start_date, end_date, pag=True):
        df = self.ewmd.get_botes(order_time_gte=start_date, order_time_lte=end_date, paginate=pag)
        return df

    def check_year_format(self, d):
        fixed_date = str(d).split('-')
        if len(fixed_date[0]) == 2:
            fixed_date[0] = '20' + fixed_date[0] if int(fixed_date[0]) <= 50 else '19' + fixed_date[0]
        return '-'.join(fixed_date)

    def clean_data(self, data):
        if not data.empty:
            data = data.replace('\n',' ',regex=True).replace('\r',' ',regex=True).replace("\''", '\"', regex=True).replace('""', '\"', regex=True)
            data = data.dropna(how='all')
            data['market_raw'] = data['market']
            data['market'] = data['market'].str[0]
            data['update_time'] = data['update_time'].apply(lambda x: self.datetime_fromat_str(x))
            data['order_time'] = data['order_time'].apply(lambda x: self.datetime_fromat_str(x))
            data['order_time'] = data['order_time'].apply(lambda x: self.check_year_format(x))
            data['order_time'] = pd.to_datetime(data['order_time']).dt.strftime("%Y-%m-%d %H:%M:%S.%f").str[:-3]
        return data

    def main(self):

        # year = 2023
        # month = 11
        # first, last = calendar.monthrange(year, month)
        # data = self.get_ewindow_hist_data(year, month, 1, last)
        start_date = date.today() - timedelta(days=7)
        end_date = date.today()
        logging.info(f"{start_date=}, {end_date=}")
        logging.info(f"Before get_data")
        data = self.get_data(start_date, end_date)
        logging.info(f"After get_data, {len(data)} rows")
        logging.info(f"Before clean_data")
        df = self.clean_data(data)
        logging.info(f"After clean_data, {len(df)} rows")
        logging.info(df)

        filename_prefix = "Upload_oil_ewindow_trade_data-"
        du.upload_to_database(df, filename_prefix, index=False, env=os.environ["environment"].upper())

if __name__ == '__main__':

    dotenv.load_dotenv(override=True)
    log = ag_log.get_log()

    ew = Ewindow()
    ew.main()
    logging.info("Complete")