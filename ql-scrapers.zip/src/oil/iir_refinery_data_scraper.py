import os
import sys
import time
import shutil
import glob as gb
import pandas as pd
from datetime import datetime

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder

historical_data_file_folder = r'\\petroineos.local\dfs\Department Private Folders\Analysis Department\Crude\TARS'
daily_file_folder = r'\\petroineos.local\dfs\Department Private Folders\Analysis Department\Crude\TARS\FTP'
archive_folder = r'\\petroineos.local\dfs\Department Private Folders\Analysis Department\Crude\TARS\FTP\Archive'
bulk_uploader_folder = bulkUploaderFolder
format_datetime = '%y%m%d%H%M%S'


def archive(file):
    shutil.move(file, os.path.join(archive_folder, os.path.basename(file)))


def generate_unique_file_name(targetFile):
    return os.path.join(bulk_uploader_folder, targetFile + datetime.today().strftime(format_datetime) + '.csv')


def process_refinery_data_file(df, columns, targetFile, renameColumns):
    full_target_path = generate_unique_file_name(targetFile)
    log.debug(list(df.columns))
    df_target = df[columns]
    if renameColumns:
        df_target.rename(columns=renameColumns, inplace=True)

    df_target.to_csv(full_target_path, header=True,index=False)
    log.debug('File created: ' + targetFile)

    #generate latest file:
    if targetFile == 'Upload_OIL_RefineryMaintenance-':
        targetFile = 'Upload_OIL_RefineryMaintenanceLatest-'
        full_target_path = generate_unique_file_name(targetFile)
        df_target.to_csv(full_target_path, header=True,index=False)
        log.debug('File created: ' + targetFile)


def get_refinery_raw_data(sourceFile):
    df = pd.read_csv(sourceFile)
    df = remove_unwanted_char(df)
    return df


def get_files(folder, filemask):
    return gb.glob(os.path.join(folder, filemask))


def remove_unwanted_char(df):
    df = df.astype(str)
    for column in df.columns:
        df[column] = df[column].str.replace(r"[\"\']", '')
        df[column] = df[column].str.replace('[', '')
        df[column] = df[column].str.replace(',', ';')
        df[column] = df[column].str.replace(']', '')
        df[column] = df[column].replace('nan', '')
    return df


def get_processed_file_list(cache_file):
    with open(cache_file, 'r') as my_file:
        my_list = [line.strip() for line in my_file]
        return my_list


def save_processed_file_list(cache_file,file_list):
    with open(cache_file, 'w') as outfile:
        for f in file_list:
            outfile.write(f)
            outfile.write('\n')


def validate(df):
    df_empty = df.loc[df['TA_START']=='']
    if len(df_empty) != 0:
        raise ValueError('empty value found in TA_START')
    return


def process_daily_files():
    procesed_file_list_cache = os.path.join(daily_file_folder, r'cache\processed_file_list.csv')
    refinery_maintenance_raw_file = 'Upload_OIL_RefineryMaintenanceIir-'
    daily_maintenance_columns = ['OUTAGE_ID', 'UNIT_NAME', 'UNIT_ID', 'PLANT_ID', \
                                 'PLANT_NAME', 'CHARGERATE', 'CAPACITY', \
                                 'TA_START', 'TA_END', 'PRECISION', 'OUTAGE_TYP', 'OUTAGE_STA', 'DELV_DATE', \
                                 'COMMENTS', 'OUT_CAUSE']
    renamed = {'OUTAGE_ID': 'EVENT_ID', 'CHARGERATE': 'U_CAPACITY', 'CAPACITY': 'CAP_OFFLINE',
               'TA_START': 'START_DATE', 'TA_END': 'END_DATE', 'OUTAGE_TYP': 'EVENT_TYPE', 'OUTAGE_STA': 'E_STATUS',
               'DELV_DATE': 'PDate', 'OUT_CAUSE': 'E_CAUSE'}
    log.debug("Get Processed File List.")
    processed_file_list = get_processed_file_list(procesed_file_list_cache)

    for dailyFile in get_files(daily_file_folder, "*.csv"):
        if dailyFile in processed_file_list:
            continue
        else:
            log.debug("Processing TARS data file:" + dailyFile)
            df = get_refinery_raw_data(dailyFile)
            if 'WORLD_REGION' in df.columns:
                df = df.drop(columns=['WORLD_REGION'])
            validate(df)
            upload_raw_file(df, refinery_maintenance_raw_file)
            processed_file_list.append(dailyFile)
            time.sleep(2)
    log.debug("Save Processed File List.")
    save_processed_file_list(procesed_file_list_cache, processed_file_list)


def upload_raw_file(df, refinery_maintenance_raw_file):
    rawfile = generate_unique_file_name(refinery_maintenance_raw_file)
    df['PDate'] = df['DELV_DATE']
    log.debug("RAW File Saved to: {0}.".format(rawfile))
    # df.to_csv(rawfile, header=True,index=False)
    su.upload_to_database(df, refinery_maintenance_raw_file)


def process_historical_data():
    unit_hist_source_files = ['2013.csv','2014.csv','2015.csv','2016.csv','2017.csv','2018(1).csv','2018(2).csv','2019(1).csv','2019-20.csv']
    unit_columns = [
        'UNIT_ID', 'UNIT_NAME', 'AREA_ID', 'AREA_NAME', 'PLANT_ID', 'PLANT_NAME', 'OWNER_NAME', 'COUNTRY', 'LIVE_DATE',
        'PHYS_CITY', 'U_STATUS', 'UTYPE_DESC', 'U_CAPACITY','CAP_UOM']

    unit_target_file = 'Upload_OIL_RefineryUnit-'

    refinery_columns = ['PLANT_ID', 'PLANT_NAME','PARENTNAME', 'OWNER_NAME', 'PHYS_CITY', 'P_COUNTY', \
                         'PLANT_STATE', 'COUNTRY', 'MARKET_REG', 'WORLD_REG', 'NERC_REG', \
                         'NERC_SUB', 'PRIM_FUEL', 'SECND_FUEL', 'FUEL_GROUP',\
                         'LATITUDE', 'LONGITUDE', 'CAP_UOM', 'IND_CODE','IND_DESC', \
                        'POWER_USAG', 'HEATRATE', 'CTRLAREAID','CTLAREADES', \
                        'PADD_REG','ISORTOREGION', 'P_TRADE_REGION', 'GAS_REGION',\
                        'AREA_ID', 'AREA_NAME', 'OFF_BLOCK', 'OFF_BLOCK2', 'WATERBODY',\
                        'OFFSHORE_F', 'OFF_AREA_N', 'OFF_CTRY_D',  'CONFIRM']

    refinery_target_file = 'Upload_OIL_Refinery-'

    maitenance_columns = ['EVENT_ID', 'EVENT_KIND', 'UNIT_NAME', 'UNIT_ID', 'PLANT_ID', \
                         'PLANT_NAME', 'START_DATE', 'END_DATE', 'E_DURATION', 'EVENT_TYPE', 'PRECISION',\
                        'E_CAUSE', 'E_STATUS', 'PREV_START', 'PREV_END','RELEASE_DT','U_CAPACITY','CAP_OFFLINE',\
                        'COMMENTS']

    refinery_maintenance_target_file = 'Upload_OIL_RefineryMaintenance-'

    for unit_hist_source_file in unit_hist_source_files:
        df = get_refinery_raw_data(unit_hist_source_file)
        validate(df)
        fullPath = os.path.join(historical_data_file_folder, unit_hist_source_file)
        process_refinery_data_file(df, unit_columns, unit_target_file, 'UNIT_ID', None)
        process_refinery_data_file(df, refinery_columns, refinery_target_file, 'PLANT_ID', {'PARENTNAME': 'PARENT_NAME'})
        process_refinery_data_file(df, maitenance_columns, refinery_maintenance_target_file, 'EVENT_ID', {'RELEASE_DT': 'PDate'})
        time.sleep(2)


def main():
    log.debug(os.getcwd())
    log.debug("Env:" + env)
    log.debug('Starting IIR Refinery scraper...')
    pd.set_option('mode.chained_assignment', None)
    try:
        #process_historical_data()
        log.debug("Processing Dailys Files.")
        #below is prod.
        process_daily_files()
        #back_fill_flattened_daily(date(2020, 9, 1), 28)
        #back_fill_flattened_daily(date(2020, 1, 1), 255)
        log.debug('IIR Refinery scraper job completed!')
    except Exception as e:
        log.error(e)
        log.debug("Job Ended with Error!!!")
        return 1

    log.debug('Exit.')
    return 0


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())


