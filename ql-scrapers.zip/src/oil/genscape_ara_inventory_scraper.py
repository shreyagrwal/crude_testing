import logging
import os
from datetime import datetime as dt
import pandas as pd
import requests
from ag_log import ag_log
from ag_secrets import SecretsClient
from ag_data_access import data_upload as du
import dotenv

def safely_update_metadata(tsa, series_name, metadata: dict):
    esixting_metadata = tsa.metadata(series_name)
    tsa.update_metadata(series_name, esixting_metadata | metadata)


def upload_stocks(tsa, df, product, flag):
    if flag == 'ara':
        metadata = {
            'storage': {
                'series_id': f'{product}.ara.genscape.ending_stocks.kt.weekly.directfeed',
                'product': f'{product}',
                'zone': 'ara',
                'source': 'genscape',
                'economic_property': 'ending_stocks',
                'unit': 'kt',
                'frequency': 'week',
            },
            'utilization': {
                'series_id': f'{product}.ara.genscape.storage_utilization.kt.weekly.directfeed',
                'product': f'{product}',
                'zone': 'ara',
                'source': 'genscape',
                'economic_property': 'storage_utilization',
                'unit': 'kt',
                'frequency': 'week',
            }

        }
    elif flag == 'nyh':
        metadata = {
            'storage': {
                'series_id': f'{product}.nyh.genscape.ending_stocks.kb.weekly.directfeed',
                'product': f'{product}',
                'zone': 'nyh',
                'source': 'genscape',
                'economic_property': 'ending_stocks',
                'unit': 'kb',
                'frequency': 'week',
            },
            'utilization': {
                'series_id': f'{product}.nyh.genscape.storage_utilization.kb.weekly.directfeed',
                'product': f'{product}',
                'zone': 'nyh',
                'source': 'genscape',
                'economic_property': 'storage_utilization',
                'unit': 'kb',
                'frequency': 'week',
            }

        }
    if not df.empty:
        data = df.set_index('reportDate')
        data.index = pd.to_datetime(data.index)
        for k in metadata:
            try:
                tsa.update(
                    metadata[k]['series_id'],
                    data[k],
                    'directfeed'
                )
                logging.info(metadata[k]['series_id'])
            except:
                logging.info(f"{k} not imported as raw data")
            safely_update_metadata(tsa, metadata[k]['series_id'], metadata[k])
    else:
        logging.info('No data detected!')


def update_saturn_series(df):
    from tshistory.api import timeseries
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')

    logging.info(df['product'].unique())
    for prod in df['product'].unique():
        logging.info(prod, ' - ara')
        filtered_ara = df[
            (df['region'] != 'New York Harbor') &
            (df['product'] == prod)
            ]
        prod = prod.replace(' ', '').replace('/', '').lower()
        ara_df = filtered_ara.groupby('reportDate').sum().reset_index()
        ara_df['storage'] = ara_df['storageAmount'] / 1000.
        ara_df['utilization'] = ara_df['storageAmount'] / ara_df['operationalCapacity']
        ara_df.sort_values(by='reportDate', inplace=True)
        # logging.info(ara_df[['reportDate','storage','utilization']])
        upload_stocks(tsa, ara_df, prod, 'ara')
        logging.info('*****************')
    for prod in df['product'].unique():
        logging.info(prod, ' - nyh')
        filtered_ny = df[
            (df['region'] == 'New York Harbor') &
            (df['product'] == prod)
            ]
        prod = prod.replace(' ', '').replace('/', '').lower()
        ny_df = filtered_ny.groupby('reportDate').sum().reset_index()
        ny_df['storage'] = ny_df['storageAmount'] / 1000.
        ny_df['utilization'] = ny_df['storageAmount'] / ny_df['operationalCapacity']
        ny_df.sort_values(by='reportDate', inplace=True)
        # logging.info(ny_df[['reportDate','storage','utilization']])
        upload_stocks(tsa, ny_df, prod, 'nyh')
        logging.info('*****************')


if __name__ == '__main__':
    dotenv.load_dotenv(override=True)
    ag_log.get_log()
    logging.info("Begin")

    secrets_client = SecretsClient()
    genscape_credential = secrets_client.get_secret(name="genscape_key")
    logging.info(f"Got credential {genscape_credential}")

    SONIA_KEY = genscape_credential.token
    sheaders = {'Gen-Api-Key': SONIA_KEY}
    ENDPOINT_HO = f'https://api.genscape.com/storage/oil/v1/region-volumes' \
                  f'?regions=NewYorkHarbor&products=HeatingOil&' \
                  f'revision=published&limit=5000&offset=0'
    ENDPOINT_ARA = f'https://api.genscape.com/storage/oil/v1/region-volumes' \
                   f'?regions=Amsterdam,Rotterdam,Antwerp,Flushing&products=HeatingOil&' \
                   f'revision=published&limit=5000&offset=0'
    logging.info(ENDPOINT_HO)
    response1 = requests.get(ENDPOINT_HO, headers=sheaders)
    data1 = pd.DataFrame.from_records(response1.json()['data'])
    response3 = requests.get(ENDPOINT_ARA, headers=sheaders)
    data3 = pd.DataFrame.from_records(response3.json()['data'])
    ENDPOINT_GAS = f'https://api.genscape.com/storage/oil/v1/region-volumes' \
                   f'?revision=published&limit=5000&offset=0'
    response2 = requests.get(ENDPOINT_GAS, headers=sheaders)
    data2 = pd.DataFrame.from_records(response2.json()['data'])
    now = dt.now()
    date_fmt = '%y%m%d%H%M%S'
    prefix = 'Upload_OIL_GenscapeAraInventory'
    data = pd.concat((data1, data2, data3))
    logging.info(data)
    du.upload_to_database(data, prefix + '-', env=os.environ["environment"].upper())

    update_saturn_series(data.drop_duplicates().reset_index(drop=True))
    logging.info("Complete")
