import requests
import json, sys, os
import pandas as pd
import random
from datetime import datetime
from googletrans import Translator
sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

class BaiduScraper:
    
    '''
    This class scrapes the traffic congestion of China and upload to BlueOcean
    '''
    
    def __init__(self) -> None:

        url = 'https://jiaotong.baidu.com/trafficindex/city/list/'
        user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36'
        headers = {'User-Agent': user_agent}
        self.response_API = requests.get(url, headers=headers)
        # print(response_API.status_code)

    def scraper(self):

        log.debug("Env:" + env)
        log.debug("Data File Folder:{0}".format(upload_folder))
        
        log.debug("Start scrapping..")
        data = self.response_API.text
        parse_json = json.loads(data)
        df = pd.DataFrame(parse_json['data']['list'])
        # df['PublishedTime'] = parse_json['data']['datetime']
        
        translator = Translator()
        df['city'] = df['cityname'].apply(lambda x: translator.translate(str(x)).text)
        df['province'] = df['provincename'].apply(lambda x: translator.translate(str(x)).text)
        
        df = df.drop(['cityletter', 'city_coords', 'city_center', 'cityname', 'provincename'], axis = 1)
        log.debug("Uploading data to BlueOcean..")
        filename_prefix = "Uoload_oil_china_baidu_trafficcongestion-"
        su.upload_to_database(df, filename_prefix)

if __name__ == '__main__':
    
    env = se.environment
    upload_folder = se.ingestion_folder
    log = ag_log.get_log()

    scr = BaiduScraper()
    scr.scraper()


