__doc__ = f""" Scrapes the Flight Radar Website

    Flight Radar website, 'flightradar24.com', tracks live flight data. This is used to indicate levels of fuel 
    consumption in the market. 

:param Developer: Charles Cai (Charles.Cai@pPetroNneos.com)
:param Owner: Charles Cai (Charles.Cai@pPetroNneos.com)
:param DatabaseTable: hive_metastore.dataengineering.oil_jet_flightradar
:param ActiveBatchJob: FlightRadar Scraper
:param Server: AP3
:param Schedule: Tuesday Mornings
:param Notes: 
    - Scraper will take 2 DAYS to finish
    - Check BO ingestion folder -> "S:\~Analysis Department\ApplicationFolder\BlueOceanBlobDataUploader\PROD"
    - See if files are being generated e.g. "Upload_OIL_Flightradar-Italy-......"
"""


import os
import ast
import sys
import time
import random
import scrapy
import numpy as np
import pandas as pd
from scrapy import cmdline
from datetime import datetime

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder

log = ag_log.get_log()


class ScrapeflightsSpider(scrapy.Spider):
    name = 'scrapeflights'
    allowed_domains = ['flightradar24.com']
    # start_urls = ['https://flightradar24.com/data/airports']

    def start_requests(self):
        yield scrapy.Request(url='https://flightradar24.com/data/airports', callback=self.parse, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
        })

    def parse(self, response):

        north_am = ['Canada', 'Mexico', 'United States']
        south_am = ['Argentina', 'Brazil', 'Chile', 'Colombia', 'Ecuador', 'Peru', 'Trinidad And Tobago', 'Venezuela']
        eur = ['Austria', 'Belgium', 'Czechia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy',
               'Netherlands', 'Norway', 'Poland', 'Portugal', 'Romania', 'Spain', 'Sweden', 'Switzerland',
               'Turkey', 'Ukraine', 'United Kingdom']
        cis = ['Azerbaijan', 'Belarus', 'Kazakhstan', 'Russia', 'Turkmenistan', 'Uzbekistan']
        mid_east = ['Iran', 'Iraq', 'Israel', 'Kuwait', 'Oman', 'Qatar', 'Saudi Arabia', 'United Arab Emirates']
        africa = ['Algeria', 'Egypt', 'Morocco', 'South Africa']
        asia_pac = ['Australia', 'Bangladesh', 'China', 'India', 'Indonesia', 'Japan', 'Hong Kong', 'Malaysia',
                    'New Zealand', 'Pakistan', 'Philippines', 'Singapore', 'South Korea', 'Sri Lanka',
                    'Taiwan', 'Thailand', 'Vietnam']
        #country_list = np.array([eur, north_am, asia_pac, mid_east, cis, south_am, africa])
        country_list = np.array([eur, north_am, asia_pac])
        #country_list = [eur + north_am + asia_pac + mid_east + cis + south_am + africa]

        # t = time.process_time()
        # if t > 0 and t < 27600:
        #     chosen_region = eur
        # elif t > 27600 and t < 83080:
        #     chosen_region = north_am
        # elif t > 83090 and t < 120410:
        #     chosen_region = asia_pac
        # elif t > 120410 and t < 124730:
        #     chosen_region = mid_east
        # elif t > 124730 and t < 132210:
        #     chosen_region = cis
        # elif t > 132210 and t < 143450:
        #     chosen_region = south_am
        # elif t > 143450 and t < 146650:
        #     chosen_region = africa

        for chosen_region in country_list:

            country_name_list = []
            country_url_list = []
            for row in response.xpath("//*[@id='tbl-datatable']/tbody/tr[not(@class='header')][position()>1]"):
                country_name = row.xpath("normalize-space(.//td[3]/a/text())").get()
                country_name_list.append(country_name)
                country_url = row.xpath("td[3]/a/@href[contains(.,'http')]").get()
                country_url_list.append(country_url)

            country_dict = dict(zip(country_name_list,country_url_list))


            for key,value in country_dict.items():
                if key in chosen_region:
                    yield response.follow(url=value, callback=self.parse_country_link, headers={
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
                    })
                else:
                    continue

    def parse_country_link(self, response):
        # logging.info(response.url)
        for row in response.xpath("//*[@id='tbl-datatable']/tbody/tr[not(@class='header')][position()>1]"):
            airport_url = row.xpath(".//td[2]/a/@href").get()
            if airport_url:
                log.debug("Airport URL: " + airport_url)
                yield response.follow(url=airport_url, callback=self.parse_airport_link, headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
                })

    def parse_airport_link(self, response):
        statistics_url = response.xpath("//nav[@class='btn-group btn-block']/a[position() = last()]/@href").get()
        yield response.follow(url=statistics_url, callback=self.parse_data_link, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
        })

    def parse_data_link(self, response):
        for row in response.xpath("//div[@id='content']/div/section/div/section"):
            airport_name = row.xpath(
                "normalize-space(.//header/div[@class='row cnt-airport-details']/div/div/h1/text())").get()
            if "'" in airport_name:
                airport_name = airport_name.replace("'","")
            airport_shortcode = row.xpath(
                "normalize-space(.//header/div[@class='row cnt-airport-details']/div/div/h2/text())").get()
            if airport_shortcode:
                airport_shortcode = airport_shortcode[:3]
            airport_country = row.xpath(
                "normalize-space(.//header/div[@class='row cnt-airport-details']/div/div/h3/text())").get()

            output = row.xpath(
                "//div[@id='content']/div/section/div/section[@id='cnt-data-content']/script[1]/text()").get().splitlines()

            scheduled = output[0].replace("var flightsScheduled = ", "")
            tracked = output[1].replace("    var flightsTracked = ", "")
            scheduled_list = ast.literal_eval(scheduled[:-1])
            tracked_list = ast.literal_eval(tracked[:-1])
            scheduled_output = [i[1] for i in scheduled_list]
            tracked_output = [i[1] for i in tracked_list]

            dates_output = [i[0] for i in scheduled_list]
            dates_output = [datetime.fromtimestamp(int(i) / 1000) for i in dates_output]
            ddates_output = [i.strftime("%Y-%m-%d") for i in dates_output]

            pdates_output = [datetime.now().strftime("%Y-%m-%d")] * len(dates_output)
            airport_name_output = [airport_name] * len(dates_output)
            airport_shortcode_output = [airport_shortcode] * len(dates_output)
            airport_country_output = [airport_country] * len(dates_output)

            dataframe_input = [pdates_output, ddates_output, airport_name_output, airport_shortcode_output,
                               airport_country_output, scheduled_output, tracked_output]
            dataframe_input_T = list(zip(*dataframe_input))
            df = pd.DataFrame(data=dataframe_input_T,
                              columns=['PDate', 'DDate', 'Airport', 'Shortcode', 'Country', 'Scheduled', 'Tracked'])

            timestamp = datetime.now().strftime("%y%m%d%H%M%S")
            #path = 'S:/~Analysis Department/ApplicationFolder/BatchUploader/UAT/FlightradarTest/'
            path = bulkUploaderFolder
            airport_country = airport_country.replace(" ","")
            df.to_csv(
                path + "\\" + 'Upload_OIL_Flightradar-' + airport_country + '_' + airport_shortcode + '_' + timestamp + '.csv',
                index=False)

            time.sleep(random.randint(19, 24))


if __name__ == '__main__':

    cmdline.execute("scrapy runspider oil/flightradar_scraper.py --set DOWNLOAD_DELAY=5".split())
