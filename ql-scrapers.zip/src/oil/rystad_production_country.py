import os
import sys
import pysftp
import shutil
import random
import zipfile
import numpy as np
import pandas as pd
from datetime import datetime

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

import warnings
warnings.filterwarnings('ignore')

class RystadDataset():

    def __init__(self):

        self.hst = "ftp.rystadenergy.com"
        self.pwrd = "5tgb%TGB1qaz!QAZ"
        self.usr = "ftppetroineosuser01"
        self.temp_path = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RystadOilProduction\\'
        self.unzipped_path = os.path.join(self.temp_path, "unzipped")
        self.rystad_zipfile_name = 'OilMarketCube.zip'
        self.format_datetime = '%y%m%d%H%M%S'

    def get_max_pdate(self):

        query = '''
        SELECT MAX(PDate) AS PDate FROM hive_metastore.dataengineering.oil_rystad_rystadproduction where IsActive = True
        '''
        pdates = bo.get_data(query)['PDate']
        return pdates[0]

    def ftp_download(self):

        print('Downloading FTP files ...')
        host = self.hst
        password = self.pwrd
        username = self.usr
        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None
        with pysftp.Connection(host, username=username, password=password, cnopts=cnopts) as sftp:
            sftp.get(remotepath='/OilMarketCube/OilMarketCube.zip', localpath=self.temp_path + self.rystad_zipfile_name)


    def get_rystad_data(self, dataset):

        print(f'Getting Rystad data for {dataset} ...')
        filename = dataset + '.csv'
        df = pd.read_csv(os.path.join( self.unzipped_path, filename), sep='|', encoding='cp1252')
        return df


    def unzip(self, sfolder, filename, dfolder):

        if (os.path.isfile(os.path.join(sfolder, filename))):
            if (filename.endswith(".zip")):
                print('Unzipping files ...')
                with zipfile.ZipFile(os.path.join(sfolder, filename), 'r') as zip_ref:
                    zip_ref.extractall(dfolder)
                log.debug("unzip file {} complete".format(filename))
            else:
                log.debug("No .zip file found")

    def unzipfile(self):

        if os.path.exists(self.unzipped_path):
            shutil.rmtree(self.unzipped_path)
        self.unzip(self.temp_path, self.rystad_zipfile_name, self.unzipped_path)

    def archive(self):

        print('Archiving files ...')
        shutil.move(self.temp_path + "\\" + self.rystad_zipfile_name,
                    self.temp_path + "\\archive\\" + self.rystad_zipfile_name + '.' + datetime.today().strftime(self.format_datetime))

    def process_production_data(self):

        print('Processing has started ...')
        # Get Production dataset
        df_production_all = self.get_rystad_data('Production')
        df_production_all.set_index('Id')
        log.debug(df_production_all.columns)

        # Adds Crude Stream
        df_crudestream = self.get_rystad_data('CrudeStream')[['Id', 'Crude Grade']]
        df_production_all = pd.merge(df_production_all, df_crudestream, left_on='FK_CrudeStream', right_on='Id', how='left')
        del df_crudestream
        df_production_all = df_production_all.drop(['Id_x','FK_CrudeStream'], axis =1)

        # Adds OilAndGas 
        df_oilandgas = self.get_rystad_data('OilAndGas')[['Id', 'API Group']]
        df_production_all = pd.merge(df_production_all, df_oilandgas, left_on='FK_OilOilAndGas', right_on='Id', how='left')
        del df_oilandgas
        df_production_all = df_production_all.drop(['Id_y','FK_OilOilAndGas'], axis =1)

        # Adds Sulphur
        df_sulphur = self.get_rystad_data('Sulphur')[['Id', 'Sulphur Group']]
        df_production_all = pd.merge(df_production_all, df_sulphur, left_on='FK_Sulphur', right_on='Id', how='left')
        del df_sulphur
        df_production_all = df_production_all.drop(['Id_y','FK_Sulphur'], axis =1)

        # Adds Asset
        df_asset = self.get_rystad_data('Asset')[['Id', 'FK_Geography']]
        df_production_all = pd.merge(df_production_all, df_asset, left_on='FK_Asset', right_on='Id', how='left')
        del df_asset
        df_production_all = df_production_all.drop(['Id_x','FK_Asset'], axis =1)

        # Adds Outage
        df_outage = self.get_rystad_data('Outage')[['Id', 'Outage Group', 'Outage Detail']]
        df_production_all = pd.merge(df_production_all, df_outage, left_on='FK_Outage', right_on='Id', how='left')
        del df_outage
        df_production_all = df_production_all.drop(['Id_x','FK_Outage'], axis =1)

        # Adds Meta Data
        df_metadata = self.get_rystad_data('Metadata')[['Id', 'Last Updated']]
        df_production_all = pd.merge(df_production_all, df_metadata, left_on='FK_Metadata', right_on='Id', how='left')
        del df_metadata
        df_production_all = df_production_all.drop(['Id_y','FK_Metadata'], axis =1)

        # Adds Timeline
        df_timeline = self.get_rystad_data('Timeline')[['Id', 'Year Month']]
        df_production_all = pd.merge(df_production_all, df_timeline, left_on='FK_TimeLine', right_on='Id', how='left')
        del df_timeline
        df_production_all = df_production_all.drop(['Id_y','FK_TimeLine'], axis =1)

        # Adds Location
        df_location = self.get_rystad_data('Geography')[['Id', 'Country', 'EIA PADD District']]
        df_production_all = pd.merge(df_production_all, df_location, left_on='FK_Geography', right_on='Id', how='left')
        del df_location        

        print(df_production_all.columns)
        log.debug(df_production_all.columns)

        df_production_all.rename(
            columns={'Year Month': 'DDate', 
            'Production wo Seasonality': 'Prod_WO_Seasonality', 
            'Crude Grade': 'Crude_Grade', 
            'Sulphur Group': 'Sulphur_Group',
            'Outage Group': 'Outage_Group', 
            'Outage Detail': 'Outage_Detail', 
            'Last Updated': 'PDate', 
            'EIA PADD District': 'EIA_PADD_District',
            'API Group': 'API_Group'},
        inplace=True)

        df_production_all['DDate'] = df_production_all['DDate'] + '-01'
        df_production_all['DDate'] = pd.to_datetime(df_production_all['DDate'], format='%Y-%m-%d')
        df_production_all['PDate'] = pd.to_datetime(df_production_all['PDate'])

        df_production_all['Country'] = df_production_all['Country'].str.replace(',', ';', regex=True).str.replace('/', "_", regex=True).str.replace('-', '_', regex=True).str.replace('"', "", regex=True).str.replace("'", "", regex=True).str.replace(".", "", regex=True).str.replace(" ", "_", regex=True)
        df_production_all['Outage_Detail'] = df_production_all['Outage_Detail'].str.replace(',', ';', regex=True).str.replace('/', "_", regex=True).str.replace('-', '_', regex=True).str.replace('"', "", regex=True).str.replace("'", "", regex=True).str.replace(".", "", regex=True)
        df_production_all['EIA_PADD_District'] = df_production_all['EIA_PADD_District'].str.replace(" ", "_", regex=True)

        df_production = df_production_all[
            ['Production', 'Prod_WO_Seasonality', 'Crude_Grade', 'API_Group',
            'Sulphur_Group', 'Outage_Group', 'Outage_Detail', 'PDate',
            'DDate', 'Country', 'EIA_PADD_District']]

        log.debug(df_production.columns)

        df_production['n_days'] = df_production['DDate'].dt.days_in_month
        df_production['Production'] = (df_production['Production']*1000)/df_production['n_days']
        df_production['Prod_WO_Seasonality'] = (df_production['Prod_WO_Seasonality']*1000)/df_production['n_days']
        df_production = df_production.drop(['n_days'], axis =1)

        # Creating pivot table
        df_production_pvt = pd.pivot_table(df_production,
               index=['PDate', 'DDate', 'Country', 'Sulphur_Group', 'Outage_Group', 'Outage_Detail',
                      'Crude_Grade', 'API_Group', 'EIA_PADD_District'], values=['Production', 'Prod_WO_Seasonality'],
               aggfunc=np.sum)
        df_production_pvt.reset_index(inplace=True)
        df_production_pvt['Unit'] = 'kbd'
        print(df_production_pvt)
        return df_production_pvt
    
    def main(self):

        try:
            log.debug('Download new file from sftp server')
            self.ftp_download()
            log.debug('unzip file')
            self.unzipfile()
            log.debug('Process production data')
            df = self.process_production_data()
            log.debug('Archive data')
            self.archive()
            filename_prefix = "Upload_OIL_Rystad_Production_"
            su.upload_to_database(df, filename_prefix)
        except Exception as e:
            print(e)
            log.debug(e)

if __name__ == '__main__':

    env = se.environment
    upload_folder = se.ingestion_folder
    log = ag_log.get_log()

    rd = RystadDataset()
    rd.main()