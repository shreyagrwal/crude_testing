"""
this is a Python script to do a one-off bulk import from multiple Excel files
We have 2 kinds of Excel files
    First-Just having 1 sheet
    Second-Multiple sheets. Each sheet representing a specific month
"""
import datetime
import logging
import os.path
from pathlib import Path
import dotenv
from ag_log import ag_log
import lib as lib


def parse_all_deliveries_and_stocks_runner_with_single_sheet_in_folder(excel_folder: str):
    """
    This function handles those Excel documents which have just 1 sheet
    """
    files_objects = Path(excel_folder).glob("*ivraisonsEtStocks*.xls")
    for file_obj in files_objects:
        excel_file = str(file_obj)
        logging.info(f"Going to process the file {excel_file}")
        logging.info("-------------------")
        product_code_mapper = lib.LanguageMapper(map_file_name="product_code_language_map.csv")
        subproduct_code_mapper = lib.LanguageMapper(map_file_name="subproduct_code_language_map.csv")
        parser = lib.ReleasedForConsumptionParser(excel_file=excel_file, product_code_mapper=product_code_mapper,
                                                  subproduct_code_mapper=subproduct_code_mapper)
        df = parser.parse()
        bo_file_name = "cpdp_release_for_consumption_{datestr}.csv".format(
            datestr=parser.document_date.strftime("%Y-%m-%d"))
        bo_destination_path = bo_file_name
        df.to_csv(bo_destination_path, index=False)
        logging.info(f"The BO file was written to {bo_destination_path}, {len(df)} records found")

        product_code_mapper = lib.LanguageMapper(map_file_name="product_code_language_map.csv")
        subproduct_code_mapper = lib.LanguageMapper(map_file_name="subproduct_code_language_map.csv")
        stock_distribution_at_eom_parses = lib.StockAtEndOfMonthDistributionParser(excel_file=excel_file,
                                                                                   document_date=parser.document_date,
                                                                                   product_code_mapper=product_code_mapper,
                                                                                   subproduct_code_mapper=subproduct_code_mapper)

        df = stock_distribution_at_eom_parses.parse()
        bo_file_name = "cpdp_stock_distribution_at_end_of_month_{datestr}.csv".format(
            datestr=parser.document_date.strftime("%Y-%m-%d"))
        bo_destination_path = bo_file_name
        df.to_csv(bo_destination_path, index=False)
        parse_stock_at_end_of_month(excel_file=excel_file, ddate=stock_distribution_at_eom_parses.document_date)

    pass


def parse_stock_at_end_of_month(excel_file: str, ddate: datetime.date):
    product_code_mapper = lib.LanguageMapper(map_file_name="product_code_language_map.csv")
    subproduct_code_mapper = lib.LanguageMapper(map_file_name="subproduct_code_language_map.csv")
    parser = lib.StockAtEndOfMonthDistributionParser(excel_file=excel_file, document_date=ddate,
                                                     product_code_mapper=product_code_mapper,
                                                     subproduct_code_mapper=subproduct_code_mapper)

    df = parser.parse()
    bo_file_name = "cpdp_stock_distribution_at_end_of_month_{datestr}.csv".format(
        datestr=parser.document_date.strftime("%Y-%m-%d"))
    bo_destination_path = bo_file_name
    df.to_csv(bo_destination_path, index=False)
    logging.info(f"The BO file was written to {bo_destination_path}, {len(df)} records found")
    pass


def parse_all_deliveries_and_stocks_runner_with_multi_sheet_in_folder(excel_folder: str):
    """
    This function handles Excel documents which have multiple sheets named as 'Page1', Page2' up to 'Page12'
    Each sheet representing a month
    """
    files_objects = Path(excel_folder).glob("*Annuelles*.xls")
    for file_obj in files_objects:
        excel_file = str(file_obj)
        logging.info(f"Going to process the file {excel_file}")
        logging.info("-------------------")
        work_sheets = [f"Page{n + 1}" for n in range(12) if True]
        for work_sheet in work_sheets:
            logging.info(f"Processing work sheet: {work_sheet}")
            product_code_mapper = lib.LanguageMapper(map_file_name="product_code_language_map.csv")
            subproduct_code_mapper = lib.LanguageMapper(map_file_name="subproduct_code_language_map.csv")
            parser = lib.ReleasedForConsumptionParser(excel_file=excel_file,
                                                      product_code_mapper=product_code_mapper,
                                                      subproduct_code_mapper=subproduct_code_mapper)

            df = parser.parse(sheet_name=work_sheet)
            bo_file_name = "cpdp_release_for_consumption_{datestr}_{filename}_{sheet}.csv".format(
                datestr=parser.document_date.strftime("%Y-%m-%d"), sheet=work_sheet, filename=file_obj.name)
            bo_destination_path = bo_file_name
            df.to_csv(bo_destination_path, index=False)
            logging.info(f"The BO file was written to {bo_destination_path}, {len(df)} records found")


if __name__ == "__main__":
    dotenv.load_dotenv(
        override=True)  # take environment variables from a privately managed .env file at the very root of the repo
    log = ag_log.get_log()
    logging.info(f"Begin cpdp scraper {__file__}")

    historic_folder = os.path.join(os.path.dirname(__file__), "historic_files")
    parse_all_deliveries_and_stocks_runner_with_single_sheet_in_folder(excel_folder=historic_folder)
    parse_all_deliveries_and_stocks_runner_with_multi_sheet_in_folder(excel_folder=historic_folder)
