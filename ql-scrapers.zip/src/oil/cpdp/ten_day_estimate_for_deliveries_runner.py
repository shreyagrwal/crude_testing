import logging
import os

from ag_log import ag_log
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import selenium.webdriver.support.wait as wait
import selenium.webdriver.support.expected_conditions as expec
import shutil
import dotenv
import src.oil.cpdp.lib as lib
from ag_data_access import data_upload as du


def extract_csv_from_downloaded_excel(excel_file: str, config: lib.CpdpConfig) -> None:
    logging.info(f"Going to parse Page1 of the {excel_file=}")

    # Extract the table cpdp_ten_day_estimate_for_deliveries
    ten_day_estimate_parser = lib.TenDayEstimateForDeliveryParser(excel_file=excel_file)
    df = ten_day_estimate_parser.parse()
    bo_file_name = "cpdp_ten_day_estimate_for_deliveries_{datestr}".format(
        datestr=lib.Util.convert_date_to_ddate(ten_day_estimate_parser.document_date))
    du.upload_to_database(data=df, filename_prefix=bo_file_name, env=os.environ["environment"].upper(), index=False)

    # Extract the table cpdp_cumulative_ten_day_estimate_for_deliveries
    cumulative_ten_day_estimate_parser = lib.CumulativeTenDayEstimateForDeliveryParser(excel_file=excel_file, language_mapper=lib.LanguageMapper())
    df = cumulative_ten_day_estimate_parser.parse()
    bo_file_name = "cpdp_cumulative_decadely_estimate_for_deliveries_{datestr}".format(
        datestr=lib.Util.convert_date_to_ddate(ten_day_estimate_parser.document_date))
    du.upload_to_database(data=df, filename_prefix=bo_file_name, env=os.environ["environment"].upper(), index=False)


def run_scrape_sequence(driver: webdriver.Chrome, config: lib.CpdpConfig):
    logging.info(f"Going to load the page {config.URL_LOGIN}")
    driver.get(url=config.URL_LOGIN)

    lib.SeleniumCommonSteps.accept_cookies(d=driver, config=config)
    lib.SeleniumCommonSteps.submit_login_password(d=driver, config=config)

    driver.get(url=config.URL)
    logging.info(f"The page {config.URL} was loaded")

    pattern = 'Estimations décadaires des livraisons'
    links_to_report_pages = lib.SeleniumCommonSteps.get_hyperlinks_with_matching_pattern(d=driver, pattern=pattern)
    if len(links_to_report_pages) == 0:
        raise Exception("No Stocks and Deliveries links found were found. Cannot continue")
    logging.info(f"Found {len(links_to_report_pages)} links which match the pattern {pattern}")

    for link in links_to_report_pages:
        purge_download_folder(config=cfg)
        excel_file = download_report(d=driver, config=config, link_url=link[1], link_text=link[0])
        lib.Util.save_excel_file_to_archive_folder(source=excel_file, environment=os.environ["environment"].upper())
        logging.info(f"Got the Excel file {excel_file}")
        extract_csv_from_downloaded_excel(excel_file=excel_file, config=config)


def download_report(d: webdriver.Chrome, config: lib.CpdpConfig, link_url: str, link_text: str) -> str:
    """
    Returns the absolute path to the downloaded Excel file. An exception if unable to download
    """
    logging.info(f"Begin-Navigate to report download page from {link_text=},{link_url=}")
    driver.get(url=link_url)

    wait.WebDriverWait(driver=d, timeout=config.PAGE_LOAD_TIMEOUT_SECS).until(
        expec.presence_of_element_located((By.XPATH, config.DOWNLOAD_PDF_XPATH)))
    logging.info(f"Complete-Navigate to report download page from {link_text=},{link_url=}")

    logging.info(f"Begin-Search for download link")
    pdf_link = d.find_element(by=By.XPATH, value=config.DOWNLOAD_PDF_XPATH)
    logging.info(f"End-Search for download link {pdf_link.text=},url={pdf_link.get_attribute('href')}")
    pdf_link.click()
    logging.info("Link was clicked..wait for download to complete")

    def is_file_xls(x: object) -> bool:
        xls_files = [f for f in os.listdir(config.DOWNLOAD_FOLDER) if os.path.basename(f).lower().endswith(".xls")]
        return len(xls_files) > 0

    wait.WebDriverWait(driver=d, timeout=config.PAGE_LOAD_TIMEOUT_SECS, poll_frequency=2).until(is_file_xls)
    logging.info("Link was clicked..download appears to be complete. Need to check further")

    downloaded_files = os.listdir(path=config.DOWNLOAD_FOLDER)
    xls_files = [f for f in downloaded_files if os.path.basename(f).lower().endswith(".xls")]
    logging.info(f"Found {len(xls_files)} files in the download folder: {config.DOWNLOAD_FOLDER}")
    if len(xls_files) == 0:
        raise FileNotFoundError()
    logging.info(f"The Excel file {xls_files[0]} was downloaded")
    return os.path.join(config.DOWNLOAD_FOLDER, xls_files[0])


def purge_download_folder(config: lib.CpdpConfig):
    """
    Delete the download folder if it exists and then re-create
    """
    if os.path.exists(config.DOWNLOAD_FOLDER):
        shutil.rmtree(path=config.DOWNLOAD_FOLDER)
        logging.info(f"The download folder {config.DOWNLOAD_FOLDER} was deleted")
    os.mkdir(config.DOWNLOAD_FOLDER)
    logging.info(f"The download folder was re-created. {config.DOWNLOAD_FOLDER}")


if __name__ == "__main__":
    dotenv.load_dotenv(
        override=True)  # take environment variables from a privately managed .env file at the very root of the repo
    log = ag_log.get_log()
    logging.info("Begin cpdp scraper")

    cfg = lib.CpdpConfig()
    driver_options = Options()

    prefs = {"download.default_directory": cfg.DOWNLOAD_FOLDER}
    driver_options.add_experimental_option("prefs", prefs)
    driver_options.add_argument(
        "--headless=new")  # Only comment when you want to see the browser window during development

    driver = webdriver.Chrome(options=driver_options)
    run_scrape_sequence(driver=driver, config=cfg)
    driver.quit()
    logging.info("Complete")
