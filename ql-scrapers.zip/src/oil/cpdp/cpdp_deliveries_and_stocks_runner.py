import datetime
import logging
import os

from ag_log import ag_log
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import selenium.webdriver.support.wait as wait
import selenium.webdriver.support.expected_conditions as expec
import shutil
import dotenv
import lib as lib
from lib import CpdpConfig
from ag_data_access import data_upload as du


def download_report(d: webdriver.Chrome, config: CpdpConfig, link_url: str, link_text: str) -> str:
    """
    Navigates to the specified url and then attempts to discover the download link ,
    followed by actually downloading the Excel document.
    Returns the absolute path to the downloaded Excel file. An exception if unable to download

    Caveats - The browser is made to download through a simulated click of the hyperlink as opposed
    to a REST call. This has implications. The name of the downloaded file is not known in advance.
    Therefore, the caller should have cleared the download folder prior to calling this function
    """
    logging.info(f"Begin-Navigate to report download page from {link_text=},{link_url=}")
    driver.get(url=link_url)

    wait.WebDriverWait(driver=d, timeout=config.PAGE_LOAD_TIMEOUT_SECS).until(
        expec.presence_of_element_located((By.XPATH, config.DOWNLOAD_PDF_XPATH)))
    logging.info(f"Complete-Navigate to report download page from {link_text=},{link_url=}")

    logging.info(f"Begin-Search for download link")
    pdf_link = d.find_element(by=By.XPATH, value=config.DOWNLOAD_PDF_XPATH)
    logging.info(f"End-Search for download link {pdf_link.text=},url={pdf_link.get_attribute('href')}")
    pdf_link.click()
    logging.info("Link was clicked..wait for download to complete")

    def is_file_xls(x: object) -> bool:
        excel_files = [f for f in os.listdir(config.DOWNLOAD_FOLDER) if os.path.basename(f).lower().endswith(".xls")]
        logging.info(f"Found {len(excel_files)} files in the download folder {config.DOWNLOAD_FOLDER}")
        return len(excel_files) > 0

    wait.WebDriverWait(driver=d, timeout=config.PAGE_LOAD_TIMEOUT_SECS, poll_frequency=2).until(is_file_xls)
    logging.info("Link was clicked..download appears to be complete. Need to check further")

    downloaded_files = os.listdir(path=config.DOWNLOAD_FOLDER)
    xls_files = [f for f in downloaded_files if os.path.basename(f).lower().endswith(".xls")]
    logging.info(f"Found {len(xls_files)} files in the download folder: {config.DOWNLOAD_FOLDER}")
    if len(xls_files) == 0:
        raise FileNotFoundError()
    logging.info(f"The Excel file {xls_files[0]} was downloaded")
    return os.path.join(config.DOWNLOAD_FOLDER, xls_files[0])


def extract_csv_from_downloaded_excel_release_for_consumption(excel_file: str, config: CpdpConfig) -> datetime.datetime:
    """
    Returns the date parsed out from the Excel. Needed for subsequent sheets
    """
    logging.info(f"Going to parse Page1 of the {excel_file=}")
    product_code_mapper = lib.LanguageMapper(map_file_name="product_code_language_map.csv")
    subproduct_code_mapper = lib.LanguageMapper(map_file_name="subproduct_code_language_map.csv")
    delivery_and_stock_parser = lib.ReleasedForConsumptionParser(excel_file=excel_file,
                                                                 product_code_mapper=product_code_mapper,
                                                                 subproduct_code_mapper=subproduct_code_mapper)
    df = delivery_and_stock_parser.parse()
    bo_file_name = "cpdp_consumption_{datestr}".format(
        datestr=delivery_and_stock_parser.document_date.strftime("%Y-%m-%d"))
    du.upload_to_database(data=df, filename_prefix=bo_file_name, env=os.environ["environment"].upper(), index=False)
    logging.info(f"Uploading  {bo_file_name} complete")
    return delivery_and_stock_parser.document_date


def extract_csv_from_downloaded_excel_stock_distribution_at_end_of_month(excel_file: str, config: CpdpConfig, document_date: datetime.datetime) -> None:
    logging.info(f"Going to parse Page2 of the {excel_file=}")
    product_code_mapper = lib.LanguageMapper(map_file_name="product_code_language_map.csv")
    subproduct_code_mapper = lib.LanguageMapper(map_file_name="subproduct_code_language_map.csv")
    stock_distribution_at_eom_parses = lib.StockAtEndOfMonthDistributionParser(excel_file=excel_file,
                                                                               document_date=document_date,
                                                                               product_code_mapper=product_code_mapper,
                                                                               subproduct_code_mapper=subproduct_code_mapper)
    df = stock_distribution_at_eom_parses.parse()
    bo_file_name = "cpdp_stock_distribution_at_end_of_month_{datestr}".format(
        datestr=document_date.strftime("%Y-%m-%d"))
    du.upload_to_database(data=df, filename_prefix=bo_file_name, env=os.environ["environment"].upper(), index=False)
    logging.info(f"Uploading  {bo_file_name} complete")


def run_scrape_sequence(driver: webdriver.Chrome, config: CpdpConfig):
    logging.info(f"Going to load the page {config.URL_LOGIN}")
    driver.get(url=config.URL_LOGIN)

    lib.SeleniumCommonSteps.accept_cookies(d=driver, config=config)
    lib.SeleniumCommonSteps.submit_login_password(d=driver, config=config)

    driver.get(url=config.URL)
    logging.info(f"The page {config.URL} was loaded")

    pattern = 'Livraisons et stocks en France'
    links_to_report_pages = lib.SeleniumCommonSteps.get_hyperlinks_with_matching_pattern(d=driver, pattern=pattern)
    if len(links_to_report_pages) == 0:
        raise Exception("No Stocks and Deliveries links found were found. Cannot continue")
    logging.info(f"Found {len(links_to_report_pages)} links which match the pattern {pattern}")
    for link in links_to_report_pages:
        purge_download_folder(config=cfg)
        excel_file = download_report(d=driver, config=config, link_url=link[1], link_text=link[0])
        lib.Util.save_excel_file_to_archive_folder(source=excel_file, environment=os.environ["environment"].upper())

        doc_date=extract_csv_from_downloaded_excel_release_for_consumption(excel_file=excel_file, config=config)
        extract_csv_from_downloaded_excel_stock_distribution_at_end_of_month(excel_file=excel_file, config=config, document_date=doc_date)


def purge_download_folder(config: CpdpConfig):
    """
    Delete the download folder if it exists and then re-create
    """
    if os.path.exists(config.DOWNLOAD_FOLDER):
        shutil.rmtree(path=config.DOWNLOAD_FOLDER)
        logging.info(f"The download folder {config.DOWNLOAD_FOLDER} was deleted")
    os.mkdir(config.DOWNLOAD_FOLDER)
    logging.info(f"The download folder was re-created. {config.DOWNLOAD_FOLDER}")


if __name__ == "__main__":
    dotenv.load_dotenv(
        override=True)  # take environment variables from a privately managed .env file at the very root of the repo
    log = ag_log.get_log()
    logging.info("Begin cpdp scraper")

    cfg = CpdpConfig()
    driver_options = Options()

    prefs = {"download.default_directory": cfg.DOWNLOAD_FOLDER}
    driver_options.add_experimental_option("prefs", prefs)

    # Comment the following line when you want to see the browser window during development
    driver_options.add_argument("--headless=new")

    driver = webdriver.Chrome(options=driver_options)
    run_scrape_sequence(driver=driver, config=cfg)
    driver.quit()
    logging.info("Complete")
