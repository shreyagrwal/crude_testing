"""
Parses the Page 4
Stocks de la distribution en fin de mois (tels qu'indiqués par les déclarants)
This translates to:
Distribution stocks at the end of the month (as indicated by declarants)

"""

import datetime
import logging
import os
from typing import Optional

import pandas as pd
import unicodedata
from .language_mapper import LanguageMapper
from .util import Util


class StockAtEndOfMonthDistributionParser(object):
    # noinspection SpellCheckingInspection
    MISSING_PRODUCT_HEADER = "Other Products"  # Not present in the Excel

    # noinspection SpellCheckingInspection
    PRODUCTS_EXPECTED_IN_THE_EXCEL = ["Carburants routiers", "Carburants alternatifs", "Carburants aériens",
                "Gazoles non routiers et fioul domestique", MISSING_PRODUCT_HEADER, "Fiouls lourds", "Carburants aéronautiques"]

    def __init__(self, excel_file: str, document_date: datetime.date, product_code_mapper: LanguageMapper, subproduct_code_mapper: LanguageMapper):
        if not os.path.exists(path=excel_file):
            raise ValueError(f"The {excel_file=} was not found")
        self.excel_file = excel_file
        self.document_date = document_date
        self.df_from_excel: Optional[pd.DataFrame] = None
        self._product_code_mapper = product_code_mapper
        self._subproduct_code_mapper = subproduct_code_mapper

    def parse(self) -> pd.DataFrame:
        self.df_from_excel = pd.read_excel(self.excel_file, parse_dates=False, sheet_name="Page4")
        # .dropna(how="all"))

        data_dict = self._extract_dictionary()

        df = pd.DataFrame(data_dict)
        df["ProductCode"] = df.apply(lambda row: self._translate_product_code(row["ProductOriginal"]), axis=1)

        df["SubProductCode"] = df.apply(lambda row: self._translate_subproduct_code(row["SubProductOriginal"]), axis=1)
        self._change_encoding_of_french_columns(df=df)
        return df

    def _extract_dictionary(self) -> dict[str, list[object]]:
        """
        Iterate over the products list that we expect to find in the Excel
        For product that is found in the Excel, read the sub products that are located under that product
        """
        ddate_list = []
        product_list = []
        sub_product_list = []
        units_list = []
        stock_list = []
        data_dict = {"DDate": ddate_list, "ProductOriginal": product_list, "SubProductOriginal": sub_product_list,
                     "Unit": units_list, "Stock": stock_list}
        for product in self.PRODUCTS_EXPECTED_IN_THE_EXCEL:
            logging.info(f"Looking for main product: {product=}")
            product_row_index, product_column, units_column, stock_column = self.__find_product_pattern_in_frame(
                product)
            if product_row_index is None:
                logging.info(f"Could not find any cell with product:{product}")
                continue
            main_product = product
            main_product_row_position = self.df_from_excel.index.get_loc(product_row_index)
            for row_position in range(main_product_row_position + 1, len(self.df_from_excel)):
                unit_of_measurement = self.df_from_excel.iloc[row_position][units_column]
                sub_product_name = str(self.df_from_excel.iloc[row_position][product_column])
                sub_product_name = Util.remove_new_line_from_string(input=sub_product_name)
                stock_value_str = self.df_from_excel.iloc[row_position][stock_column]
                ddate = self.document_date.strftime("%Y-%m-%d")
                logging.info(
                    f"{row_position=},{main_product=},{sub_product_name=}, {unit_of_measurement=},{stock_value_str=}")
                if pd.isna(unit_of_measurement) and pd.isna(sub_product_name) and pd.isna(stock_value_str):
                    logging.info("All values are NA, so consider this to be an end of product list")
                    break
                if not self.__is_unit_of_measurement_valid(unit_of_measurement):
                    logging.info(
                        f"The unit of measurement was {unit_of_measurement} , was not found to be valid. Skipping")
                    break
                # Do we need to check for NaN in unit of measurement
                ddate_list.append(ddate)
                product_list.append(main_product)
                sub_product_list.append(sub_product_name)
                units_list.append(unit_of_measurement)
                stock_list.append(self.__safely_convert_stock_to_float(stock_value_str))
        return data_dict

    def __find_product_pattern_in_frame(self, product: str) -> tuple[object, str, str, str]:
        """
        Returns the DataFrame position of the cell as a tuple (index, column name, units column name, stock column name)
        which matches the specified product

        """
        columns = self.df_from_excel.columns

        if product == self.MISSING_PRODUCT_HEADER:
            # This is a one of document where a missing header is to be treated as a product header
            idx1, product1_column, units1_column, stock1_column = self.__find_product_pattern_in_frame(
                product="GAZOLE NON ROUTIER")
            if idx1 is None:
                return None, "", "", ""
            loc1 = self.df_from_excel.index.get_loc(idx1)
            previous_row = self.df_from_excel.iloc[loc1 - 1]
            return previous_row.name, product1_column, units1_column, stock1_column
        for idx, row in self.df_from_excel.iterrows():
            for column_index in range(len(columns)):
                product_column = str(columns[column_index])
                cell_value = row[product_column]
                if Util.safe_compare_excel_string(str1=str(cell_value), str2=product):
                    units_column = str(columns[column_index + 1])
                    stock_column = str(columns[column_index + 2])
                    return idx, product_column, units_column, stock_column
        return None, "", "", ""

    def __is_unit_of_measurement_valid(self, unit_of_measurement: object):
        if str(unit_of_measurement) == "m3" or str(unit_of_measurement) == "tonnes":
            return True
        return False

    def __safely_convert_stock_to_float(self, stock_value_str: str):
        if stock_value_str == "-":
            return 0
        return float(stock_value_str)

    def _translate_product_code(self, french: str) -> str:
        """
        Converts from French product description to product code
        """
        french_purified = Util.remove_new_line_from_string(input=french)
        return self._product_code_mapper.french_to_english(word=french_purified)

    def _translate_subproduct_code(self, french: str) -> str:
        """
        Converts French sub product description to sub product code
        """
        french_purified = Util.remove_new_line_from_string(input=french)
        return self._subproduct_code_mapper.french_to_english(word=french_purified)

    def _change_encoding_of_french_columns(self, df: pd.DataFrame):
        def apply_func(text):
            if not pd.notnull(text):
                return text
            # noinspection SpellCheckingInspection
            return unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('utf-8')

        df["SubProductOriginal"] = df["SubProductOriginal"].apply(apply_func)

        df["ProductOriginal"] = df["ProductOriginal"].apply(apply_func)
