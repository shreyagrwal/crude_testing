"""
Parses the Page1 of the Excel file.
Stocks and deliveries

Mises à la consommation (acquittées et en exemption de taxes)
This translates to:
Released for consumption (paid and exempt from taxes)
"""
import datetime
import logging
import os
from typing import Optional
import pandas as pd
from .language_mapper import LanguageMapper
import unicodedata
from .util import Util


class ReleasedForConsumptionParser(object):
    """
    Implements parsing logic for the Excel sheet with the French words mises à la consummtion
    """
    FINAL_TOTAL_LINE = "TOTAL GÉNÉRAL"  # The final delimiter where the parser should stop

    def __init__(self, excel_file: str, product_code_mapper: LanguageMapper, subproduct_code_mapper: LanguageMapper):
        if not os.path.exists(path=excel_file):
            raise ValueError(f"The {excel_file=} was not found")
        self.excel_file = excel_file

        self.col_volume = ""
        self.col_density = ""
        self.col_tonnes = ""
        self.col_products = "Unnamed: 0"
        self.col_variations = ""
        self.df_from_excel: Optional[pd.DataFrame] = None
        self.document_date: Optional[datetime.datetime] = None
        self._product_code_mapper = product_code_mapper
        self._subproduct_code_mapper = subproduct_code_mapper


    def parse(self, sheet_name: Optional[str] = None) -> pd.DataFrame:
        """
        Parses the Excel and returns a DataFrame in the desired BO tabular format
        """
        if sheet_name is None:
            self.df_from_excel = pd.read_excel(self.excel_file, parse_dates=False, sheet_name="Page1").dropna(how="all")
        else:
            self.df_from_excel = pd.read_excel(self.excel_file, parse_dates=False, sheet_name=sheet_name).dropna(
                how="all")

        self.document_date = self._get_document_date()
        logging.info(f"The document date was found to {self.document_date}")
        self._determine_columns_with_values()
        data_dict = self._extract_dictionary()
        df = pd.DataFrame(data_dict)
        df["YoYVariationPct"] = df["YoYVariationPct"].astype(float)

        # df["Product"] = df.apply(lambda row: self._translate(row["ProductOriginal"]), axis=1)
        # df["SubProduct"] = df.apply(lambda row: self._translate(row["SubProductOriginal"]), axis=1)

        df["ProductCode"] = df.apply(lambda row: self._translate_product_code(row["ProductOriginal"]), axis=1)

        df["SubProductCode"] = df.apply(lambda row: self._translate_subproduct_code(row["SubProductOriginal"]), axis=1)

        self._change_encoding_of_french_columns(df=df)
        df["DensityUnits"] = "tonnes/m3"
        df["VolumeUnits"] = "m3"
        df["MassUnits"] = "tonnes"

        return df

    def _get_document_date(self) -> datetime.datetime:
        first_row = self.df_from_excel.iloc[0]
        first_row.dropna()
        return first_row.dropna().iloc[0]

    def _determine_columns_with_values(self):
        """
        Scans the documents for well know string markers (density, volume, tonnes and returns the names of those Columns
        """
        for idx, row in self.df_from_excel.iterrows():
            for column in self.df_from_excel.columns:
                cell_text = str(row[column])
                if cell_text == "m3" and not self.col_volume:
                    self.col_volume = column
                    logging.info(f"Got column m3, {self.col_volume=}")
                elif cell_text == "tonnes" and not self.col_tonnes:
                    self.col_tonnes = column
                    logging.info(f"Got column tonnes, {self.col_tonnes=}")
                elif "Densités" in cell_text and not self.col_density:
                    self.col_density = column
                    logging.info(f"Got column density, {self.col_density=}")
                elif "Variations" in cell_text:
                    self.col_variations = column
                    logging.info(f"Got column density, {self.col_variations=}")
        pass

    def _extract_dictionary(self) -> dict[str, list[object]]:
        """
        Iterated over the XL file and extracts a dictionary of required data items
        """
        ddate_list = []
        product_list = []
        sub_product_list = []
        density_list = []
        volume_list = []
        tonnes_list = []
        variations_list: list[Optional[float]] = []
        data_dict = {"DDate": ddate_list, "ProductOriginal": product_list, "SubProductOriginal": sub_product_list,
                     "Density": density_list, "Volume": volume_list, "Mass": tonnes_list,
                     "YoYVariationPct": variations_list}
        ddate = self.document_date.strftime("%Y-%m-%d")
        row_index_units_of_measurement = \
            self.df_from_excel[self.df_from_excel[self.col_volume].astype(str) == "m3"].iloc[0].name
        row_index_first_product = row_index_units_of_measurement + 1
        current_main_product = None
        for idx, row in self.df_from_excel.iterrows():
            # logging.info(f"{idx}, {row[col_products]}")
            if int(idx) < row_index_first_product:
                continue
            if pd.isna(row[self.col_products]):
                continue
            product = str(row[self.col_products])
            # if product in self.PRODUCTS_TO_SKIP:
            #     continue

            is_bottom_most_total = self.FINAL_TOTAL_LINE in product
            if is_bottom_most_total:
                logging.info(f"Found the line matching {self.FINAL_TOTAL_LINE}")
                break
            is_product_line = pd.isna(row[self.col_volume]) and pd.isna(row[self.col_tonnes]) and pd.isna(
                row[self.col_density])
            is_total_line = product.startswith("TOTAL")
            if is_total_line:
                logging.info(f"Skipping total, {product}")
                continue
            if is_product_line:
                current_main_product = product
                continue
            density = self._parse_text_to_float(row[self.col_density])
            volume = self._parse_text_to_float(row[self.col_volume])
            tonnes = self._parse_text_to_float(row[self.col_tonnes])
            variations = self._parse_text_to_float(cell_text=row[self.col_variations])
            logging.info(
                f"{idx=},{current_main_product=}, {product=}, {density=} , {volume=}, {density=}, {tonnes=}, {variations=}")
            product_list.append(current_main_product)
            sub_product_list.append(Util.remove_new_line_from_string(product))
            density_list.append(density)
            volume_list.append(volume)
            tonnes_list.append(tonnes)
            ddate_list.append(ddate)
            variations_list.append(variations)
        return data_dict

    def _translate(self, french: str) -> str:
        """
        Converts French to English. Should be called from apply method of DataFrame
        """
        return self._language_mapper.french_to_english(word=french)

    def _change_encoding_of_french_columns(self, df: pd.DataFrame):
        def apply_func(text):
            if not pd.notnull(text):
                return text
            # noinspection SpellCheckingInspection
            return unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('utf-8')

        df["SubProductOriginal"] = df["SubProductOriginal"].apply(apply_func)

        df["ProductOriginal"] = df["ProductOriginal"].apply(apply_func)
        pass

    def _parse_text_to_float(self, cell_text: object) -> Optional[float]:
        """
        Converts complex text to float
         Example:
             '1.12'
             ' - 1.12'
             '  '
             'n.s.'
             None
        """
        if isinstance(cell_text, float):
            # '1.2'
            return cell_text
        if isinstance(cell_text, str):
            cell_text = cell_text.strip()
            cell_text = cell_text.replace(" ", "")
            cell_text = cell_text.replace(",", ".")
        if not cell_text:
            # None or empty text
            return None
        if str(cell_text).isalpha():
            # pure alphabets
            return None
        try:
            # Handle '-0.0' or any numeric that was not originally converted to float
            return float(str(cell_text))
        except:
            return None

    def _translate_product_code(self, french: str) -> str:
        """
        Converts from French product description to product code
        """
        french_purified = Util.remove_new_line_from_string(input=french)
        return self._product_code_mapper.french_to_english(word=french_purified)

    def _translate_subproduct_code(self, french: str) -> str:
        """
        Converts French sub product description to sub product code
        """
        french_purified = Util.remove_new_line_from_string(input=french)
        return self._subproduct_code_mapper.french_to_english(word=french_purified)
