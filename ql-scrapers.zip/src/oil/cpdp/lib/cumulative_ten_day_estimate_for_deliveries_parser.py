import dataclasses as dc
import re
from datetime import datetime
from typing import Optional, Any

import pandas as pd

from .language_mapper import LanguageMapper
from .util import Util


@dc.dataclass
class CellCoordinate(object):
    """
    Simple entity to record the position of a specific cell
    """
    column_name: str
    column_index: int
    row_index: Any
    raw_cell_text: str

    def match_position(self, row: int, column: int):
        return self.column_index == column and self.row_index == row


class CumulativeTenDayEstimateForDeliveryParser(object):
    MONTH_TEXT = "Mois"
    PRODUCT_TEXT = "Produit"
    CUMULATIVE_TEXT_PATTERN = r"cumul\s*des\s*\d*\s*d"  # r"cumul\s*des\s*\d*\s*d\w*" # r"Ensemble\s*du\s*mois"
    WORKING_DAYS_IN_CURRENT_PERIOD_PATTERN = r"\d*\s*jours\s*ouvr"
    WORKING_DAYS_IN_PREVIOUS_MONTH_PATTERN = r"\d*\s*jours\s*ouvr"
    WORKING_DAYS_IN_PREVIOUS_YEAR_PATTERN = r"\d*\s*jours\s*ouvr"
    DAYS_EXTRACTION_PATTERN = r"\d{1,}\b"

    def __init__(self, excel_file: str, language_mapper: LanguageMapper = None):
        self.excel_file = excel_file
        self._language_mapper = language_mapper
        self.__df_from_excel: Optional[pd.DataFrame] = None
        # self._product_row_indices = []
        self._cell_date: Optional[CellCoordinate] = None

        self._cell_product: Optional[CellCoordinate] = None
        self._cell_cumulative: Optional[CellCoordinate] = None
        self._product_cells: list[CellCoordinate] = []
        self._all_excel_column_names: list[str] = []
        self._cell_working_days_in_current_period: Optional[CellCoordinate] = None
        self._cell_working_days_in_previous_month: Optional[CellCoordinate] = None
        self._cell_working_days_in_previous_year: Optional[CellCoordinate] = None
        pass

    @property
    def df_from_excel(self) -> pd.DataFrame:
        if self.__df_from_excel is None:
            self.__df_from_excel = pd.read_excel(self.excel_file, parse_dates=False)
            self.__df_from_excel.dropna(axis='columns', how='all', inplace=True)
            self.__df_from_excel.dropna(axis=0, how="all", inplace=True)
            self._all_excel_column_names.extend(list(self.df_from_excel.columns))
        return self.__df_from_excel

    @property
    def document_date(self) -> datetime.date:
        if self._cell_date is None:
            raise RuntimeError("The position of the Cell with date has not yet been extracted")
        return Util.parse_french_date_to_english(french_date=self._cell_date.raw_cell_text)

    def parse(self) -> pd.DataFrame:
        """
        Parses the Excel for the cummulative ten day estimate values and returns a DataFrame
        See the docs folder for the table colums
        """
        ddate_list = []
        # product_list = []
        product_original_list = []
        number_of_measured_decades_list: list[int] = []
        number_of_working_days_in_current_measurement_period_list: list[int] = []
        number_of_working_days_in_previous_month_list: list[int] = []
        number_of_working_days_in_previous_year_list: list[int] = []

        mom_change_list: list[int] = []
        yoy_change_list: list[int] = []

        self._detect_columns_and_rows_of_key_data_items()
        ddate = Util.convert_date_to_ddate(date=self.document_date)

        number_of_working_days_in_current_measurement_period = int(
            re.match(pattern=self.DAYS_EXTRACTION_PATTERN,
                     string=self._cell_working_days_in_current_period.raw_cell_text,
                     flags=re.IGNORECASE).group(0))

        number_of_working_days_in_previous_month = int(
            re.match(pattern=self.DAYS_EXTRACTION_PATTERN,
                     string=self._cell_working_days_in_previous_month.raw_cell_text,
                     flags=re.IGNORECASE).group(0))

        number_of_working_days_in_previous_year = int(
            re.match(pattern=self.DAYS_EXTRACTION_PATTERN,
                     string=self._cell_working_days_in_previous_year.raw_cell_text,
                     flags=re.IGNORECASE).group(0))

        number_of_measured_decades = int(
            re.search(pattern=self.DAYS_EXTRACTION_PATTERN, string=self._cell_cumulative.raw_cell_text,
                      flags=re.IGNORECASE).group(0))

        for product_cell in self._product_cells:
            product_name = product_cell.raw_cell_text
            product_original_list.append(product_name)
            ddate_list.append(ddate)
            number_of_measured_decades_list.append(number_of_measured_decades)
            number_of_working_days_in_current_measurement_period_list.append(
                number_of_working_days_in_current_measurement_period)
            number_of_working_days_in_previous_month_list.append(number_of_working_days_in_previous_month)
            number_of_working_days_in_previous_year_list.append(number_of_working_days_in_previous_year)

            mom_change_cell_value = self.df_from_excel.loc[product_cell.row_index][
                self._cell_working_days_in_previous_month.column_index]
            mom_change = self._safely_convert_cell_text_to_float(cell_value=mom_change_cell_value)
            mom_change = round(mom_change * 100) if mom_change is not None else None

            mom_change_list.append(mom_change)

            yoy_change_cell_value = self.df_from_excel.loc[product_cell.row_index][
                self._cell_working_days_in_previous_year.column_index]
            yoy_change = self._safely_convert_cell_text_to_float(cell_value=yoy_change_cell_value)
            yoy_change = round(yoy_change * 100) if yoy_change is not None else None
            yoy_change_list.append(yoy_change)

        data_dict = {"DDate": ddate_list, "ProductOriginal": product_original_list,
                     "NumberOfMeasuredDecades": number_of_measured_decades_list,
                     "NumberOfWorkingDaysInCurrentMeasurementPeriod": number_of_working_days_in_current_measurement_period_list,
                     "NumberOfWorkingDaysInPreviousMonth": number_of_working_days_in_previous_month_list,
                     "NumberOfWorkingDaysInPreviousYear": number_of_working_days_in_previous_year_list,
                     "MoMChangePercentage": mom_change_list,
                     "YoYChangePercentage": yoy_change_list}
        df_bo_table = pd.DataFrame(data=data_dict)

        df_bo_table["Product"] = df_bo_table.apply(lambda row: self._translate(row["ProductOriginal"]), axis=1)
        # self._create_translated_column(df=df_bo_table)
        # self._change_encoding_of_french_columns(df=df_bo_table)
        return df_bo_table

    def _translate(self, french: str) -> str:
        """
        Converts French to English. Should be called from apply method of DataFrame
        """
        return self._language_mapper.french_to_english(word=french)

    def _detect_columns_and_rows_of_key_data_items(self):
        """
        Iterate over rows and then iterator over all columns till all required cell positions are extracted
        """
        count_of_detections = -1
        while True:
            if count_of_detections == 0:
                break
            count_of_detections = 0
            for idx, row in self.df_from_excel.iterrows():
                for column_index in range(len(self._all_excel_column_names)):
                    column_name = self._all_excel_column_names[column_index]
                    is_cell_na = pd.isna(row[column_name])
                    current_cell_value = str(row[column_name]).strip()
                    if current_cell_value.startswith(self.MONTH_TEXT) and self._cell_date is None:
                        date_column_index = column_index + 1
                        date_string = self.df_from_excel.loc[idx][date_column_index]
                        self._cell_date = CellCoordinate(column_index=date_column_index,
                                                         column_name=self._all_excel_column_names[date_column_index],
                                                         row_index=row, raw_cell_text=date_string)
                        count_of_detections += 1

                    elif self.PRODUCT_TEXT in current_cell_value and self._cell_product is None:
                        self._cell_product = CellCoordinate(column_index=column_index, column_name=column_name,
                                                            row_index=idx, raw_cell_text=current_cell_value)
                        count_of_detections += 1
                    elif (self._cell_product is not None) and (
                            column_index == self._cell_product.column_index) and not is_cell_na and (
                            idx > self._cell_product.row_index):
                        if not any(
                                filter(lambda c: c.match_position(column=column_index, row=idx), self._product_cells)):
                            self._product_cells.append(
                                CellCoordinate(raw_cell_text=current_cell_value, column_index=column_index,
                                               row_index=idx, column_name=column_name))
                            count_of_detections += 1
                    elif (self._cell_cumulative is None) and (
                            re.search(pattern=self.CUMULATIVE_TEXT_PATTERN, string=current_cell_value,
                                      flags=re.IGNORECASE)):
                        self._cell_cumulative = CellCoordinate(raw_cell_text=current_cell_value,
                                                               column_name=column_name, column_index=column_index,
                                                               row_index=idx)
                        count_of_detections += 1
                    elif (self._cell_cumulative is not None) and (
                            self._cell_working_days_in_current_period is None) and (
                            column_index == self._cell_cumulative.column_index) and (
                            re.match(pattern=self.WORKING_DAYS_IN_CURRENT_PERIOD_PATTERN, string=current_cell_value,
                                     flags=re.IGNORECASE)):
                        self._cell_working_days_in_current_period = CellCoordinate(raw_cell_text=current_cell_value,
                                                                                   column_name=column_name,
                                                                                   column_index=column_index,
                                                                                   row_index=idx)

                        count_of_detections += 1
                    elif (self._cell_cumulative is not None) and (
                            self._cell_working_days_in_previous_month is None) and (
                            column_index == self._cell_cumulative.column_index) and (
                            re.match(pattern=self.WORKING_DAYS_IN_PREVIOUS_MONTH_PATTERN, string=current_cell_value,
                                     flags=re.IGNORECASE)):
                        self._cell_working_days_in_previous_month = CellCoordinate(raw_cell_text=current_cell_value,
                                                                                   column_name=column_name,
                                                                                   column_index=column_index,
                                                                                   row_index=idx)
                        count_of_detections += 1
                    elif (self._cell_cumulative is not None) and (
                            self._cell_working_days_in_previous_year is None) and (
                            column_index == self._cell_cumulative.column_index + 1) and (
                            re.match(pattern=self.WORKING_DAYS_IN_PREVIOUS_YEAR_PATTERN, string=current_cell_value,
                                     flags=re.IGNORECASE)):
                        self._cell_working_days_in_previous_year = CellCoordinate(raw_cell_text=current_cell_value,
                                                                                  column_name=column_name,
                                                                                  column_index=column_index,
                                                                                  row_index=idx)
                        count_of_detections += 1
                    else:
                        pass

        pass

    def _safely_convert_cell_text_to_float(self, cell_value: Any) -> Optional[float]:
        if pd.isna(cell_value):
            return None
        return float(cell_value)
