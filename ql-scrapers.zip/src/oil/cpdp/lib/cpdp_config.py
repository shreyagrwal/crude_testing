import logging
import os
from ag_secrets import SecretsClient


class CpdpConfig:
    """
    Holds configuration information for all aspects of this scraping
    """

    def __init__(self):
        # config = self._read_config()
        self.URL = "https://www.cpdp.org/donnees-statistiques/"  # config.get(section="CPDP", option="CPDP_URL_BASE")
        self.URL_LOGIN = "https://www.cpdp.org/user/login"  # config.get(section="CPDP", option="CPDP_URL_LOGIN")
        self.ACCEPT_COOKIE_BUTTON_TEXT_PATTERN = "ccept"
        self.PASSWORD_SUBMIT_BUTTON_XPATH = "//input[contains(@value,'connect')]"
        self.DELIVERIES_AND_STOCKS_LINK_PATTERN = "Livraisons et stocks en France"
        self.PAGE_LOAD_TIMEOUT_SECS: int = 120
        self.DOWNLOAD_PDF_XPATH = "//a[@id='download_link']"

        self.DOWNLOAD_FOLDER = os.path.join(os.environ["temp"], os.environ["environment"],
                                            r"cpdp\download")  # config.get(section="CPDP", option="DOWNLOAD_FOLDER")
        self.DOWNLOAD_FOLDER = os.path.abspath(self.DOWNLOAD_FOLDER)

        if not os.path.exists(self.DOWNLOAD_FOLDER):
            os.makedirs(self.DOWNLOAD_FOLDER)

        client = SecretsClient()
        cpdp_login_password = client.get_secret(name="www.cpdp.org")
        logging.info(f"{cpdp_login_password=}")
        self.LOGIN = cpdp_login_password.username
        self.PASSWORD = cpdp_login_password.password
        pass
