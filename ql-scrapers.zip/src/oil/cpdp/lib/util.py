import datetime
import logging
import os.path
import shutil
import datetime
from typing import Optional


class Util(object):
    """
    Reusable methods
    """

    CENTRAL_APPLICATION_FOLDER = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Scrapers\cpdp-excel'
    FRENCH_MONTHS = ["JANVIER", "FÉVRIER", "MARS", "AVRIL", "MAI", "JUIN", "JUILLET", "AOÛT", "SEPTEMBRE",
                     "OCTOBRE",
                     "NOVEMBRE", "DÉCEMBRE"]  # noinspection INSPECTION_NAME

    @classmethod
    def safe_compare_excel_string(cls, str1: str, str2: str) -> bool:
        """
        Compare 2 strings obtained from Excel by ignoring case and ignoring the intermediate spaces
        """
        frags1 = str1.split()
        frags1 = list(map(lambda x: x.lower(), frags1))
        frags2 = str2.split()
        frags2 = list(map(lambda x: x.lower(), frags2))

        return frags1 == frags2

    @classmethod
    def remove_new_line_from_string(cls, input: str) -> str:
        """
        Removed leading, trailing and intermediate new line characters and most punctuations from the specified string
        When to use this function ?
        When you get a string from Excel, there is a possibility that the sentence might have wrapped due to the presence of new line characters
        """
        frags = input.split()
        return ' '.join(frags)

    @classmethod
    def parse_french_date_to_english(cls, french_date: str) -> datetime.date:
        # noinspection SpellCheckingInspection

        french_date_frags = [x.upper() for x in french_date.split(sep=' ') if len(x.strip()) > 0]
        if len(french_date_frags) != 2:
            raise RuntimeError(f"Could not parse the string '{french_date}' to get month and year")
        french_month = french_date_frags[0]
        month_index = cls.FRENCH_MONTHS.index(french_month) + 1
        year = int(french_date_frags[1])
        dt = datetime.date(year=year, month=month_index, day=1)
        logging.info(f"Parsed the date to {dt}")
        return dt

    @classmethod
    def convert_date_to_ddate(cls, date: datetime.date) -> str:
        """
        Converts a date to DDdate format. E.g. 2024-04-012
        """
        return date.strftime("%Y-%m-%d")

    @classmethod
    def save_excel_file_to_archive_folder(cls, source: str, environment: str,
                                          central_application_folder: Optional[str] = CENTRAL_APPLICATION_FOLDER) -> None:
        """
        Uploads the specified file to the central network share.
        When to use this function? If you want to keep a copy of some file for future reference. e.g. Excel file(s) downloaded via scraper
        """
        if not environment:
            raise ValueError(f"The parameter environment should be specified DEV or PROD")
        destination_folder = os.path.join(central_application_folder, environment)
        source_file_name = os.path.basename(source)
        exact_upload_date_time: str = datetime.datetime.today().strftime('%y%m%d%H%M%S')
        frags = source_file_name.split('.')
        source_file_name_without_extension = frags[0]
        file_extension = frags[1]

        source_file_name_with_date = f"{source_file_name_without_extension}-{source_file_name_without_extension}-{exact_upload_date_time}.{file_extension}"
        shutil.copy(src=source, dst=os.path.join(destination_folder, source_file_name_with_date))
        logging.info(f"The file {source} was saved to the central file share: {destination_folder}")
