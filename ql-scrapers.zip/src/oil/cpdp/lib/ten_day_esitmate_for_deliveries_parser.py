import logging
import os
from datetime import datetime, date
from typing import Optional, Any

import pandas as pd
import re
import dataclasses as dc

import unicodedata

from .language_mapper import LanguageMapper
from .util import Util


@dc.dataclass
class M1M12DaysInDecadeColumnInfo(object):
    """
    Holds information about the decade column pairs right below m-1, m-12 (e.g. 7 jours ouvres, 8 jours ouvres)
    """

    m1_days_in_decade_column_name: str
    m2_days_in_decade_column_name: str
    m1_days_in_decade_value: int
    m2_days_in_decade_value: int
    row_index: object


@dc.dataclass
class DaysInCurrentDecade(object):
    """
    Holds information about days in decade
    This information is located right under the 3 cells 1 decade, 2 decade and 3 decade
    """
    column_name: str
    row_index: object
    days_in_decade_value: int


class TenDayEstimateForDeliveryParser(object):
    # noinspection SpellCheckingInspection
    DECADE_PATTERN = r"^\s*\d.\s*\w*\s*décade\s*\b"  # This will match 2e décade
    # noinspection SpellCheckingInspection
    MONTH_TEXT = "Mois"

    # noinspection SpellCheckingInspection
    PRODUCT_TEXT = "Produit"
    DECADES = [1, 2, 3]

    # noinspection SpellCheckingInspection
    DAYS_IN_DECADE_PATTERN = r"\b\d{1,2}\s*jours\s*ouvr"  # This will match '8 jours ouvrés'
    CUMULATIVE_PATTERN = "ensemble\s*du\s*mois"

    def __init__(self, excel_file: str, language_mapper: LanguageMapper = None):
        if not os.path.exists(path=excel_file):
            raise ValueError(f"The {excel_file=} was not found")
        self.excel_file = excel_file
        self.document_date: Optional[datetime.date] = None
        if language_mapper is None:
            language_mapper = LanguageMapper()
        self._language_mapper = language_mapper
        self._column_date = None
        self._index_date = None

        self._column_product: Optional[str] = None
        self._index_product: Optional[int] = None
        self._product_row_indices = []

        self._all_excel_column_names: list[str] = []
        self._all_m1_m12_days_in_decade_column_info: list[M1M12DaysInDecadeColumnInfo] = []
        self._days_in_decade_column: list[DaysInCurrentDecade] = []
        self.__df_from_excel: Optional[pd.DataFrame] = None
        self._cumulative_column_name: Optional[str] = None
        logging.info(f"Created instance of {type(TenDayEstimateForDeliveryParser)} using {excel_file=}")

    @property
    def df_from_excel(self) -> pd.DataFrame:
        if self.__df_from_excel is None:
            self.__df_from_excel = pd.read_excel(self.excel_file, parse_dates=False)
            self.__df_from_excel.dropna(axis='columns', how='all', inplace=True)
            self.__df_from_excel.dropna(axis=0, how="all", inplace=True)
            self._all_excel_column_names = list(self.df_from_excel.columns)
        return self.__df_from_excel

    def parse(self) -> pd.DataFrame:
        """
        Parses the Excel and returns a DataFrame in the desired BO tabular format
        """
        self._determine_row_with_m1_m12_days_in_decade_values()
        self._determine_row_with_days_in_decade_values()
        self._detect_columns_and_rows_of_key_data_items()
        self.document_date = self._extract_document_date()
        data_dict = self._extract_dictionary()

        df_bo_table = pd.DataFrame(data_dict)
        df_bo_table["Product"] = df_bo_table.apply(lambda row: self._translate(row["ProductOriginal"]),
                                                   axis=1)
        self._create_translated_column(df=df_bo_table)
        self._change_encoding_of_french_columns(df=df_bo_table)
        return df_bo_table

    def parse_cummulative(self) -> pd.DataFrame:
        """
        Parses the Excel for the cummulative ten day estimate values and returns a DataFrame
        See the docs folder for the table colums
        """
        ddate_list = []
        # product_list = []
        product_original_list = []
        number_of_measured_decades_list: list[int] = []
        number_of_working_days_in_current_measurement_period_list: list[int] = []
        number_of_working_days_in_previous_month_list: list[int] = []
        number_of_working_days_in_previous_year_list: list[int] = []

        self._determine_row_with_m1_m12_days_in_decade_values()
        self._determine_row_with_days_in_decade_values()
        self._detect_columns_and_rows_of_key_data_items()
        self.document_date = self._extract_document_date()

        for product_index in self._product_row_indices:
            product_name = self.df_from_excel.loc[product_index][self._column_product]
            product_original_list.append(product_name)
            ddate_list.append(self.document_date.strftime("%Y-%m-%d"))
            number_of_measured_decades_list.append(99)
            number_of_working_days_in_current_measurement_period_list.append(99)
            number_of_working_days_in_previous_month_list.append(99)
            number_of_working_days_in_previous_year_list.append(99)

        data_dict = {"DDate": ddate_list, "ProductOriginal": product_original_list,
                     "NumberOfMeasuredDecades": number_of_measured_decades_list,
                     "NumberOfWorkingDaysInCurrentMeasurementPeriod": number_of_working_days_in_current_measurement_period_list,
                     "NumberOfWorkingDaysInPreviousMonth": number_of_working_days_in_previous_month_list,
                     "NumberOfWorkingDaysInPreviousYear": number_of_working_days_in_previous_year_list}
        df_bo_table = pd.DataFrame(data=data_dict)
        self._create_translated_column(df=df_bo_table)
        self._change_encoding_of_french_columns(df=df_bo_table)
        return df_bo_table

    def _extract_dictionary(self) -> dict[str, list[object]]:
        """
        Iterate over rows and columns and using the positions discovered earlier, create a dictionary that can be
        used for DataFrame
        """
        if len(self._all_m1_m12_days_in_decade_column_info) == 0:
            raise RuntimeError("Decade info for m-1, m-12 column pairs has not been populated")
        ddate_list = []
        product_list = []
        decade_list: list[int] = []
        decade1_list: list[int] = []
        decade2_list: list[int] = []
        m1_list: list[int] = []
        m2_list: list[int] = []
        days_in_decade_list: list[int] = []
        data_dict = {"DDate": ddate_list, "ProductOriginal": product_list, "Decade": decade_list,
                     "MoMChangePercentage": m1_list,
                     "YoYChangePercentage": m2_list,
                     "MoMDaysInDecade": decade1_list,
                     "YoYDaysInDecade": decade2_list,
                     "DaysInCurrentDecade": days_in_decade_list}
        ddate = Util.convert_date_to_ddate(date=self.document_date)

        for decade_index in range(len(self._all_m1_m12_days_in_decade_column_info)):
            decade_value = self.DECADES[decade_index]
            decade_column_info = self._all_m1_m12_days_in_decade_column_info[decade_index]
            days_in_decade_column_info = self._days_in_decade_column[decade_index]
            for product_index in self._product_row_indices:
                product_name = self.df_from_excel.loc[product_index][self._column_product]
                product_list.append(product_name)
                ddate_list.append(ddate)
                decade_list.append(decade_value)

                m1_value = self._safely_round_cell_text_to_int(
                    self.df_from_excel.loc[product_index][decade_column_info.m1_days_in_decade_column_name])
                m1_list.append(m1_value)

                m2_value = self._safely_round_cell_text_to_int(
                    self.df_from_excel.loc[product_index][decade_column_info.m2_days_in_decade_column_name])
                m2_list.append(m2_value)

                decade1_list.append(decade_column_info.m1_days_in_decade_value)
                decade2_list.append(decade_column_info.m2_days_in_decade_value)
                days_in_decade_list.append(days_in_decade_column_info.days_in_decade_value)
                logging.info(
                    f"Got a row: {decade_value=}, {product_name=}, {decade_column_info.m1_days_in_decade_value=},{decade_column_info.m2_days_in_decade_value=},{m1_value=} , {m2_value=} ,{ddate=}")
        return data_dict

    def _extract_document_date(self) -> datetime.date:
        if not self._column_date or not self._index_date:
            raise RuntimeError("The row/column for date was not initialized")
        pass
        french_date_str = str(self.df_from_excel.loc[self._index_date][self._column_date])
        logging.info(f"Got the french date string {french_date_str}")

        return Util.parse_french_date_to_english(french_date=french_date_str)

    def _detect_columns_and_rows_of_key_data_items(self):
        """
        Iterate over rows and then columns in each row to find the positions of key markers
        """
        if len(self._all_m1_m12_days_in_decade_column_info) == 0:
            raise RuntimeError("The row with decade info has not been detected")

        for idx, row in self.df_from_excel.iterrows():
            for column_index in range(len(self._all_excel_column_names)):
                column_name = self._all_excel_column_names[column_index]
                current_cell_value = str(row[column_name])
                if current_cell_value.startswith(self.MONTH_TEXT):
                    logging.info(f"Found column for month '{self.MONTH_TEXT}', {column_name=}, {idx=}")
                    self._column_date = self._all_excel_column_names[column_index + 1]
                    self._index_date = idx
                elif current_cell_value.startswith(self.PRODUCT_TEXT):
                    logging.info(f"Found the Products column '{self.PRODUCT_TEXT}', {column_name=}, {idx=}")
                    self._column_product = column_name
                elif column_name == self._column_product:
                    if current_cell_value == "nan":
                        # No more rows
                        continue
                    else:
                        self._product_row_indices.append(idx)
                        continue
                elif re.match(pattern=self.CUMULATIVE_PATTERN, string=current_cell_value,
                              flags=re.RegexFlag.IGNORECASE):
                    self._cumulative_column_name = column_name
                else:
                    pass

    pass

    def _translate(self, french: str) -> str:
        """
        Converts French to English. Should be called from apply method of DataFrame
        """
        return self._language_mapper.french_to_english(word=french)

    def _change_encoding_of_french_columns(self, df: pd.DataFrame):
        df["ProductOriginal"] = df["ProductOriginal"].apply(
            lambda x: unicodedata.normalize('NFKD', x).encode('ascii', 'ignore').decode('utf-8') if pd.notnull(
                x) else x)
        pass

    def _create_translated_column(self, df: pd.DataFrame):
        df["Product"] = df.apply(lambda row: self._translate(row["ProductOriginal"]), axis=1)
        pass

    def _determine_row_with_m1_m12_days_in_decade_values(self):
        """
        Find the row which has lots of column pairs which have the pattern '7 jours ouvres','8 jours ouvres' as an example
        These are tagged with m-1 , m-12
        """
        for idx, row in self.df_from_excel.iterrows():
            temp_buffer: list[tuple[str, str]] = []  # Decade column name, decade cell text
            for column_index in range(len(self._all_excel_column_names)):
                column_name = self._all_excel_column_names[column_index]
                current_cell_value = str(row[column_name])
                if re.search(pattern=self.DAYS_IN_DECADE_PATTERN, string=current_cell_value) is not None:
                    temp_buffer.append((column_name, current_cell_value))
            if len(temp_buffer) >= 6:
                for temp_buffer_index in range(3):
                    m1_decade_index = temp_buffer_index * 2
                    m2_decade_index = temp_buffer_index * 2 + 1
                    m1_days_in_decade_value = self.__parse_days_in_decade(temp_buffer[m1_decade_index][1])
                    m2_days_in_decade_value = self.__parse_days_in_decade(temp_buffer[m2_decade_index][1])
                    col_info = M1M12DaysInDecadeColumnInfo(
                        m1_days_in_decade_column_name=temp_buffer[m1_decade_index][0],
                        m2_days_in_decade_column_name=temp_buffer[m2_decade_index][0],
                        row_index=idx,
                        m1_days_in_decade_value=m1_days_in_decade_value,
                        m2_days_in_decade_value=m2_days_in_decade_value)
                    self._all_m1_m12_days_in_decade_column_info.append(col_info)
                break
        pass

    def __parse_days_in_decade(self, decade_text: str) -> int:
        """
        Returns 8 from the string '8 jours ouvrés'
        """
        return int(decade_text.split(sep=' ')[0])

    def _determine_row_with_days_in_decade_values(self):
        """
        Find the first row which has the 3 decades e.g. 1ère décade , 2e décade , 3e décade
        """
        for idx, row in self.df_from_excel.iterrows():
            temp_buffer: list[tuple[str, str]] = []  # Decade column name, decade cell text
            for column_index in range(len(self._all_excel_column_names)):
                column_name = self._all_excel_column_names[column_index]
                current_cell_value = str(row[column_name])
                if re.search(pattern=self.DAYS_IN_DECADE_PATTERN, string=current_cell_value) is not None:
                    temp_buffer.append((column_name, current_cell_value))
                if len(temp_buffer) == 3:
                    break
            if len(temp_buffer) == 3:
                for temp_buffer_index in range(3):
                    days_in_decade_value = self.__parse_days_in_decade(temp_buffer[temp_buffer_index][1])
                    col_info = DaysInCurrentDecade(row_index=idx, days_in_decade_value=days_in_decade_value,
                                                   column_name=temp_buffer[temp_buffer_index][0])
                    self._days_in_decade_column.append(col_info)
                break
        pass

    def _safely_round_cell_text_to_int(self, cell_value: Any) -> Optional[int]:
        if pd.isna(cell_value):
            return None
        return int(round(float(cell_value) * 100))
