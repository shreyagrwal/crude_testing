from selenium import webdriver
from selenium.webdriver.common.by import By

from .cpdp_config import CpdpConfig
import logging
import selenium.webdriver.support.wait as wait
import selenium.webdriver.support.expected_conditions as expec


class SeleniumCommonSteps(object):
    """
    Methods which implement reusable work flows
    """

    def __init__(self):
        pass

    @classmethod
    def accept_cookies(cls, d: webdriver.Chrome, config: CpdpConfig):
        logging.info(f"Going to get the Accept cookie button ")
        accept_cookie_button_xpath = f"//button[contains(text(),'{config.ACCEPT_COOKIE_BUTTON_TEXT_PATTERN}')]"
        logging.info(f"Going to wait till {accept_cookie_button_xpath=} is found")
        wait.WebDriverWait(driver=d, timeout=config.PAGE_LOAD_TIMEOUT_SECS).until(
            expec.presence_of_element_located((By.XPATH, accept_cookie_button_xpath)))
        logging.info(f"Wait for {accept_cookie_button_xpath=} complete")

        accept_cookie_button = d.find_element(by=By.XPATH,
                                              value=accept_cookie_button_xpath)
        logging.info(f"Got the Accept cookie button {accept_cookie_button=}")
        accept_cookie_button.click()
        logging.info(f"The Accept cookie button was clicked")

    @classmethod
    def submit_login_password(cls, d: webdriver.Chrome, config: CpdpConfig):
        logging.info(f"Going to get the user name field")
        username_field = d.find_element(by=By.ID, value="edit-name")
        logging.info(f"Got the user name field {username_field=}")
        username_field.send_keys(config.LOGIN)
        logging.info(f"After sending keys {config.LOGIN=}")

        logging.info(f"Going to get the password field")
        password_field = d.find_element(by=By.ID, value="edit-pass")
        logging.info(f"Got the password field {password_field=}")
        password_field.send_keys(config.PASSWORD)
        logging.info(f"After sending keys {config.PASSWORD[:2]}*****{config.PASSWORD[-2:]}")
        logging.info(f"The page {config.URL_LOGIN} was loaded")

        logging.info(f"Going to get the Submit button")
        submit_button = d.find_element(by=By.XPATH, value=config.PASSWORD_SUBMIT_BUTTON_XPATH)
        logging.info(f"Got the Submit button {submit_button.text=} , {submit_button.get_attribute('outerHTML')=}")
        submit_button.click()
        logging.info(f"The submit button on the {config.URL_LOGIN} was clicked")

    @classmethod
    def get_hyperlinks_with_matching_pattern(cls, d: webdriver.Chrome, pattern: str) -> list[tuple[str, str]]:
        """
        Searches for all hyperlink elements where the text matches the specified pattern
        Returns a list of tuples (link text, link url)
        """
        xpath = f"//a[contains(text(),'{pattern}')]"
        all_links = d.find_elements(by=By.XPATH, value=xpath)
        document_links: list[tuple[str, str]] = []  # A tuple containing the link text and link url
        for link in all_links:
            logging.info(link.text)
            document_links.append((link.text, link.get_attribute('href')))
            # if config.DELIVERIES_AND_STOCKS_LINK_PATTERN in link.text:
            #     document_links.append((link.text, link.get_attribute('href')))
        logging.info(f"All links were parsed, found={len(document_links)}")
        logging.info(document_links)
        return document_links