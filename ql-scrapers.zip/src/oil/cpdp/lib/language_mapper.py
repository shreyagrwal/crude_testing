import csv
import logging
import os
from typing import Optional, Dict


class LanguageMapper(object):
    """
    Wrapper over French to english mapper file
    """

    def __init__(self, map_file_name: Optional[str] = None):
        self.__dict_name_values: Dict[str, str] = dict()
        if map_file_name is None:
            # TODO This is a temporary if clause to maintain existing code
            # Remove this when all tables have been migrated to ProductCodes
            self._map_file = os.path.join(os.path.dirname(__file__), "language_map.csv")
        else:
            self._map_file = os.path.join(os.path.dirname(__file__), map_file_name)
        self.__load_dictionary_from_csv()
        # self._df_french_to_english = pd.read_csv(self._map_file)

    def __load_dictionary_from_csv(self):
        with open(self._map_file, newline='', encoding='utf-8') as csvfile:
            line_reader = csv.reader(csvfile, delimiter=',', quotechar='|')
            for row in line_reader:
                logging.info(', '.join(row))
                if len(row) == 0:
                    continue
                french = row[0]
                english = row[1]
                self.__dict_name_values[french.strip().lower()] = english
        pass

    def french_to_english(self, word: str) -> str:
        """
        Give a French word, finds the english equivalent
        """
        if not word:
            raise ValueError("Expected non-empty word")
        word = word.strip().lower()
        if word not in self.__dict_name_values:
            raise ValueError(f"No translation found for the french word: '{word}'")
        return self.__dict_name_values[word].strip()
