import datetime
import logging
import os
from unittest.mock import MagicMock

import src.oil.cpdp.lib as lib

sample_excel_file = os.path.join(os.path.dirname(__file__), "files/202403_ESTDECA.xls")
EXPECTED_COLUMNS = ["DDate", "ProductOriginal", "Product", "Decade", "MoMChangePercentage", "YoYChangePercentage",
                    "MoMDaysInDecade", "YoYDaysInDecade", "DaysInCurrentDecade"]


def test_ctor():
    parser = lib.TenDayEstimateForDeliveryParser(excel_file=sample_excel_file)

    # Assert
    assert parser.excel_file == sample_excel_file
    assert parser.df_from_excel is not None


def test_parser():
    # Arrange
    expected_date = datetime.date(year=2024, month=3, day=1)
    expected_ddate = "2024-03-01"
    fake_mapper = lib.LanguageMapper()
    fake_mapper.french_to_english = MagicMock(side_effect=lambda word: f"english-{word}")
    parser = lib.TenDayEstimateForDeliveryParser(excel_file=sample_excel_file, language_mapper=fake_mapper)

    # Act
    df_actual_results = parser.parse()

    # Assert
    logging.info(df_actual_results.head(len(df_actual_results)))
    assert parser.document_date == expected_date

    assert len(df_actual_results.columns) == len(EXPECTED_COLUMNS)
    for expected_column in EXPECTED_COLUMNS:
        assert expected_column in df_actual_results.columns

    assert len(df_actual_results) == 12

    assert df_actual_results.iloc[0]["DDate"] == expected_ddate
    assert df_actual_results.iloc[0]["Product"] == "english-SUPERCARBURANTS"
    assert df_actual_results.iloc[0]["ProductOriginal"] == "SUPERCARBURANTS"
    assert df_actual_results.iloc[0]["Decade"] == 1
    assert df_actual_results.iloc[0]["MoMDaysInDecade"] == 7
    assert df_actual_results.iloc[0]["YoYDaysInDecade"] == 8
    assert df_actual_results.iloc[0]["MoMChangePercentage"] == -5
    assert df_actual_results.iloc[0]["YoYChangePercentage"] == -30

    assert df_actual_results.iloc[4]["DDate"] == expected_ddate
    assert df_actual_results.iloc[4]["Product"] == "english-SUPERCARBURANTS"
    assert df_actual_results.iloc[4]["ProductOriginal"] == "SUPERCARBURANTS"
    assert df_actual_results.iloc[4]["Decade"] == 2
    assert df_actual_results.iloc[4]["MoMDaysInDecade"] == 7
    assert df_actual_results.iloc[4]["YoYDaysInDecade"] == 6
    assert df_actual_results.iloc[4]["MoMChangePercentage"] == 18
    assert df_actual_results.iloc[4]["YoYChangePercentage"] == 56

    last_row = len(df_actual_results) - 1
    assert df_actual_results.iloc[last_row]["DDate"] == expected_ddate
    assert df_actual_results.iloc[last_row]["Product"] == "english-FIOULS DOMESTIQUES"
    assert df_actual_results.iloc[last_row]["ProductOriginal"] == "FIOULS DOMESTIQUES"
    assert df_actual_results.iloc[last_row]["Decade"] == 3
    assert df_actual_results.iloc[last_row]["MoMDaysInDecade"] == 7
    assert df_actual_results.iloc[last_row]["YoYDaysInDecade"] == 9
    assert df_actual_results.iloc[last_row]["MoMChangePercentage"] == -24
    assert df_actual_results.iloc[last_row]["YoYChangePercentage"] == -31

    expected_days_in_decade = {1: 6, 2: 8, 3: 7}
    for index, (decade, days_in_decade_value) in enumerate(expected_days_in_decade.items()):
        assert df_actual_results.query(
            expr=f" (ProductOriginal == 'SUPERCARBURANTS') and (Decade == {decade}) ").iloc[0][
                   "DaysInCurrentDecade"] == days_in_decade_value
        assert df_actual_results.query(
            expr=f" (ProductOriginal == 'GAZOLES ROUTIERS') and (Decade == {decade}) ").iloc[0][
                   "DaysInCurrentDecade"] == days_in_decade_value
        assert df_actual_results.query(
            expr=f" (ProductOriginal == 'GAZOLES NON ROUTIERS') and (Decade == {decade}) ").iloc[0][
                   "DaysInCurrentDecade"] == days_in_decade_value
        assert df_actual_results.query(
            expr=f" (ProductOriginal == 'FIOULS DOMESTIQUES') and (Decade == {decade}) ").iloc[0][
                   "DaysInCurrentDecade"] == days_in_decade_value


def test_parser_with_empty_cells():
    # Arrange
    expected_date = datetime.date(year=2024, month=4, day=1)
    expected_ddate = "2024-04-01"

    sample_excel_file_with_empty_cells = os.path.join(os.path.dirname(__file__), "files/202404_ESTDECA_empty_cells.xls")
    fake_mapper = lib.LanguageMapper()
    fake_mapper.french_to_english = MagicMock(side_effect=lambda word: f"english-{word}")
    parser = lib.TenDayEstimateForDeliveryParser(excel_file=sample_excel_file_with_empty_cells,
                                                 language_mapper=fake_mapper)

    # Act
    df_actual_results = parser.parse()

    # Assert

    logging.info(df_actual_results.head(len(df_actual_results)))
    assert parser.document_date == expected_date

    assert len(df_actual_results.columns) == len(EXPECTED_COLUMNS)
    for expected_column in EXPECTED_COLUMNS:
        assert expected_column in df_actual_results.columns

    assert len(df_actual_results) == 12
    assert df_actual_results.iloc[0]["DDate"] == expected_ddate

    assert df_actual_results.query("Decade ==1")["MoMChangePercentage"].isna().any() == False
    assert df_actual_results.query("Decade ==1")["YoYChangePercentage"].isna().any() == False

    assert df_actual_results.query("Decade ==2")["MoMChangePercentage"].isna().all()
    assert df_actual_results.query("Decade ==2")["YoYChangePercentage"].isna().all()
    assert df_actual_results.query("Decade ==3")["MoMChangePercentage"].isna().all()
    assert df_actual_results.query("Decade ==3")["YoYChangePercentage"].isna().all()
