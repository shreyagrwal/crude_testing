import datetime
import os
from unittest.mock import MagicMock

import pandas as pd

import src.oil.cpdp.lib as lib

EXPECTED_COLUMNS = ["DDate", "ProductOriginal", "Product", "NumberOfMeasuredDecades",
                    "NumberOfWorkingDaysInCurrentMeasurementPeriod", "NumberOfWorkingDaysInPreviousMonth",
                    "NumberOfWorkingDaysInPreviousYear",
                    "MoMChangePercentage",
                    "YoYChangePercentage"]


def test_parse_with_mar_2024():
    # Arrange
    sample_excel_file = os.path.join(os.path.dirname(__file__), "files/202403_ESTDECA.xls")
    expected_ddate = "2024-03-01"
    expected_date = datetime.date(year=2024, month=3, day=1)
    fake_mapper = lib.LanguageMapper()
    fake_mapper.french_to_english = MagicMock(side_effect=lambda word: f"english-{word}")
    parser = lib.CumulativeTenDayEstimateForDeliveryParser(excel_file=sample_excel_file, language_mapper=fake_mapper)

    # Act
    df_actual_results = parser.parse()

    # Assert
    assert parser.document_date == expected_date

    assert isinstance(df_actual_results, pd.DataFrame) is True

    assert len(df_actual_results) == 4

    assert len(df_actual_results.columns) == len(EXPECTED_COLUMNS)
    for expected_column in EXPECTED_COLUMNS:
        assert expected_column in df_actual_results.columns

    assert df_actual_results.iloc[0]["DDate"] == expected_ddate
    assert df_actual_results.iloc[0]["Product"] == "english-SUPERCARBURANTS"
    assert df_actual_results.iloc[0]["ProductOriginal"] == "SUPERCARBURANTS"
    assert df_actual_results.iloc[0]["NumberOfMeasuredDecades"] == 3
    assert df_actual_results.iloc[0]["NumberOfWorkingDaysInCurrentMeasurementPeriod"] == 21
    assert df_actual_results.iloc[0]["MoMChangePercentage"] == 11
    assert df_actual_results.iloc[0]["YoYChangePercentage"] == -3
    assert df_actual_results.iloc[0]["NumberOfWorkingDaysInPreviousMonth"] == 21
    assert df_actual_results.iloc[0]["NumberOfWorkingDaysInPreviousYear"] == 23

    assert df_actual_results.iloc[1]["DDate"] == expected_ddate
    assert df_actual_results.iloc[1]["Product"] == "english-GAZOLES ROUTIERS"
    assert df_actual_results.iloc[1]["ProductOriginal"] == "GAZOLES ROUTIERS"
    assert df_actual_results.iloc[1]["NumberOfMeasuredDecades"] == 3
    assert df_actual_results.iloc[1]["NumberOfWorkingDaysInCurrentMeasurementPeriod"] == 21
    assert df_actual_results.iloc[1]["MoMChangePercentage"] == 7
    assert df_actual_results.iloc[1]["YoYChangePercentage"] == -18
    assert df_actual_results.iloc[1]["NumberOfWorkingDaysInPreviousMonth"] == 21
    assert df_actual_results.iloc[1]["NumberOfWorkingDaysInPreviousYear"] == 23

    assert df_actual_results.iloc[2]["DDate"] == expected_ddate
    assert df_actual_results.iloc[2]["Product"] == "english-GAZOLES NON ROUTIERS"
    assert df_actual_results.iloc[2]["ProductOriginal"] == "GAZOLES NON ROUTIERS"
    assert df_actual_results.iloc[2]["NumberOfMeasuredDecades"] == 3
    assert df_actual_results.iloc[2]["NumberOfWorkingDaysInCurrentMeasurementPeriod"] == 21
    assert df_actual_results.iloc[2]["MoMChangePercentage"] == 25
    assert df_actual_results.iloc[2]["YoYChangePercentage"] == -19
    assert df_actual_results.iloc[2]["NumberOfWorkingDaysInPreviousMonth"] == 21
    assert df_actual_results.iloc[2]["NumberOfWorkingDaysInPreviousYear"] == 23

    assert df_actual_results.iloc[3]["DDate"] == expected_ddate
    assert df_actual_results.iloc[3]["Product"] == "english-FIOULS DOMESTIQUES"
    assert df_actual_results.iloc[3]["ProductOriginal"] == "FIOULS DOMESTIQUES"
    assert df_actual_results.iloc[3]["NumberOfMeasuredDecades"] == 3
    assert df_actual_results.iloc[3]["NumberOfWorkingDaysInCurrentMeasurementPeriod"] == 21
    assert df_actual_results.iloc[3]["MoMChangePercentage"] == -6
    assert df_actual_results.iloc[3]["YoYChangePercentage"] == -27
    assert df_actual_results.iloc[3]["NumberOfWorkingDaysInPreviousMonth"] == 21
    assert df_actual_results.iloc[3]["NumberOfWorkingDaysInPreviousYear"] == 23


def test_parse_with_april_2024():
    # Arrange
    sample_excel_file = os.path.join(os.path.dirname(__file__), "files/202404_ESTDECA.xls")
    expected_ddate = "2024-04-01"
    expected_date = datetime.date(year=2024, month=4, day=1)
    fake_mapper = lib.LanguageMapper()
    fake_mapper.french_to_english = MagicMock(side_effect=lambda word: f"english-{word}")
    parser = lib.CumulativeTenDayEstimateForDeliveryParser(excel_file=sample_excel_file, language_mapper=fake_mapper)

    # Act
    df_actual_results = parser.parse()

    # Assert
    assert parser.document_date == expected_date

    assert isinstance(df_actual_results, pd.DataFrame) is True

    assert len(df_actual_results) == 4

    assert len(df_actual_results.columns) == len(EXPECTED_COLUMNS)
    for expected_column in EXPECTED_COLUMNS:
        assert expected_column in df_actual_results.columns

    assert df_actual_results.iloc[0]["DDate"] == expected_ddate
    assert df_actual_results.iloc[0]["Product"] == "english-SUPERCARBURANTS"
    assert df_actual_results.iloc[0]["ProductOriginal"] == "SUPERCARBURANTS"
    assert df_actual_results.iloc[0]["NumberOfMeasuredDecades"] == 2
    assert df_actual_results.iloc[0]["NumberOfWorkingDaysInCurrentMeasurementPeriod"] == 14
    assert df_actual_results.iloc[0]["MoMChangePercentage"] == 13
    assert df_actual_results.iloc[0]["YoYChangePercentage"] == 15
    assert df_actual_results.iloc[0]["NumberOfWorkingDaysInPreviousMonth"] == 14
    assert df_actual_results.iloc[0]["NumberOfWorkingDaysInPreviousYear"] == 13

    assert df_actual_results.iloc[1]["DDate"] == expected_ddate
    assert df_actual_results.iloc[1]["Product"] == "english-GAZOLES ROUTIERS"
    assert df_actual_results.iloc[1]["ProductOriginal"] == "GAZOLES ROUTIERS"
    assert df_actual_results.iloc[1]["NumberOfMeasuredDecades"] == 2
    assert df_actual_results.iloc[1]["NumberOfWorkingDaysInCurrentMeasurementPeriod"] == 14
    assert df_actual_results.iloc[1]["MoMChangePercentage"] == 6
    assert df_actual_results.iloc[1]["YoYChangePercentage"] == 5
    assert df_actual_results.iloc[1]["NumberOfWorkingDaysInPreviousMonth"] == 14
    assert df_actual_results.iloc[1]["NumberOfWorkingDaysInPreviousYear"] == 13

    assert df_actual_results.iloc[2]["DDate"] == expected_ddate
    assert df_actual_results.iloc[2]["Product"] == "english-GAZOLES NON ROUTIERS"
    assert df_actual_results.iloc[2]["ProductOriginal"] == "GAZOLES NON ROUTIERS"
    assert df_actual_results.iloc[2]["NumberOfMeasuredDecades"] == 2
    assert df_actual_results.iloc[2]["NumberOfWorkingDaysInCurrentMeasurementPeriod"] == 14
    assert df_actual_results.iloc[2]["MoMChangePercentage"] == 39
    assert df_actual_results.iloc[2]["YoYChangePercentage"] == 20
    assert df_actual_results.iloc[2]["NumberOfWorkingDaysInPreviousMonth"] == 14
    assert df_actual_results.iloc[2]["NumberOfWorkingDaysInPreviousYear"] == 13

    assert df_actual_results.iloc[3]["DDate"] == expected_ddate
    assert df_actual_results.iloc[3]["Product"] == "english-FIOULS DOMESTIQUES"
    assert df_actual_results.iloc[3]["ProductOriginal"] == "FIOULS DOMESTIQUES"
    assert df_actual_results.iloc[3]["NumberOfMeasuredDecades"] == 2
    assert df_actual_results.iloc[3]["NumberOfWorkingDaysInCurrentMeasurementPeriod"] == 14
    assert df_actual_results.iloc[3]["MoMChangePercentage"] == -28
    assert df_actual_results.iloc[3]["YoYChangePercentage"] == -17
    assert df_actual_results.iloc[3]["NumberOfWorkingDaysInPreviousMonth"] == 14
    assert df_actual_results.iloc[3]["NumberOfWorkingDaysInPreviousYear"] == 13


def test_parse_with_empty_cells():
    # Arrange
    sample_excel_file = os.path.join(os.path.dirname(__file__), "files/202404_ESTDECA_empty_cells.xls")
    expected_ddate = "2024-04-01"
    expected_date = datetime.date(year=2024, month=4, day=1)
    fake_mapper = lib.LanguageMapper()
    fake_mapper.french_to_english = MagicMock(side_effect=lambda word: f"english-{word}")
    parser = lib.CumulativeTenDayEstimateForDeliveryParser(excel_file=sample_excel_file, language_mapper=fake_mapper)

    # Act
    df_actual_results = parser.parse()

    # Assert
    assert parser.document_date == expected_date

    assert df_actual_results.iloc[0]["DDate"] == expected_ddate
    assert df_actual_results.iloc[0]["Product"] == "english-SUPERCARBURANTS"
    assert df_actual_results.iloc[0]["ProductOriginal"] == "SUPERCARBURANTS"
    assert df_actual_results.iloc[0]["NumberOfMeasuredDecades"] == 3
    assert df_actual_results.iloc[0]["NumberOfWorkingDaysInCurrentMeasurementPeriod"] == 21
    assert df_actual_results.iloc[0]["MoMChangePercentage"] is None
    assert df_actual_results.iloc[0]["YoYChangePercentage"] is None
    assert df_actual_results.iloc[0]["NumberOfWorkingDaysInPreviousMonth"] == 21
    assert df_actual_results.iloc[0]["NumberOfWorkingDaysInPreviousYear"] == 19

    assert df_actual_results.iloc[1]["DDate"] == expected_ddate
    assert df_actual_results.iloc[1]["Product"] == "english-GAZOLES ROUTIERS"
    assert df_actual_results.iloc[1]["ProductOriginal"] == "GAZOLES ROUTIERS"
    assert df_actual_results.iloc[1]["NumberOfMeasuredDecades"] == 3
    assert df_actual_results.iloc[1]["NumberOfWorkingDaysInCurrentMeasurementPeriod"] == 21
    assert df_actual_results.iloc[1]["MoMChangePercentage"] is None
    assert df_actual_results.iloc[1]["YoYChangePercentage"] is None
    assert df_actual_results.iloc[1]["NumberOfWorkingDaysInPreviousMonth"] == 21
    assert df_actual_results.iloc[1]["NumberOfWorkingDaysInPreviousYear"] == 19

    assert df_actual_results.iloc[2]["DDate"] == expected_ddate
    assert df_actual_results.iloc[2]["Product"] == "english-GAZOLES NON ROUTIERS"
    assert df_actual_results.iloc[2]["ProductOriginal"] == "GAZOLES NON ROUTIERS"
    assert df_actual_results.iloc[2]["NumberOfMeasuredDecades"] == 3
    assert df_actual_results.iloc[2]["NumberOfWorkingDaysInCurrentMeasurementPeriod"] == 21
    assert df_actual_results.iloc[2]["MoMChangePercentage"] is None
    assert df_actual_results.iloc[2]["YoYChangePercentage"] is None
    assert df_actual_results.iloc[2]["NumberOfWorkingDaysInPreviousMonth"] == 21
    assert df_actual_results.iloc[2]["NumberOfWorkingDaysInPreviousYear"] == 19

    assert df_actual_results.iloc[3]["DDate"] == expected_ddate
    assert df_actual_results.iloc[3]["Product"] == "english-FIOULS DOMESTIQUES"
    assert df_actual_results.iloc[3]["ProductOriginal"] == "FIOULS DOMESTIQUES"
    assert df_actual_results.iloc[3]["NumberOfMeasuredDecades"] == 3
    assert df_actual_results.iloc[3]["NumberOfWorkingDaysInCurrentMeasurementPeriod"] == 21
    assert df_actual_results.iloc[3]["MoMChangePercentage"] is None
    assert df_actual_results.iloc[3]["YoYChangePercentage"] is None
    assert df_actual_results.iloc[3]["NumberOfWorkingDaysInPreviousMonth"] == 21
    assert df_actual_results.iloc[3]["NumberOfWorkingDaysInPreviousYear"] == 19
