import os
import shutil

import src.oil.cpdp.lib as lib
import pytest


@pytest.mark.parametrize("str_1, str_2, expected_result",
                         [("hello world", "Hello world", True), ("hello\nworld", "HELLO world", True)])
def test_safe_compare_excel_string(str_1: str, str_2: str, expected_result: bool):
    # Act
    actual_result = lib.Util.safe_compare_excel_string(str1=str_1, str2=str_2)

    # Assert
    assert actual_result == expected_result


def test_save_excel_file():
    # Arrange - Create a folder under current python file and use this as a fake upload location
    mock_environment = "mockenv"
    this_dir = os.path.dirname(__file__)
    temporary_application_folder = os.path.join(this_dir, "temp")
    destination_under_app_folder = os.path.join(temporary_application_folder, mock_environment)
    if not os.path.exists(destination_under_app_folder):
        os.makedirs(destination_under_app_folder)

    source_file = __file__
    lib.Util.save_excel_file_to_archive_folder(environment=mock_environment, source=source_file,
                                               central_application_folder=temporary_application_folder)

    # Clean up
    assert len(os.listdir(destination_under_app_folder)) == 1
    shutil.rmtree(path=temporary_application_folder)
