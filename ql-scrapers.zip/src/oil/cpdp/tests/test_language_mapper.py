import logging
import os

import pandas as pd
import pytest

import src.oil.cpdp.lib as lib
import googletrans as googletrans


def test_ctor_with_default_parameters():
    mapper = lib.LanguageMapper()
    assert mapper is not None


def test_with_product_codes():
    # Arrange
    mapper = lib.LanguageMapper(map_file_name="product_code_language_map.csv")

    # Assert
    assert mapper.french_to_english(word="Carburants alternatifs") == "ALTERNATIVEFUELS"


def test_with_sub_product_codes():
    # Arrange
    mapper = lib.LanguageMapper(map_file_name="subproduct_code_language_map.csv")

    # Assert
    assert mapper.french_to_english(word="SUPERÉTHANOL E85") == "ETHANOLE85"


def test_when_match_found_then_english_translation_should_be_returned():
    mapper = lib.LanguageMapper()
    # Act
    actual_english_word = mapper.french_to_english(word="B100 ")

    # Assert
    assert actual_english_word == "Biodiesel B100"


def test_when_no_match_found_then_exception_must_be_raised():
    mapper = lib.LanguageMapper()
    search_word = "blah"
    with pytest.raises(ValueError, match=fr".*found for the french word: '{search_word}'"):
        mapper.french_to_english(word=search_word)


@pytest.mark.skip(reason="Only run when you want to generate fresh translationa from Google. Needs human inspection")
def test_one_time_language_translation():
    """
    This test has no real TDD significance. Run this test on the product code and subproduct code files to see
    what Google Translate throws up. Google Translate was the first approach we took in translating French
    product descriptions to English. But, on subsequent iterations we relied on human interpretation
    """
    csv_file = os.path.join(os.path.dirname(__file__), "../lib", "product_code_language_map.csv")
    df = pd.read_csv(filepath_or_buffer=csv_file)
    translator = googletrans.Translator()
    results_file = os.path.join(os.path.dirname(__file__), "translation_results.csv")
    with open(file=results_file, mode="w", encoding="utf8") as f:
        f.write(f"french,english\n")
        for idx, row in df.iterrows():
            french = row["french"]
            english = translator.translate(text=french, src=googletrans.LANGUAGES["fr"])
            logging.info(f",{french},{english.text}")
            f.write(f"{french},{english.text}\n")
