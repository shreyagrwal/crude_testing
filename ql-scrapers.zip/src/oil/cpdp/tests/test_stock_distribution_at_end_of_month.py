import datetime
import logging
from unittest.mock import MagicMock

import src.oil.cpdp.lib as lib
import os
import pandas as pd

RECENT_EXCEL_FILE = os.path.join(os.path.dirname(__file__), "files/202402_LivraisonsEtStocks.xls")
EXPECTED_COLUMNS = ["DDate", "ProductCode", "SubProductCode", "ProductOriginal", "SubProductOriginal", "Unit", "Stock"]


def test_ctor():
    product_code_mapper = lib.LanguageMapper(map_file_name="product_code_language_map.csv")
    subproduct_code_mapper = lib.LanguageMapper(map_file_name="subproduct_code_language_map.csv")
    expected_document_date = datetime.date(year=2020, month=5, day=9)
    parser = lib.StockAtEndOfMonthDistributionParser(excel_file=RECENT_EXCEL_FILE, document_date=expected_document_date,
                                                     product_code_mapper=product_code_mapper,
                                                     subproduct_code_mapper=subproduct_code_mapper)

    # Assert
    assert parser.excel_file == RECENT_EXCEL_FILE
    assert parser.df_from_excel is None
    assert parser.document_date == expected_document_date


def test_parser_on_most_recent_excel_file():
    # Arrange
    document_date = datetime.date(year=2020, month=5, day=9)
    product_code_mapper = lib.LanguageMapper(map_file_name="product_code_language_map.csv")
    subproduct_code_mapper = lib.LanguageMapper(map_file_name="subproduct_code_language_map.csv")

    parser = lib.StockAtEndOfMonthDistributionParser(excel_file=RECENT_EXCEL_FILE, document_date=document_date,
                                                     product_code_mapper=product_code_mapper,
                                                     subproduct_code_mapper=subproduct_code_mapper)
    expected_ddate = document_date.strftime("2020-05-09")

    # Act
    df_actual_results = parser.parse()

    # Assert
    logging.info(df_actual_results.head(len(df_actual_results)))
    for expected_column in EXPECTED_COLUMNS:
        assert expected_column in df_actual_results.columns

    assert len(df_actual_results) == 18

    assert df_actual_results["DDate"].eq(expected_ddate).all()

    filtered = df_actual_results[df_actual_results["ProductOriginal"] == "Carburants routiers"]
    assert len(filtered) == 6
    assert filtered.iloc[0]["ProductCode"] == "ROADFUELS"
    assert filtered.iloc[0]["SubProductCode"] == "GASSP95E5"
    assert filtered.iloc[0]["ProductOriginal"] == "Carburants routiers"
    assert filtered.iloc[0]["SubProductOriginal"] == "SUPER SP95-E5"
    assert filtered.iloc[0]["Unit"] == "m3"
    assert filtered.iloc[0]["Stock"] == 1329557

    assert filtered.iloc[5]["ProductCode"] == "ROADFUELS"
    assert filtered.iloc[5]["SubProductCode"] == "DIESELB30"
    assert filtered.iloc[5]["ProductOriginal"] == "Carburants routiers"
    assert filtered.iloc[5]["SubProductOriginal"] == "GAZOLE B30"
    assert filtered.iloc[5]["Unit"] == "m3"
    assert filtered.iloc[5]["Stock"] == 0

    filtered = df_actual_results[df_actual_results["ProductOriginal"] == "Carburants aeriens"]
    assert len(filtered) == 2
    assert filtered.iloc[0]["ProductCode"] == "AVIATIONFUEL"
    assert filtered.iloc[0]["SubProductCode"] == "AVGAS"
    assert filtered.iloc[0]["ProductOriginal"] == "Carburants aeriens"
    assert filtered.iloc[0]["SubProductOriginal"] == "ESSENCE AVIATION"
    assert filtered.iloc[0]["Unit"] == "m3"
    assert filtered.iloc[0]["Stock"] == 2635

    assert filtered.iloc[1]["ProductCode"] == "AVIATIONFUEL"
    assert filtered.iloc[1]["SubProductCode"] == "AVFUELOIL"
    assert filtered.iloc[1]["ProductOriginal"] == "Carburants aeriens"
    assert filtered.iloc[1]["SubProductOriginal"] == "CARBUREACTEUR"
    assert filtered.iloc[1]["Unit"] == "m3"
    assert filtered.iloc[1]["Stock"] == 1230434

    filtered = df_actual_results[df_actual_results["ProductOriginal"] == parser.MISSING_PRODUCT_HEADER]
    assert len(filtered) == 8
    assert filtered.iloc[5]["ProductCode"] == "OTHERPRODUCTS"
    assert filtered.iloc[5]["SubProductCode"] == "MARINEFISHINGDIESEL"
    assert filtered.iloc[5]["ProductOriginal"] == "Other Products"
    assert filtered.iloc[5]["SubProductOriginal"] == "DML & GAZOLE PECHE"
    assert filtered.iloc[5]["Unit"] == "m3"
    assert filtered.iloc[5]["Stock"] == 117056

    assert filtered.iloc[0]["ProductCode"] == "OTHERPRODUCTS"
    assert filtered.iloc[0]["SubProductCode"] == "NONROADDIESEL"
    assert filtered.iloc[0]["ProductOriginal"] == "Other Products"
    assert filtered.iloc[0]["SubProductOriginal"] == "GAZOLE NON ROUTIER"
    assert filtered.iloc[0]["Unit"] == "m3"
    assert filtered.iloc[0]["Stock"] == 17155

    assert filtered.iloc[1]["ProductCode"] == "OTHERPRODUCTS"
    assert filtered.iloc[1]["SubProductCode"] == "NONROADDIESELB30"
    assert filtered.iloc[1]["ProductOriginal"] == "Other Products"
    assert filtered.iloc[1]["SubProductOriginal"] == "GAZOLE NON ROUTIER B30"
    assert filtered.iloc[1]["Unit"] == "m3"
    assert filtered.iloc[1]["Stock"] == 0

    assert filtered.iloc[7]["ProductCode"] == "OTHERPRODUCTS"
    assert filtered.iloc[7]["SubProductCode"] == "LANDHEAVYFUEL"
    assert filtered.iloc[7]["ProductOriginal"] == "Other Products"
    assert filtered.iloc[7]["SubProductOriginal"] == "FIOULS LOURDS TERRESTRES"
    assert filtered.iloc[7]["Unit"] == "tonnes"
    assert filtered.iloc[7]["Stock"] == 16684


def test_parser_on_old_excel_file():
    old_excel_file = os.path.join(os.path.dirname(__file__), "files/202309_LivraisonsEtStocks.xls")
    expected_columns = ["DDate", "Product", "SubProduct", "ProductOriginal", "SubProductOriginal", "Unit", "Stock"]
    document_date = datetime.date(year=2023, month=9, day=1)
    product_code_mapper = lib.LanguageMapper(map_file_name="product_code_language_map.csv")
    subproduct_code_mapper = lib.LanguageMapper(map_file_name="subproduct_code_language_map.csv")
    parser = lib.StockAtEndOfMonthDistributionParser(excel_file=old_excel_file, document_date=document_date,
                                                     subproduct_code_mapper=subproduct_code_mapper,
                                                     product_code_mapper=product_code_mapper)
    expected_ddate = document_date.strftime("2020-05-09")

    # Act
    df_actual_results = parser.parse()
    logging.info(f"Found {len(df_actual_results)} rows")

    # Assert
    for expected_column in EXPECTED_COLUMNS:
        assert expected_column in df_actual_results.columns

    logging.info(df_actual_results[["DDate", "ProductCode", "SubProductCode", "Unit", "Stock"]].head(20))
    assert len(df_actual_results) == 16
    pass

    filtered = df_actual_results[df_actual_results["ProductOriginal"] == "Carburants routiers"]
    assert len(filtered) == 7

    filtered = df_actual_results[df_actual_results["ProductOriginal"] == "Fiouls lourds"]
    assert len(filtered) == 1

    filtered = df_actual_results[df_actual_results["ProductOriginal"] == "Carburants alternatifs"]
    assert len(filtered) == 3

    filtered = df_actual_results[df_actual_results["ProductOriginal"] == "Gazoles non routiers et fioul domestique"]
    assert len(filtered) == 3

    filtered = df_actual_results[df_actual_results["ProductOriginal"] == "Carburants aeronautiques"]
    assert len(filtered) == 2
