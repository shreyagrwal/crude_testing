"""
These are integration tests. They are intended to aid in TDD.
"""
import logging
import datetime

import pandas as pd

import src.oil.cpdp.lib as lib
import os
from unittest.mock import MagicMock
import numpy as np

sample_excel_file = os.path.join(os.path.dirname(__file__), "files/202402_LivraisonsEtStocks.xls")
product_code_mapper = lib.LanguageMapper(map_file_name="product_code_language_map.csv")
subproduct_code_mapper = lib.LanguageMapper(map_file_name="subproduct_code_language_map.csv")


def test_ctor():
    parser = lib.ReleasedForConsumptionParser(excel_file=sample_excel_file, product_code_mapper=product_code_mapper, subproduct_code_mapper=subproduct_code_mapper)

    # Assert
    assert parser.excel_file == sample_excel_file


def test_parse():
    fake_mapper = lib.LanguageMapper()
    fake_mapper.french_to_english = MagicMock(side_effect=lambda word: f"english-{word}")
    expected_columns = ["DDate", "ProductCode", "SubProductCode", "ProductOriginal", "SubProductOriginal", "Density", "Volume",
                        "Mass", "YoYVariationPct"]
    parser = lib.ReleasedForConsumptionParser(excel_file=sample_excel_file, product_code_mapper=product_code_mapper, subproduct_code_mapper=subproduct_code_mapper)

    # Act
    df_actual_results = parser.parse()

    # Assert
    for expected_column in expected_columns:
        assert expected_column in df_actual_results.columns

    assert df_actual_results.dtypes["YoYVariationPct"] == np.dtype('float64')
    assert len(df_actual_results) == 18

    assert df_actual_results.iloc[0]["DDate"] == "2024-02-01"
    assert df_actual_results.iloc[0]["ProductCode"] == "ROADFUELS"
    assert df_actual_results.iloc[0]["SubProductCode"] == "GASSP95E5"
    assert df_actual_results.iloc[0]["ProductOriginal"] == "Carburants routiers"
    assert df_actual_results.iloc[0]["SubProductOriginal"] == "SUPERCARBURANT SP95-E5"
    assert df_actual_results.iloc[0]["Density"] == 0.755
    assert df_actual_results.iloc[0]["Volume"] == 146996
    assert df_actual_results.iloc[0]["Mass"] == 110982
    assert df_actual_results.iloc[0]["YoYVariationPct"] == 3.7
    assert df_actual_results.iloc[0]["DensityUnits"] == "tonnes/m3"
    assert df_actual_results.iloc[0]["VolumeUnits"] == "m3"
    assert df_actual_results.iloc[0]["MassUnits"] == "tonnes"

    assert df_actual_results.iloc[0]["YoYVariationPct"] == 3.7
    assert df_actual_results.iloc[1]["YoYVariationPct"] == 13.9
    assert df_actual_results.iloc[2]["YoYVariationPct"] == 15.9
    assert df_actual_results.iloc[3]["YoYVariationPct"] == 1.2

    assert df_actual_results.iloc[4]["YoYVariationPct"] == 0.0
    assert df_actual_results.iloc[5]["YoYVariationPct"] == 45.2

    assert df_actual_results.iloc[15]["DDate"] == "2024-02-01"
    assert df_actual_results.iloc[15]["ProductCode"] == "OTHERPRODUCTS"
    assert df_actual_results.iloc[15]["SubProductCode"] == "MARINEFISHINGDIESEL"
    assert df_actual_results.iloc[15]["ProductOriginal"] == "Autres produits"
    assert df_actual_results.iloc[15]["SubProductOriginal"] == "DML & GAZOLE PECHE"
    assert df_actual_results.iloc[15]["Density"] == 0.845
    assert df_actual_results.iloc[15]["Volume"] == 38370
    assert df_actual_results.iloc[15]["Mass"] == 32423
    assert pd.isna(df_actual_results.iloc[15]["YoYVariationPct"])
    assert df_actual_results.iloc[15]["DensityUnits"] == "tonnes/m3"
    assert df_actual_results.iloc[15]["VolumeUnits"] == "m3"
    assert df_actual_results.iloc[15]["MassUnits"] == "tonnes"

    assert df_actual_results.iloc[16]["DDate"] == "2024-02-01"
    assert df_actual_results.iloc[16]["ProductCode"] == "OTHERPRODUCTS"
    assert df_actual_results.iloc[16]["SubProductCode"] == "MARINEHEAVYFUELOILS"
    assert df_actual_results.iloc[16]["ProductOriginal"] == "Autres produits"
    assert df_actual_results.iloc[16]["SubProductOriginal"] == "FIOULS LOURDS MARITIMES (SOUTES)"
    assert pd.isna(df_actual_results.iloc[16]["Density"])
    assert pd.isna(df_actual_results.iloc[16]["Volume"])
    assert df_actual_results.iloc[16]["Mass"] == 75883
    assert pd.isna(df_actual_results.iloc[16]["YoYVariationPct"])
    assert df_actual_results.iloc[16]["DensityUnits"] == "tonnes/m3"
    assert df_actual_results.iloc[16]["VolumeUnits"] == "m3"
    assert df_actual_results.iloc[16]["MassUnits"] == "tonnes"

    assert df_actual_results.iloc[17]["DDate"] == "2024-02-01"
    assert df_actual_results.iloc[17]["ProductCode"] == "OTHERPRODUCTS"
    assert df_actual_results.iloc[17]["SubProductCode"] == "LANDHEAVYFUEL"
    assert df_actual_results.iloc[17]["ProductOriginal"] == "Autres produits"
    assert df_actual_results.iloc[17]["SubProductOriginal"] == "FIOULS LOURDS TERRESTRES"
    assert pd.isna(df_actual_results.iloc[17]["Density"])
    assert pd.isna(df_actual_results.iloc[17]["Volume"])
    assert df_actual_results.iloc[17]["Mass"] == 21381
    assert df_actual_results.iloc[17]["YoYVariationPct"] == 24.1
    assert df_actual_results.iloc[17]["DensityUnits"] == "tonnes/m3"
    assert df_actual_results.iloc[17]["VolumeUnits"] == "m3"
    assert df_actual_results.iloc[17]["MassUnits"] == "tonnes"


def test_parser_old_excel_file_with_multiple_sheets():
    # Arrange
    old_excel_file = os.path.join(os.path.dirname(__file__), "files/2020_Livraisons_Annuelles_Multiple_Sheets.xls")
    expected_columns = ["DDate", "Product", "SubProduct", "ProductOriginal", "SubProductOriginal", "Unit", "Stock"]
    document_date = datetime.date(year=2023, month=9, day=1)
    fake_mapper = lib.LanguageMapper()
    fake_mapper.french_to_english = MagicMock(side_effect=lambda word: f"english-{word}")

    parser = lib.ReleasedForConsumptionParser(excel_file=old_excel_file, product_code_mapper=product_code_mapper, subproduct_code_mapper=subproduct_code_mapper)

    # Act
    df_actual_results = parser.parse(sheet_name="Page1")
    logging.info(f"Found {len(df_actual_results)} rows")

    # Assert
    assert len(df_actual_results) == 17
    pass
