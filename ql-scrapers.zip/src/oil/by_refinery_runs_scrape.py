import os
import sys
import shutil
import pandas as pd

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se


env = se.environment
bulkUploaderFolder = se.ingestion_folder
log = ag_log.get_log()
log.debug("Start to scrape refinery run files.")
source_destination = r'\\petroineos.local\dfs\Department Private Folders\Analysis Department\Projects\Europe Refinery Run\By-refinery\Archive\Scrape'
sql_folder = bulkUploaderFolder
archive_destination = r'\\petroineos.local\dfs\Department Private Folders\Analysis Department\Projects\Europe Refinery Run\By-refinery\Archive\Scrape Done'

file_names = os.listdir(source_destination)


def throttle_utilisation(df):
    msk = (df['COUNTRY']!='Greece') & (df['FORECAST_UTILISATION']>96)
    df.loc[msk,'FORECAST_UTILISATION']=96
    df['FORECAST_RUNS'] = df['FORECAST_AVAILABLE_CAPACITY']*df['FORECAST_UTILISATION']/100
    return df


for file_name in file_names:
    log.debug("File Name: " + file_name)
    df = throttle_utilisation(pd.read_csv(os.path.join(source_destination, file_name)))
    df.to_csv(os.path.join(source_destination, file_name.split('-')[0]), index=False)
    su.upload_to_database(df, file_name)
    shutil.move(os.path.join(source_destination, file_name), archive_destination)
log.debug("Job Completed.")