import os
import sys
import json
import uuid
import pandas as pd
import argparse
import requests
import pycountry
import numpy as np
from bs4 import BeautifulSoup
from datetime import datetime, date
sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder


def get_country_city():
    query = '''
        SELECT country ,city
        FROM hive_metastore.dataengineering.oil_tomtom_trafficcongestioncountrycity
        WHERE IsActive = True
    '''
    return bo.get_data(query)


def get_request(url):
    log.debug('processing url:{}'.format(url))
    response = requests.get(url)
    if (response.status_code != 200):
        log.error("url:{}")
    rs = response.content
    city = str(response.url).split('_')[-1]
    country = pycountry.countries.get(alpha_3=str(response.url).split('_')[-2].split('liveHourly/')[-1]).name.upper()
    data_array = json.loads(rs)['data']
    df = pd.DataFrame(data_array)
    log.debug('record count:{}'.format(df.count()))
    df['UpdateTime'] = pd.to_datetime(df['UpdateTime'], unit='ms').dt.strftime("%Y-%m-%d %H:%M")
    df['UpdateTimeWeekAgo'] = pd.to_datetime(df['UpdateTimeWeekAgo'], unit='ms').dt.strftime("%Y-%m-%d %H:%M")
    df['City'] = city
    df['Country'] = country.replace('TAIWAN, PROVINCE OF CHINA', 'CHINA').replace('HONG KONG', 'CHINA')
    df = df.rename(columns={"UpdateTime": "PDate"})
    csv_columns = ['Country', 'City', 'TrafficIndexLive', 'PDate', 'JamsCount', 'JamsDelay', 'JamsLength',
                   'TrafficIndexWeekAgo', 'UpdateTimeWeekAgo']
    for column in csv_columns:
        if column not in df.columns:
            df[column] = ''

    return df[csv_columns]


def get_country_url_list(url):
    log.debug("Getting country url " + url)
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'lxml')
    city_names = soup.body.find_all('span', class_="RankingTable__city-name")
    country_names = soup.body.find_all('div', class_="RankingTable__city-country")

    def get_country_code(country_names):
        rlist = []
        for a in country_names:
            try:
                cname = a.get_text()
                cobject_name = pycountry.countries.get(name=cname)
                if cobject_name is None:
                    cobject_official = pycountry.countries.get(official_name=cname)
                    if cobject_official is None:
                        cobjectfuzzy = pycountry.countries.search_fuzzy(cname)
                        if len(cobjectfuzzy) == 1:
                            rlist.append(cobjectfuzzy[0].alpha_3)
                        else:
                            cobject_common = pycountry.countries.get(common_name=cname)
                            rlist.append(cobject_common.alpha_3)
                    else:
                        rlist.append(cobject_official.alpha_3)
                else:
                    rlist.append(cobject_name.alpha_3)
            except:
                rlist.append(cname)
        return rlist

    def get_unify_city_names(city_names):
        rlist = []
        for c in city_names:
            cname = c.get_text().replace('.', '').replace(',', '').replace(' ', '-').lower()
            if 'moscow' in cname:
                rlist.append('moscow')
            elif 'bengaluru' in cname:
                rlist.append('bangalore')
            elif 'kyiv' in cname:
                rlist.append('kiev')
            elif 'birmingham-wolverhampton' in cname:
                rlist.append('birmingham')
            elif 'gdansk-gdynia-and-sopot' in cname:
                rlist.append('gdansk-gdynia-sopot')
            else:
                rlist.append(cname)
        return rlist

    country_codes = get_country_code(country_names)
    formatted_city_name = get_unify_city_names(city_names)

    url_address_list = []
    for i in range(len(formatted_city_name)):
        url_address_list.append('https://api.midway.tomtom.com/ranking/liveHourly/{}_{}'.
                                format(country_codes[i], formatted_city_name[i]))
    return url_address_list


def generate_uuid(pdate, table):
    """
    Used to create ingestion_id
    pdate: str pdate
    table: str table name or scraper name
    """
    return "{}{}{}".format(table, pdate.replace("-", ""), str(uuid.uuid4()))


def get_country_code(x):
    if x == 'Russia':
        x = 'RUSSIAN FEDERATION'
    elif x == 'Taiwan':
        return 'TWN'
    elif x == 'United States of America':
        return 'USA'
    iso = pycountry.countries.get(name=x.title()).alpha_3
    return iso


def get_country_url_list_db():
    df_country_city = get_country_city()
    df_country_city.columns = df_country_city.columns.str.lower()
    df_country_city['country_iso'] = df_country_city['country'].apply(get_country_code)
    df_country_city['city'] = df_country_city['city'].str.replace('.', '', regex=False)
    df_country_city['city'] = df_country_city['city'].str.replace(',', '')
    df_country_city['city'] = df_country_city['city'].str.replace(' ', '-')
    df_country_city['city'] = df_country_city['city'].str.replace('Gdansk-Gdynia-and-Sopot', 'gdansk-gdynia-sopot')
    df_country_city['city'] = df_country_city['city'].str.replace('Birmingham-Wolverhampton', 'birmingham')
    df_country_city['city'] = df_country_city['city'].str.replace('Bengaluru', 'bangalore')
    df_country_city['city'] = df_country_city['city'].str.replace('Kyiv', 'kiev')
    df_country_city['city'] = df_country_city['city'].str.replace('Moscow-region-(oblast)', 'moscow', regex=False)
    url_address_list = []
    for index, row in df_country_city.iterrows():
        [iso, city] = row[['country_iso', 'city']]
        url_address_list.append('https://api.midway.tomtom.com/ranking/liveHourly/{}_{}'.format(iso, city.lower()))
    return url_address_list


def main():
    log.debug("Env:" + env)

    parser = argparse.ArgumentParser()
    parser.add_argument('--pdp_env', default=env, help='env for PDP if different from ADI')

    args = parser.parse_args()
    pdp_env = args.pdp_env.upper()

    try:
        log.debug("Try to Get Country List.")
        country_list_url = 'https://www.tomtom.com/en_gb/traffic-index/ranking/'

        bulk_uploader_folder = bulkUploaderFolder

        filename = 'Upload_OIL_TrafficCongestionAll-'
        format_datetime = '%y%m%d%H%M%S'
        columns = ['Country', 'City', 'TrafficIndexLive', 'PDate']

        dfbase = pd.DataFrame(columns=columns)
        # urls = get_country_url_list(country_list_url)
        urls = get_country_url_list_db()

        for url in urls:
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            log.debug("Trying the Country URL: " + url)
            try:
                dftemp = get_request(url)
                #dfbase = dfbase.append(dftemp)
                dfbase = pd.concat([dfbase,dftemp], axis=0)
                log.debug("Completed.")
            except Exception as e:
                log.error("Failed to scrape city data. Url: " + url)
                log.error(e)

        filefullname = os.path.join(bulk_uploader_folder, filename + datetime.today().strftime(format_datetime) + ".csv")
        csv_columns = ['Country', 'City', 'TrafficIndexLive', 'PDate', 'JamsCount', 'JamsDelay', 'JamsLength',
                       'TrafficIndexWeekAgo', 'UpdateTimeWeekAgo']
        dfbase = dfbase[csv_columns]
        log.debug('start writing to ADI csv')
        # dfbase.to_csv(path_or_buf=filefullname, header=True, index=False)
        su.upload_to_database(dfbase, filename)

        log.debug('Preparing PDP path')
        # Upload to PDP. Code to facilitate the migration to PDP
        pdate = str(date.today())
        ingestion_id = generate_uuid(pdate=pdate, table="")
        ingestion_id = ingestion_id[:15]
        dfbase["Created"] = dfbase["PDate"]
        dfbase["Modified"] = dfbase["PDate"]
        dfbase["TrafficIndexHistoric"] = np.NaN
        column_order = ["PDate","Country","City","TrafficIndexLive","TrafficIndexHistoric","Created","Modified","JamsCount","JamsDelay","JamsLength","TrafficIndexWeekAgo","UpdateTimeWeekAgo"]
        dfbase = dfbase[column_order]

        # renaming columns to conform with the PDP Data Governance Policy
        column_new_names = ["pdate","country","city","traffic_index_live","traffic_index_historic","created","modified","jams_count","jams_delay","jams_length","traffic_index_week_ago","update_time_week_ago"]
        dfbase.columns = column_new_names

        log.debug("Job Completed.")
        exit(0)
    except Exception as e:
        log.error(e)
        log.debug("Job Ended with Error!!!")
        exit(1)


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())
