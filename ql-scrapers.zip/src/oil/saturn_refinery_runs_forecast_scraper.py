import pandas as pd
from tshistory.api import timeseries
import os
import sys
from datetime import datetime
sys.path.append(os.getcwd())
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder


url="http://tst-qdev-ap9.petroineos.local/api"

def get_series(cn_string : str) -> pd.DataFrame:

    print("start getting series...")
    tsa = timeseries(uri=cn_string)

    series_names = {'OECD_EUR':'crude.petroineos.oecd_europe.throughput.kbd.monthly.forecast.override',
                   'NWE':'crude.petroineos.nwe.throughput.kbd.monthly',
                    'MED':'crude.petroineos.med.throughput.kbd.monthly'}

    df = pd.DataFrame()
    for name, series_name in series_names.items():
        print("Getting " + name + "...")
        my_series=tsa.get(series_name)
        df[name] = my_series

    df.reset_index(inplace=True)
    df = df.rename(columns={'index':'DDate'})
    df['PDate'] = datetime.today()
    df = pd.melt(df, id_vars=['PDate', 'DDate'], value_vars=['OECD_EUR','NWE','MED'])
    df = df.rename(columns={'variable': 'Region','value': 'kbd'})
    return df


if __name__ == '__main__':
    cn =url
    df = get_series(cn_string=cn)
    print("Saving to BlueOcean")

    filename = 'Upload_OIL_Refinery_Regional_Runs_Forecast-'
    su.upload_to_database(df, filename)
    print("Done")




