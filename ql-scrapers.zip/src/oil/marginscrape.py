import os
import sys
import time
import numpy as np
import pandas as pd

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder

log = ag_log.get_log()

date = time.strftime("%Y-%m-%d")

if env=='PROD':
    #read csvs
    log.debug("Reading All CSVs into DataFrame")
    nwe_cashed_margin = pd.read_csv(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RefineryMargin\PROD\European Margin\CashedComplexMargin\\NWEMarginData.csv')
    med_cashed_margin = pd.read_csv(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RefineryMargin\PROD\European Margin\CashedComplexMargin\\MedMarginData.csv')
    nwe_complex_forward_margin = pd.read_csv(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RefineryMargin\PROD\European Margin\CashedComplexMargin\\NWEComplexForwardMargin-abs.csv')
    hydro_complex_forward_margin = pd.read_csv(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RefineryMargin\PROD\European Margin\CashedComplexMargin\\HydroskimWTIComplexForwardMargin-abs.csv')
    top_complex_forward_margin = pd.read_csv(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RefineryMargin\PROD\European Margin\CashedComplexMargin\\ToppingWTIComplexForwardMargin-abs.csv')
    med_complex_forward_margin = pd.read_csv(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RefineryMargin\PROD\European Margin\CashedComplexMargin\\MedComplexForwardMargin-abs.csv')
elif env=='UAT':
    #read csvs
    log.debug("Reading All CSVs into DataFrame")
    nwe_cashed_margin = pd.read_csv(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RefineryMargin\UAT\European Margin\CashedComplexMargin\\NWEMarginData.csv')
    med_cashed_margin = pd.read_csv(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RefineryMargin\UAT\European Margin\CashedComplexMargin\\MedMarginData.csv')
    nwe_complex_forward_margin = pd.read_csv(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RefineryMargin\UAT\European Margin\CashedComplexMargin\\NWEComplexForwardMargin-abs.csv')
    hydro_complex_forward_margin = pd.read_csv(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RefineryMargin\UAT\European Margin\CashedComplexMargin\\HydroskimWTIComplexForwardMargin-abs.csv')
    top_complex_forward_margin = pd.read_csv(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RefineryMargin\UAT\European Margin\CashedComplexMargin\\ToppingWTIComplexForwardMargin-abs.csv')
    med_complex_forward_margin = pd.read_csv(r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RefineryMargin\UAT\European Margin\CashedComplexMargin\\MedComplexForwardMargin-abs.csv')

# put into dataframe
log.debug("Cleansing the DataFrames")
df_nwe_cashed_margin = pd.DataFrame(nwe_cashed_margin)
df_nwe_cashed_margin.columns=['pdate', 'nwecomplex','nwehydroskim', 'nwetopping', 'nwesimple']
df_nwe_cashed_margin['ddate']=df_nwe_cashed_margin['pdate']
df_nwe_cashed_margin['type']=0
df_nwe_cashed_margin=df_nwe_cashed_margin.set_index('pdate')

df_med_cashed_margin = pd.DataFrame(med_cashed_margin)
df_med_cashed_margin.columns=['pdate','medcomplex','medsimple']
df_med_cashed_margin['ddate']=df_med_cashed_margin['pdate']
df_med_cashed_margin['type']=0
df_med_cashed_margin=df_med_cashed_margin.set_index('pdate')

df_nwe_complex_forward_margin = pd.DataFrame(nwe_complex_forward_margin)
df_nwe_complex_forward_margin.rename(columns={df_nwe_complex_forward_margin.columns[0]: "ddate" }, inplace = True)
df_nwe_complex_forward_margin=df_nwe_complex_forward_margin.set_index('ddate')

df_hydro_complex_forward_margin = pd.DataFrame(hydro_complex_forward_margin)
df_hydro_complex_forward_margin.rename(columns={df_hydro_complex_forward_margin.columns[0]: "ddate" }, inplace = True)
df_hydro_complex_forward_margin=df_hydro_complex_forward_margin.set_index('ddate')

df_top_complex_forward_margin = pd.DataFrame(top_complex_forward_margin)
df_top_complex_forward_margin.rename(columns={df_top_complex_forward_margin.columns[0]: "ddate" }, inplace = True)
df_top_complex_forward_margin=df_top_complex_forward_margin.set_index('ddate')

df_med_complex_forward_margin = pd.DataFrame(med_complex_forward_margin)
df_med_complex_forward_margin.rename(columns={df_med_complex_forward_margin.columns[0]: "ddate" }, inplace = True)
df_med_complex_forward_margin=df_med_complex_forward_margin.set_index('ddate')

# stack and manipulate forward margins
log.debug("Stack and Manipulate Forward Margins")
with pd.option_context('display.multi_sparse',False):
    df_nwe_complex_forward_margin_stack = df_nwe_complex_forward_margin.stack()
    df_nwe_complex_forward_margin_stack = (df_nwe_complex_forward_margin_stack.to_frame()).reset_index()
    df_nwe_complex_forward_margin_stack.columns = ['ddate', 'pdate', 'nwecomplex']
    df_nwe_complex_forward_margin_stack['type'] = np.where((df_nwe_complex_forward_margin_stack['ddate'] == '0001-01-01'), 1,2)
    df_nwe_complex_forward_margin_stack['ddate'] = np.where((df_nwe_complex_forward_margin_stack['ddate'] == '0001-01-01'), pd.to_datetime(df_nwe_complex_forward_margin_stack['pdate']).dt.strftime('%Y-%m-01'),df_nwe_complex_forward_margin_stack['ddate'])

    df_hydro_complex_forward_margin_stack = df_hydro_complex_forward_margin.stack()
    df_hydro_complex_forward_margin_stack = (df_hydro_complex_forward_margin_stack.to_frame()).reset_index()
    df_hydro_complex_forward_margin_stack.columns = ['ddate', 'pdate', 'nwehydroskim']
    df_hydro_complex_forward_margin_stack['type'] = np.where((df_hydro_complex_forward_margin_stack['ddate'] == '0001-01-01'), 1,2)
    df_hydro_complex_forward_margin_stack['ddate'] = np.where((df_hydro_complex_forward_margin_stack['ddate'] == '0001-01-01'), pd.to_datetime(df_hydro_complex_forward_margin_stack['pdate']).dt.strftime('%Y-%m-01'),df_hydro_complex_forward_margin_stack['ddate'])

    df_top_complex_forward_margin_stack = df_top_complex_forward_margin.stack()
    df_top_complex_forward_margin_stack = (df_top_complex_forward_margin_stack.to_frame()).reset_index()
    df_top_complex_forward_margin_stack.columns = ['ddate', 'pdate', 'nwetopping']
    df_top_complex_forward_margin_stack['type'] = np.where((df_top_complex_forward_margin_stack['ddate'] == '0001-01-01'), 1,2)
    df_top_complex_forward_margin_stack['ddate'] = np.where((df_top_complex_forward_margin_stack['ddate'] == '0001-01-01'), pd.to_datetime(df_top_complex_forward_margin_stack['pdate']).dt.strftime('%Y-%m-01'),df_top_complex_forward_margin_stack['ddate'])

    df_med_complex_forward_margin_stack = df_med_complex_forward_margin.stack()
    df_med_complex_forward_margin_stack = (df_med_complex_forward_margin_stack.to_frame()).reset_index()
    df_med_complex_forward_margin_stack.columns = ['ddate', 'pdate', 'medcomplex']
    df_med_complex_forward_margin_stack['type'] = np.where((df_med_complex_forward_margin_stack['ddate'] == '0001-01-01'), 1,2)
    df_med_complex_forward_margin_stack['ddate'] = np.where((df_med_complex_forward_margin_stack['ddate'] == '0001-01-01'), pd.to_datetime(df_med_complex_forward_margin_stack['pdate']).dt.strftime('%Y-%m-01'),df_med_complex_forward_margin_stack['ddate'])

    df_nwe_complex_forward_margin_stack=df_nwe_complex_forward_margin_stack.set_index(['ddate','pdate','type'])
    df_hydro_complex_forward_margin_stack=df_hydro_complex_forward_margin_stack.set_index(['ddate','pdate','type'])
    df_top_complex_forward_margin_stack=df_top_complex_forward_margin_stack.set_index(['ddate','pdate','type'])
    df_med_complex_forward_margin_stack=df_med_complex_forward_margin_stack.set_index(['ddate','pdate','type'])

log.debug("Processing the Result Files")
forward_result = pd.concat([df_nwe_complex_forward_margin_stack, df_hydro_complex_forward_margin_stack, df_top_complex_forward_margin_stack, df_med_complex_forward_margin_stack], axis=1, join="inner") #took out ,df_med_simple_forward_margin_stack,df_nwe_simple_forward_margin_stack,
cashed_result = pd.concat([df_nwe_cashed_margin, df_med_cashed_margin], axis=1, join="inner")
cashed_result = cashed_result.loc[:,~cashed_result.columns.duplicated()]

forward_result = forward_result.reset_index()
cashed_result = cashed_result.reset_index()
result = pd.concat([cashed_result, forward_result], ignore_index=True, sort=False)
result[['nwecomplex','nwehydroskim', 'nwetopping','nwesimple','medcomplex','medsimple']]=result[['nwecomplex','nwehydroskim', 'nwetopping','nwesimple','medcomplex','medsimple']].round(2)

log.debug(result)
log.debug("CSV File Saved to: {0}.".format(bulkUploaderFolder))

su.upload_to_database(result, 'Upload_OIL_EuroMargin-')

print(result)
