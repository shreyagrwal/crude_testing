import os
import sys
import time
import shutil
import pandas as pd
from pathlib import Path
from zipfile import ZipFile
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from concurrent.futures import ThreadPoolExecutor

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_email import ag_email_helper as aeh
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se


env = se.environment
log = ag_log.get_log()

bulkUploaderFolder = se.trigger_ingestion_folder
login_email = 'johnvonstackelberg@petroineos.co.uk'
login_password = 'IEAMods2023##'

format_datetime = '%y%m%d%H%M%S'

filename = 'Upload_Oil_IEA'
temp_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\IEA'
saturn_datafeed = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\Behzad\IEA\saturn_dirct_datafeed'
bulk_uploader_folder = bulkUploaderFolder

def measure_execution_time(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        execution_time = end_time - start_time
        print(f"Function '{func.__name__}' executed in {execution_time:.6f} seconds")
        return result
    return wrapper
@measure_execution_time
def load_chorme_settings():
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
#        chrome_options.add_argument('--headless')  # Otherwise headless Chrome
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": os.path.join(temp_path, '_download'),
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--ignore-ssl-errors=yes")
    chrome_options.add_argument("--ignore-certificate-errors")

    service = Service(executable_path=".\\tools\\chromedriver.exe")
    browser = webdriver.Chrome(service=service, options=chrome_options)
    #browser = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    return browser

@measure_execution_time
def send_updates_report(email_from, emails, updated_time):
    sub = "IEA updates found: (" + updated_time.strftime("%Y-%m-%d, %H:%M:%S") + ")"
    body = "<b> New IEA data detected </b>" \
           + "<br>" \
           + "<b>Last Updated: " + updated_time.strftime("%Y-%m-%d, %H:%M:%S") + "</b>" \
           + "<br>" \
           + "<br>" \
           + "<b> Scraping completed </b>" \
           + "<br>" \
           + "<b> Please wait to allow data upload to database</b>" \
           + "<br>"
    imgList = []

    email_sender = aeh.AgEmailHelper()
    email_sender.send_mail_with_embedded_images(email_from, emails, sub, body, imgList)

@measure_execution_time
def get_to_download_page(browser, url1, url2):
    # Navigate to the website to start
    browser.get(url1)
    time.sleep(2)

    if browser.current_url == 'https://webstore.iea.org/login?ReturnUrl=%2fmods-sdbs-data':
        log.debug("Certificate Verification Error Encountered.")
        log.debug("Press Visit Site Anyway.")
        verification_button = browser.find_element_by_xpath('//*[@id="options"]/form[1]/input[5]')
        verification_button.click()
        time.sleep(5)
    else:
        log.debug("No Issue with Certificate Verification.")

    log.debug("Main Website Page Reached.")
    login_button = browser.find_element('xpath', '/html/body/header/div/div/nav/ul/li[8]/a')
    login_button.click()
    time.sleep(2)

    username = browser.find_element('xpath', '//*[@id="input-login-email"]')
    password = browser.find_element('xpath', '//*[@id="input-login-password"]')
    username.send_keys(login_email)
    password.send_keys(login_password)
    time.sleep(3)

    login_button_xpaths = ['/html/body/div[4]/div/div[2]/div[1]/div/form/div[4]/button',
                               '/html/body/div[5]/div/div[2]/div[1]/div/form/div[4]/button',
                               '/html/body/div[5]/section/div/div/div/div[1]/div/form/div[4]/button',
                               '/html/body/div[4]/section/div/div/div/div[1]/div/form/div[4]/button',
                               '/html/body/div[4]/section/div/div/div/div[1]/div/form/div[3]/button']

    count = 1
    for login_button_xpath in reversed(login_button_xpaths):
        try:
            log.debug("Trying " + str(count) + " xPath.")
            log.debug("xPath: " + login_button_xpath)
            login_button = browser.find_element('xpath', login_button_xpath)
            login_button.click()
            log.debug(str(count) +  " xPath works.")
            log.debug("Continue Navigate to Data Page.")
            time.sleep(2)
            break
        except:
            log.debug(str(count) +  " xPath doesn't work.")
            log.debug("Try next.")
            count += 1
    if count > len(login_button_xpaths):
        log.debug("None xPath in the list works, Check the xpath on the website")
        log.debug("Exit with Error.")
        exit(1)


    # Navigate to Data Page
    browser.get(url2)
    time.sleep(2)

@measure_execution_time
def get_last_update_datetime(browser):
    timestamp_output = browser.find_element('xpath',
        '//*[@id="content"]/div[2]/section/div/section[2]/div/div/div/div[1]/ul/li[2]/div[2]').get_attribute(
        "innerHTML")
    timestamp_output = datetime.strptime(timestamp_output, '%d/%m/%Y')
    # item = browser.find_element('xpath', '//*[@id="ph-title"]/div')
    # timestamp_string_in_html = item.text
    # log.debug(timestamp_string_in_html)
    # date_slice = timestamp_string_in_html[14:17]
    # month_dict = {'Jan': '01', 'Feb': '02', 'Mar': '03', 'Apr': '04', 'May': '05', 'Jun': '06',
    #               'Jul': '07', 'Aug': '08', 'Sep': '09', 'Oct': '10', 'Nov': '11', 'Dec': '12'}
    # month_slice = month_dict[timestamp_string_in_html[18:21]]
    # year_slice = timestamp_string_in_html[27:31]
    # hour_slice = timestamp_string_in_html[32:34]
    # minute_slice = timestamp_string_in_html[35:37]
    # second_slice = timestamp_string_in_html[38:len(timestamp_string_in_html) - 1]
    # timestamp_output = datetime(
    #     int(year_slice), int(month_slice), int(date_slice), int(hour_slice), int(minute_slice), int(second_slice))
    # log.debug(timestamp_output)
    return timestamp_output

@measure_execution_time
def save_timestamp(timestamp_output, timestamp_path):
    print(timestamp_path)
    timestamp_file = open(timestamp_path, "w")
    toFile = str(timestamp_output)
    timestamp_file.write(toFile)
    timestamp_file.close()
    log.debug("Timestamp saved")

@measure_execution_time
def delete_folder(folder):
    try:
        shutil.rmtree(os.path.join(temp_path, folder))
        print(f'Folder {os.path.join(temp_path, folder)} successfully removed!')
    except:
        log.debug("no " + folder + " folder found")

@measure_execution_time
def download_the_files(browser, sleeping_time, url_supply_demand, url_trade_flow):
    # Navigate to Supply, Demand, Balances and Stocks Page
    browser.get(url_supply_demand)
    time.sleep(2)
    # Download Crude Oil text zip
    browser.get('https://webstore.iea.org/download/productpage/3?fileName=crudebal.zip')
    time.sleep(sleeping_time)
    # Download Product text zip
    browser.get('https://webstore.iea.org/download/productpage/3?fileName=prodbal.zip')
    time.sleep(sleeping_time)
    # Download Supply text zip
    browser.get('https://webstore.iea.org/download/productpage/3?fileName=supply.zip')
    time.sleep(sleeping_time)
    # Download Stocks text zip
    browser.get('https://webstore.iea.org/download/productpage/3?fileName=stocks.zip')
    time.sleep(sleeping_time)
    # Download World Oil Supply and Demand text zip
    browser.get('https://webstore.iea.org/download/productpage/3?fileName=summary.zip')
    time.sleep(sleeping_time)
    # Navigate to Trade Flow Page
    browser.get(url_trade_flow)
    time.sleep(2)
    # Download Imports text zip
    browser.get('https://webstore.iea.org/download/productpage/1?fileName=oilimpor.zip')
    time.sleep(sleeping_time)
    # Download Exports text zip
    browser.get('https://webstore.iea.org/download/productpage/1?fileName=oilexpor.zip')
    time.sleep(sleeping_time)

@measure_execution_time
def datacol(df, col_name):
    return df[col_name]

@measure_execution_time
def splitfields(data):
    """Generator that parses the data correctly into fields"""
    for line in data:
        fields = line.rsplit(maxsplit=4)
        fields[0] = fields[0].strip()  # trim line-initial spaces
        yield fields

@measure_execution_time
def make_pdp_folder_path(pdp_env, current_workflow):
    """
    Generate abs path to PDP given the current CSV being proccesed and the PDP env
    Args:
        pdp_env: str PDP env name in uppercase such as TEST
        current_workflow: Name of the csv workflow being processed such as CRUDEBAL

    Returns:

    """
    output_folder_mapping = {"CRUDEBAL": "IEACrudeBalances",
                             "OILEXPOR": "IEAOilExport",
                             "OILIMPOR": "IEAOilImport",
                             "PRODBAL": "IEAProductBalances"
                             }

    if current_workflow not in output_folder_mapping.keys():
        raise ValueError("{} does not match one of the expected folder mappings {}".format(current_workflow, ",".join(
            output_folder_mapping.keys())))

    workflow_output = output_folder_mapping[current_workflow]

    pdp_upload_path = r"\\petroineos.local\dfs\Department Shared Folders\~Projects\AppShare\{}\PDP\PITL\{}\Input".format(
        pdp_env, workflow_output)

    return pdp_upload_path

@measure_execution_time
def unzip_reformat_iea(unzip_file_list, timestamp_output):
    
    savefile_folder = 'ALL'
    zip_name = ['SDBS','IMPEXP']

    def extract_zip(zip_path):
        print(zip_path)
        with ZipFile(zip_path, 'r') as file:
            file_path = os.path.join(temp_path, '_unzipped', savefile_folder + '_unzipped')
            file.extractall(file_path)
            time.sleep(5)
        print("Unzipping to location: " + os.path.join(file_path, savefile_folder))
        log.debug("Unzipping to location: " + os.path.join(file_path, savefile_folder))

    with ThreadPoolExecutor(max_workers=1) as executor:
        executor.map(extract_zip, [os.path.join(temp_path, '_download', zip_name[0] + ".zip"),
                                    os.path.join(temp_path, '_download', zip_name[1] + ".zip")])
    time.sleep(1)

    def process_file(file):
        file_path = os.path.join(temp_path, '_unzipped', savefile_folder + '_unzipped')
        file_dir, file_cols, file_data, file_output = file_spec(file)
        log.debug("Reading DataFrame: " + os.path.join(file_path, file_data + ".txt"))
        print("Reading DataFrame: " + os.path.join(file_path, file_data + ".txt"))
        with open(os.path.join(file_path, file_data + '.txt')) as data:
            df = pd.DataFrame(splitfields(data), columns=file_cols)
            if (file_data == 'OECDDE') or (file_data == 'SUPPLY'):
                df = df[~((df['Month'].str.contains('Q')) | (df['Month'].str.len() == 4))]
            elif file_data == 'NOECDDE':
                df = df[df['Quarter'].str.contains('Q')]
        df['PDate'] = timestamp_output.date()
        # Output the csv file
        file_name = filename + file_output + "-" + datetime.today().strftime(format_datetime) + ".csv"
        adi_output_path = os.path.join(bulk_uploader_folder, file_name)
        log.debug("CSV File Saved to: {0}.".format(adi_output_path))
        print(f'{filename}{file_output}-')
        su.upload_to_database(df, f'{filename}{file_output}-', upload_destination='TRIGGER', header=True, index=False)
        #df.to_csv(os.path.join(saturn_datafeed, f'{filename}{file_output}.csv'), index=False)
    # Extract zips concurrently

    with ThreadPoolExecutor(max_workers=4) as executor:
        executor.map(process_file, unzip_file_list)
        #time.sleep(2)
    # Process files concurrently
    # for file in unzip_file_list:
    #     process_file(file)

@measure_execution_time
def file_spec(file_type):
    if file_type == 'prodbal':
        file_dir = 'Prodbal'
        file_data = 'PRODDAT'
        file_cols = ['ProductType', 'Country', 'Flow', 'Month', 'Value']
        file_output = 'PRODBAL'

    elif file_type == 'crudebal':
        file_dir = 'Crudebal'
        file_data = 'CRUDEDAT'
        file_cols = ['Country', 'ProductType', 'Flow', 'Month', 'Value']
        file_output = 'CRUDEBAL'

    elif file_type == 'oilimpor':
        file_dir = 'OilImpor'
        file_data = 'IMPORDAT'
        file_cols = ['DestCountry', 'ProductType', 'SourceCountry', 'Month', 'Value']
        file_output = 'OILIMPOR'

    elif file_type == 'oilexpor':
        file_dir = 'OilExpor'
        file_data = 'EXPORDAT'
        file_cols = ['SourceCountry', 'ProductType', 'DestCountry', 'Month', 'Value']
        file_output = 'OILEXPOR'

    elif file_type == 'oecddem':
        file_dir = 'OilDemOECD'
        file_data = 'OECDDE'
        file_cols = ['SourceCountry', 'ProductType', 'Month', 'Value']
        file_output = 'OILDEMOECD'

    elif file_type == 'noecddem':
        file_dir = 'OilDemNonOECD'
        file_data = 'NOECDDE'
        file_cols = ['SourceCountry', 'Quarter', 'Value']
        file_output = 'OILDEMNOECD'

    elif file_type == 'supply':
        file_dir = 'OilSupply'
        file_data = 'SUPPLY'
        file_cols = ['SourceCountry', 'ProductType', 'Month', 'Value']
        file_output = 'OILSUPPLY'

    elif file_type == 'stocks':
        file_dir = 'OilStocks'
        file_data = 'stockdat'
        file_cols = ['Source', 'SourceCountry', 'ProductType', 'Month', 'Value']
        file_output = 'OILSTOCKS'
    return file_dir, file_cols, file_data, file_output

@measure_execution_time
def wait_for_file(file_path, timeout_seconds=60):
    """
    Waits until the specified file exists in the given path.
    :param file_path: Path to the file.
    :param timeout_seconds: Maximum time to wait (default is 60 seconds).
    """
    start_time = time.time()
    while not os.path.exists(file_path):
        if time.time() - start_time > timeout_seconds:
            print(f"Timeout: File '{file_path}' did not appear within {timeout_seconds} seconds.")
            break
        time.sleep(1)

@measure_execution_time
def main():
    log.debug("Env:" + env)
    sleeping_time = 30
    unzip_file_list = ['prodbal', 'crudebal', 'oilimpor', 'oilexpor', 'oecddem', 'noecddem', 'supply', 'stocks']

    url = 'https://www.iea.org/'
    url_data = 'https://www.iea.org/account/licence/products'
    url_supply_demand = 'https://webstore.iea.org/mods-sdbs-data#modal'
    url_trade_flow = 'https://webstore.iea.org/mods-trade-data'

    log.debug("Initialising Chrome.")
    # Initiate Chrome Driver
    browser = load_chorme_settings()

    try:
        log.debug("Getting the website.")
        # Start Scraping
        get_to_download_page(browser, url, url_data)

        log.debug("Click Data Button.")
        view_data_button = browser.find_element('xpath',
            '//*[@id="content"]/div[2]/section/div/article[1]/div/div/div/div[2]/div[1]/div[2]/div[2]/button')
        view_data_button.click()
        time.sleep(2)

        # Get last updated datetime
        log.debug("Getting File Updated Datetime.")
        if env == 'PROD': 
            timestamp_path = os.path.join(temp_path, '_temp', 'timestamp.txt')
        elif env == 'UAT': 
            timestamp_path = os.path.join(temp_path, '_temp', 'timestampuat.txt')
        else: 
            print('Please select env as PROD or UAT (for testing)')

        timestamp_output = get_last_update_datetime(browser)    
         # Compare timestamp, scraper stops if no new updates found
        log.debug("Compare with datetime in temp file.")
        my_file = Path(timestamp_path)
        if my_file.is_file():
            log.debug('Timestamp file found, start to compare')
            timestamp_output_existing = open(timestamp_path, "r").read()

            if str(timestamp_output) == timestamp_output_existing:
                log.debug('No new update found, scraper stops')
                browser.close()
                browser.quit()
                return 0

            log.debug('New update detected, start to download the files')
            log.debug('Timestamp: ' + str(timestamp_output))
        else:
            log.debug('No timestamp file found, start to download the files')
            log.debug('Timestamp: ' + str(timestamp_output))
            return 0

        # Remove existing Download and Unzipped Folders
        log.debug('Remove existing Download and Unzipped Folders.')
        print('Remove existing Download and Unzipped Folders.')
        delete_folder('_download')
        delete_folder('_unzipped')

        log.debug('Download the New Files.')
        anchor = browser.find_element('xpath', '//*[@id="content"]/div[2]/section/div/article[1]/div/div/div/div[2]/div[1]/div[2]/div[1]/a') 
        csv_online = anchor.get_attribute("href")
        print('Download the New Files.',csv_online)
        browser.get(csv_online)
        
        # time.sleep(sleeping_time)
        file_name = "IMPEXP.zip"
        file_path = os.path.join(temp_path, '_download', file_name)
        wait_for_file(file_path)


        log.debug('Download the New Files.')
        anchor = browser.find_element('xpath', '//*[@id="content"]/div[2]/section/div/article[2]/div/div/div/div[2]/div[1]/div[2]/div[1]/a')
        csv_online = anchor.get_attribute("href")
        print('Download the New Files.',csv_online)
        browser.get(csv_online)
        
        # time.sleep(sleeping_time)
        file_name = "SDBS.zip"
        file_path = os.path.join(temp_path, '_download', file_name)
        wait_for_file(file_path)

        
        # # Download the files
        # download_the_files(browser, sleeping_time, url_supply_demand, url_trade_flow)

        # close and quit chrone webdriver
        log.debug('Close and Quit Chrone Webdrivers.')
        browser.close()
        browser.quit()
        # timestamp_output = datetime.today()
        timestamp_path = os.path.join(temp_path, '_temp')
        # Unzip the files
        log.debug('Unzip the Downloaded ZIP Files.')
        unzip_reformat_iea(unzip_file_list, timestamp_output)
        log.debug('Save New Timestamp to Temp File.')
        # Update Timestamp in temp folder
        #save_timestamp(timestamp_output, timestamp_path)
        if env == 'PROD': 
            save_timestamp(timestamp_output, timestamp_path + '/timestamp.txt')
        elif env == 'UAT': 
            save_timestamp(timestamp_output, timestamp_path + '/timestampuat.txt')
        # Send Notification email
        log.debug('Sending out Notifiction Email.')
        if env == 'UAT':
            send_updates_report("behzadhosseini@petroineos.co.uk", "behzadhosseini@petroineos.co.uk", timestamp_output)
        elif env == 'PROD':
            send_updates_report("Charles.Cai@petroineos.com", "John.VonStackelberg@petroineos.com;Loic.Balland@petroineos.com;Syed.Ahmad@petroineos.com;Charles.Cai@petroineos.com;dong.xia@petroineos.com;bobby.hemming@petroineos.co.uk;behzadhosseini@petroineos.co.uk", timestamp_output)
        log.debug("Job Completed.")

        #--------------------------------
        @measure_execution_time
        def process_file_saturn(file):
            file_path = os.path.join(temp_path, '_unzipped' , 'ALL_unzipped')
            file_dir, file_cols, file_data, file_output = file_spec(file)
            print("Reading DataFrame: " + os.path.join(file_path, file_data + ".txt"))
            with open(os.path.join(file_path, file_data + '.txt')) as data:
                df = pd.DataFrame(splitfields(data), columns=file_cols)
                if (file_data == 'OECDDE') or (file_data == 'SUPPLY'):
                    df = df[~((df['Month'].str.contains('Q')) | (df['Month'].str.len() == 4))]
                elif file_data == 'NOECDDE':
                    df = df[df['Quarter'].str.contains('Q')]
            df['PDate'] = timestamp_output.date()

            print(f'{filename}{file_output}')
            df.to_csv(os.path.join(saturn_datafeed, f'{filename}{file_output}.csv'), index=False)

        saturn_list = ['prodbal', 'crudebal', 'oilimpor', 'oilexpor']
        with ThreadPoolExecutor(max_workers=4) as executor:
            executor.map(process_file_saturn, saturn_list)
        return 0
    except:
        log.error(sys.exc_info()[0])
        log.debug("Job Ended with Error!!!")
        return 1


if __name__ == "__main__":
    exit(main())
