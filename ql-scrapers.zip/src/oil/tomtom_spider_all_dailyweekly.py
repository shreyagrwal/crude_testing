import os
import sys
import json
import uuid
import pandas as pd
import requests
import argparse
import pycountry
from datetime import date
from datetime import datetime
from bs4 import BeautifulSoup

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder


def get_country_city():
    query = '''
        SELECT country,city
        FROM hive_metastore.dataengineering.oil_tomtom_trafficcongestioncountrycity
        WHERE IsActive = True
    '''
    return bo.get_data(query)


def get_request(url, period_argument):
    log.debug('processing url:{}'.format(url))
    url = url.replace('liveHourly', period_argument + 'Stats')
    response = requests.get(url)
    if (response.status_code != 200):
        log.error("url:{}")
    rs = response.content
    city = str(response.url).split('_')[-1]
    country = pycountry.countries.get(
        alpha_3=str(response.url).split('_')[-2].split(period_argument + 'Stats/')[-1]).name.upper()
    data_array = json.loads(rs)
    df = pd.DataFrame(data_array)
    log.debug('record count:{}'.format(df.count()))
    df['Pdate'] = date.today()
    df['City'] = city
    df['Country'] = country.replace('TAIWAN, PROVINCE OF CHINA', 'CHINA').replace('HONG KONG', 'CHINA')

    if period_argument == 'weekly':
        csv_columns = ['Pdate', 'Country', 'City', 'week', 'weekStart', 'congestion', 'diffRatio']
    elif period_argument == 'daily':
        df = df.rename(columns={"date": "Ddate"})
        csv_columns = ['Pdate', 'Ddate', 'Country', 'City', 'weekday', 'week', 'congestion', 'diffRatio']

    for column in csv_columns:
        if column not in df.columns:
            df[column] = ''
    return df[csv_columns]


def get_country_url_list(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'lxml')
    city_names = soup.table.tbody.find_all('span', class_="RankingTable__city-name")
    country_names = soup.table.tbody.find_all('div', class_="RankingTable__city-country")

    def get_country_code(country_names):
        rlist = []
        for a in country_names:
            try:
                cname = a.get_text()
                cobject_name = pycountry.countries.get(name=cname)
                if cobject_name is None:
                    cobject_official = pycountry.countries.get(official_name=cname)
                    if cobject_official is None:
                        cobjectfuzzy = pycountry.countries.search_fuzzy(cname)
                        if len(cobjectfuzzy) == 1:
                            rlist.append(cobjectfuzzy[0].alpha_3)
                        else:
                            cobject_common = pycountry.countries.get(common_name=cname)
                            rlist.append(cobject_common.alpha_3)
                    else:
                        rlist.append(cobject_official.alpha_3)
                else:
                    rlist.append(cobject_name.alpha_3)
            except:
                rlist.append(cname)
        return rlist

    def get_unify_city_names(city_names):
        rlist = []
        for c in city_names:
            cname = c.get_text().replace('.', '').replace(',', '').replace(' ', '-').lower()
            if 'moscow' in cname:
                rlist.append('moscow')
            elif 'bengaluru' in cname:
                rlist.append('bangalore')
            elif 'kyiv' in cname:
                rlist.append('kiev')
            elif 'birmingham-wolverhampton' in cname:
                rlist.append('birmingham')
            elif 'gdansk-gdynia-and-sopot' in cname:
                rlist.append('gdansk-gdynia-sopot')
            else:
                rlist.append(cname)
        return rlist

    country_codes = get_country_code(country_names)
    formatted_city_name = get_unify_city_names(city_names)

    url_address_list = []
    for i in range(len(formatted_city_name)):
        url_address_list.append('https://api.midway.tomtom.com/ranking/liveHourly/{}_{}'.
                                format(country_codes[i], formatted_city_name[i]))
    return url_address_list


def generate_uuid(pdate, table):
    """
    Used to create ingestion_id
    pdate: str pdate
    table: str table name or scraper name
    """
    return "{}{}{}".format(table, pdate.replace("-", ""), str(uuid.uuid4()))


def get_country_code(x):
    if x == 'Russia':
        x = 'RUSSIAN FEDERATION'
    elif x == 'Taiwan':
        return 'TWN'
    elif x == 'United States of America':
        return 'USA'
    #print(x)
    iso = pycountry.countries.get(name=x.title()).alpha_3
    return iso


def get_country_url_list_db():
    df_country_city = get_country_city()
    df_country_city.columns = df_country_city.columns.str.lower()
    df_country_city['country_iso'] = df_country_city['country'].apply(get_country_code)
    df_country_city['city'] = df_country_city['city'].str.replace('.', '', regex=False)
    df_country_city['city'] = df_country_city['city'].str.replace(',', '')
    df_country_city['city'] = df_country_city['city'].str.replace(' ', '-')
    df_country_city['city'] = df_country_city['city'].str.replace('Gdansk-Gdynia-and-Sopot', 'gdansk-gdynia-sopot')
    df_country_city['city'] = df_country_city['city'].str.replace('Birmingham-Wolverhampton', 'birmingham')
    df_country_city['city'] = df_country_city['city'].str.replace('Bengaluru', 'bangalore')
    df_country_city['city'] = df_country_city['city'].str.replace('Kyiv', 'kiev')
    df_country_city['city'] = df_country_city['city'].str.replace('Moscow-region-(oblast)', 'moscow', regex=False)
    url_address_list = []
    for index, row in df_country_city.iterrows():
        [iso, city] = row[['country_iso', 'city']]
        url_address_list.append('https://api.midway.tomtom.com/ranking/liveHourly/{}_{}'.format(iso, city.lower()))
    return url_address_list


def main(argv):
    log.debug("ADI Env:" + env)
    country_list_url = 'https://www.tomtom.com/en_gb/traffic-index/ranking/'

    parser = argparse.ArgumentParser()
    parser.add_argument('-period', action='store', dest='period', default='daily', help='select daily or weekly')
    parser.add_argument('--pdp_env', default=env, help='env for PDP if different from ADI')

    args = parser.parse_args(argv)

    period_argument = args.period
    pdp_env = args.pdp_env.upper()

    log.debug("PDP Env:" + pdp_env)

    log.debug("Getting TomTom Data Type: " + period_argument)
    bulk_uploader_folder = bulkUploaderFolder

    filename = 'Upload_OIL_TrafficCongestionAll' + period_argument + '-'
    format_datetime = '%y%m%d%H%M%S'
    columns = ['Country', 'City']

    dfbase = pd.DataFrame(columns=columns)

    log.debug("Getting Country List.")
    # urls = get_country_url_list(country_list_url)

    urls = get_country_url_list_db()
    for url in urls:
        try:
            log.debug("Trying the Country URL: " + url)
            dftemp = get_request(url, period_argument)
            #dfbase = dfbase.append(dftemp)
            dfbase = pd.concat([dfbase,dftemp], axis=0)
            #print(dfbase.columns, [period_argument])
            log.debug("Completed.")
        except Exception as e:
            log.error("Failed to scrape city data. Url: " + url)
            log.error(e)

    filefullname = os.path.join(bulk_uploader_folder, filename + datetime.today().strftime(format_datetime) + ".csv")

    log.debug('start writing to csv')
    # dfbase.to_csv(path_or_buf=filefullname, header=True, index=False)
    su.upload_to_database(dfbase, filename)
    log.debug("CSV File Saved to: {}.".format(filefullname))


    # Upload to PDP. Code to facilitate the migration to PDP
    period_argument_camel = period_argument.title()
    if period_argument_camel in ["Daily", "Weekly"]:
        period_argument_camel = period_argument.title()
        pdate = str(date.today())
        ingestion_id = generate_uuid(pdate=pdate, table=period_argument_camel)
        ingestion_id = ingestion_id[:15]

        # make all columns lower case to conform with the PDP Data Governance Policy
        column_dict_mapping = {'PDate': 'pdate',
                               'Pdate': 'pdate',
                               'Ddate': 'ddate',
                               'weekday': 'weekday',
                               'weekStart': 'week_start',
                               'week': 'week',
                               'congestion': 'congestion',
                               'Created': 'created',
                               'Modified': 'modified',
                               'Country': 'country',
                               'City': 'city',
                               'diffRatio': 'diff_ratio'}

        current_column_mapping = {key: column_dict_mapping[key] for key in column_dict_mapping.keys() if key in dfbase.columns.tolist()}

        dfbase = dfbase.rename(current_column_mapping, axis='columns')
        dfbase["created"] = dfbase["pdate"]
        dfbase["modified"] = dfbase["pdate"]

        if period_argument_camel == "Daily":
            column_order = ["pdate","ddate",  "country", "city","week", "weekday", "congestion","diff_ratio", "created", "modified"]

        else:
            column_order = ["pdate", "week", "week_start", "country", "city", "congestion","diff_ratio", "created", "modified"]

        dfbase = dfbase[column_order]
    else:
        log.debug("Period {} does not match Daily or Weekly".format(period_argument_camel))
    return 0


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main(sys.argv[1:]))
