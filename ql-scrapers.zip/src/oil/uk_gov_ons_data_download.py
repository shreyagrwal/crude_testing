""" Download and parse various macro economics datasets from ONS """
import os, sys
sys.path.append(os.getcwd())
import argparse
from datetime import datetime, timedelta

import numpy as np
from dateutil.relativedelta import relativedelta
import warnings
import requests
import os
import pandas as pd
import logging
import re

log_filename = "logs/onsscraper.log"
os.makedirs(os.path.dirname(log_filename), exist_ok=True)
handler = logging.FileHandler(log_filename)
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
handler.setFormatter(formatter)
root = logging.getLogger()
root.setLevel(os.environ.get("LOGLEVEL", "DEBUG"))
root.addHandler(handler)
root.addHandler(logging.StreamHandler())
log = logging.getLogger("onsscraper")

format_datetime = '%Y-%m-%d'


# output_folder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\AzureDataUploader\staging_area'


def ag_get_data(query):
    """
    Run a SQL query on the datalake
    :param query:
    :return:
    """
    warnings.simplefilter('ignore', requests.packages.urllib3.exceptions.InsecureRequestWarning)
    params = {"Database": "BIGDATAOIL", "Query": query}
    resp = requests.post('https://TST-QDEV-AP7.petroineos.local:5001/genericdata/GetGenericData/', json=params,
                         verify=False)
    json_result = resp.json()
    df = pd.DataFrame(json_result)
    return df


def get_latest_rdate_in_dl():
    """
    Get the latest injected rdate from the datalake
    :return:
    """

    query = """
     select max(rdate) as max_rdate FROM [oil].[dbo].[macro_weekly_shipping_indicators]
     """
    rdate_df = ag_get_data(query)
    max_rdate = rdate_df['max_rdate'].values[0]
    log.info('The last fetched rdate was {}'.format(max_rdate))

    max_rdate = datetime.strptime(max_rdate, format_datetime)

    return max_rdate


def download_latest_excel(href_link,output_folder):
    """
    Download the latest spreadsheet from gov.uk
    We are downloading the ods format due to issues with parsing the file using pandas/openpyxl
    This is a known problem when there is a chart in one of the tabs
    :return:
    """

    file_name = get_file_name(href_link)

    full_file_path = os.path.join(output_folder, file_name)

    request = requests.get(href_link, stream=True)
    print(request)
    if request.status_code == 200:
        log.info("{} has been published and will be downloaded to {}".format(href_link, full_file_path))
        # time.sleep(5)
        with open(full_file_path, 'wb') as out_file:
            out_file.write(request.content)
    else:
        log.info("{} has not yet been published.".format(href_link))
        full_file_path = None

    return full_file_path


def get_file_name(link):
    """
    Extract filename from href link
    :param link:
    :return:
    """
    file_name = link.split('/')[-1]
    return file_name


def extract_ukspendingoncreditanddebitcards(excel_path, pdate, rdate, excel_name_date,upload_folder):
    """
    Extract and parse data on UK spending based on creadit and debic card information.
    Dataset is split into daily and monthly
    :param excel_path:
    :param pdate:
    :param rdate:
    :param excel_name_date:
    :return:
    """
    df_daily = pd.read_excel(excel_path, sheet_name='Daily CHAPS indices', skiprows=4)
    df_daily = df_daily.iloc[:5].T
    df_daily = df_daily.reset_index()


    headers = df_daily.iloc[0]
    df_daily = pd.DataFrame(df_daily.values[1:], columns=headers)
    df_daily['pdate'] = pdate
    df_daily['rdate'] = rdate
    df_daily = df_daily.rename(columns={
        'Category': 'ddate',
    })

    df_monthly = pd.read_excel(excel_path, sheet_name='Monthly CHAPS index', skiprows=4)
    df_monthly = df_monthly.iloc[:5].T
    df_monthly = df_monthly.reset_index()

    headers = df_monthly.iloc[0]
    df_monthly = pd.DataFrame(df_monthly.values[1:], columns=headers)

    df_monthly['pdate'] = pdate
    df_monthly['rdate'] = rdate
    df_monthly = df_monthly.rename(columns={
        'Month': 'ddate',
    })

    file_output_path_daily = os.path.join(upload_folder,
                                          "oil-macro-uk_spending_credit_debit_card_daily-{}.csv".format(
                                              excel_name_date))

    file_output_path_monthly = os.path.join(upload_folder,
                                            "oil-macro-uk_spending_credit_debit_card_monthly-{}.csv".format(
                                                excel_name_date))

    df_daily.to_csv(file_output_path_daily, index=False)
    df_monthly.to_csv(file_output_path_monthly, index=False)


def extract_hr1redundancies(excel_path, pdate, rdate, excel_name_date,upload_folder):
    """
    Extract and parse data on potential redundancies
    :param excel_path:
    :param pdate:
    :param rdate:
    :param excel_name_date:
    :return:
    """
    df = pd.read_excel(excel_path, sheet_name='Potential redundancies', skiprows=1)
    df = df.iloc[:, :7]

    new_columns = [clean_x(x) for x in list(df.columns)]
    df.columns = new_columns

    df['pdate'] = pdate
    df['rdate'] = rdate

    df = df.replace({'\*': np.nan}, regex=True)

    df = df.rename(columns={
        'potential_redundancies_4-week_rolling_average_indexed_100_weekly_average_from_week_ending_21_apr_19_to_week_ending_23_feb_20': 'potential_redundancies_4w_mva_index_21apr19_to23feb20',
        'employers_proposing_redundancies_4-week_rolling_average_indexed_100_weekly_average_from_week_ending_21_apr_19_to_week_ending_23_feb_20': 'employers_proposing_redundancies_4w_mva_index_21apr19_to23feb20'})

    file_output_path = os.path.join(upload_folder,
                                    "oil-macro-uk_potential_redundancies-{}.csv".format(excel_name_date))

    df.to_csv(file_output_path, index=False)


def parse_trafficcameraactivity(path, sheet_name='Trend', sheet_name_nice_name=None):
    """
    Extract and clean traffic camera activity data from ONS
    :param path:
    :param sheet_name:
    :param sheet_name_nice_name:
    :return:
    """
    df = pd.read_excel(path, sheet_name=sheet_name, skiprows=0, header=None)

    t_df = df.T
    t_df = t_df.reset_index()
    headers = t_df.iloc[0]
    headers[0] = 'city'
    headers[1] = 'transport_type'
    headers[2] = 'comment'

    t_df = pd.DataFrame(t_df.values[1:], columns=headers)

    id_vars = ['city', 'transport_type', 'comment']
    value_vars = [x for x in t_df.columns if x not in id_vars]
    t_df = t_df.reset_index(inplace=False)
    t_df = pd.melt(
        t_df, id_vars=id_vars,
        value_vars=value_vars,
        var_name='ddate', value_name='value'
    )

    # t_df
    t_df['category'] = sheet_name_nice_name

    return t_df


def extract_trafficcameraactivity(excel_path, pdate, rdate, excel_name_date,upload_folder):
    """
    Prepare traffic camera activity datasets
    :param excel_path:
    :param pdate:
    :param rdate:
    :param excel_name_date:
    :return:
    """
    df_list = []

    sheet_name_list = ['Trend', 'Non seasonally adjusted', 'Seasonally adjusted']
    for sheet_name in sheet_name_list:
        sheet_name_nice_name = sheet_name.replace(" ", "_").lower()

        df = parse_trafficcameraactivity(path=excel_path, sheet_name=sheet_name,
                                         sheet_name_nice_name=sheet_name_nice_name)
        df = df[['city', 'transport_type', 'ddate', 'value', 'category']]
        df_list.append(df)

    df = pd.concat(df_list)
    df = df.replace({'\*': np.nan}, regex=True)
    df = df.replace({'Δ': np.nan}, regex=True)
    df = df.replace({'#': np.nan}, regex=True)
    df['pdate'] = pdate
    df['rdate'] = rdate

    file_output_path = os.path.join(upload_folder,
                                    "oil-macro-uk_traffic_camera_activity-{}.csv".format(excel_name_date))

    df.to_csv(file_output_path, index=False)


def extract_weeklyshippingindicators(excel_path, pdate, rdate, excel_name_date,upload_folder):
    """
    Parsing and extractin weekly shipping indicators
    :param excel_path:
    :param pdate:
    :param rdate:
    :param excel_name_date:
    :return:
    """
    sheet_list = ['Daily all visits', 'Daily C&T visits', 'Weekly all visits', 'Weekly all unique ships',
                  'Weekly C&T visits', 'Weekly C&T unique ships']
    df_list = []

    for sheet_name in sheet_list:
        log.info("Working on sheet name {}".format(sheet_name))

        sheet_nice_name = sheet_name.replace(' ', '_').replace('&', '_and_')

        df = pd.read_excel(excel_path, sheet_name=sheet_name, skiprows=0, header=None)
        t_df = df.T
        headers = t_df.iloc[1]
        headers[0] = 'Metric'
        headers[1] = 'Seasonal Adjustment'
        headers[2] = 'Port'
        headers[3] = 'Units'

        t_df = pd.DataFrame(t_df.values[2:], columns=headers)
        t_df = t_df.loc[:, t_df.columns.notna()]

        id_vars = ['Metric', 'Seasonal Adjustment', 'Port', 'Units', 'Date']
        id_vars = [x for x in id_vars if x in t_df.columns]
        value_vars = [x for x in t_df.columns if x not in id_vars]
        t_df = t_df.reset_index(inplace=False)
        t_df = pd.melt(
            t_df, id_vars=id_vars,
            value_vars=value_vars,
            var_name='ddate', value_name='value'
        )

        t_df['category'] = sheet_nice_name.lower()

        df_list.append(t_df)

    df = pd.concat(df_list)
    df = df[['Metric', 'Seasonal Adjustment', 'Port', 'Units', 'ddate', 'value', 'category']]

    df['pdate'] = pdate
    df['rdate'] = rdate
    df = df.replace({'x': np.nan}, regex=True)

    file_output_path = os.path.join(upload_folder,
                                    "oil-macro-weekly_shipping_indicators-{}.csv".format(excel_name_date))

    df.to_csv(file_output_path, index=False)


def extract_csv_files(excel_path, file_name,upload_folder):
    """
    Convert Excel tab to csv file and save to blob upload folder
    :param excel_path:
    :return:
    """

    excel_name_date = excel_path.replace('.xlsx', '')[-6:]

    rdate = datetime.strptime(excel_name_date, '%d%m%y')  # publish date
    pdate = datetime.today().strftime(format_datetime)

    if 'ukspendingoncreditanddebitcards' in file_name:
        log.info("Extracting data for ukspendingoncreditanddebitcards")
        extract_ukspendingoncreditanddebitcards(excel_path, pdate, rdate, excel_name_date,upload_folder)
    elif 'hr1redundancies' in file_name:
        log.info("Extracting data for hr1redundancies")
        extract_hr1redundancies(excel_path, pdate, rdate, excel_name_date,upload_folder)
    elif 'trafficcameraactivity' in file_name:
        log.info("Extracting data for trafficcameraactivity")
        extract_trafficcameraactivity(excel_path, pdate, rdate, excel_name_date,upload_folder)
    elif 'weeklyshippingindicators' in file_name:
        log.info("Extracting data for weeklyshippingindicators")
        extract_weeklyshippingindicators(excel_path, pdate, rdate, excel_name_date,upload_folder)

    else:
        log.error("{} does not match any cleaning scripts".format(file_name))


def clean_x(column):
    """
    Clean up column names to conform with our data standards
    :param column:
    :return:
    """
    column = column.lower()
    column = column.replace('%', "percent")
    column = re.sub(r'(?<=\[)[^]]+(?=\])', '', column)
    column = column.rstrip()
    column = column.lstrip()
    column = column.replace(']', "")
    column = column.replace('[', "")
    column = column.replace('(', "")
    column = column.replace(')', "")
    column = column.replace(' ', "_")
    column = column.replace(',', "")
    column = column.replace('/', "_")
    column = column.replace(':', "_")
    column = column.replace('=', "_")
    column = column.replace('\n', "_")
    column = column.replace('___', "_")
    column = column.replace('__', "_")

    return column


def get_date_range_list_since_last_rdate():
    """
    Generate a list of dates since the last publish date
    :return:
    """
    try:
        last_rdate = get_latest_rdate_in_dl()
    except Exception as e:
        log.info("Failed getting latest rdate from the data lake")
        last_rdate = datetime.today() - timedelta(days=6)  # to download data published in the last 6 days
    last_rdate = datetime.today() - timedelta(days=8)
    log.info("Last rdate was {}".format(last_rdate))
    current_date = datetime.today()
    date_range = list(pd.date_range(last_rdate + relativedelta(days=1), current_date, freq='d'))
    date_range.append(current_date)
    return date_range


def generate_href_links(name, dataset_name):
    """ Generate a list of potential file download links """

    date_range = get_date_range_list_since_last_rdate()
    link_list = []
    for date_obj in date_range:
        full_year = date_obj.strftime('%Y')
        if dataset_name == 'hr1redundancies':
            full_year = 'current'
        year = date_obj.strftime('%y')
        month = date_obj.strftime('%m')
        day = date_obj.strftime('%d')
        href_link = r"""https://www.ons.gov.uk/file?uri=/economy/economicoutputandproductivity/output/datasets/{5}/{0}/{4}dataset{1}{2}{3}.xlsx""".format(
            full_year, day, month, year, dataset_name, name)
        link_list.append(href_link)

    return link_list, date_range


def download_and_process_ons_data(output_folder,upload_folder):
    """
    Orchestrate the data processing by downloading the latest Excel spreadsheet and uploading converted CSV files to blob
    :return:
    """

    dataset_config_dict = {'ukspendingoncreditanddebitcards': 'ukspendingoncreditanddebitcards',
                           'weeklyshippingindicators': 'weeklyshippingindicators',
                           'advancednotificationofpotentialredundancies': 'hr1redundancies',
                           'trafficcameraactivity': 'trafficcameraactivity'}

    error_list = []

    for name, dataset_name in dataset_config_dict.items():
        href_list, date_range_list = generate_href_links(name=name, dataset_name=dataset_name)
        print(date_range_list)
        one_success = False
        for href_link in href_list:
            print(href_link)
            full_file_path = download_latest_excel(href_link=href_link,output_folder=output_folder)

            if full_file_path is None:
                log.info("Download failed for {}".format(href_link))
                continue
            #
            file_name = get_file_name(link=href_link)

            log.info("Filename {} at {}".format(file_name, full_file_path))
            extract_csv_files(excel_path=full_file_path, file_name=file_name,upload_folder=upload_folder)
            one_success = True

        # W expect new data to arrive once a week, if no data has arrived after 8 days will throw an error
        if one_success is False and len(date_range_list) > 8:
            error_list.append(dataset_name)

    if len(error_list) != 0:
        error_msg = """ERROR: No data was downloaded for {} and its been more than one week since we last fetched data. This could simply mean that no new data has been published in "
        "the given date range, but most likely means the website has been updated and we need to update the script.""".format(
            ",".join(error_list))

        log.error(error_msg)
        raise FileNotFoundError(error_msg)


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--output_folder", help="Local folder to store the downloaded files",default=r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Scrapers\macro")
    parser.add_argument("--upload_folder", help="Local folder to save the cleaned CSV files",default=r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\AzureDataUploader\OIL")
    # parser.add_argument("--upload_folder", help="Local folder to save the cleaned CSV files",default=r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\AzureDataUploader")

    args = parser.parse_args()

    output_folder = args.output_folder
    upload_folder = args.upload_folder


    download_and_process_ons_data(output_folder=output_folder,upload_folder=upload_folder)
