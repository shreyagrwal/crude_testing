import os
import sys
import time
import random
import pandas as pd
from pathlib import Path
from datetime import datetime
from selenium import webdriver
import matplotlib.pyplot as plt
from pandas.tseries.offsets import MonthEnd

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_email import ag_email_helper as aeh
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder

format_date = '%Y-%m-%d'
format_datetime = '%y%m%d%H%M%S'
appFolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\Diagrams'
temp_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\Scrapers\Echo'

filename = 'Upload_OIL_EchoCrude' + '-'
bulk_uploader_folder = bulkUploaderFolder
url_weekly = 'http://enterpriseproducts.com/customers/wti-crude-quality-echo'
url_monthly_wti = 'http://enterpriseproducts.com/customers/wti-crude-quality-echo-intermediate-hist'
url_monthly_wtl = 'http://enterpriseproducts.com/customers/wti-crude-quality-echo-light-hist'
sleeping_time = 30


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
#        chrome_options.add_argument('--headless')  # Otherwise headless Chrome
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": r"c:\temp\\",
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")

    browser = webdriver.Chrome(executable_path=".\\Tools\\chromedriver.exe", chrome_options=chrome_options)
    return browser


def get_latest_pdate(Product):
    query = '''
      SELECT max(Date_To) From
      dataengineering.oil_crude_echocrude
      Where Product = ''' + "'" + Product + "'" + '''
      AND Freq = 'Weekly' 
      AND IsActive = True
    '''
    return bo.get_data(query)


def get_latest_table(crude):
    query = '''
        SELECT Product
              ,Freq
              ,Date_From
              ,API
              ,Sulphur
              ,BSW
              ,Nickel
              ,Vanadium
        From dataengineering.oil_crude_echocrude
        where IsActive = True 
        AND product= ''' + "'" + crude + "'"
    return bo.get_data(query)


def send_upload_fail_warning(email_from, emails, pdate_1, pdate_2, count):

    sub = "Echo Crude Database Update FAILED!"
    body = "<b>Echo Crude databas upload failed after " + str(count) + " attemps</b>" \
           + "<br>" \
           + "<br>" \
           + "<b>Latest data timestamp pulished on echo terminal website: " + str(pdate_1) + "</b>" \
           + "<br>" \

    imgList = []

    email_sender = aeh.AgEmailHelper()
    email_sender.send_mail_with_embedded_images(email_from, emails, sub, body, imgList)


def send_report(email_from, emails, imgs, pdate_new):

    folder, img_df_1_filename = os.path.split(imgs[0])
    folder, img_df_2_filename = os.path.split(imgs[1])
    folder, img_df_3_filename = os.path.split(imgs[2])
    folder, img_df_4_filename = os.path.split(imgs[3])

    sub = "West Texas Intermediate & Light Crude Quality at ECHO - (" + pdate_new.strftime("%Y-%m-%d") + ")"
    body = "<b><font size='+2'> West Texas Intermediate & LIght Crude Quality at ECHO:</font></b>" \
           + "<br>" \
           + "<br>" \
           + "<b><font size='+1.5'> 1. ECHO Terminal - WTI API:</font></b>" \
           + "<br>" \
           + "<img src='cid:" + img_df_1_filename + "'>" \
           + "<br>" \
           + "<b><font size='+1.5'> 2. ECHO Terminal - WTI Surphur Content, %:</font></b>" \
           + "<br>" \
           + "<img src='cid:" + img_df_2_filename + "'>" \
           + "<br>" \
           + "<br>" \
           + "<b><font size='+1.5'> 3. ECHO Terminal - WTL API:</font></b>" \
           + "<br>" \
           + "<img src='cid:" + img_df_3_filename + "'>" \
           + "<br>" \
           + "<br>" \
           + "<b><font size='+1.5'> 4. ECHO Terminal - WTL Surphur Content, %:</font></b>" \
           + "<br>" \
           + "<img src='cid:" + img_df_4_filename + "'>" \
           + "<br>" \
           + "<br>" \
           + "<b>Updated: " + pdate_new.strftime("%Y-%m-%d") + "</b>" \
           + "<br>" \

    email_sender = aeh.AgEmailHelper()
    email_sender.send_mail_with_embedded_images(email_from, emails, sub, body, imgs)


def generate_and_send_report(imgs, pdate_new):
    if env == 'UAT':
        send_report("behzadhosseini@petroineos.co.uk", "behzadhosseini@petroineos.co.uk", imgs, pdate_new)
    else:
        send_report("John.VonStackelberg@petroineos.com",
                    "CrudeTradingNSea@petroineos.com;John.VonStackelberg@petroineos.com;Tianyang.Li@petroineos.com;Hani.Moledina@petroineos.com;Charles.Cai@petroineos.com;Dong.Xia@petroineos.com;behzadhosseini@petroineos.co.uk;bobby.hemming@petroineos.co.uk", imgs, pdate_new)


def compare(df):
    if df['position_x'] == df['position_y']:
        return '-'
    elif df['position_x'] < df['position_y']:
        return 'Buy'
    else:
        return 'Sell'


def color_negative_red(value):

    if value < 0:
        color = 'red'
    elif value > 0:
        color = 'green'
    else:
        color = 'black'

    return 'color: %s' % color


def save_to_csv(df, filename):
    filefullname = os.path.join(bulk_uploader_folder, filename + datetime.today().strftime(format_datetime) + ".csv")
    # df.to_csv(path_or_buf=filefullname, header=True, index=False)
    su.upload_to_database(df, filename)
    log.debug("CSV File Saved to: {0}.".format(filefullname))
    time.sleep(1)


def cleansing_weekly_table(df_list, table_index):
    cols = ['Product', 'Date_Range', 'API', 'Sulphur', 'BSW', 'Nickel', 'Vanadium']
    df = pd.DataFrame(df_list[table_index]._get_values, columns=cols)
    df[['Date_From', 'Date_To']] = df['Date_Range'].str.split(' - ', n=1, expand=True)
    df['Date_From'] = pd.to_datetime(df['Date_From'], errors='coerce', format='%m/%d/%y')
    df['Date_To'] = pd.to_datetime(df['Date_To'], errors='coerce', format='%m/%d/%y')
    df['Date_From'] = df['Date_From'].dt.strftime(format_date)
    df['Date_To'] = df['Date_To'].dt.strftime(format_date)
    df['Freq'] = 'Weekly'
    df['Pdate'] = datetime.today().strftime(format_date)
    df = df.drop(['Date_Range'], axis=1)
    return df


def cleansing_monthly_table(df_list):
    cols = ['Product', 'Date_From', 'API', 'Sulphur', 'BSW', 'Nickel', 'Vanadium']
    df = pd.DataFrame(df_list[0]._get_values, columns=cols)
    df[['Month', 'Year']] = df['Date_From'].str.split('/', n=1, expand=True)
    df['Day'] = 1
    df['Date_From'] = pd.to_datetime(df[['Year', 'Month', 'Day']])
    df['Date_To'] = df['Date_From'] + MonthEnd(0)
    df['Date_From'] = df['Date_From'].dt.strftime(format_date)
    df['Date_To'] = df['Date_To'].dt.strftime(format_date)
    df['Freq'] = 'Monthly'
    df['Pdate'] = datetime.today().strftime(format_date)
    df = df.drop(['Year', 'Month', 'Day'], axis=1)
    return df


def get_temp_timestamp(crude):
    # Get last updated datetime
    timestamp_path = os.path.join(temp_path, '_temp', 'timestamp' + crude + '.txt')

    # Compare timestamp, scraper stops if no new updates found
    my_file = Path(timestamp_path)
    if my_file.is_file():
        log.debug('Timestamp file found, start to compare')
        timestamp_output_existing = open(timestamp_path, "r").read()
        timestamp_output_existing = pd.to_datetime(timestamp_output_existing)
    else:
        log.debug('No timestamp file found, start to download the files')
        timestamp_output_existing = datetime(2000, 1, 1)
    return timestamp_output_existing


def save_timestamp(timestamp_output, crude):
    timestamp_path = os.path.join(temp_path, '_temp', 'timestamp' + crude + '.txt')
    timestamp_file = open(timestamp_path, "w")
    toFile = str(timestamp_output)
    timestamp_file.write(toFile)
    timestamp_file.close()
    log.debug(crude + " Timestamp saved")


def get_weekly_table(browser, url_weekly):
    browser.get(url_weekly)
    # time.sleep(random.uniform(5, 10))
    time.sleep(random.uniform(1, 2))
    df_list = pd.read_html(browser.page_source)
    df_weekly_wti = cleansing_weekly_table(df_list, 0)
    df_weekly_wtl = cleansing_weekly_table(df_list, 1)
    time.sleep(1)
    return df_weekly_wti, df_weekly_wtl


def get_monthly_table(browser, url):
    browser.get(url)
    # time.sleep(random.uniform(5, 10))
    time.sleep(random.uniform(1, 2))
    df_list = pd.read_html(browser.page_source)
    df_monthly = cleansing_monthly_table(df_list)
    time.sleep(1)
    return df_monthly


def scrape_echo_data(browser, url_weekly, url_monthly_wti, url_monthly_wtl):

    df_weekly_wti, df_weekly_wtl = get_weekly_table(browser, url_weekly)

    timestamp_new_wti, timestamp_new_wtl = df_weekly_wti['Date_To'].max(), df_weekly_wtl['Date_To'].max()

    timestamp_new_wti = pd.to_datetime(timestamp_new_wti)
    timestamp_new_wtl = pd.to_datetime(timestamp_new_wtl)

    timestamp_existing_wti, timestamp_existing_wtl = get_temp_timestamp('wti'), get_temp_timestamp('wtl')

    if timestamp_new_wti == timestamp_existing_wti and timestamp_new_wtl == timestamp_existing_wtl:
        log.debug('No new update found, scraper stops')
        browser.close()
        browser.quit()
        exit(0)

    log.debug('WTI Timestamp: ' + str(timestamp_new_wti))
    log.debug('WTL Timestamp: ' + str(timestamp_new_wtl))

    df_monthly_wti = get_monthly_table(browser, url_monthly_wti)
    df_monthly_wtl = get_monthly_table(browser, url_monthly_wtl)

    save_to_csv(df_weekly_wti, filename)
    save_to_csv(df_weekly_wtl, filename)
    save_to_csv(df_monthly_wti, filename)
    save_to_csv(df_monthly_wtl, filename)

    save_timestamp(timestamp_new_wti, 'wti')
    save_timestamp(timestamp_new_wtl, 'wtl')

    return timestamp_new_wti, timestamp_new_wtl


def plot_the_graph(df_monthly, df_weekly, crude, category):
    fig, ax1 = plt.subplots(figsize=(12, 6))
    # Plot against LHS y-axis
    ln1 = ax1.plot(df_monthly['Date_From'], df_monthly[category], label='Monthly', marker='o')
    ln2 = ax1.plot(df_weekly['Date_From'], df_weekly[category], label='Weekly', marker='o')

    if category == 'API':
        y_label = 'API'
        if crude == 'wti':
            ax1.axhspan(42.5, 43.5, color='gainsboro')
    else:
        y_label = 'Sulphur Content, %'

        if crude == 'wti':
            df_weekly['sulphur_standard'] = 0.12
            ax1.plot(df_weekly['Date_From'], df_weekly['sulphur_standard'], color='gray', linestyle='dashed', linewidth=2.5)

    ax1.set_xlabel('Date')
    ax1.set_ylabel(y_label)
    ax1.set_title('ECHO Terminal ' + y_label + ' - ' + crude.upper())
    # add lines together for legend
    lns = ln1 + ln2
    labs = [l.get_label() for l in lns]
    ax1.legend(lns, labs, loc=0)
    ax1.grid()
    fig.tight_layout()
    img = os.path.join(appFolder, 'echo_terminal_' + crude + '_' + category + '.png')
    plt.savefig(img)
    return img


def plot_crude_property(df, crude):
    df['Date_From'] = pd.to_datetime(df['Date_From'])
    df_monthly = df[df['Freq'] == 'Monthly']
    df_weekly = df[df['Freq'] == 'Weekly']

    img1 = plot_the_graph(df_monthly, df_weekly, crude, 'API')
    img2 = plot_the_graph(df_monthly, df_weekly, crude, 'Sulphur')

    return img1, img2


def send_email(pdate_new_wti, pdate_new_wtl):
    count = 0
    while count < 5:
        log.debug("Wait for {} sec to allow the batchuploarder to upload new data to database, this is {} try.".format(
            sleeping_time, count + 1))
        time.sleep(sleeping_time)
        if pdate_new_wti == pd.to_datetime(get_latest_pdate('wti').iloc[0, 0])\
                and pdate_new_wtl == pd.to_datetime(get_latest_pdate('wtl').iloc[0, 0]):
            log.debug("Database update completed.")
            log.debug("Sending out notification email.")
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

            log.debug("Getting Current and Previous Allocation Tables from Database.")
            df_wti = get_latest_table('wti')
            df_wtl = get_latest_table('wtl')

            img1, img2 = plot_crude_property(df_wti, 'wti')
            img3, img4 = plot_crude_property(df_wtl, 'wtl')

            # Send email with plots
            log.debug("Sending Emails with Position and NAV updates.")
            imgs = [img1, img2, img3, img4]
            generate_and_send_report(imgs, max(pdate_new_wti, pdate_new_wtl))
            log.debug("Job Completed.")
            break
        else:
            count += 1
    if count >= 5:
        log.debug("New Data File Failed to Uploaded to Database")
        log.debug("Sending Warning Email.")
        send_upload_fail_warning("dong.xia@petroineos.com", "dong.xia@petroineos.com", pdate_new_wti, pdate_new_wti, count)

        log.debug("Job Failed.")
        exit(1)


def main():
    try:
        # Initiate Chrome Driver
        log.debug("Env:" + env)
        log.debug("BatchUploader Waiting Time: {0}s.".format(sleeping_time))
        log.debug("Initialising Chrome.")
        browser = load_chrome_settings()

        # Start Scraping - get allocation table from main page
        log.debug("Getting allocation table.")
        pdate_new_wti, pdate_new_wtl = scrape_echo_data(browser, url_weekly, url_monthly_wti, url_monthly_wtl)

        # close and close chrone webdriver
        browser.close()
        browser.quit()

        # wait for data to be uploaded to database and send position report
        log.debug("Wait for data to be uploaded to database and send position report.")
        send_email(pdate_new_wti, pdate_new_wtl)
        log.debug("Job Completed.")
        return 0

    except Exception as e:
        log.error(e)
        log.debug("Job Ended with Error!!!")
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())