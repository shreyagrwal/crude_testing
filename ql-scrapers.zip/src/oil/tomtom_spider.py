import os
import sys
import json
import pandas
import requests
from datetime import datetime

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder


def get_request(url):
    log.debug('processing url:{}'.format(url))
    response = requests.get(url)
    rs = response.content
    city = str(response.url).split('_')[-1]
    data_array = json.loads(rs)['data']
    df = pandas.DataFrame(data_array)
    log.debug('record count:{}'.format(df.count()))
    df['UpdateTime'] = pandas.to_datetime(df['UpdateTime'], unit='ms')
    df['City'] = city
    df = df.rename(columns={"UpdateTime": "PDate"})
    return df[['City','TrafficIndexLive', 'PDate']]


def main():
    urls = ['https://api.midway.tomtom.com/ranking/liveHourly/CHN_beijing'
            ,'https://api.midway.tomtom.com/ranking/liveHourly/CHN_shanghai'
            ,'https://api.midway.tomtom.com/ranking/liveHourly/CHN_shenzhen'
            ,'https://api.midway.tomtom.com/ranking/liveHourly/CHN_guangzhou'
            ,'https://api.midway.tomtom.com/ranking/liveHourly/CHN_dongguan'
            ,'https://api.midway.tomtom.com/ranking/liveHourly/CHN_zhuhai'
            ,'https://api.midway.tomtom.com/ranking/liveHourly/CHN_wuhan']
    columns = ['City','TrafficIndexLive','TrafficIndexHistoric','PDate']

    log.debug("Env:" + env)
    bulk_uploader_folder = bulkUploaderFolder
    filename = 'Upload_OIL_TrafficCongestion-'
    format_datetime = '%y%m%d%H%M%S'

    dfbase = pandas.DataFrame(columns=columns)
    for url in urls:
        log.debug("Scrape " + url)
        dftemp = get_request(url)
        dfbase = dfbase.append(dftemp)

    filefullname = os.path.join(bulk_uploader_folder,filename+ datetime.today().strftime(format_datetime)+".csv")
    log.debug('start writing to csv '+ filefullname)
    # dfbase.to_csv(path_or_buf=filefullname,header=True,index=False)
    su.upload_to_database(dfbase, filename)


if __name__ == "__main__":
    log = ag_log.get_log()
    log.debug ('start running def main()')
    main()

