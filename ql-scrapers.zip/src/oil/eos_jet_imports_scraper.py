import os
import sys
import shutil

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder

log = ag_log.get_log()
log.debug("Start to scrape Jet Tracking files.")
source_destination = r'\\petroineos.local\dfs\Department Private Folders\Analysis Department\OilProd\JetCargoTracking\Scrape'
sql_folder = bulkUploaderFolder
archive_destination = r'\\petroineos.local\dfs\Department Private Folders\Analysis Department\OilProd\JetCargoTracking\Scrape Done'

file_names = os.listdir(source_destination)

for file_name in file_names:
    log.debug("File Name: " + file_name)
    shutil.copy(os.path.join(source_destination, file_name), sql_folder)
    shutil.move(os.path.join(source_destination, file_name), archive_destination)
log.debug("Job Completed.")

