import os
import sys
import ftplib
import os.path

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_email import ag_email_helper as aeh
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder


def main():
    ftpaddress = 'ftp.oilanalytics.com'
    username = 'pet_ftp'
    passw = '8FiDIcHs9LD2'
    localdir = 'c:/Temp/test/ftp'

    if not os.path.exists(localdir):
        os.makedirs(localdir)
    ftp = ftplib.FTP_TLS(ftpaddress)
    ftp.login(username,passw)
    ftp.prot_p()
    ftproot = '/Custom/pet'
    ftp.cwd(ftproot)
    subfoldername = ''
    run_through_folder(ftproot,subfoldername,ftp, localdir)


def run_through_folder(ftproot, subfoldername, ftp, localdir):
    datalist = []
    cwd = os.path.join(ftproot, subfoldername)
    ftp.cwd(cwd)
    ftp.dir(datalist.append)
    for d in datalist:
        if '<DIR>' in d:
            #get folder name and recurs
            folder_name = d.split(' ')[-1]
            log.debug('found foldername:{}'.format(folder_name))
            subsubfolder = os.path.join(subfoldername,folder_name)
            run_through_folder(ftproot,subsubfolder,ftp,localdir)
        else:
            ftp.cwd(cwd)
            fname = d.split(' ')[-1]
            log.debug('filename:{}'.format(fname))
            download_file(os.path.join(localdir,subfoldername),fname,ftp)


def download_file(localdir, filename, ftp):
    if not os.path.exists(localdir):
        os.makedirs(localdir)
    log.debug('saving file {}'.format(filename))
    handle = open(os.path.join(localdir, filename), 'wb')
    ftp.retrbinary('RETR {}'.format(filename), handle.write)


if __name__ == '__main__':
    log = ag_log.get_log()
    main()
