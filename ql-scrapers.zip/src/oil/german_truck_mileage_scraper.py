import os
import ssl
import sys
import pandas as pd
from datetime import datetime

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se


env = se.environment
bulkUploaderFolder = se.ingestion_folder
ssl._create_default_https_context = ssl._create_unverified_context  # SSL Certificate

file_url = 'https://www.destatis.de/DE/Themen/Branchen-Unternehmen/Industrie-Verarbeitendes-Gewerbe/Tabellen/Lkw-Maut-Fahrleistungsindex-Daten.xlsx?__blob=publicationFile'
format_datetime = '%y%m%d%H%M%S'
filename = 'Upload_OIL_GermanTruckMileage-'
bulk_uploader_folder = bulkUploaderFolder


def get_latest_ddate_from_db():
    query = '''
        SELECT max(ddate)
        FROM hive_metastore.dataengineering.oil_mobility_germantruckmileage
        where IsActive = True
    '''
    return bo.get_data(query)


def save_to_csv(df, filename):
    filefullname = os.path.join(bulk_uploader_folder, filename + datetime.today().strftime(format_datetime) + ".csv")
    log.debug("CSV File Saved to: {0}.".format(filefullname))
    # df.to_csv(path_or_buf=filefullname, header=True, index=False)
    su.upload_to_database(df, filename)


def scrape_truck_mileage_data(url):
    df = pd.read_excel(url, sheet_name='Daten', skiprows=range(0, 5))
    return df


def translate_into_english(df):
    df.columns = ['ddate', 'week', 'weekday', 'unadjusted_values', 'seasonally_adj_values', 'adj_values_seven_days_average', 'dod_pctg_adj_values']
    df['weekday'].loc[df['weekday'].str.contains('Montag')] = 'Monday'
    df['weekday'].loc[df['weekday'].str.contains('Dienstag')] = 'Tuesday'
    df['weekday'].loc[df['weekday'].str.contains('Mittwoch')] = 'Wednesday'
    df['weekday'].loc[df['weekday'].str.contains('Donnerstag')] = 'Thursday'
    df['weekday'].loc[df['weekday'].str.contains('Freitag')] = 'Friday'
    df['weekday'].loc[df['weekday'].str.contains('Samstag')] = 'Saturday'
    df['weekday'].loc[df['weekday'].str.contains('Sonntag')] = 'Sunday'
    df['pdate'] = datetime.today()
    return df


def format_data(df):
    df['week'] = df['week'].astype(int)
    return df


def check_date_and_save(df):
    ddate_existing = pd.to_datetime(get_latest_ddate_from_db().iat[0, 0])
    ddate_latest = df['ddate'].max()
    if ddate_latest == ddate_existing:
        log.debug("No new data found on website, scraper stopped~~~")
    else:
        if ddate_existing == None:
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            log.debug("No data found in database, start to scrape.")
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        else:
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            log.debug("New German Truck Mileage index data found on the website")
            log.debug("The latest data point is " + str(ddate_latest.strftime("%Y-%m-%d")))
            log.debug("Start to scrape.")

        df = format_data(df)
        save_to_csv(df, filename)


def main():
    try:
        log.debug("Env:" + env)
        
        log.debug("Read CSV file from website.")
        df = scrape_truck_mileage_data(file_url)

        log.debug("Translate weekdays into English.")
        df = translate_into_english(df)

        log.debug("Check Pdate and export to csv.")
        check_date_and_save(df)
        
        log.debug("Job Completed.")
        return 0
    except Exception as e:
        log.error(e)
        log.debug("Job Ended with Error!!!")
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())
