import re
import os
import sys
import time
import pandas as pd
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import chromedriver_autoinstaller
from selenium.webdriver.common.by import By
# from azure.storage.blob import BlobServiceClient, __version__

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

# chromedriver_autoinstaller.install()
# try:
#     print("Azure Blob Storage v" + __version__ )
# except Exception as ex:
#     print('Exception:')
#     print(ex)


log = ag_log.get_log()
format_datetime = '%Y-%m-%d'
env = se.environment
bulkUploaderFolder = se.ingestion_folder
temp_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\BEIS'
temp_filename = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RystadOilProduction\Scrapers\Temp\uk_road_fuel_sale_time_check.tmp'
upload_folder = bulkUploaderFolder

def check_new_data_released(check_time:int = 30): #default time is 30 minutes
    browser = load_chrome_settings()
    browser.get("https://www.gov.uk/government/statistics/average-road-fuel-sales-and-stock-levels")
    time.sleep(2)
    current_date = browser.find_element(By.XPATH, '//*[@id="content"]/div[2]/div/div[1]/div/dl/dd[3]').text  # fullpath -> /html/body/div[3]/main/div[2]/div/div[1]/div/dl/dd[3]
    current_date = current_date.replace('Last updated ', '').replace(' — See all updates', '') + f' {datetime.now().hour}:{datetime.now().minute}'
    c_date = datetime.strptime(current_date, '%d %B %Y %H:%M')
    lastupdate_date = read_from_temp(temp_filename)
    l_date = datetime.strptime(lastupdate_date, '%d %B %Y %H:%M')
    print(f'Curent release date is {c_date} and last data released at {l_date}')
    if c_date.date() != l_date.date():
        save_to_tmp(c_date.strftime("%d %B %Y %H:%M"), temp_filename)
    isNew = (datetime.now() - l_date).total_seconds() / 60.0 < check_time
    print(f'Check time is set to {check_time} and total min diff is {(datetime.now() - l_date).total_seconds() / 60.0} \n')
    return isNew

def save_to_tmp(content, filename):
    with open(filename, 'w') as file:
        file.write(str(content))

def read_from_temp(file):
    with open(file, 'r') as content_file:
        content = content_file.read()
        return content

# def upload_to_blob(file_path):
#     """
#     Upload files to blob
#     :param file_path:
#     :return:
#     """

#     dir_name = 'datasets/staging/input'
#     connection_str = r'DefaultEndpointsProtocol=https;AccountName=stadlspetro;AccountKey=ZbRP1NdYXccZiLAxY+Wasf0Cg0DPUYPDVDAnI2/GOYTG+0bcTWJ3GcqPCxOTIpdUUZzpTQ3AWv4N5wWryTl4Lw==;EndpointSuffix=core.windows.net'
#     container_name = 'fsdlspetro'

#     blob_service_client = BlobServiceClient.from_connection_string(connection_str)

#     blob_name = f"{dir_name}/{os.path.basename(file_path)}"
#     blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)

#     print("\nUploading to Azure Storage as blob:\n\t" + file_path)

#     # Upload the created file
#     with open(file_path, "rb") as data:
#         blob_client.upload_blob(data)


def load_chrome_settings():
    """
    Setting up selenium settings
    :return:
    """
    chrome_options = webdriver.ChromeOptions()
    # if sys.gettrace() is None:  # Check if it's in Debug model
    #     chrome_options.add_argument('--headless')  # Otherwise headless Chrome
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": temp_path,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--ignore-ssl-errors=yes")
    chrome_options.add_argument("--ignore-certificate-errors")

    #chromedriver_autoinstaller.install()
    #browser = webdriver.Chrome(chrome_options=chrome_options)
    service = Service(executable_path='.\\tools\\chromedriver.exe')
    browser = webdriver.Chrome(service=service, options=chrome_options)
    #browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", options=chrome_options)
    #browser = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    return browser


def download_latest_excel():
    """
    Download the latest spreadsheet from gov.uk
    We are downloading the ods format due to issues with parsing the file using pandas/openpyxl
    This is a known problem when there is a chart in one of the tabs
    :return:
    """

    log.debug("Initialising Chrome.")
    try:
        # Initiate Chrome Driver
        time.sleep(2)
        browser = load_chrome_settings()
        time.sleep(2)
        browser.get("https://www.gov.uk/government/statistics/average-road-fuel-sales-and-stock-levels")
        time.sleep(2)
        data_format = 'Excel'
        download_link = browser.find_element(By.LINK_TEXT, "Official statistics in development on average road fuel sales, deliveries and stock levels (monthly data) – {}".format(data_format))
        time.sleep(5)
        href_link = download_link.get_attribute('href')  # getting the href to get the file name for easier local
        log.debug(f'{get_file_name(href_link)}')
        # processing
        log.info('File link {}'.format(href_link))
        browser.get(href_link)
        time.sleep(15)  # sleeping for 15 seconds to give enough time to download the file

        log.debug("Download Completed.")
        return href_link

    except Exception as e:
        log.error(e)
        log.error(sys.exc_info()[0])
        log.debug("Job Ended with Error!!!")
        return None


def download_weekly_road_fuel_prices_csv():
    """
    Download the latest pump prices from BEIS on gov uk
    :return:
    """
    log.debug("Initialising Chrome.")
    try:
        # Initiate Chrome Driver
        time.sleep(2)
        browser = load_chrome_settings()
        time.sleep(2)

        browser.get("https://www.gov.uk/government/statistics/weekly-road-fuel-prices")

        download_link = browser.find_element(By.PARTIAL_LINK_TEXT, "Weekly road fuel prices (CSV)")
        href_link = download_link.get_attribute('href')  # getting the href to get the file name for easier local
        # processing
        log.info('File link {}'.format(href_link))
        browser.get(href_link)
        time.sleep(15)  # sleeping for 15 seconds to give enough time to download the file

        log.debug("Download Completed.")
        return href_link

    except Exception as e:
        log.error(e)
        log.error(sys.exc_info()[0])
        log.debug("Job Ended with Error!!!")
        return None


def get_file_name(link):
    """
    Extract filename from href link
    :param link:
    :return:
    """
    file_name = link.split('/')[-1]
    return file_name


def clean_x(column):
    """
    Clean up column names to conform with our data standards
    :param column:
    :return:
    """
    print(column)
    column = str(column)
    column = column.lower()
    column = column.replace('%', "percent")
    column = re.sub(r'(?<=\[)[^]]+(?=\])', '', column)
    column = column.rstrip()
    column = column.lstrip()
    column = column.replace(']', "")
    column = column.replace('"', "")
    column = column.replace('/n', "")
    column = column.replace('\n', "")
    column = column.replace('[', "")
    column = column.replace('(', "")
    column = column.replace(')', "")
    column = column.replace(' ', "_")
    column = column.replace(',', "")
    column = column.replace('/', "_")
    column = column.replace(':', "_")
    column = column.replace('_____','')
    column = column.rstrip('_')

    return column


def extract_csv_files(excel_path):
    """
    Convert Excel tabs to csv files and upload to blob store
    :param excel_path:
    :return:
    """

    tab_dict = {
        'Main table - sales': {'skiprows': 6, 'name_part': 'sales'},  # ok
        'Main table - stock levels': {'skiprows': 6, 'name_part': 'stock_levels'},
        'Main table - deliveries': {'skiprows': 6, 'name_part': 'deliveries'},
    }

    excel_name_date = os.path.basename(excel_path).split("_")[0].replace(".", "")
    excel_name_date_obj = datetime.strptime(excel_name_date, '%Y%m%d')
    ddate = excel_name_date_obj.strftime(format_datetime)
    pdate = datetime.today().strftime(format_datetime)

    for tab in tab_dict.keys():
        # tab = tab.replace('_',' ')
        print("Working on {}".format(tab))
        skiprows = tab_dict[tab]['skiprows']

        name_part = tab_dict[tab]['name_part']
        df = pd.read_excel(excel_path, sheet_name=tab, skiprows=skiprows, engine=None)
        df.columns = df.iloc[0]
        df = df[1:]
        df.columns = [clean_x(x) for x in df.columns]
        columns = [x for x in list(df.columns) if x != 'nan']
        df['pdate'] = pdate
        df['ddate'] = ddate
        columns = ['ddate', 'pdate'] + columns
        df = df[columns]
        df = df[~df['weekday'].isna()]
        df = df.loc[df.apply(lambda x: not any([x[col] == 'Return to top of the page' for col in df.columns]), axis=1)]
        file_output_path = os.path.join(upload_folder, "oil-gasoline_diesel-beis_{}-{}.csv".format(name_part, excel_name_date))
        su.upload_to_database(df, f"oil-gasoline_diesel-beis_{name_part}-{excel_name_date}-")
        # df.to_csv(file_output_path, index=None)
        # upload_to_blob(file_path=file_output_path)
        log.info("Completed conversion and upload for {}".format(file_output_path))


def download_and_process_road_fuel_sales_and_stock_levels_files():
    """
    Orchestrate the data processing by downloading the latest Excel spreadsheet and uploading converted CSV files to blob
    :return:
    """

    href_link = download_latest_excel()

    if href_link is None:
        raise ValueError("Download failed")

    file_name = get_file_name(link=href_link)
    output_path = os.path.join(temp_path, file_name)

    log.info("Filename {} at {}".format(file_name, output_path))
    extract_csv_files(excel_path=output_path)


def download_and_process_weekly_road_fuel_prices():
    """
    Download and process data on weekly service station pump prices
    :return:
    """
    #
    href_link = download_weekly_road_fuel_prices_csv()
    file_name = get_file_name(link=href_link)
    # file_name = 'CSV_210322.csv'
    file_path = os.path.join(temp_path, file_name)

    df = pd.read_csv(file_path, skiprows=1, encoding='unicode_escape')
    columns = list(df.columns)
    columns = columns[:7]
    df = df[columns]

    new_columns = ['ddate', 'ulsp_pence_litre', 'ULSD_pence_litre', 'duty_rate_ulsp_pence_litre',
                   'duty_rate_ulsd_pence_litre', 'vat_ulsp_percentage_rate', 'vat_ulsd_percentage_rate']
    df.columns = new_columns

    pdate = datetime.today().strftime(format_datetime)

    df['pdate'] = pdate

    excel_name_date = pdate.replace('-', '').split(" ")[0]
    name_part = "weekly_uk_road_fuel_prices"
    file_output_path = os.path.join(upload_folder,
                                    "oil-gasoline_diesel-beis_{}-{}.csv".format(name_part, excel_name_date))

    df = df.iloc[1:, :]
    df = df.loc[df.apply(lambda x: not any([x[col] == 'Return to top of the page' for col in df.columns]), axis=1)]
    su.upload_to_database(df, f"oil-gasoline_diesel-beis_{name_part}-{excel_name_date}-")
    # df.to_csv(file_output_path, index=None)
    # upload_to_blob(file_path = file_output_path)
    log.info("Completed cleaning and upload for {}".format(file_output_path))


if __name__ == "__main__":
    if check_new_data_released():
        download_and_process_road_fuel_sales_and_stock_levels_files()
        download_and_process_weekly_road_fuel_prices()
    else:
        print('No new data released yet!')
