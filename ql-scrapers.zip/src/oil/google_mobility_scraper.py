import os
import ssl
import sys
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder

ssl._create_default_https_context = ssl._create_unverified_context  # SSL Certificate

file_url = 'https://www.gstatic.com/covid19/mobility/Global_Mobility_Report.csv'
format_datetime = '%y%m%d%H%M%S'
filename = 'Upload_OIL_GoogleMobility-'
bulk_uploader_folder = bulkUploaderFolder


def get_latest_ddate_from_db():
    query = '''
        SELECT max(ddate)
        FROM hive_metastore.dataengineering.oil_mobility_googlemobility
        AND IsActive = True
    '''
    return bo.get_data(query)


def save_to_csv(df, filename):
    filename_date = filename + datetime.today().strftime(format_datetime) + ".csv"
    filefullname = os.path.join(bulk_uploader_folder, filename_date)

    # df.to_csv(path_or_buf=filefullname, header=True, index=False)
    su.upload_to_database(df, filename)
    log.debug("CSV File Saved to ADI: {0}.".format(filefullname))


def scrape_google_mobility_data(url):
    df = pd.read_csv(url)
    return df


def get_diff(df_new, df_old, on_list):
    compare = df_new.merge(df_old, on=on_list, indicator=True, how='outer', suffixes=['_old', '_new'])
    df_added = compare[compare['_merge'] == 'left_only'].drop(columns='_merge')
    df_deleted = compare[compare['_merge'] == 'right_only'].drop(columns='_merge')
    df_no_change = compare[compare['_merge'] == 'both'].drop(columns='_merge')
    del compare
    return df_added, df_deleted, df_no_change


def cleansing_data(df):
    df.columns = ['country_region_code', 'country_region', 'sub_region_1', 'sub_region_2',
                  'metro_area', 'iso_3166_2_code', 'census_fips_code', 'place_id', 'ddate', 'retail_and_recreation',
                  'grocery_and_pharmacy', 'parks', 'transit_stations', 'workplaces', 'residential']
    df = df.drop(columns='place_id')

    df[['country_region_type', 'sub_region_1_type', 'sub_region_2_type', 'sub_region_2_type']] = \
        df[['country_region', 'sub_region_1', 'sub_region_2', 'metro_area']] \
            .transform(lambda x: np.where(x.isnull(), x, x.name))
    df['region_type'] = df.sub_region_2_type.fillna(df.sub_region_2_type).fillna(df.sub_region_1_type).fillna(
        df.country_region_type)
    df['region_name'] = df.metro_area.fillna(df.sub_region_2).fillna(df.sub_region_1).fillna(df.country_region)
    df['pdate'] = datetime.today().date()
    df = df[['ddate', 'region_type', 'region_name', 'country_region_code', 'iso_3166_2_code', 'country_region',
             'sub_region_1', 'sub_region_2', 'metro_area', 'retail_and_recreation', 'grocery_and_pharmacy',
             'parks', 'transit_stations', 'workplaces', 'residential', 'census_fips_code', 'pdate']]
    df = df.replace("'", "", regex=True).replace(",", "", regex=True)
    return df


def get_latest_data_only(df, column, days):
    data_cutoff_date = df[column].max() - timedelta(days=days)
    df = df[df[column] > data_cutoff_date]
    return df


def check_date_and_save(df):
    ddate_existing = pd.to_datetime(get_latest_ddate_from_db().iat[0, 0])
    ddate_latest = df['ddate'].max()
    if ddate_latest == ddate_existing:
        log.debug("No new data found on website, scraper stopped~~~")
    else:
        if ddate_existing == None:
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            log.debug("No data in database, start to scrape.")
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        else:
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            log.debug("New Google Mobility Indicator data found on the website")
            log.debug("The latest data point is " + str(ddate_latest))
            log.debug("Start to scrape.")

        df['ddate'] = pd.to_datetime(df['ddate'], format='%Y-%m-%d')
        df = get_latest_data_only(df, 'ddate', 5)

        save_to_csv(df, filename)


def main():
    try:
        log.debug("Env:" + env)

        log.debug("Read CSV file from website.")
        df = scrape_google_mobility_data(file_url)

        log.debug("Cleaning the downloaded file.")
        df = cleansing_data(df)

        log.debug("Check Pdate and export to csv.")
        check_date_and_save(df)
        log.debug("Job Completed.")
        return 0
    except Exception as e:
        log.error(e)
        log.debug("Job Ended with Error!!!")
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())
