import os
import io
import sys
import requests
import pandas as pd
from datetime import datetime, timedelta

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se


log = ag_log.get_log()
env = se.environment
bulkUploaderFolder = se.ingestion_folder
url = 'https://covid.ourworldindata.org/data/owid-covid-data.csv'

log.debug("Env:" + env)
s = requests.get(url).content

log.debug("Getting covid data table.")
df = pd.read_csv(io.StringIO(s.decode('utf-8')))
df.rename(columns={'date': 'PDate'}, inplace=True)
df['PDate'] = pd.to_datetime(df['PDate'])

log.debug("Limit number of days to be uploaded.")
if env == 'PROD':
    df = df[df['PDate'] >= datetime.today() - timedelta(days=45)]

df['location'] = df['location'].str.replace("'", '').replace(',', ';')

log.debug("Export the Data into CSV File.")
format_datetime = '%y%m%d%H%M%S'
filename = 'Upload_OIL_Covid-'
bulk_uploader_folder = bulkUploaderFolder

# filefullname = os.path.join(bulk_uploader_folder, filename + datetime.today().strftime(format_datetime) + ".csv")
# df.to_csv(path_or_buf=filefullname, header=True, index=False)

su.upload_to_database(df, filename)
log.debug("Job Completed.")
