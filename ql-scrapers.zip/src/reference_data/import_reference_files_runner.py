"""
This is a solution to ingest reference data into BlueOcean. The reference CSV files are located in the sub-folder
This file is response will for copying over any .CSV files from the sub folder to BlueOcean upload location
"""
import logging
import os.path
from ag_log import ag_log
from ag_data_access import data_upload
import pandas as pd
import dotenv


def copy_over_csv_files_to_bo_import_folder() -> None:
    environment = os.environ["environment"].upper()
    csv_files_folder = os.path.join(os.path.dirname(__file__), "data_files")
    for csv_file_name in os.listdir(csv_files_folder):
        csv_file_base_name = csv_file_name.split('.')[0]
        csv_file_abs_path = os.path.join(csv_files_folder, csv_file_name)
        logging.info(f"Found CSV file: {csv_file_abs_path}")
        df_reference = pd.read_csv(csv_file_abs_path)
        data_upload.upload_to_database(data=df_reference, filename_prefix=csv_file_base_name, env=environment,
                                       index=False)
    pass


if __name__ == "__main__":
    dotenv.load_dotenv(
        override=True)  # take environment variables from a privately managed .env file at the very root of the repo
    log = ag_log.get_log()
    logging.info(f"Begin {__file__}")
    copy_over_csv_files_to_bo_import_folder()
    logging.info(f"End {__file__}")
