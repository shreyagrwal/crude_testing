environment = 'UAT'
ingestion_folder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\BlueOceanBlobDataUploader\UAT\incoming'
trigger_ingestion_folder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\BlueOceanBlobDataUploader\UAT\incoming\trigger'
if environment == 'PROD':
    ingestion_folder = r'\\petroineos.local\dfs\BlueOcean\central\jobs\incoming'
    trigger_ingestion_folder = r'\\petroineos.local\dfs\BlueOcean\central\jobs\incoming\trigger'
