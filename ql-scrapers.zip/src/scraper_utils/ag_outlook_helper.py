import win32com.client as win32
from os import path


class AgOutlookHelper:

    def send_mail(toaddress, subject, body):

        outlook = win32.Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
        mail.To = toaddress
        mail.Subject = subject
        mail.HTMLBody = body

        mail.Send()



