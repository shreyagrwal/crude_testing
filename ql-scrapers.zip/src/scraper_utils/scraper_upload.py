import os
import random
import logging
import pandas as pd
from datetime import datetime
import src.scraper_utils.scraper_environment as se


log = logging.getLogger()


def upload_to_database(data: pd.DataFrame, filename_prefix: str, upload_destination: str = 'BO', index=False,
                       header=True, float_format=None, encoding: str = 'utf-8-sig', additional_locations=None):
    """Method to upload data to the correct database. Note: this function will save the dataframe to a csv file,
    in the correct format, to the required ingestion folder. The file must be a csv for ingestion.
    Parameters:
        data pd.DataFrame: Data to be uploaded to the database, in the form of a pandas dataframe
        filename_prefix str: The filename prefix of the file, this must map to the target db name
        to_csv_args dict: (Optional) the args used when saving the csv file - default '.to_csv(..., index=False)'
    Returns:
        None
    """

    parse_filename_prefix(filename_prefix)  # Check the validity of the filename prefix
    if not parse_data(data):                # Check the viability of the data for upload
        log.info(f'DataFrame for upload {filename_prefix} did not meet the requirements for upload, no data uploaded.')
        return None  # Do not upload data if it doesn't meet the requirements set out in parse_data(..)

    # Add the exact time to the end of the filename prefix
    exact_upload_date_time: str = datetime.today().strftime('%y%m%d%H%M%S')
    random_integer: str = str(random.randint(10000, 99999))  # Prevents files being overwritten when run in quick succession
    # During migration phase upload to ADI and to BO
    # Note ingestion_folder=BO
    save_locations = {
        'BO': os.path.join(se.ingestion_folder, f'{filename_prefix}{exact_upload_date_time}-{random_integer}.csv'),
        'TRIGGER': os.path.join(se.trigger_ingestion_folder, f'{filename_prefix}{exact_upload_date_time}-{random_integer}.csv'),
    }

    if additional_locations is None:
        additional_paths = []
    else:
        additional_paths = [
            os.path.join(loc, f'{filename_prefix}{exact_upload_date_time}-{random_integer}.csv')
            for loc in additional_locations
        ]

    if upload_destination == 'NONE':
        upload_paths = []
    elif upload_destination == 'ALL':
        upload_paths = [save_locations[x] for x in save_locations.keys()]
    else:
        upload_paths = [save_locations[upload_destination]]

    for save_file_path in upload_paths + additional_paths:
        log.info(f'Uploading file to: {save_file_path}')
        data.to_csv(save_file_path, index=index, header=header, float_format=float_format, encoding=encoding)
    pass


class InvalidFileNamePrefixException(Exception):
    """Raised when the filename prefix is not valid"""
    def __init__(self, filename_prefix: str):
        self.message = f"Invalid filename prefix: '{filename_prefix}'"
        super().__init__(self.message)


def parse_data(data: pd.DataFrame) -> bool:
    """Method to parse the data before upload. Purpose of the test is to make sure the data being uploaded if sensible,
    e.g., the data must not have shape 0 in either axis. If the data fails to meet the requirements then do not upload
    the data to the database. Important to set out strict fail conditions"""

    fail_conditions = [
        True if data.shape[0] == 0 else False,
    ]  # True indicates that we have NOT met the requirements for upload

    if any(fail_conditions):
        return False
    return True


def parse_filename_prefix(filename_prefix: str):
    """Method to check the filename_prefix supplied in a script. If the filename supplied is in adequate we cannot save
    the data to the upload folder so raise an issue"""
    if len(filename_prefix) <= 4:
        raise InvalidFileNamePrefixException(filename_prefix)

    invalid_chars = [' ', '.', ',']
    if any([True if bad_char in filename_prefix else False for bad_char in invalid_chars]):
        raise InvalidFileNamePrefixException(filename_prefix)
    pass


