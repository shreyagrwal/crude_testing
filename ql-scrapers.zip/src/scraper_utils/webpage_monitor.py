import ag_email.ag_email_helper as outlook
import pandas as pd
import requests
import time
import sys
from os import path
from lxml import html
from lxml import etree
from datetime import date
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from ag_log import ag_log

class WebsiteMonitor:

    email_from = 'charles.cai@petroineos.com'
    temp_folder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\RystadOilProduction\Scrapers\Temp\\'

    def __init__(self, email_from, switch_on = False):
        self.email_helper = outlook.AgEmailHelper()
        self.email_from = email_from
        self.switch_on = switch_on

    def scrape_page(self, url):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
        response = requests.get(url, headers=headers)
        return response.text

    def init_chrome(self):
        # Initiate Driver
        chrome_options = webdriver.ChromeOptions()
        #if sys.gettrace() is None:  # Check if it's in Debug model
            #chrome_options.add_argument('--headless')  # Otherwise headless Chrome
        chrome_options.add_experimental_option("useAutomationExtension", False)
        chrome_options.add_experimental_option("prefs", {
            "download.default_directory": r"c:\temp",
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "safebrowsing.enabled": True
        })
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("test-type")
        chrome_options.add_argument("start-maximized")
        chrome_options.add_argument("--js-flags=--expose-gc")
        chrome_options.add_argument("--enable-precise-memory-info")
        chrome_options.add_argument("--disable-popup-blocking")
        chrome_options.add_argument("--disable-default-apps")
        chrome_options.add_argument("--enable-automation")
        chrome_options.add_argument("test-type=browser")
        chrome_options.add_argument("disable-infobars")
        chrome_options.add_argument("--disable-extensions")

        self.browser = webdriver.Chrome(executable_path=".\\tools\\chromedriver.exe", options=chrome_options)
        #self.browser = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

    def close_chrome(self):
        if self.browser:
            self.browser.close()
            del self.browser

    def scrape_page_with_headless_chrome(self, url):
        self.browser.get(url)
        time.sleep(2)
        source = self.browser.page_source
        if "Certificate verification error" in source:
            continue_button = self.browser.find_element('xpath', '//*[@id="options"]/form[1]/input[5]')
            if continue_button:
                continue_button.click()
                time.sleep(2)
                source = self.browser.page_source
        return source

    def save_to_tmp(self, content, filename):
        with open(filename, 'w') as file:
            file.write(content)

    def diff(self, text1, text2):
        return text1 != text2

    def filter(self, content, xpath):
        tree = html.fromstring(content)
        list = tree.xpath(xpath)
        if len(list) == 0:
            self._alert_support("Warning: No Data Found")
        else:
            return etree.tostring(list[0]).decode("utf-8")

    def read_from_temp(self, file):
        if not path.exists(file):
            return
        with open(file, 'r') as content_file:
            content = content_file.read()
            return content

    def _alert_user(self, elements, previous):
        sub = "Webpage Change Alert - " + self.name
        body = "Changes have been detected in following website: " + self.url + "<br>"

        if elements:
            body = body + "<br>" + " New Data: " + elements + "<br>"
        else:
            self._alert_support("Warning: No elements found.")
            return

        if previous:
            body = body + "<br>" + " Old Data: " + previous + "<br>"
        if self.switch_on:
            self.email_helper.send_mail_with_embedded_images(self.email_from, self.emails, sub, body)
        self.email_helper.send_mail_with_embedded_images(self.email_from, self.email_from, sub, body)

    def _alert_user_newpage(self, elements):
        sub = "New Webpage Alert Setup Successfully - " + self.name
        body = "The following website monitor has been setup: " + self.url + "<br>"

        if elements:
            body = body + "<br>" + " Monitored Data: " + elements + "<br>"
        else:
            body = body + "<br>" + " Monitored Data is empty"

        if self.switch_on:
            self.email_helper.send_mail_with_embedded_images(self.email_from, self.emails, sub, body)
        self.email_helper.send_mail_with_embedded_images(self.email_from, self.email_from, sub, body)

    def _alert_user_error(self, e):
        sub = "New Webpage Alert Setup Failed - " + self.name
        body = "The following website monitor failed: " + self.url + "<br>"

        body = body + " Error Message: " + e + "<br>"

        if self.switch_on:
            self.email_helper.send_mail_with_embedded_images(self.email_from, self.emails, sub, body)

        self.email_helper.send_mail_with_embedded_images(self.email_from, self.email_from, sub, body)

    def _alert_support(self, e):
        sub = "Error occurred - " + self.name
        body = "The following website monitor failed: " + self.url + "<br>"

        body = body + " Error Message: " + e + "<br>"

        self.email_helper.send_mail_with_embedded_images(self.email_from, self.email_from, sub, body)

    def monitor(self, xpath):
        # #content = self.scrape_page(self.url)
        # content = self.scrape_page_with_headless_chrome(self.url)
        # elements = self.filter(content, self.xpath)
        self.browser.get(self.url)
        time.sleep(2)
        elements = self.browser.find_element(By.XPATH, xpath).text
        print('\nCurrent date is = ', elements)
        print()
        self._diff_data_and_alert_user(elements)

    def _diff_data_and_alert_user(self, elements):
        tmpfile = self.temp_folder + self.name + ".tmp"
        if not path.exists(tmpfile):
            self.save_to_tmp(elements, tmpfile)
            self._alert_user_newpage(elements)
        previous = self.read_from_temp(tmpfile)
        changes = self.diff(elements, previous)
        if not elements:
            self._alert_support("Warning: No elements found.")
            return
        
        if changes:
            self._alert_user(elements, previous)

            self.save_to_tmp(elements, tmpfile)

    def monitor_one_webpage(self, df, i):
        self.name = df['Name'][i]
        self.url = df['Url'][i]
        self.emails = df['Email'][i]
        self.xpath = df['Xpath'][i]
        print("Name, Url, Email, Xpath: " + self.name + "," + self.url + "," + self.emails + "," + self.xpath)
        if self.name and self.url and self.emails and self.xpath:
            try:
                self.monitor(self.xpath)
            except Exception as e:
                print(e)
                self._diff_data_and_alert_user(e)

    def run_monitor(self, config_file):
        df = pd.read_excel(config_file, sheet_name='Websites', engine='openpyxl')
        self.scheduled_monitor(config_file, df)

    def monitor_once(self, config_file):
        log = ag_log.get_log()
        try:
            self.init_chrome()
            df = pd.read_excel(config_file, sheet_name='Websites', engine='openpyxl')
            for i in df.index:
                self.monitor_one_webpage(df, i)
            print("Done one iteration!")
            self.close_chrome()
        except Exception as e:
            log.error(e)
            exit(1)
            self.close_chrome()

    def scheduled_monitor(self, config_file):
        while date.today().weekday() < 5:
            self.monitor_once(config_file)
            time.sleep(300)