import logging
import os
import traceback
from ag_email import ag_email_helper as aeh
import dotenv

dotenv.load_dotenv()  # take environment variables from a privately managed .env file at the very root of the repo


#
# Demonstrates
#   The concept of using environment variables to avoid hard coding
#   The email body in this example references the following environment variables
#       - environment: DEV or PROD . This is defined in the Variables tab of the parent folder of the Active Batch job
#       - DEVOPS_VERSION: The version that matches the display number of the Azure Devops CI/CD build. This is automatically initialized within the Active Batch job when initactivebatch.ps1 is invoked
#       - ql_scraper_demo_email_recipients: The list of recipients. This environment variable should be configured in the Variables tab of the current job
#   Using a personal .env file to manage environment variables during local development. This file should reside at the very root of your project
#   Reading the .env file in the main block
#   When cofiguring the Active Batch job, the environment variable 'ql_scraper_demo_email_recipients' should be configured using the Job Variables tab
#

def send_dummy_report(recipients: str):
    email_sender = aeh.AgEmailHelper()
    folder = os.path.dirname(__file__)
    environment = os.environ["environment"]
    computer_name = os.environ["COMPUTERNAME"]
    version=os.environ["DEVOPS_VERSION"]
    dummy_body = f"Dummy body from {__file__} <hr/><small>environment=({environment}) </small> <br/> <small>COMPUTERNAME={computer_name}</small><br/> <small>Version={version}</small>"
    filename = os.path.basename(__file__)
    dummy_subject = f"ql-scraper-Dummy email from  from {filename} ({environment})"

    email_sender.send_mail(from_="saurabhdasgupta@petroineos.co.uk", to_=recipients, body=dummy_body,
                           subject=dummy_subject)
    print(f"Email was sent to {recipients}")


if __name__ == "__main__":
    try:
        print("This is a demo Python script")
        print("Going to initialize logging")
        logging.basicConfig(level=logging.INFO)
        logging.info("Logging was initialized")
        recipients = os.environ.get("ql_scraper_demo_email_recipients")
        if recipients is None:
            raise Exception("Could not find environment variable 'ql_scraper_demo_email_recipients'")
        pass
        send_dummy_report(recipients=recipients)
    except Exception as err:
        #
        #the following does not produce a sensible error message
        #E.g. When the environment variable environment was not set, then the error message was as follows:
        #WARNING:root:Found error in the file C:\Petroineos\AzureDevops\ql-reports\dev\blah\1.0.2b.23470\src\saturn\simple_email_demo.py, 'environment'
        #
        logging.warning(f"Found error in the file {__file__}, {str(err)}")
        logging.error(f"Stack trace is {traceback.format_exc()}")
        exit(1) #Important! If we do not return non-zero, then the caller process (Active Batch as an example) will never know that the child process failed
        pass
