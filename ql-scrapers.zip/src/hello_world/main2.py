import traceback
import logging
import os
import configparser
import dotenv
from ag_email import ag_email_helper as aeh


def create_config()->configparser.ConfigParser:
    config_parser=configparser.ConfigParser(os.environ,interpolation=configparser.ExtendedInterpolation())
    environment=os.environ["environment"]
    ini_file=os.path.join(os.path.dirname(__file__), f"main2.{environment}.ini")
    logging.info(f"Going to read INI from the file {ini_file}")
    config_parser.read(ini_file)
    logging.info(f"End-Going to read INI from the file {ini_file}")
    return config_parser

def send_dummy_report(config: configparser.ConfigParser)->None:
    recipients=config.get("demosection1","recipients")
    if recipients is None:
        raise Exception("Could not find environment variable 'ql_scraper_demo_email_recipients'")
    pass
    logging.info(f"Email will be set to {recipients}")
    email_sender = aeh.AgEmailHelper()
    folder = os.path.dirname(__file__)
    environment = os.environ["environment"]
    computer_name = os.environ["COMPUTERNAME"]
    version=os.environ["DEVOPS_VERSION"]
    dummy_body = f"Dummy body from {__file__} <br/>Demonstrates how to read from INI file<hr/><small>environment=({environment}) </small> <br/> <small>COMPUTERNAME={computer_name}</small><br/> <small>Version={version}</small>"
    filename = os.path.basename(__file__)
    dummy_subject = f"ql-scraper-Dummy email from  from {filename} ({environment})"

    email_sender.send_mail(from_="saurabhdasgupta@petroineos.co.uk", to_=recipients, body=dummy_body,
                           subject=dummy_subject)
    print(f"Email was sent to {recipients}")

    pass

if __name__ == "__main__":
    try:
        dotenv.load_dotenv()  # take environment variables from a privately managed .env file at the very root of the repo
        print("This is a demo Python script")
        print("Going to initialize logging")
        logging.basicConfig(level=logging.INFO)
        logging.info("Logging was initialized")
        config=create_config()
        logging.info("------------------------------")
        logging.info("Value of config section demosection1:key1='{value}'".format(value=config.get("demosection1","key1")))
        logging.info("Value of config section demosection1:key2='{value}'".format(value=config.get("demosection1","key2")))
        logging.info("Value of config section demosection1:secret1='{value}'".format(value=config.get("demosection1","secret1")))
        logging.info("------------------------------")
        logging.info("Value of config section demosection2:another_key1='{value}'".format(value=config.get("demosection2","another_key1")))
        logging.info("Value of config section demosection2:another_key2='{value}'".format(value=config.get("demosection2","another_key2")))
        logging.info("Value of config section demosection2:another_secret1='{value}'".format(value=config.get("demosection2","another_secret1")))
        logging.info("------------------------------")
        
        send_dummy_report(config=config)
    except Exception as err:
        logging.warning(f"Found error in the file {__file__}, {str(err)}")
        logging.error(f"Stack trace is {traceback.format_exc()}")
        exit(1) #Important! If we do not return non-zero, then the caller process (Active Batch as an example) will never know that the child process failed
        pass
