import os
import sys
import time
import shutil
import dotenv
import argparse
import datetime
import pandas as pd
from selenium import webdriver

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_secrets import SecretsClient
from ag_data_access import data_upload as du


dotenv.load_dotenv()
env = os.environ.get('environment', 'UAT')
icis_secret = SecretsClient().get_secret(name="icisedge_dong")

BASE_URL = r"https://lngedge.icis.com/my-downloads"
DOWNLOAD_FOLDER = r"\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\LNGModelData\lng_sendout\ICIS tracking download"


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": DOWNLOAD_FOLDER,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")
    browser = webdriver.Chrome(executable_path="..\\tools\\chromedriver.exe", chrome_options=chrome_options)
    return browser


def login_to_website(browser):
    browser.get(BASE_URL)  # go to website

    time.sleep(1)
    login_username_field = r"/html/body/div[3]/div[1]/div/div/div[2]/form/fieldset/div[1]/input"
    browser.find_element('xpath', login_username_field).send_keys(icis_secret.username)
    time.sleep(0.1)

    login_password_field = r"/html/body/div[3]/div[1]/div/div/div[2]/form/fieldset/div[2]/input"
    browser.find_element('xpath', login_password_field).send_keys(icis_secret.password)
    time.sleep(0.1)

    login_button = r"/html/body/div[3]/div[1]/div/div/div[2]/form/fieldset/div[4]/div[1]/button[1]"
    browser.find_element('xpath', login_button).click()
    time.sleep(30)


def download_cargo_tracking_file(browser):
    download_button = r"/html/body/ui-view/ui-view/div/div/div[3]/div[2]/div[2]/a"
    browser.find_element('xpath', download_button).click()
    time.sleep(30)
    pass


def process_icis_tracking_file():
    filepath = os.path.join(DOWNLOAD_FOLDER, "LNGEdge_EuHubReport.xlsx")
    data = pd.read_excel(filepath)
    save_timestamp = pd.Timestamp.now().strftime('%Y-%m-%d %H%M%S')
    shutil.move(filepath, os.path.join(DOWNLOAD_FOLDER, rf"archive\icis_euhub_report-{save_timestamp}.xlsx"))
    return data


def upload_data_to_blueocean(data):
    data['PDateTime'] = pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
    data.columns = [''.join([x.capitalize() for x in column.split(' ')]) for column in data.columns]
    data['Eta'] = pd.to_datetime(data['Eta']).dt.strftime('%Y-%m-%d')
    data['DepartureDate'] = pd.to_datetime(data['DepartureDate']).dt.strftime('%Y-%m-%d')
    data = data.rename(columns={'Pdatetime': 'PDateTime'})
    columns = [
        "PDateTime", "Vessel", "DestinationCountry", "DestinationPort", "Eta", "Capacity",
        "Laden", "OriginPort", "OriginCountry", "DepartureDate", "PredictionBasis"
    ]
    du.upload_to_database(data[columns], 'Upload_lng_icis_cargo_tracking-', env=env)
    pass


def main():
    log.info("Initiate Chrome Driver.")
    browser = load_chrome_settings()

    log.info("Login to ICIS Edge website.")
    login_to_website(browser)

    log.info("Download Raw Tracking file.")
    download_cargo_tracking_file(browser)

    log.info('Processing raw file')
    dataframe = process_icis_tracking_file()

    log.info('Transform and upload to blueocean')
    upload_data_to_blueocean(dataframe)
    pass


if __name__ == '__main__':
    log = ag_log.get_log()
    main()
    pass

