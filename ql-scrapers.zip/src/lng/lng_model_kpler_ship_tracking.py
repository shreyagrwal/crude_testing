import os
import sys
import datetime

import numpy as np
import xlsxwriter
import pandas as pd
from fuzzywuzzy import fuzz
from datetime import timedelta
import matplotlib.pyplot as plt

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_data_access import blueocean_access as bo

pd.set_option('display.max_colwidth', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.expand_frame_repr', False)

data_dir = r'\\petroineos.local\DFS\User Home Drive\bobbyhemming\Documents\LNG Model'
ICIS_FEATURES = [
    'Vessel name', 'IMO', 'Voyage status', 'Cargo Id', 'Capacity(cubic metres of LNG)',
    'Mass at destination(tonnes)', 'Volume at destination(cubic metres LNG)', 'Cargo origin port',
    'Cargo origin country', 'Vessel departureport', 'Vessel departurecountry', 'Vessel departurepier',
    'Departure (UTC)', 'Destinationprediction basis', 'Cargo destinationport', 'Cargo destinationcountry',
    'Vessel destination port', 'Vessel destination country', 'Arrival (UTC)', 'Estimated arrivalat dest',
    'Is re-export', 'Cargo origin departure time (UTC)', 'Cargo destination arrival time (UTC)', 'Is Partial',
    'Is STS'
]

"""
            SELECT 
                concat(int(voyage_id), int(trade_id))
                vessel_name as 'Vessel Name', 
                int(voyage_id) as voyage_id,
                int(vessel_id) as IMO,
                trade_link_1_seller_name as Seller,
                trade_link_1_buyer_name as Buyer,
                origin_country_name as 'Cargo origin country', 
                origin_location_name as 'Cargo origin port', 
                destination_country_name as Cargo destination country,
                destination_location_name as 'Cargo destination port',
                cargo_origin_cubic_meters,
                cargo_destination_cubic_meters/(0.455*160000) as 'Mass at destination(tonnes)', 
                origin_reload_sts_partial,
                voyage_start as 'Cargo origin departure time (UTC)', 
                voyage_end as 'Cargo destination arrival time (UTC)', status as 'Voyage status', 
                destination_reload_sts_partial, pdate
            FROM workspace.bobbyhemming.lng_kpler_tradesdaily 
            WHERE IsActive = True 
            ORDER BY vessel_name, voyage_start DESC
        """


KPLER_RENAME = {
    'status': 'Voyage status',
    'vessel_name': 'Vessel name',
    'cargo_destination_cubic_meters': 'Volume at destination(cubic metres LNG)',
    'origin_location_name': 'Cargo origin port',
    'origin_country_name': 'Cargo origin country',
    'voyage_start': 'Departure (UTC)',
    'voyage_end': 'Arrival (UTC)',
    'destination_country_name': 'Cargo destinationcountry',
    'destination_location_name': 'Cargo destinationport',
    'destination_reload_sts_partial': 'Is Partial'
}
ICIS_RENAME = {
    'Cargo origin departure time (UTC)': 'Departure (UTC)',
    'Cargo destination arrival time (UTC)': 'Arrival (UTC)',
    '': 'Mass at destination(tonnes)'

}

subset_cols = [
            'Vessel name', 'Voyage status', 'Volume at destination(cubic metres LNG)', 'Cargo origin port',
            'Cargo origin country', 'Departure (UTC)', 'Arrival (UTC)',  'Cargo destinationport',
            'Cargo destinationcountry', 'DepMonth', 'ArrMonth', 'Cargoes']


class LNGHelperFunctions:

    @staticmethod
    def get_kpler_trades_europe():
        query = """
            SELECT int(trade_id) as trade_id, vessel_name, int(voyage_id) as voyage_id, voyage_start, voyage_end, status, 
                continent_origin_name, origin_country_name, origin_location_name, 
                destination_country_name, destination_location_name, cargo_origin_cubic_meters,
                cargo_destination_cubic_meters, origin_reload_sts_partial, 
                destination_reload_sts_partial, pdate
            FROM workspace.bobbyhemming.lng_kpler_tradesdaily 
            WHERE IsActive = True
            and YEAR(voyage_start) in (2017, 2018, 2019, 2020, 2021)
            ORDER BY vessel_name, voyage_start DESC
        """

        data = bo.get_data(query).rename(columns=KPLER_RENAME)

        data['Volume at destination(cubic metres LNG)'] = data['Volume at destination(cubic metres LNG)'] - 2000

        data = data[data['Volume at destination(cubic metres LNG)'] >= 160000 * 0.2]
        data['Departure (UTC)'] = pd.to_datetime(data['Departure (UTC)'], format='%Y-%m-%d %H:%M:%S')
        data['Arrival (UTC)'] = pd.to_datetime(data['Arrival (UTC)'], format='%Y-%m-%d %H:%M:%S')
        data['DepMonth'] = data['Departure (UTC)'].dt.strftime('%Y-%m')
        data['ArrMonth'] = data['Arrival (UTC)'].dt.strftime('%Y-%m')
        data['voyage_days_duration'] = (data['Arrival (UTC)'] - data['Departure (UTC)']).dt.days

        # data['Volume at destination(cubic metres LNG)'] = data.apply(lambda x: x['Volume at destination(cubic metres LNG)'] - 200*x['voyage_days_duration'], axis=1)
        # data['Volume at destination(cubic metres LNG)'] = data.apply(lambda x: x['Volume at destination(cubic metres LNG)'] + 1000 if x['Arrival (UTC)'] >= datetime.datetime(year=2020, month=6, day=1) else x['Volume at destination(cubic metres LNG)'], axis=1)
        data['Cargoes'] = data['Volume at destination(cubic metres LNG)'] / 160000
        return data

    @staticmethod
    def get_icis_tracking_europe(filename, target_cols=None):
        europe_countries = [
            'Belgium', 'France', 'Lithuania', 'Norway', 'Portugal', 'Russia', 'Spain', 'Turkey',
            'United Kingdom'
        ]
        if not target_cols:
            target_cols = ICIS_FEATURES
        filepath = os.path.join(data_dir, filename)
        data = pd.read_csv(filepath)
        data = data[data['Cargo origin port'] == 'Yamal LNG']
        data.columns = [col.replace('\n', '').replace('\r', '') for col in data.columns]
        # print(data.columns)
        data = data.rename(columns=ICIS_RENAME)
        # data[data['Cargo destination country'].isna()]['Cargo destination country'] = ''
        # data[data['Cargo origin country'].isna()]['Cargo origin country'] = ''
        data['Departure (UTC)'] = pd.to_datetime(data['Departure (UTC)'], format='%d %b %Y %H:%M:%S')
        # 2017, 2018, 2019
        data = data[
            (datetime.datetime(2017, 1, 1) <= data['Departure (UTC)']) &
            (data['Departure (UTC)'] < datetime.datetime(2022, 1, 1))
        ]
        data['Arrival (UTC)'] = pd.to_datetime(data['Arrival (UTC)'], format='%d %b %Y %H:%M:%S')
        data['Volume at destination(cubic metres LNG)'] = data['Mass at destination (tonnes)']/0.455
        data = data[data['Volume at destination(cubic metres LNG)'] >= 160000 * 0.2]
        data['Cargo destinationcountry'] = data['Cargo destination country']
        data['Cargo destinationport'] = data['Cargo destination port']
        data['DepMonth'] = data['Departure (UTC)'].dt.strftime('%Y-%m')
        data['ArrMonth'] = data['Arrival (UTC)'].dt.strftime('%Y-%m')
        data['Cargoes'] = data['Volume at destination(cubic metres LNG)'] / 160000
        # data = self.data_cleaning(data)
        return data

    @staticmethod
    def get_kpler_trades():
        query = """
            SELECT vessel_name, int(voyage_id) as voyage_id, voyage_start, voyage_end, status, 
                continent_origin_name, origin_country_name, origin_location_name, 
                destination_country_name, destination_location_name, cargo_origin_cubic_meters,
                cargo_destination_cubic_meters, origin_reload_sts_partial, 
                destination_reload_sts_partial, pdate
            FROM workspace.bobbyhemming.lng_kpler_tradesdaily 
            WHERE IsActive = True 
            ORDER BY vessel_name, voyage_start DESC
        """

        data = bo.get_data(query).rename(columns=KPLER_RENAME)
        data = data    # .drop_duplicates('voyage_id')
        data['Volume at destination(cubic metres LNG)'] = data['Volume at destination(cubic metres LNG)'] - 2000

        data = data[data['Volume at destination(cubic metres LNG)'] >= 160000 * 0.2]
        data['Departure (UTC)'] = pd.to_datetime(data['Departure (UTC)'], format='%Y-%m-%d %H:%M:%S')
        data['Arrival (UTC)'] = pd.to_datetime(data['Arrival (UTC)'], format='%Y-%m-%d %H:%M:%S')
        data['DepMonth'] = data['Departure (UTC)'].dt.strftime('%Y-%m')
        data['ArrMonth'] = data['Arrival (UTC)'].dt.strftime('%Y-%m')
        data['voyage_days_duration'] = (data['Arrival (UTC)'] - data['Departure (UTC)']).dt.days

        # data['Volume at destination(cubic metres LNG)'] = data.apply(lambda x: x['Volume at destination(cubic metres LNG)'] - 200*x['voyage_days_duration'], axis=1)
        # data['Volume at destination(cubic metres LNG)'] = data.apply(lambda x: x['Volume at destination(cubic metres LNG)'] + 1000 if x['Arrival (UTC)'] >= datetime.datetime(year=2020, month=6, day=1) else x['Volume at destination(cubic metres LNG)'], axis=1)
        data['Cargoes'] = data['Volume at destination(cubic metres LNG)'] / 160000
        return data

    @staticmethod
    def get_icis_tracking(filename, target_cols=None):
        if not target_cols:
            target_cols = ICIS_FEATURES
        filepath = os.path.join(data_dir, filename)
        data = pd.read_csv(filepath)
        data.columns = [col.replace('\n', '').replace('\r', '') for col in data.columns]
        # print(data.columns)
        data = data.rename(columns=ICIS_RENAME)
        # data[data['Cargo destination country'].isna()]['Cargo destination country'] = ''
        # data[data['Cargo origin country'].isna()]['Cargo origin country'] = ''
        data['Departure (UTC)'] = pd.to_datetime(data['Departure (UTC)'], format='%d %b %Y %H:%M:%S')
        data['Arrival (UTC)'] = pd.to_datetime(data['Arrival (UTC)'], format='%d %b %Y %H:%M:%S')
        data['Volume at destination(cubic metres LNG)'] = data['Mass at destination (tonnes)']/0.455
        data = data[data['Volume at destination(cubic metres LNG)'] >= 160000 * 0.2]
        data['Cargo destinationcountry'] = data['Cargo destination country']
        data['Cargo destinationport'] = data['Cargo destination port']
        data['DepMonth'] = data['Departure (UTC)'].dt.strftime('%Y-%m')
        data['ArrMonth'] = data['Arrival (UTC)'].dt.strftime('%Y-%m')
        data['Cargoes'] = data['Volume at destination(cubic metres LNG)'] / 160000
        # data = self.data_cleaning(data)
        return data

    @staticmethod
    def data_cleaning(data):
        # data['Vessel name'] = data['Vessel name'].apply(lambda x: x.strip())
        # data['Cargo origin port'] = data['Cargo origin port'].apply(lambda x: x.strip().lower())
        # data['Cargo destinationcountry'] = data['Cargo destinationcountry'].apply(lambda x: x.strip())
        data['Cargo origin country'] = data['Cargo origin country'].apply(lambda x: x.replace('Russian Federation', 'Russia'))
        data['Cargo destinationcountry'] = data['Cargo destinationcountry'].apply(lambda x: x.replace(', Province of China', ''))
        data['Cargo origin port'] = data['Cargo origin port'].apply(lambda x: x.replace('Lumut I', 'Lumut'))
        return data

    @staticmethod
    def select(data, source, vessel='Seri Alam', date_from=datetime.datetime(2017, 11, 15),
               date_to=datetime.datetime(2018, 3, 15), min_volume=0.2):
        data = data[(data['Departure (UTC)'] >= date_from) & (data['Departure (UTC)'] <= date_to)]
        # data = data[data['Vessel name'] == vessel]
        data.insert(0, 'Source', source)
        data = data[data['Volume at destination(cubic metres LNG)'] >= 160000*min_volume]
        data['id'] = data['Source'] + '-' + data.index.astype(str)
        return data

    @staticmethod
    def differences(data):
        data[''] = ''
        data['Delta Departure'] = (data['Departure (UTC)_icis'] - data['Departure (UTC)_kpler']).dt.days
        data['Delta Arrival'] = (data['Arrival (UTC)_icis'] - data['Arrival (UTC)_kpler']).dt.days
        data['Delta Volume'] = data['Volume at destination(cubic metres LNG)_icis']/data['Volume at destination(cubic metres LNG)_kpler']
        data['Delta Origin Port'] = data.apply(lambda x: fuzz.partial_ratio(x['Cargo origin port_icis'], x['Cargo origin port_kpler']), axis=1)
        data['Delta Destination Port'] = data.apply(lambda x: fuzz.partial_ratio(x['Cargo destinationport_icis'], x['Cargo destinationport_kpler']), axis=1)
        return data

    def compare(self, df_i, df_k, days=3, days_a=3):
        rows = []
        missed_kpler = []
        df_i = self.data_cleaning(df_i)
        df_k = self.data_cleaning(df_k)
        matches = df_i.copy(deep=True)
        for index, voyage in df_k.iterrows():
            start, end = voyage['Departure (UTC)'] - timedelta(days=days), voyage['Departure (UTC)'] + timedelta(days=days)
            start_a, end_a = voyage['Arrival (UTC)'] - timedelta(days=days_a), voyage['Arrival (UTC)'] + timedelta(days=days_a)
            vessel_name = voyage['Vessel name']
            destination_country = voyage['Cargo destinationcountry']
            origin_port = voyage['Cargo origin port']

            matches['Match'] = \
                (
                        ((matches['Departure (UTC)'] >= start) & (matches['Departure (UTC)'] <= end)) |
                        ((matches['Arrival (UTC)'] >= start_a) & (matches['Arrival (UTC)'] <= end_a))
                ) & \
                (matches['Vessel name'].apply(lambda x: x.lower()) == vessel_name.lower()) & \
                (matches['Cargo origin country'].apply(lambda x: x.lower()) == voyage['Cargo origin country'].lower()) & \
                (matches['Cargo destinationcountry'].apply(lambda x: x.lower()) == destination_country.lower())  # (matches['Cargo origin port'] == origin_port) & \

            m = matches[matches['Match']]
            m.columns = [col+'_icis' for col in m.columns]
            v = pd.DataFrame([voyage.tolist()], columns=voyage.index)
            v.columns = [col + '_kpler' for col in v.columns]
            if 0 < len(m) < 2:
                rows.append(pd.concat([m, v.set_index(m.index)], axis=1))
                # matches = matches.drop(m.index)
            elif len(m) >= 2:
                rows.append(pd.concat([m.iloc[[0]], v.set_index(m.iloc[[0]].index)], axis=1))
                matches.drop(m.iloc[[0]].index)
                print('\nMerging multiple!!!!', start, end)
                print(m[m['Vessel name_icis'] == vessel_name])
                # raise ValueError('Number of days either side is too high')
            else:
                missed_kpler.append(v)
                # print('\nPOTENTIAL MISMATCH!!!!', start, end)
                # print('ICIS: Empty DataFrame')
                # print('KPLER: ', v[v['Vessel name_kpler'] == vessel_name])
                # print('\n')

        final = pd.concat(rows)
        print(final.head(), '\n', final.shape)
        final = self.differences(final)
        missed_kpler = pd.concat(missed_kpler)
        missed_icis = df_i[~df_i['id'].isin(final['id_icis'])]

        w = pd.ExcelWriter(os.path.join(data_dir, "icis_kpler_discrepancies2.xlsx"),  mode="w", engine="xlsxwriter")
        final.to_excel(w, sheet_name='icis_kpler_comparison')
        missed_kpler.to_excel(w, sheet_name='missing_kpler')
        missed_icis.to_excel(w, sheet_name='missing_icis')
        w.close()
        print(missed_kpler.head(), '\n', missed_kpler.shape)
        print(missed_icis.head(), '\n', missed_icis.shape)
        exit()

    def main(self):
        cols = [
            'Vessel name', 'Voyage status', 'Volume at destination(cubic metres LNG)', 'Cargo origin port',
            'Cargo origin country', 'Departure (UTC)', 'Arrival (UTC)', 'Cargo destinationport', 'Cargo destinationcountry',
            'Is Partial', 'DepMonth', 'ArrMonth', 'Cargoes'
        ]
        df_kpler = self.get_kpler_trades()[cols]
        df_icis = self.get_icis_tracking('icis_shiptracking_full.csv')[cols]
        # print((list(df_icis.columns)))
        # print((list(df_kpler.columns)))

        df_icis = self.select(df_icis, source='ICIS')
        df_kpler = self.select(df_kpler, source='Kpler')

        w = pd.ExcelWriter(os.path.join(data_dir, "lng_months_view2.xlsx"), mode="w", engine="xlsxwriter")
        df_kpler.to_excel(w, sheet_name='kpler')
        df_icis.to_excel(w, sheet_name='icis')
        w.close()

        # self.compare(df_icis, df_kpler)
        pass

    @staticmethod
    def is_within_number_of_days(t1, t2, days=1):
        return t1 - timedelta(days=days) <= t2 <= t1 - timedelta(days=days)

    @staticmethod
    def aggregate_cargoes(x):
        row = {
            # 'Country': x['Cargo destinationcountry'].iloc[0],
            'Count': len(x),
            'Cargoes': sum(x['Cargoes'])
        }
        return pd.Series(row)

    def balances(self, target):
        cols = [
            'Vessel name', 'Voyage status', 'Volume at destination(cubic metres LNG)', 'Cargo origin port',
            'Cargo origin country', 'Departure (UTC)', 'Arrival (UTC)', 'Cargo destinationport', 'Cargo destinationcountry',
            'Is Partial', 'DepMonth', 'ArrMonth', 'Cargoes'
        ]
        df_kpler = self.get_kpler_trades()[cols]
        df_kpler = df_kpler.drop_duplicates(subset=subset_cols)

        df_icis = self.get_icis_tracking('icis_shiptracking_full.csv')[cols]

        df_monthly_kpler = df_kpler.groupby(by=target).apply(lambda x: self.aggregate_cargoes(x))
        df_monthly_icis = df_icis.groupby(by=target).apply(lambda x: self.aggregate_cargoes(x))
        df = pd.merge(df_monthly_kpler, df_monthly_icis, how='inner', left_index=True, right_index=True)
        df = df.drop(index=['2012-01', '2023-07', '2023-08'])

        df['diff_x'] = df.apply(lambda x: 100*np.absolute(x['Cargoes_x']-x['Cargoes_y'])/x['Cargoes_x'], axis=1)
        df['diff_y'] = df.apply(lambda x: 100*np.absolute(x['Cargoes_x']-x['Cargoes_y'])/x['Cargoes_y'], axis=1)
        df['rolling_cargoes_3m_x'] = df['Cargoes_x'].rolling(3).mean()
        df['rolling_cargoes_3m_y'] = df['Cargoes_y'].rolling(3).mean()

        df.columns = [col.replace('x', 'kpler').replace('y', 'icis') for col in df.columns]
        df['diff'] = df['rolling_cargoes_3m_kpler'] - df['rolling_cargoes_3m_icis']
        df['diff (%kpler)'] = 100*df['diff']/df['rolling_cargoes_3m_kpler']
        df['rolling_diff'] = df['diff'].rolling(3).mean()
        df['cum_diff'] = df['diff'].cumsum()
        df['cum_rolling_diff'] = df['rolling_diff'].cumsum()

        return df
        # df.to_csv('temp.csv')

    def balances_europe(self, target):
        cols = ['trade_id', 'voyage_id',
            'Vessel name', 'Voyage status', 'Volume at destination(cubic metres LNG)', 'Cargo origin port',
            'Cargo origin country', 'Departure (UTC)', 'Arrival (UTC)', 'Cargo destinationport', 'Cargo destinationcountry',
            'Is Partial', 'DepMonth', 'ArrMonth', 'Cargoes'
        ]
        df_kpler = self.get_kpler_trades_europe()[cols]
        # df_kpler = df_kpler.drop_duplicates(subset=subset_cols)
        df_kpler = df_kpler[df_kpler.duplicated(subset_cols, keep=False)]
        df_kpler.to_csv(os.path.join(data_dir, 'temp0.csv'))
        exit()

        df_icis = self.get_icis_tracking_europe('icis_shiptracking_full.csv')[cols]
        df_icis.to_csv(os.path.join(data_dir, 'temp1.csv'))

        df_monthly_kpler = df_kpler.groupby(by=target).apply(lambda x: self.aggregate_cargoes(x))
        df_monthly_icis = df_icis.groupby(by=target).apply(lambda x: self.aggregate_cargoes(x))
        exit()


        df = pd.merge(df_monthly_kpler, df_monthly_icis, how='inner', left_index=True, right_index=True)
        # df = df.drop(index=['2012-01', '2023-07', '2023-08'])

        df['diff_x'] = df.apply(lambda x: 100*np.absolute(x['Cargoes_x']-x['Cargoes_y'])/x['Cargoes_x'], axis=1)
        df['diff_y'] = df.apply(lambda x: 100*np.absolute(x['Cargoes_x']-x['Cargoes_y'])/x['Cargoes_y'], axis=1)
        df['rolling_cargoes_3m_x'] = df['Cargoes_x'].rolling(3).mean()
        df['rolling_cargoes_3m_y'] = df['Cargoes_y'].rolling(3).mean()

        df.columns = [col.replace('x', 'kpler').replace('y', 'icis') for col in df.columns]
        df['diff'] = df['rolling_cargoes_3m_kpler'] - df['rolling_cargoes_3m_icis']
        df['diff (%kpler)'] = 100*df['diff']/df['rolling_cargoes_3m_kpler']
        df['rolling_diff'] = df['diff'].rolling(3).mean()
        df['cum_diff'] = df['diff'].cumsum()
        df['cum_rolling_diff'] = df['rolling_diff'].cumsum()

        return df


if __name__ == '__main__':
    supply = LNGHelperFunctions().balances_europe(['DepMonth'])
    demand = LNGHelperFunctions().balances(['ArrMonth'])
    w = pd.ExcelWriter(os.path.join(data_dir, "lng_global_balances_comparison_2000(2).xlsx"), mode="w", engine="xlsxwriter")
    demand.to_excel(w, sheet_name='Global Demand')
    supply.to_excel(w, sheet_name='Global Supply')
    # LNGHelperFunctions().main()
    w.close()
    pass

