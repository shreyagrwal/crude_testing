import os, sys
sys.path.append(os.getcwd())
from bs4 import BeautifulSoup
import requests
import time
import smtplib
import win32com.client as win32
import pandas as pd
from ag_log import ag_log
from scraper_utils import scraper_environment as se
from ag_data_access import blueocean_access as bo

log = ag_log.get_log()
env = se.environment
bulkUploaderFolder = se.ingestion_folder
while True:

    url = "http://www.kesis.net/sub/sub_0002_eng.jsp"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "lxml")
    #print(soup)
    #print("First Step")
    df1 = pd.DataFrame(columns=['1'])
    #df2 = pd.DataFrame(columns=['1'])
    title = soup.find("td", class_="en_title").getText()
    print(title)
    #df1 = pd.DataFrame(title)
    date = soup.find("td", class_="en_dt").getText()
    print(date)
    #for el in soup.find_all("td", class_="en_dt"):
        #df2.append(el.get_text())
        #print(el.get_text())
    if str(date).find("(2019-10") == -1:
        print("Failed")
        time.sleep(10800)
        continue
    else:
        msg = 'Subject: Korean Gas Data Published'
        fromaddr = 'oliver.maddox@petrochinaintl.co.uk'
        # set the 'to' addresses,
        toaddrs = ['oliver.maddox@petrochinaintl.co.uk']
        print("Found")
        outlook = win32.Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
        mail.To = "oliver.maddox@petrochinaintl.co.uk"
        mail.Subject = msg
        mail.Body = msg

        mail.Send()

        # Print the email's contents
        print('From: ' + fromaddr)
        print('To: ' + str(toaddrs))
        print('Message: ' + msg)

        # send the email
        # server.sendmail(fromaddr, toaddrs, msg)
        # disconnect from the server
        # server.quit()

        break

log.debug('Job Completed.')