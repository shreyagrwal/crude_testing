import os, sys
sys.path.append(os.getcwd())
import os
import shutil
import requests
import scrapy
from scrapy.crawler import CrawlerProcess, CrawlerRunner
from scrapy import cmdline
from selenium import webdriver
import pandas as pd
import numpy as np
import glob as gb
from pathlib import Path
from tabula import read_pdf
from datetime import datetime, timedelta, date
from ag_log import ag_log
from scraper_utils import scraper_environment as se
from ag_data_access import blueocean_access as bo
from random import randint
from time import sleep

env = se.environment
bulkUploaderFolder = se.ingestion_folder
url_main_page = 'https://new.kpx.or.kr/board.es?mid=a10109030500&bid=0018'
appFolder = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\SouthKorea'
downloadFolder = os.path.join(appFolder, 'download')

def load_chorme_settings():
    chrome_options = webdriver.ChromeOptions()
    # Debug mode disabled
    # if sys.gettrace() is None:  # Check if it's in Debug model
    #     chrome_options.add_argument('--headless')
    chrome_options.add_experimental_option("useAutomationExtension", False);
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": downloadFolder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type");
    chrome_options.add_argument("start-maximized");
    chrome_options.add_argument("--js-flags=--expose-gc");
    chrome_options.add_argument("--enable-precise-memory-info");
    chrome_options.add_argument("--disable-popup-blocking");
    chrome_options.add_argument("--disable-default-apps");
    chrome_options.add_argument("--enable-automation");
    chrome_options.add_argument("test-type=browser");
    chrome_options.add_argument("disable-infobars");
    chrome_options.add_argument("--disable-extensions");
    chrome_options.add_argument("--disable-extensions");

    browser = webdriver.Chrome(executable_path="..\\tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser

def delete_temp_files(appFolder):
    for filename in os.listdir(appFolder):
        file_path = os.path.join(appFolder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))
def save_timestamp(timestamp_output, timestamp_path):
    timestamp_file = open(timestamp_path, "w")
    toFile = str(timestamp_output)
    timestamp_file.write(toFile)
    timestamp_file.close()
    log.debug("Timestamp saved")
def scrape_korean_outage():
    # Initiate Chrome Driver
    log.debug("Initiate Chrome Driver.")
    browser = load_chorme_settings()
    # Start Scraping
    log.debug("Get South Korean Outage Schedule~~~~~~~~~~~~~~~")
    timestamp = get_outage_schedule(browser)
    # close and close chrone webdriver
    browser.close()
    browser.quit()
    return timestamp

def get_outage_schedule(browser):
    browser.get(url_main_page)
    sleep(randint(1, 5))
    [y, m, d] = browser.find_element("xpath", '//*[@id="contents_body"]/div/div[2]/table/tbody/tr[1]/td[3]').get_attribute("innerHTML").split('/')
    timestamp = datetime(int(y), int(m), int(d))
    print(timestamp.strftime('%Y-%m-%d'))
    browser.find_element("xpath", '//*[@id="contents_body"]/div/div[2]/table/tbody/tr[1]/td[2]/a').click()
    sleep(randint(10, 15))
    # browser.get('https://new.kpx.or.kr/boardDownload.es?bid=0018&list_no=68973&seq=1')
    browser.find_element("xpath", '/html/body/div[4]/main/div/section[2]/div[2]/div/article/div[3]/ul/li/span[2]').click()
    sleep(randint(10, 15))
    return timestamp




def main():
    try:
        # # # Delete Files in Temp folder
        # delete_temp_files(downloadFolder)
        #
        # # Scrape South Korean Outage File
        # log.debug("Env:"+env)
        # timestamp_new = scrape_korean_outage()
        #
        # # Compare with timestamp in temp file.
        # log.debug("Compare with timestamp in temp file.")
        # timestamp_path = os.path.join(appFolder, 'timestamp.txt')
        # my_file = Path(timestamp_path)
        # if my_file.is_file():
        #     log.debug('Timestamp file found, start to compare')
        #     timestamp_output_existing = open(timestamp_path, "r").read()
        #     if str(timestamp_new) == timestamp_output_existing:
        #         log.debug('No new update found, scraper stops')
        #         return 0
        # else:
        #     log.debug('No timestamp file found.')
        # log.debug('New timestamp detected: ' + str(timestamp_new))

        # Process Downloaded file
        log.debug("Processing downloaded pdf file.")
        os.chdir(downloadFolder)
        for pdf in gb.glob("*.pdf"):
            if not '~' in pdf:
                try:
                    print("Found a file to scrape: {0}".format(pdf))
                    # reformat_data(pdf)
                    filedate = rename_file(pdf)
                    renamed_file = os.path.join(appDir, 'processed', 'renamed', filedate + ".pdf")
                    shutil.copy(pdf, renamed_file)  # Rename and save a copy to renamed folder
                    scrape(renamed_file, filedate)  # Scrape
                    time.sleep(0.5)
                    shutil.move(os.path.join(appDir, pdf), os.path.join(appDir, 'processed', 'archive', pdf))
                    print('File Completed: {0}.'.format(pdf))
                except Exception as e:
                    time.sleep(0.1)
                    log.error(e)
                    print("File moved to error folder.")
                    shutil.move(os.path.join(appDir, pdf), os.path.join(appDir, 'processed', 'error', pdf))
                    # exit(1)
        return 0

        # Finishing the Job
        log.debug("csv file exported.")

        log.debug("Save the Latest timestamp.")
        save_timestamp(timestamp_new, timestamp_path)
        return 0
    except Exception as e:
        log.error(e)
        return 1


def rename_file(filename):
    filedate = filename.replace('每日天然气简报', '').replace('.pdf', '').replace('.', '').replace(' ', '')
    filedate = filedate.split('(')[0]
    if len(filedate) == 6:
        filedate = '20' + filedate
    elif len(filedate) != 8:
        log.debug("Check Datetime Length, the current format is: " + filedate)
        log.debug("Datetime format has to be 'yyyymmdd' or 'yymmdd'.")
        exit(1)
    return filedate

def reformat_data(pdf):

    # Define the paths
    path = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\SouthKorea'

    # Read in the pdf data to a dataframe using tabula library - very useful library for downloading pdf data into pandas dataframe
    df = read_pdf(os.path.join(downloadFolder, pdf), pages=0)[0]

    # Read in a reference pdf from 24th June which was formatted differently.
    # Add extra steps if our pdf matches formatting of this pdf
    df_ref = read_pdf(path + '\sk_outages_pdf_archive' + '\sk_outages_' + '20220624' + '.pdf', pages=0)[0]
    if list(df.columns) == list(df_ref.columns):
        capacity = [i.split()[0] for i in df.iloc[:,3]]
        startdate = [i.split()[1] for i in df.iloc[:,3]]
        df = df.drop(df.columns[3], axis=1)
        df.insert(3,'Cap','')
        df['Cap'] = capacity
        df.insert(4,'StartDate','')
        df['StartDate'] = startdate
    else:
        pass

    # We will now create a dictionary to map Korean reactor names to English power type:

    # First create lists of reactor names from imported Excel file.
    # IMPORTANT - never move or delete this file as otherwise this script won't run.
    # If more Korean reactor names need to be added, that is fine. Just need to adhere to existing format in the file.
    df_names = pd.read_excel(path + r'\korean_reactor_names.xlsx')
    nuke_names = df_names['Nuclear reactors'].tolist()
    coal_names = df_names['Coal reactors'].tolist()

    # Tidy up the lists
    nuke_names = [x for x in nuke_names if str(x) != 'nan']
    coal_names = [x.replace(' ', '') for x in coal_names]

    # Create dictionaries from names (to english)
    nuke_dict = dict(zip(nuke_names, ['nuclear'] * len(nuke_names)))
    coal_dict = dict(zip(coal_names, ['coal'] * len(coal_names)))

    # Combine to make final names dictionary
    names_dict = {**nuke_dict, **coal_dict}

    # Pass dictionary as filter to create new column in dataframe
    df['Type'] = df.iloc[:, 2].map(names_dict)

    # Pass nuke & coal names as filter to remove every other row - we are only interested in nuclear & coal maintenance
    df = df[(df['Type'] == 'nuclear') | (df['Type'] == 'coal')]

    # Function to add pdate column into first column within a given dataframe
    def add_dt_col(dataframe):
        dataframe.insert(0, 'PDate', '')
        pdate2 = datetime.strptime(pdate, "%Y%m%d")
        pdate3 = datetime.strftime(pdate2, "%Y-%m-%d")
        dataframe['PDate'] = len(dataframe.iloc[:, 0]) * [pdate3]

    # Apply the function to add the pdate column
    add_dt_col(df)

    # Convert Korean header names to English
    headers_kor = df.columns.tolist()
    headers_eng = ['PDate', 'KorType1', 'KorType2', 'Reactor', 'Capacity', 'StartDate', 'StartTime',
                   'EndDate', 'EndTime', 'Days', 'VolEmis']
    headers_dict = dict(zip(headers_kor, headers_eng))
    df.rename(columns=headers_dict, inplace=True)

    # Re-order the columns
    headers_final = ['PDate', 'Type'] + headers_eng[1:]
    df = df.reindex(columns=headers_final)

    # Convert text format of date columns into pandas datetime
    df['StartDate'] = pd.to_datetime(df['StartDate'])
    df['EndDate'] = pd.to_datetime(df['EndDate'])

    # If Capacity or Days columns are strings, convert to numerical, i.e. remove thousand separator
    # Stole this function from online - first it defines what is a valid float, then applies to each column entry
    def remove_k_separator(input_column):
        valid = '1234567890.'
        def sanitize(data):
            return float(''.join(filter(lambda char: char in valid, data)))
        if np.any([isinstance(val, str) for val in df[input_column]]) == True:
            df[input_column] = df[input_column].apply(sanitize)

    # Apply function to Capacity & Days columns
    remove_k_separator('Capacity')
    remove_k_separator('Days')

    # If the final column (VolEmis) has '~' as a value, replace with blank data entry instead, as database wont be able to handle this
    if '~' in df.VolEmis.values:
        df['VolEmis'] = df['VolEmis'].replace('~', ' ')
    else:
        pass

    # Export the dataframe as a csv into the desired folders - four times in total

    # Export csv into our own records
    df.to_csv(path + r'\sk_outages_archive\ForDatabase' + r'\Upload_LNG_KoreanPowerMaintenance-' + pdate + '.csv',
              index=False)
    # Push csv directly into database - comment this out, we will no longer push into the old database (use datalake instead)
    # df.to_csv(db_path + r'\Upload_LNG_KoreanPowerMaintenance-' + pdate + '.csv',index=False)

    # Export csv with different filename format into our own records. The 'Datalake' is the new, more powerful database which is able to handle Korean text for exmaple
    df.to_csv(path + r'\sk_outages_archive\ForDatalake' + r'\lng-maintenance-korean-' + pdate + '.csv',
              index=False)
    # Finally push csv directly into the datalake
    df.to_csv(os.path.join(bulkUploaderFolder, 'lng-maintenance-korean-' + pdate + '.csv'), index=False)



    # Comment out the code below - was part of work undertaken with Chris Ottessen but isnt required for the script now
    # # Reformat & export data to datalake
    #
    # # Get Data
    # def get_dtn_df_from_serverless_sql_endpoint(self):
    #     """ Get DTN data from the serverless view in Azure"""
    #     server = 'petro-synapse-ws-ondemand.sql.azuresynapse.net'
    #     # server = 'petro-synapse-ws.sql.azuresynapse.net' # dedicated
    #     database = 'oil'
    #     username = 'petro-adminsqldev'
    #     password = 'Nw_}W@7K_QA<wnuP'
    #     driver = '{ODBC Driver 18 for SQL Server}'
    #     connection = pyodbc.connect(
    #         'DRIVER=' + driver + ';SERVER=tcp:' + server + ';PORT=1433;DATABASE=' + database + ';UID=' + username + ';PWD=' + password)
    #
    #     sql_query = """SELECT  * FROM petrosqldev.dbo.vw_gasoline_dtn_daily_padd"""
    #     df = pd.read_sql(sql_query, connection)
    #
    #     return df

    # def upload_to_blob(file_path):
    #     """
    #     Upload files to blob
    #     :param file_path:
    #     :return:
    #     """
    #     dir_name = 'datasets/staging/input'
    #     account_name = 'stadlspetro'
    #     account_key = r'ZbRP1NdYXccZiLAxY+Wasf0Cg0DPUYPDVDAnI2/GOYTG+0bcTWJ3GcqPCxOTIpdUUZzpTQ3AWv4N5wWryTl4Lw=='  # this will be removed from the code once we have set up a key vault
    #     container_name = 'fsdlspetro'
    #     block_blob_service = BlockBlobService(
    #         account_name=account_name,
    #         account_key=account_key
    #     )
    #
    #     blob_name = f"{dir_name}/{os.path.basename(file_path)}"
    #     block_blob_service.create_blob_from_path(container_name, blob_name, file_path)
    #
    #
    # datalake_filename = 'lng-maintenance-korean-' + pdate + '.csv'
    # df.to_csv(datalake_filename,
    #           index=False)
    # upload_to_blob(datalake_filename)
    # os.remove(datalake_filename)


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())




# ActiveBatch will run this script every day to pull out latest Korean Maintenance Data.
# Although the data schedule on website seems to be every Friday, we run daily as sometimes (e.g. during holiday seasons), Korean Power Exchange diverges from normal schedule)

# Summary of how the code works:
# Scrapy spider which crawls korean power website and downloads the MOST RECENT pdf (i.e. the latest maintenance)
# Saves the pdf with a new title, into archive folder
# That pdf is then used to extract information for key maintenance


# We define the pdf download function first - the Scrapy spider if defined after

''' A function which takes in a pdate, to find the corresponding pdf file which has been scraped, 
and then extracts data from that file and reformats into csv/excel to output. Will be applied below.'''



# Now we will define the Scrapy spider itself - i.e. the section of the code which actually does the scraping

# Name the spider
# class KoreaOutageSpider(scrapy.Spider):
#     name = "KoreaOutage"
#
#     # Initialise the spider with main wbesite url
#     # The 'User-Agent' clause is added to mimic Google Chrome, so that the website thinks we are just visiting the website with Chrome normally rather than scraping
#     def start_requests(self):
#         yield scrapy.Request(url='https://new.kpx.or.kr/board.es?mid=a10109030500&bid=0018',
#                              callback=self.parse_main_page, headers={
#                 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
#             })
#
#     # Extract url to navigate to next page
#     def parse_main_page(self, response):
#         main_url = 'https://new.kpx.or.kr'
#         for row in response.xpath("//*[@id='contents_body']/div/div[2]/table/tbody/tr[1]"):
#             data_url = row.xpath(".//td[2]/a/@href").get()
#             yield response.follow(url=main_url + data_url, callback=self.parse_second_page, headers={
#                 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
#             })
#
#     # Extract pdate and pdf download link from final webpage
#     def parse_second_page(self, response):
#         main_url = 'https://new.kpx.or.kr'
#         final_url = response.xpath("//*[@id='contents_body']/div/article/div[3]/ul/li/span[2]/a/@href").get()
#         #'//*[@id="contents_body"]/div/article/div[3]/ul/li/span[2]/a'
#         url_download = main_url + final_url
#         dt = response.xpath("//*[@id='contents_body']/div/article/ul/li[1]/span/text()").get()[:10]
#         dtx = datetime.strptime(dt, "%Y/%m/%d")
#         pdate = datetime.strftime(dtx, "%Y%m%d")
#
#         # Save the maintenance file into pdf archive directory, renaming using pdate scraped above. We will later revisit this directory using the function above to extract the data and produce the csv.
#         path = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\SouthKorea\sk_outages_pdf_archive'
#         if not os.path.exists(path): os.mkdir(path)
#         file = path + '\sk_outages_' + pdate + '.pdf'
#         output = open(file, 'wb')
#         resp = requests.get(url_download)
#         output.write(resp.content)
#         output.close()
#
#         # Apply the function we defined above to create the csv and export to database, datalake & also keep personal records.
#         # This is wehy we had to define the function before the spider - because the spider uses the function
#         reformat_data(pdate)


# Run the spider using command line code, adding a clause to set a delay of 10 seconds when scraping the data - helps to avoid detection to mitigate risk of being banned
# cmdline.execute("scrapy runspider KoreaOutages_scraper.py --set DOWNLOAD_DELAY=10".split())

print('Ran successfully')