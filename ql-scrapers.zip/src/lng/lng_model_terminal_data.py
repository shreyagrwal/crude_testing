import os
import sys
import random
import pycountry
import pandas as pd
from datetime import datetime

sys.path.append(os.getcwd())
from ag_data_access import blueocean_access as bo

file_drop_dir = r'\\petroineos.local\DFS\User Home Drive\bobbyhemming\Documents\to_blueocean\lng_model'

target_files = [
    'Upload_lng_model_regasification-2023-08-07.csv',
    'Upload_lng_model_liquification.csv'
]

country_count = {}


def generate_countries_dict():
    countries: dict = {}
    for country in pycountry.countries:
        # print(country.name, country.alpha_2)
        countries[country.name] = country.alpha_2

    countries["Ivory Coast"] = countries["Côte d'Ivoire"]
    countries['Russia'] = countries['Russian Federation']
    countries['South Korea'] = countries['Korea, Republic of']
    countries['Vietnam'] = countries['Viet Nam']
    countries['Brunei'] = 'BN'
    countries['East Africa'] = 'EAFR'
    countries['Iran'] = countries['Iran, Islamic Republic of']
    countries['Republic of Congo'] = countries['Congo, The Democratic Republic of the']
    countries['Tanzania'] = countries['Tanzania, United Republic of']
    countries['Atlantic Storage withdrawal'] = 'ATL-SW'
    countries['Asian Storage withdrawal'] = 'ASI-SW'
    countries['Atlantic Storage injection'] = 'ATL-SI'
    countries['Asian Storage injection'] = 'ASI-SI'
    countries['Global'] = 'GLB'
    for country, country_code in countries.items():
        country_count[country_code] = 0
    return countries


countries_dict = generate_countries_dict()
print(countries_dict)


def create_unique_country_index(row: pd.Series, country_col='Import Country', prefix='RDB'):
    print(row)
    countries = countries_dict
    cc: str = countries[row[country_col]].upper()
    country_count[cc] += 1
    # dest: str = row['Destination']
    # dest: str = dest[0:3].upper() if len(dest.split()) < 3 else ''.join([x[0] for x in dest.split()]).upper()
    #
    # term: str = row['Terminal'][0:3].upper()
    # random_integer: str = str(random.randint(10000, 99999))
    # + dest
    return prefix + '-' + cc + '-' + '{0:03}'.format(country_count[cc])


def get_terminals_historic_capacity(filename):
    data = pd.read_csv(os.path.join(file_drop_dir, filename))
    if 'regasification' in filename:
        static_data = bo.get_data("""
            SELECT idx, ImportCountry, Destination, Terminal, Pricenode, Basin, CountryZone, Importcapacitymmtpa, 
                    Storagecapacitycbm, Status, `Ramp-up`, `Start-up`,`Earlystart-up`,`Latestart-up`,Retirement,Sponsors  
            FROM workspace.bobbyhemming.lng_model_regasification_terminals
            WHERE IsActive = True""").drop_duplicates('idx')
        merge_cols = [col for col in static_data.columns if col != 'idx']
        data.columns = [col.strip().replace(' ', '').replace('(', '').replace(')', '') for col in data.columns]
        result = pd.merge(static_data, data, how='inner', on=merge_cols).drop(columns=merge_cols)
        result = pd.melt(result, id_vars=['idx'], value_vars=[col for col in result.columns if col != 'idx']).rename(columns={'variable': 'DDate', 'value': 'Capacity'})
        result['DDate'] = pd.to_datetime(result['DDate'], format='%b-%y').dt.strftime('%Y-%m-%d')
        result.to_csv(os.path.join(file_drop_dir, 'Upload_lng_model_regasification_terminal_historic_capacity-1.csv'), index=False, encoding='utf-8-sig')
    elif 'liquification' in filename:
        static_data = bo.get_data("""
            SELECT idx, Exportcountry, Source, Train, Pricenode, Basin, Countryzone, LiquefactionCapacity, 
                    StorageCapacity, Status, `Ramp-up`, `Start-up`, `Earlystart-up`, `Latestart-up`, Retirement, Owner
            FROM workspace.bobbyhemming.lng_model_liquification_terminals
            WHERE IsActive = True""").drop_duplicates('idx')
        merge_cols = [col for col in static_data.columns if col != 'idx']
        data.columns = [col.strip().replace(' ', '').replace('(', '').replace(')', '') for col in data.columns]
        result = pd.merge(static_data, data, how='inner', on=merge_cols).drop(columns=merge_cols)
        result = pd.melt(result, id_vars=['idx'], value_vars=[col for col in result.columns if col != 'idx']).rename(columns={'variable': 'DDate', 'value': 'Capacity'})
        result['DDate'] = pd.to_datetime(result['DDate'], format='%b-%y').dt.strftime('%Y-%m-%d')
        result.to_csv(os.path.join(file_drop_dir, 'Upload_lng_model_liquification_terminal_historic_capacity-1.csv'),
                      index=False, encoding='utf-8-sig')
    else:
        pass


def get_terminal_meta_info():
    # Read in target upload files:
    for file in target_files:
        print(file)
        df = pd.read_csv(os.path.join(file_drop_dir, file))
        # df = df.dropna(subset=['Export Country'])

        candidate_data = df.copy(deep=True)
        if 'regasification' in file:
            countries_dict = generate_countries_dict()
            candidate_data.insert(0, 'idx', candidate_data.apply(lambda x: create_unique_country_index(x, prefix='RDB'), axis=1))
            candidate_data.to_csv('Upload_lng_model_regasification-1.csv')
        elif 'liquification' in file:
            countries_dict = generate_countries_dict()
            candidate_data.insert(0, 'idx', candidate_data.apply(lambda x: create_unique_country_index(x, country_col='Export country', prefix='LDB'), axis=1))
            candidate_data.to_csv('Upload_lng_model_liquification-1.csv', index=False, encoding='utf-8-sig')
        else:
            pass

    pass


def get_supply_demand_nodes(filename):
    supply_columns = ['Export country', 'Source', 'Price node', 'Basin']
    demand_columns = ['Import country', 'Price node', 'Basin']
    df = pd.read_csv(os.path.join(file_drop_dir, filename))

    candidate_data = df.copy(deep=True)
    if 'supply' in filename:
        countries_dict = generate_countries_dict()
        candidate_data = candidate_data[supply_columns]
        candidate_data = candidate_data.drop_duplicates(subset=supply_columns)
        candidate_data.insert(0, 'idx', candidate_data.apply(lambda x: create_unique_country_index(x, country_col='Export country', prefix='SDB'), axis=1))
        candidate_data.to_csv('Upload_lng_model_supply_nodes-1.csv', index=False, encoding='utf-8-sig')
    elif 'demand' in filename:
        countries_dict = generate_countries_dict()
        candidate_data = candidate_data[demand_columns]
        candidate_data = candidate_data.drop_duplicates(subset=demand_columns)
        candidate_data.insert(0, 'idx', candidate_data.apply(lambda x: create_unique_country_index(x, country_col='Import country', prefix='DDB'), axis=1))
        candidate_data.to_csv('Upload_lng_model_demand_nodes-1.csv', index=False, encoding='utf-8-sig')
    else:
        pass
    pass


def get_supply_demand_historic(filename):
    df = pd.read_csv(os.path.join(file_drop_dir, filename))
    data = df.copy(deep=True)
    if 'supply' in filename:
        static_data = bo.get_data("""
                    SELECT idx, Exportcountry, Source, Pricenode, Basin
                    FROM workspace.bobbyhemming.lng_model_supply_nodes
                    WHERE IsActive = True""").drop_duplicates('idx')
        merge_cols = [col for col in static_data.columns if col not in ['idx', 'Measure']]
        data.columns = [col.strip().replace(' ', '').replace('(', '').replace(')', '') for col in data.columns]
        result = pd.merge(static_data, data, how='inner', on=merge_cols).drop(columns=merge_cols)
        result = pd.melt(result, id_vars=['idx', 'Measure'], value_vars=[col for col in result.columns if col not in ['idx', 'Measure']]).rename(columns={'variable': 'DDate', 'value': 'Value'})
        result['DDate'] = pd.to_datetime(result['DDate'], format='%b-%y').dt.strftime('%Y-%m-%d')
        result['PDate'] = datetime.now().date().strftime('%Y-%m-%d')
        result.to_csv(os.path.join(file_drop_dir, 'Upload_lng_model_supply_historic-1.csv'), index=False, encoding='utf-8-sig')
    elif 'demand' in filename:
        static_data = bo.get_data("""
                    SELECT idx, Importcountry, Pricenode, Basin
                    FROM workspace.bobbyhemming.lng_model_demand_nodes
                    WHERE IsActive = True""").drop_duplicates('idx')
        merge_cols = [col for col in static_data.columns if col not in ['idx', 'Measure']]
        data.columns = [col.strip().replace(' ', '').replace('(', '').replace(')', '') for col in data.columns]
        result = pd.merge(static_data, data, how='inner', on=merge_cols).drop(columns=merge_cols)
        result = pd.melt(result, id_vars=['idx', 'Measure'], value_vars=[col for col in result.columns if col not in ['idx', 'Measure']]).rename(columns={'variable': 'DDate', 'value': 'Value'})
        result['DDate'] = pd.to_datetime(result['DDate'], format='%b-%y').dt.strftime('%Y-%m-%d')
        result['PDate'] = datetime.now().date().strftime('%Y-%m-%d')
        result.to_csv(os.path.join(file_drop_dir, 'Upload_lng_model_demand_historic-1.csv'), index=False, encoding='utf-8-sig')
    pass


if __name__ == '__main__':
    # get_terminal_meta_info()
    # get_terminals_historic_capacity('regasification_historical.csv')
    # get_terminals_historic_capacity('liquification_historical.csv')
    # get_supply_demand_nodes('supply_nodes_historical.csv')
    # get_supply_demand_nodes('demand_nodes_historical.csv')
    get_supply_demand_historic('supply_nodes_historical.csv')
    get_supply_demand_historic('demand_nodes_historical.csv')
    pass

