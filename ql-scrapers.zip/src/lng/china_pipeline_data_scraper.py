import os, sys
sys.path.append(os.getcwd())
import numpy as np
import pandas as pd
import glob as gb
from tabula import read_pdf
from PyPDF2 import PdfReader
import re
import os
import shutil
from datetime import datetime, date
import time
from os import path
from ag_log import ag_log
from scraper_utils import scraper_environment as se

env = se.environment
# csvFolder = se.ingestion_folder
# filename = 'Upload_LNG_ChinesePipelineData-'

filename = 'ChinesePipelineData-'
csvFolder = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\China\processed\excel'

log = ag_log.get_log()

appDir = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\China'

os.chdir(appDir)

dict_pipelines = {
    '中俄东线': 'Gazprom',
    '中俄东线(万方)': 'Gazprom',
    '阿姆河': 'Turkmen1',
    '康采恩': 'Turkmen2',
    '乌输气公司': 'Uzbek',
    '哈输气公司': 'Kazakh',
    '中亚进口总量': 'TotalCAExport',
    '中亚到岸总量': 'TotalCAChinaImport',
    '缅甸总量': 'Myanmar'
}

list_row = ['中俄东线', '阿姆河', '康采恩', '乌输气公司', '哈输气公司', '霍尔果斯AB线', '霍尔果斯C线',
            '缅甸皎漂OGT', '缅甸国内下载', '缅甸末站南坎', '万方', '油当量', '中俄东线(万方)']

def rename_file(filename):
    filedate = filename.replace('每日天然气简报', '').replace('.pdf', '').replace('.', '').replace(' ', '')
    filedate = filedate.split('(')[0]
    if len(filedate) == 6:
        filedate = '20' + filedate
    elif len(filedate) != 8:
        log.debug("Check Datetime Length, the current format is: " + filedate)
        log.debug("Datetime format has to be 'yyyymmdd' or 'yymmdd'.")
        exit(1)
    return filedate


def get_date_in_footer(renamed_file):
    marked_date = PdfReader(renamed_file).pages[1].extract_text().split("中国石油国际事业有限公司")[1].replace('\n', '').replace(' ', '')\
        .replace('年', ',').replace('月', ',').replace('日', '')
    [y, m, d] = marked_date.split(',')
    footer_date = datetime(int(y), int(m), int(d))
    return footer_date


def clean_whitespace(input_str):
    # This pattern should be equal to r'(.*)(\d{1}),(\d\s?\d\s?\d)(.*)' due to a numerical reason
    pattern = r'(\s?)(\d?),(\d\s?\d\s?\d)(.*)'
    matched_results = re.match(pattern, input_str)
    # tracker_str = input_str
    if matched_results is None:
        return input_str
    else: # If this pattern can be found
        updated_results = (matched_results[1] + matched_results[2] + ',' + matched_results[3].replace(" ", "")
                           + clean_whitespace(matched_results[4]))
        return updated_results

def remove_text_in_first_row(df):
    df.iloc[0, :] = df.iloc[0, :].apply(lambda x: str(x).replace("累", ''))
    df.iloc[0, :] = df.iloc[0, :].apply(lambda x: str(x).replace("划", ''))
    df.iloc[0, :] = df.iloc[0, :].apply(lambda x: str(x).replace("计", ''))
    df.iloc[0, :] = df.iloc[0, :].apply(lambda x: str(x).replace("欠", ''))
    df.iloc[0, :] = df.iloc[0, :].apply(lambda x: str(x).replace("   ", ' '))
    df.iloc[0, :] = df.iloc[0, :].apply(lambda x: str(x).replace("  ", ' '))
    df.iloc[0, :] = df.iloc[0, :].apply(lambda x: str(x).replace('- ', '-'))
    df.iloc[0, :] = df.iloc[0, :].apply(lambda x: clean_whitespace(str(x)))
    return df


def scrape(renamed_file, filedate):
    # Read Pipeline Data Table
    list_df = read_pdf(renamed_file, pages=2)
    df = list_df[len(list_df)-2]
    df = df.dropna(how='all').dropna(axis=1, how='all')
    df = df.replace('I', '', regex=True)

    # # Get Report Date
    # # Date verifying currently disabled.
    # date_footer = get_date_in_footer(renamed_file)
    date_filename = datetime(int(filedate[0:4]), int(filedate[4:6]), int(filedate[6:8]))
    # if abs((date_filename - date_footer).days) > 0:
    #     print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
    #     print('Reporting dates inconsistent in file name and footer, please check.')
    #     print('Footer Date: ' + date_footer.strftime('%Y-%m-%d'))
    #     print('File Name Date: ' + date_footer.strftime('%Y-%m-%d'))
    #     exit(1)
    # else:
    #     print('Reporting dates check passed.')
    #     print('Report Date: ' + date_footer.strftime('%Y-%m-%d'))
    list_dt = ''.join([i for i in df.iloc[-1, 0].replace("月", '-').replace("日", '-')if i == ','
                       or i == ':' or i == '-' or i in str(list(range(0, 10)))]).replace(' ', '').split(',')
    list_dt = list(filter(None, list_dt))
    [rus_dt, ca_dt, mym_dt] = [datetime.strptime(filedate[0:4] + '-' + dt, '%Y-%m-%d-%H:%M') for dt in list_dt]

    # Re-align the Tables Rows and Columns
    # pipeline_col = df.stack().reset_index(level=0, drop=True).str.contains('万方', na=False).idxmax()
    # df = df[df[pipeline_col].notna()]
    df['shift'] = ''
    for i in range(8):
        df['shift'][df.iloc[:, i].astype(str).str.strip().str.split(' ').str[-1].isin(list_row)] = -i
    df = df[df['shift'] != '']
    df_T = df.T
    for col in df_T:
        df_T[col] = df_T[col].shift(df_T[col]['shift'])
    df = df_T.T
    df.iloc[:, 0] = df.iloc[:, 0].replace(' ', '').str.strip().str.split(' ').str[-1]

    # Replace the '万方' to actual locations
    i = 1
    for index, row in df.iterrows():
        if row.iloc[0] == '万方':
            row.iloc[0] = '万方' + str(i)
            i += 1
        else:
            pass
    df = df.replace({'万方1': '中亚进口总量', '万方2': '中亚到岸总量', '万方3': '缅甸总量'})
    del i

    # Filter out information Row
    df_total = df[df.iloc[:, 0].isin(dict_pipelines.keys())]
    # df_total = df_total.dropna(axis='columns', how='any')

    # Text Cleaning
    df_total = remove_text_in_first_row(df_total)
    df_total = df_total.replace('- ', '-', regex=True) #remove any space between - and number.
    df_total = df_total.replace('Q', '0', regex=True)
    df_total = df_total.replace('l', '1', regex=True)

    # Split the merged cells and create dateframe
    list_list = []
    for index, row in df_total.iterrows():
        list_list.append([item for sublist in [str(i).split(' ') for i in row] for item in sublist])
    list_list = [list(filter(None, l)) for l in list_list] # Filter out empty string
    list_list = [[st for st in l if st != 'nan'] for l in list_list] # Filter out nan string
    df_splitted = pd.DataFrame(list_list).iloc[:, :9]
    df_splitted.columns = ['Pipeline', 'DailyActl', 'DailySched', 'YearlySched', 'MonthlyCltv', 'YearlyCltv', 'DailyDev', 'MonthlyDevToDate', 'YearlyDevToDate']

    # Clean Total CA into China
    df_splitted = df_splitted.set_index('Pipeline')
    df_splitted.loc['中亚到岸总量', 'DailySched':'YearlyDevToDate'] = df_splitted.loc['中亚到岸总量', 'DailySched':'YearlyDevToDate'].shift(2)
    df_splitted.loc['中亚到岸总量', 'DailyDev':'YearlyDevToDate'] = df_splitted.loc['中亚到岸总量', 'DailyDev':'YearlyDevToDate'].shift(3)
    df_splitted = df_splitted.reset_index()

    # Prepare Csv export
    for col in df_splitted.columns[df_splitted.columns != 'Pipeline']:
        df_splitted[col] = df_splitted[col].apply(lambda x: float(x.replace(',', ''))*10000/1000000 if str(x) != 'nan' else x)
    df_splitted = df_splitted.replace({'Pipeline': dict_pipelines})
    print(df_splitted)
    if df_splitted.shape[0] != 8:
        print('Record missing, there was only ' + str(df_splitted.shape[0]) + ' rows.')
        print(renamed_file)
        exit(1)

    df_splitted['Unit'] = 'mcm'
    df_splitted['UpdatedDate'] = ''
    df_splitted['UpdatedDate'][df_splitted['Pipeline'] == 'Myanmar'] = rus_dt
    df_splitted['UpdatedDate'][df_splitted['Pipeline'] == 'Gazprom'] = mym_dt
    df_splitted['UpdatedDate'][df_splitted['UpdatedDate'] == ''] = ca_dt
    df_splitted['ReportDate'] = date_filename.strftime(('%Y-%m-%d %H:%M:%S'))
    # Individual CSV Export
    fullfilename = os.path.join(csvFolder, 'historical', filename + filedate + ".csv")
    df_splitted.to_csv(fullfilename, index=False)

    # CSV with full history
    fullfilename_full = os.path.join(csvFolder, "pipeline.csv")
    df_full = pd.read_csv(fullfilename_full)
    df_full = pd.concat([df_full, df_splitted])
    df_full = df_full.drop_duplicates(subset=['Pipeline', 'ReportDate'])
    df_full = df_full.sort_values(by=['ReportDate','Pipeline'])
    df_full.to_csv(os.path.join(csvFolder, "pipeline.csv"), index=False)

    # CSV with the latest data
    fullfilename_latest = os.path.join(csvFolder, "pipeline_latest.csv")
    df_latest = pd.read_csv(fullfilename_latest)
    pdate_latest = pd.to_datetime(df_latest['ReportDate']).max().to_pydatetime()
    if date_filename >= pdate_latest:
        df_splitted.to_csv(os.path.join(csvFolder, "pipeline_latest.csv"), index=False)


def main():
    for pdf in gb.glob("*.pdf"):
        if not '~' in pdf:
            try:
                if pdf.find("简报") != -1:
                    print("Found a file to scrape: {0}".format(pdf))
                    filedate = rename_file(pdf)
                    renamed_file = os.path.join(appDir, 'processed', 'renamed', filedate + ".pdf")
                    shutil.copy(pdf, renamed_file) # Rename and save a copy to renamed folder
                    scrape(renamed_file, filedate) # Scrape
                    time.sleep(0.5)
                    shutil.move(os.path.join(appDir, pdf), os.path.join(appDir, 'processed', 'archive', pdf))
                print('File Completed: {0}.'.format(pdf))
            except Exception as e:
                time.sleep(0.1)
                log.error(e)
                print("File moved to error folder.")
                shutil.move(os.path.join(appDir, pdf), os.path.join(appDir, 'processed', 'error', pdf))
                # exit(1)
    return 0

if __name__ == "__main__":
    exit(main())