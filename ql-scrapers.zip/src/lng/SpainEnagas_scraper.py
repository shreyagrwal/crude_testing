import os, sys
sys.path.append(os.getcwd())
import requests
import pandas as pd
from datetime import datetime, timedelta, date
from calendar import monthrange
from dateutil import relativedelta
import os
from ag_log import ag_log
from scraper_utils import scraper_environment as se
from ag_data_access import blueocean_access as bo
env = se.environment
bulkUploaderFolder = se.ingestion_folder
# Download enagas data - will be run automatically by ActiveBatch at ~5pm daily

# Set up dictionary to convert between enagas spanish dates and our english dates
mnths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
mnths_es = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic']
zip_iter = zip(mnths, mnths_es)
mnth_dict = dict(zip_iter)


# Set up function to download gnl & transporte sheets from enagas file and save as separate csv's after reformatting
def download_enagas(mnth, yr):
    # format the url for downloading data
    url1 = "https://enagas.es/web-corporativa-ext-templating/Excel?nombreFichero=POWeb_"
    url2 = "_es.xlsx&app_implementation=es.enagas.webcorp.applications.ws.poweb.PoWebLogic"

    # try downloading with both m0 and m1 techniques - will never be both hence we can use a try/except if the first attempt fails, used the second.
    try:
        url = url1 + mnth_dict[mnth] + yr + url2
        name_file = "m0"
        resp = requests.get(url)
    except:
        url = url1 + mnth_dict[mnth] + yr + "_M1" + url2
        name_file = "m1"
        resp = requests.get(url)

    # download the file into our Spain scrape directory
    path = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\Spain'
    if not os.path.exists(path): os.mkdir(path)
    file = path + r'\test.xlsx'
    output = open(file, 'wb')
    output.write(resp.content)
    output.close()

    # pull out the two downloaded excel workbooks we need from the Excel file we have downloaded
    wb1 = pd.read_excel(file, sheet_name='PO GNL')
    wb3 = pd.read_excel(file, sheet_name='PO Transporte')

    # pull out pdate as a string to rename file, then convert to datetime object with dtx, then finally convert dtx to dty & dtz - i.e. two strings
    dt = wb1.iloc[2, 1][20:]
    dtx = datetime.strptime(dt, "%d/%m/%Y %H:%M:%S")
    dty = datetime.strftime(dtx, "%Y%m%d")
    dtz = datetime.strftime(dtx, "%b%y")

    # pull out ddate as string to rename file
    dt2 = wb1.iloc[0, 1][28:][:3] + wb1.iloc[0, 1][28:][-4:]
    # slice dt2 and covnert to lowercase, and then convert date to english using date dictionary we defined at the start
    dt2x = [k for k, v in mnth_dict.items() if v == dt2[:3].lower()][0]
    # add on the year
    dt2y = dt2x + wb1.iloc[0, 1][28:][-2:]
    # finally convert the full string to a datetime object, and then convert back to a date string with format "%Y%m%d
    dt2z = datetime.strftime(datetime.strptime(dt2y, '%b%y'), "%Y%m%d")

    # archive the original Excel file
    try:
        os.rename(file, path + r'\enagas_archive\es_gas_' + dt2y + '_' + dty + '.xlsx')
    except:
        pass

    # convert each worksheet to a dataframe
    gnl = wb1.iloc[5:, 1:]
    trans = wb3.iloc[6:, 1:]

    # change dataframe headers
    gnl_header = gnl.iloc[0]
    gnl = gnl[1:]
    gnl.columns = gnl_header
    gnl.columns.values[0] = 'DDate'

    trans_header = trans.iloc[0]
    trans = trans[1:]
    trans.columns = trans_header
    trans.columns.values[0] = 'DDate'

    # delete first and last row of gnl dataframe, as we don't need data
    gnl.drop(gnl.tail(1).index, inplace=True)
    gnl.drop(gnl.head(1).index, inplace=True)

    # delete all rows which are completely empty
    gnl = gnl.dropna(how='all')
    trans = trans.dropna(how='all')

    # prepare pdate for function below
    pdate = dty

    # function to add pdate column
    def format_dataframes(dfx):
        dfx.insert(0, 'PDate', '')
        dfx['PDate'] = [pdate] * len(dfx.index)

    # apply function to both dataframes
    for item in [gnl, trans]:
        format_dataframes(item)

    # export final csvs
    # archive versions (store a record-for database versions later on)
    gnl_csv = gnl.to_csv(path + r'\es_gas_gnl' + r'\es_gas_gnl_' + dt2y + '_' + dty + '.csv', index=False)
    trans_csv = trans.to_csv(path + r'\es_gas_trans' + r'\es_gas_trans_' + dt2y + '_' + dty + '.csv', index=False)

    # actual versions (the latest version of the file)
    gnl_excel = gnl.to_excel(path + r'\es_gas_gnl_' + name_file + '.xlsx', index=False)
    trans_excel = trans.to_excel(path + r'\es_gas_trans_' + name_file + '.xlsx', index=False)

    # delete the 'test' file as not required - although this doesn't seem to work and the 'test' file remains, although irrelevant for overall code
    if os.path.exists(file):
        os.remove(file)
    else:
        pass


# Pull in from es_gas_gnl & es_gas_trans to produce dataframe of every scraped field
# This is run after the code above, because first we download the data, now we will be producing the formatted csv's for m0 & m1 which we will be pushing into the database

def enagas_to_dataframe(ddate_mnth, pdate):
    # Set up paths
    path = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\Spain'
    db_path = bulkUploaderFolder
    ddate2 = datetime.strptime(ddate_mnth, "%b%y")
    mnth_days = monthrange(ddate2.year, ddate2.month)[1]

    # Read in the csv data to dataframes
    df_gnl = pd.read_csv(path + '\es_gas_gnl\es_gas_gnl_' + ddate_mnth + '_' + pdate + '.csv')
    gnl_list = [df_gnl.iloc[mnth_days - 1, 2], df_gnl.iloc[mnth_days - 1, 7],
                df_gnl.iloc[mnth_days - 1, 12], df_gnl.iloc[mnth_days - 1, 17],
                df_gnl.iloc[mnth_days - 1, 22], df_gnl.iloc[mnth_days - 1, 27]]

    df_trans = pd.read_csv(path + '\es_gas_trans\es_gas_trans_' + ddate_mnth + '_' + pdate + '.csv')
    trans_list = [df_trans.iloc[mnth_days, 2], df_trans.iloc[mnth_days, 3],
                  df_trans.iloc[mnth_days, 4], df_trans.iloc[mnth_days, 5],
                  df_trans.iloc[mnth_days, 6], df_trans.iloc[mnth_days, 7],
                  df_trans.iloc[mnth_days, 9], df_trans.iloc[mnth_days, 10],
                  df_trans.iloc[mnth_days, 11], df_trans.iloc[mnth_days, 12],
                  df_trans.iloc[mnth_days, 14], df_trans.iloc[mnth_days, 15],
                  df_trans.iloc[mnth_days, 18], df_trans.iloc[mnth_days, 23],
                  df_trans.iloc[mnth_days, 24]]

    # Combine the data into one list
    values_list = gnl_list + trans_list

    # Create list of field headers, to match up with how Enagas define the data columns
    headers_list = ['BarcelonaInventory', 'CartagenaInventory', 'HuelvaInventory',
                    'BilbaoInventory', 'SaguntoInventory', 'MugardosInventory',
                    'BarcelonaSendout', 'CartagenaSendout', 'HuelvaSendout',
                    'BBGSendout', 'SaguntoSendout', 'ReganosaSendout',
                    'IberianPipelineImports', 'PirineosPipelineImports',
                    'TarifaPipelineImports', 'AlmeriaPipelineImports', 'IndigenousBiogas',
                    'IndigenousNatGas', 'StorageNetInjection', 'Distribution', 'LNGTrucking']

    # Define the pdate & ddate
    pdate2 = datetime.strptime(pdate, "%Y%m%d")
    pdate3 = datetime.strftime(pdate2, "%Y-%m-%d")
    pdate_list = len(values_list) * [pdate3]

    ddate3 = datetime.strftime(ddate2, "%Y-%m-%d")
    ddate_list = len(values_list) * [ddate3]

    # Create the dataframe
    es_gas_df = pd.DataFrame(
        {'PDate': pdate_list,
         'DDate': ddate_list,
         'Fields': headers_list,
         'Value': values_list
         })

    # Export the dataframe as a csv into the desired folders
    # Keep an in-house version in our own directories
    es_gas_df.to_csv(
        path + r'\es_gas_for_database' + r'\Upload_LNG_SpanishEnagasData-' + ddate_mnth + '-' + pdate + '.csv',
        index=False)
    # Also push directly into the database, to pull out later on when required
    es_gas_df.to_csv(
        db_path + r'\Upload_LNG_SpanishEnagasData-' + ddate_mnth + '-' + pdate + '.csv',
        index=False)


# Run this every day - so every day you try to scrape current month and next month on enagas website
# Uses current month & current year as function inputs

def iterate_mnths():
    # m0 will be the current month, whilst m1 will be the enxt month.
    # Both dates converted to %b%y e.g. Jan22 format to match up with Enagas website url
    m0 = datetime.strftime(datetime.now(), "%b%y")
    m1 = datetime.strftime(date.today() + relativedelta.relativedelta(months=1), "%b%y")

    # try to download the data & then also output the formatted csv for m0
    try:
        download_enagas(m0[:3], m0[-2:])
        enagas_to_dataframe(m0, datetime.strftime(datetime.now(), "%Y%m%d"))
    except:
        pass

    # try to download the data & then also output the formatted csv for m1
    try:
        download_enagas(m1[:3], m1[-2:])
        enagas_to_dataframe(m1, datetime.strftime(datetime.now(), "%Y%m%d"))
    except:
        pass

#Call all of the above to run the code
iterate_mnths()

print('Ran successfully')