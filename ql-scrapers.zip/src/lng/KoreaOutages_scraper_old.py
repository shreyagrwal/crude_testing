import os, sys
sys.path.append(os.getcwd())
import os
import requests
import scrapy
import shutil
from scrapy.crawler import CrawlerProcess, CrawlerRunner
from scrapy import cmdline
import pandas as pd
import numpy as np
from tabula import read_pdf
from datetime import datetime, timedelta, date
from ag_log import ag_log
from scraper_utils import scraper_environment as se
from ag_data_access import blueocean_access as bo
import glob as gb
from time import sleep
import certifi
certifi.where()

env = se.environment
bulkUploaderFolder = se.ingestion_folder
# mode = 'scraping'
mode = 'process_all_PDF'

# ActiveBatch will run this script every day to pull out the latest Korean Maintenance Data.
# Although the data schedule on website seems to be every Friday, we run daily as sometimes (e.g. during holiday seasons), Korean Power Exchange diverges from normal schedule)

# Summary of how the code works:
# Scrapy spider which crawls korean power website and downloads the MOST RECENT pdf (i.e. the latest maintenance)
# Saves the pdf with a new title, into archive folder
# That pdf is then used to extract information for key maintenance


# We define the pdf download function first - the Scrapy spider if defined after

''' A function which takes in a pdate, to find the corresponding pdf file which has been scraped, 
and then extracts data from that file and reformats into csv/excel to output. Will be applied below.'''
def reformat_data(mainfolder, pdate):
    # Define the paths

    os.path.join(mainfolder)
    # Read in the pdf data to a dataframe using tabula library - very useful library for downloading pdf data into pandas dataframe
    df = read_pdf(os.path.join(mainfolder, 'sk_outages_' + pdate + '.pdf'), pages=0)[0]

    # Read in a reference pdf from 24th June which was formatted differently.
    # Add extra steps if our pdf matches formatting of this pdf
    df_ref = read_pdf(os.path.join(mainfolder, 'referencefile', 'sk_outages_' + '20220624' + '.pdf'), pages=0)[0]
    if list(df.columns) == list(df_ref.columns):
        capacity = [i.split()[0] for i in df.iloc[:, 3]]
        startdate = [i.split()[1] for i in df.iloc[:, 3]]
        df = df.drop(df.columns[3], axis=1)
        df.insert(3,'Cap','')
        df['Cap'] = capacity
        df.insert(4,'StartDate','')
        df['StartDate'] = startdate
    else:
        pass

    # We will now create a dictionary to map Korean reactor names to English power type:

    # # Create a list of reactor method 1:
    # # First create lists of reactor names from imported Excel file.
    # # IMPORTANT - never move or delete this file as otherwise this script won't run.
    # # If more Korean reactor names need to be added, that is fine. Just need to adhere to existing format in the file.
    # df_names = pd.read_excel(path + r'\korean_reactor_names.xlsx')
    # nuke_names = df_names['Nuclear reactors'].tolist()
    # coal_names = df_names['Coal reactors'].tolist()
    #
    # # Tidy up the lists
    # nuke_names = [x for x in nuke_names if str(x) != 'nan']
    # coal_names = [x.replace(' ', '') for x in coal_names]
    #
    # # Create dictionaries from names (to english)
    # nuke_dict = dict(zip(nuke_names, ['nuclear'] * len(nuke_names)))
    # coal_dict = dict(zip(coal_names, ['coal'] * len(coal_names)))
    #
    # # Combine to make final names dictionary
    # names_dict = {**nuke_dict, **coal_dict}
    #
    # # Pass dictionary as filter to create new column in dataframe
    # df['Type'] = df.iloc[:, 2].map(names_dict)
    #
    # # Pass nuke & coal names as filter to remove every other row - we are only interested in nuclear & coal maintenance
    # df = df[(df['Type'] == 'nuclear') | (df['Type'] == 'coal')]

    # Create a list of reactor method 2:
    # dict_reactor = {'자력': 'nuclear', '유연탄': 'coal', '원자력': 'coal'}
    dict_reactor = {'자력': 'nuclear', '연탄': 'coal'}
    df['Type'] = df['연료원'].apply(lambda x: dict_reactor[x[-2:]] if x[-2:] in list(dict_reactor.keys()) else np.nan)
    df = df.dropna(subset=['Type'])
    df['PDate'] = datetime.strptime(pdate, "%Y%m%d")
    # Function to add pdate column into first column within a given dataframe

    # Convert Korean header names to English
    df.columns =['KorType1', 'KorType2', 'Reactor', 'Capacity', 'StartDate', 'StartTime',
                   'EndDate', 'EndTime', 'Days', 'Note', 'Type', 'PDate']
    df['StartDatetime'] = df['StartDate'] + ' ' + df['StartTime']
    df['StartDatetime'] = pd.to_datetime(df['StartDatetime'], format='%Y-%m-%d %H:%M')
    df['EndDatetime'] = df['EndDate'] + ' ' + df['EndTime']
    df['EndDatetime'] = pd.to_datetime(df['EndDatetime'], format='%Y-%m-%d %H:%M')

    df = df[['PDate', 'Type', 'KorType1', 'KorType2', 'Reactor', 'Capacity', 'StartDatetime',
                   'EndDatetime', 'Days', 'Note']]

    # If Capacity or Days columns are strings, convert to numerical, i.e. remove thousand separator
    # Stole this function from online - first it defines what is a valid float, then applies to each column entry
    def remove_k_separator(input_column):
        valid = '1234567890.'
        def sanitize(data):
            return float(''.join(filter(lambda char: char in valid, data)))
        if np.any([isinstance(val, str) for val in df[input_column]]) == True:
            df[input_column] = df[input_column].apply(sanitize)

    # Apply function to Capacity & Days columns
    remove_k_separator('Capacity')
    remove_k_separator('Days')

    # If the final column (VolEmis) has '~' as a value, replace with blank data entry instead, as database wont be able to handle this
    df['Note'] = df['Note'].replace('~', ' ')

    # Export the dataframe as a csv into the desired folders - four times in total

    # Export csv into our own records
    df.to_csv(os.path.join(mainfolder, 'sk_outages_archive', 'ForDatabase', 'Upload_LNG_KoreanPowerMaintenance-' + pdate + '.csv'),
              index=False, encoding="utf-8-sig")
    # Push csv directly into database - comment this out, we will no longer push into the old database (use datalake instead)
    # df.to_csv(db_path + r'\Upload_LNG_KoreanPowerMaintenance-' + pdate + '.csv',index=False)

    # Export csv with different filename format into our own records. The 'Datalake' is the new, more powerful database which is able to handle Korean text for exmaple
    df.to_csv(os.path.join(mainfolder, 'sk_outages_archive', 'ForDatalake', 'lng-maintenance-korean-' + pdate + '.csv'),
              index=False, encoding="utf-8-sig")
    # Finally push csv directly into the datalake
    df.to_csv(os.path.join(bulkUploaderFolder, 'lng-maintenance-korean-' + pdate + '.csv'), index=False, encoding="utf-8-sig")


# Now we will define the Scrapy spider itself - i.e. the section of the code which actually does the scraping
# Name the spider
class KoreaOutageSpider(scrapy.Spider):
    name = "KoreaOutage"

    # Initialise the spider with main wbesite url
    # The 'User-Agent' clause is added to mimic Google Chrome, so that the website thinks we are just visiting the website with Chrome normally rather than scraping
    def start_requests(self):
        yield scrapy.Request(url='https://new.kpx.or.kr/board.es?mid=a10109030500&bid=0018',
                             callback=self.parse_main_page, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
            })

    # Extract url to navigate to next page
    def parse_main_page(self, response):
        main_url = 'https://new.kpx.or.kr'
        for row in response.xpath("//*[@id='contents_body']/div/div[2]/table/tbody/tr[1]"):
            data_url = row.xpath(".//td[2]/a/@href").get()
            yield response.follow(url=main_url + data_url, callback=self.parse_second_page, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
            })

    # Extract pdate and pdf download link from final webpage
    def parse_second_page(self, response):
        # main_url = 'https://new.kpx.or.kr'
        # final_url = response.xpath("//*[@id='contents_body']/div/article/div[3]/ul/li/span[2]/a/@href").get()
        # url_download = main_url + final_url
        # dt = response.xpath("//*[@id='contents_body']/div/article/ul/li[1]/span/text()").get()[:10]
        # dtx = datetime.strptime(dt, "%Y/%m/%d")
        # pdate_new = datetime.strftime(dtx, "%Y%m%d")
        #
        # # Save the maintenance file into pdf archive directory, renaming using pdate scraped above. We will later revisit this directory using the function above to extract the data and produce the csv.
        mainfolder = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\SouthKorea'
        # if not os.path.exists(os.path.join(mainfolder, 'sk_outages_pdf_archive')): os.mkdir(os.path.join(mainfolder, 'sk_outages_pdf_archive'))
        # filename = os.path.join(mainfolder, 'sk_outages_' + pdate_new + '.pdf')
        # output = open(filename, 'wb')
        # resp = requests.get(url_download)
        # output.write(resp.content)
        # output.close()
        pdate_new = '20230512'
        filename = os.path.join(mainfolder, 'sk_outages_' + pdate_new + '.pdf')
        # Apply the function we defined above to create the csv and export to database, datalake & also keep personal records.
        # This is why we had to define the function before the spider - because the spider uses the function
        print('Mode: ' + mode)
        if mode == 'process_all_PDF':
            os.chdir(mainfolder)
            for pdf in gb.glob("*.pdf"):
                if not '~' in pdf:
                    try:
                        print("Found a pdf to process: {0}".format(pdf))
                        pdate = pdf.replace('.pdf', '').replace('sk_outages_', '')
                        reformat_data(mainfolder, pdate)
                        shutil.move(os.path.join(mainfolder, pdf),os.path.join(mainfolder, 'sk_outages_pdf_archive', pdf))
                        print('File Completed: {0}.'.format(pdf))
                    except Exception as e:
                        sleep(0.1)
                        print(e)
                        print("File moved to error folder.")
                        shutil.move(os.path.join(mainfolder, pdf), os.path.join(mainfolder, 'sk_outages_pdf_error', pdf))
        else:
            print("Processing downloaded pdf file.")
            reformat_data(mainfolder, pdate_new)
            print('File Completed: {0}.'.format(filename))

# Run the spider using command line code, adding a clause to set a delay of 10 seconds when scraping the data - helps to avoid detection to mitigate risk of being banned
cmdline.execute("scrapy runspider KoreaOutages_scraper_old.py --set DOWNLOAD_DELAY=10".split())

print('Ran successfully')