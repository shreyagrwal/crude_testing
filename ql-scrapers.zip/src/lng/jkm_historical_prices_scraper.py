import os
import sys
import time
import pytz
import logging
import argparse
import win32com.client as win32
from datetime import datetime, timedelta

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder
log = logging.getLogger()

targetFolder = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\JKM Broker Curves'


def initiliase_outlook():
    outlook = win32.Dispatch("Outlook.Application")
    mapi = outlook.GetNamespace("MAPI")
    return mapi


def save_message_attachment(mapi):
    root_folder = mapi.Folders.Item(1).Folders['Inbox']
    target_folder = root_folder.Folders['JKM Prices']
    log.debug(root_folder.Name)
    for msg in target_folder.Items:
        count_attachments = msg.Attachments.Count
        received_date = msg.ReceivedTime
        print(received_date, date_to_fill_from)
        if count_attachments > 0:
            log.debug("{0} Attachment(s) Found.".format(count_attachments))
            for att in msg.Attachments:
                att_file_name = os.path.join(targetFolder, att.Filename)
                if '.xlsx' in att_file_name and 'EOD' not in att_file_name:
                    if received_date >= date_to_fill_from:
                        now = datetime.now()
                        time.sleep(2)
                        att_file_name = os.path.join(targetFolder, att.Filename)
                        att.SaveAsFile(att_file_name)
                        print("Attachment Saved: {0}".format(att_file_name))
                        log.debug("Attachment Saved: {0}".format(att_file_name))


if __name__ == '__main__':
    env = se.environment
    log = ag_log.get_log()

    parser = argparse.ArgumentParser()
    parser.add_argument('-backfill', action='store', dest='backfill', default='False', help='backfill historical data')
    parser.add_argument('-backfill_days', action='store', dest='backfill_days', default=365,
                        help='number of days to backfill')
    args = parser.parse_args(sys.argv[1:])

    if args.backfill == 'False':
        date_to_fill_from = datetime.now(pytz.timezone('utc')) - timedelta(days=1)
    else:
        date_to_fill_from = datetime.now(pytz.timezone('utc')) - timedelta(days=int(args.backfill_days))

    print(args.backfill_days, date_to_fill_from)
    mapi_agent = initiliase_outlook()
    save_message_attachment(mapi_agent)
    exit(0)


