import os, sys
sys.path.append(os.getcwd())
from scraper_utils.webpage_monitor import WebsiteMonitor


config_file = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Scraper\WebMonitor\Websites.xlsx'

monitor = WebsiteMonitor('charles.cai@petroineos.com', True)
#monitor.run_monitor(config_file)
monitor.monitor_once(config_file)