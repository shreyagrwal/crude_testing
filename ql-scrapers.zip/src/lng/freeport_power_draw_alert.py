import os
import sys
import time
import shutil
import selenium
import argparse
import glob as gb
import pandas as pd
import datetime as dt
from pytz import timezone
from datetime import timedelta
from selenium import webdriver
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import MaxNLocator
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import WebDriverException

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_secrets import SecretsClient
from ag_email import ag_email_helper as aeh
from src.scraper_utils import scraper_environment as se

env = se.environment
woodmac_secret = SecretsClient().get_secret(name="woodmac")

# username = 'oliver.maddox@petrochinaintl.co.uk'
# password = 'OllieWoodmac2220!'

power_full = 28
dict_time_deltas = {1: 0.1, 3: 0.2, 6: 0.2, 12: 0.2, 24: 0.25}
# Timedelta vs Threshold

_now = dt.datetime.now()
_today = dt.date.today()
first_day_of_T2_quarter = dt.datetime((_now + timedelta(days=-182)).year, 3 * (((_now + timedelta(days=-182)).month - 1) // 3) + 1, 1)
url_front_page = 'https://apps2.genscape.com/Analyst/#/query/template/208'
url_power_monitoring = 'https://apps2.genscape.com/Analyst/#/query/saved/26937'

app_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\WoodMac\NatGas'
temp_path = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\WoodMac\NatGas\download\temp'
diagramFolder = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Diagrams'


def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    # Debug mode disabled

    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": temp_path,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")

    try:
        service = Service(executable_path=".\\tools\\chromedriver.exe")
    except WebDriverException as e:
        log.debug(e)
        log.info('Trying different ChromeDriver path instead: "..\\tools\\chromedriver.exe". ')
        service = Service(executable_path="..\\tools\\chromedriver.exe")
    browser = webdriver.Chrome(service=service, options=chrome_options)
    return browser


def send_report(email_from: str, email_to: str, timestamp_latest, list_imgs, html_df_summary, power_latest):
    folder, img0 = os.path.split(list_imgs[0])
    folder, img1 = os.path.split(list_imgs[1])

    sub = "Freeport Power Change Detected - " + timestamp_latest.strftime("%Y-%m-%d %H:%M") + " local time, latest reading: " + str(round(power_latest, 1)) + 'MG'
    body = f"""
        <b><font size='+2'></font></b>"
        <br>
        <br>{html_df_summary}</b> 
        <br> 
        <img src='cid:{img0}'> 
        <br>
        <img src='cid:{img1}'>
        <br>
        <br>
    """

    email_sender = aeh.AgEmailHelper()
    email_sender.send_mail_with_embedded_images(email_from, email_to, sub, body, list_imgs)
    pass


def download_csv_file(browser, url_data_item):
    ## 1. login
    # go to website
    browser.get(url_data_item)
    time.sleep(5)

    # username Step 1 - NatGas Analyst
    print('Username 1')
    browser.find_element('xpath', '/html/body/div/div/div[2]/form/div/div/div[3]/span/div/div/div/div/div/div/div/div/div/div[1]/div/input').send_keys(woodmac_secret.username)
    time.sleep(0.1)
    browser.find_element('xpath', '/html/body/div/div/div[2]/form/div/div/button').click()
    time.sleep(3)
    # username Step 2 - Verisk
    print('Username 2  - Verisk')
    browser.find_element('xpath', '/html/body/div[2]/main/div[2]/div/div/form/div[1]/div[2]/div[1]/div[2]/span/input').send_keys(woodmac_secret.username)
    time.sleep(0.1)
    browser.find_element('xpath', '/html/body/div[2]/main/div[2]/div/div/form/div[2]/input').click()
    time.sleep(3)
    print('password')
    browser.find_element('xpath', '/html/body/div[2]/main/div[2]/div/div/form/div[1]/div[2]/div[2]/div[2]/span/input').send_keys(woodmac_secret.password)
    time.sleep(0.1)
    browser.find_element('xpath', '/html/body/div[2]/main/div[2]/div/div/form/div[2]/input').click()
    time.sleep(45)

    # Get to power monitoring page
    print('Jump to Power Monitor page.')
    browser.get(url_power_monitoring)
    time.sleep(45)

    print('Query Power draw data.')
    browser.find_element('xpath', '/html/body/div[2]/div[1]/div/div/div[1]/div/div[1]/div[1]/div[1]/span').click()
    time.sleep(45)
    print('Start to download.')
    browser.find_element('xpath', '/html/body/div[2]/div[1]/div/div/div[2]/div/div/div/div[7]/div/div/div[2]/div/div/div[3]/div/div[2]/div[2]/div[4]').click()
    time.sleep(5)
    browser.find_element('xpath', '/html/body/div[2]/div[1]/div/div/div[2]/div/div/div/div[7]/div/div/div[2]/div/div[3]/div/div/div/div[1]/div[3]/button[2]').click()
    time.sleep(5)
    browser.find_element('xpath', '/html/body/div[2]/div[1]/div/div/div[2]/div/div/div/div[7]/div/div/div[2]/div/div[3]/div/div/div/div[2]/div[1]/button[1]').click()
    time.sleep(15)
    print('Download completed.')


def plot_and_email(file_path, list_imgs):
    df = pd.read_csv(file_path)
    df_freeport = df[df['Facility'] == 'Freeport LNG']
    df_freeport['Date Hour'] = pd.to_datetime(df_freeport['Date Hour'])
    df_freeport = df_freeport[df_freeport['Date Hour'] >= (_now - timedelta(days=180)).replace(day=1)]
    timestamp_latest = df_freeport['Date Hour'].max()
    power_latest = df_freeport['Avg of Mag Field (MG)'][df_freeport['Date Hour'] == timestamp_latest].values[0]
    raise_flag = False
    list_summary = []
    df_table = pd.DataFrame()
    for hrs, threshold in dict_time_deltas.items():
        timestamp_past = timestamp_latest + timedelta(hours=-hrs)
        power_past = df_freeport['Avg of Mag Field (MG)'][df_freeport['Date Hour'] == timestamp_past].values[0]
        power_change = abs(power_past - power_latest) / power_full
        print('hrs: ' + str(hrs) + ', latest: ' + str(round(power_latest, 2)) + ', past: ' + str(
            round(power_past, 2)) + ', changes:' + '{: .2%}'.format(power_change))
        if power_change >= threshold:
            raise_flag = True
            list_summary += [
                [str(round(power_latest, 2)), str(round(power_past, 2)), timestamp_past.strftime('%Y-%m-%d %H:%M'),
                 '{: .2%}'.format(power_change)]]
    df_table = pd.DataFrame(list_summary, columns=['Latest Reading, MG', 'Previous Reading, MG', 'Previous Timestamp', 'Change, %'])
    html_df_summary = df_table.to_html(index=False).replace('<tr>', '<tr style="text-align: center;">')

    list_df_for_plot = [df_freeport[df_freeport['Date Hour'] >= (_now - timedelta(days=15))], df_freeport]
    for i in range(len(list_df_for_plot)):
        df_for_plot = list_df_for_plot[i]
        img = list_imgs[i]
        fig, ax1 = plt.subplots(figsize=(9, 3.5))
        ax1.plot(df_for_plot['Date Hour'], df_for_plot['Avg of Mag Field (MG)'], label='Avg of Mag Field',
                 color='black', linewidth=1.5)
        ax1.axhline(y=power_full, color='r', linestyle='--', label='Full Capacity', linewidth=2)

        ax1 = plt.gca()
        ax1.set_ylim([0, 30])
        ax1.set_facecolor("white")
        ax1.set_ylabel('Milligauss (MG)', fontsize=10)
        if i == 0:
            ax1.xaxis.set_minor_locator(mdates.DayLocator(interval=1))
            ax1.xaxis.set_major_locator(mdates.DayLocator(interval=5))
            ax1.xaxis.set_major_formatter(mdates.DateFormatter('%d-%b'))
        else:
            ax1.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
            ax1.xaxis.set_major_locator(mdates.MonthLocator(interval=1))
            ax1.yaxis.set_major_locator(MaxNLocator(integer=True))
        # ax1.yaxis.set_major_locator(mticker.MultipleLocator(1))

        plt.xlabel("Months", fontsize=10)
        ax1.grid(color='dimgrey', linestyle='--', linewidth=0.1, alpha=1, zorder=1)
        # ax1.legend(loc='best', edgecolor='black', facecolor='white', framealpha=1, frameon=True)
        ax1.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), fancybox=True, shadow=True, ncol=5,
                   edgecolor='black', facecolor='white', framealpha=1, frameon=True)
        plt.title('Freeport LNG Terminal Power Line Monitor', fontsize=14)
        plt.tight_layout()
        plt.savefig(img)

    return raise_flag, timestamp_latest, html_df_summary, power_latest


def download_woodmac_data():
    # Remove and create temp folder
    delete_and_recreate_temp_folder()
    # Initiate Chrome Driver
    log.debug("Initiate Chrome Driver.")
    browser = load_chrome_settings()
    # Start Scraping
    log.debug("Let's start bid for the auction")
    download_csv_file(browser, url_front_page)
    # close and close chrone webdriver
    browser.close()
    browser.quit()


def delete_and_recreate_temp_folder():
    if os.path.isdir(temp_path):
        shutil.rmtree(temp_path)
        print('Temp folder removed.')
        time.sleep(5)
    os.mkdir(temp_path)
    print('Temp folder created.')


def main(args):
    # Download the latest WoodMac Freeport Power Draw File
    download_woodmac_data()
    time.sleep(1)

    files = [f for f in os.listdir(temp_path) if '.csv' in f and os.path.isfile(os.path.join(temp_path, f))]
    print(temp_path)
    print(os.listdir(temp_path))
    print(files)
    filename = files[0]
    file_path = os.path.join(temp_path, f'{filename}')
    log.debug(f"Found file to scrape: {file_path}")
    list_imgs = [
        os.path.join(diagramFolder, 'Freeport_LNG_Terminal_Power_Line_Monitor' + _today.strftime('%y-%m-%d') + '2weeks.png'),
        os.path.join(diagramFolder, 'Freeport_LNG_Terminal_Power_Line_Monitor' + _today.strftime('%y-%m-%d') + '6months.png')
    ]
    raise_flag, timestamp_latest, html_df_summary, power_latest = plot_and_email(file_path, list_imgs)
    log.debug(f'File Completed: {file_path}.')

    if args.morning_report == 'True':
        if env == 'UAT':
            send_report(
                'bobby.hemming@petrochinaintl.co.uk',
                'bobby.hemming@petrochinaintl.co.uk',
                timestamp_latest,
                list_imgs,
                html_df_summary,
                power_latest
            )
        else:
            send_report(
                'bobby.hemming@petrochinaintl.co.uk',
                'oliver.maddox@petrochinaintl.co.uk;dong.xia@petroineos.co.uk;bobby.hemming@petrochinaintl.co.uk',  # oliver.maddox@petrochinaintl.co.uk;dong.xia@petroineos.co.uk;
                timestamp_latest,
                list_imgs,
                html_df_summary,
                power_latest
            )
        pass
    else:
        f = open(os.path.join(app_path, f"last_alert.txt"), "r").read()
        timezone_uk = timezone('UTC')
        last_alert = pd.to_datetime(f, utc=True)
        log.info('Raise alert: ', raise_flag, '. Last time alerted: ', last_alert)
        if dt.datetime.now(tz=timezone_uk) >= last_alert + timedelta(hours=6):
            if raise_flag:
                send_report(
                    'bobby.hemming@petrochinaintl.co.uk',
                    'oliver.maddox@petrochinaintl.co.uk;dong.xia@petroineos.co.uk;bobby.hemming@petrochinaintl.co.uk',
                    timestamp_latest,
                    list_imgs,
                    html_df_summary,
                    power_latest
                )
                now = dt.datetime.now()
                now = now.strftime('%Y-%m-%dT%H:%M:%S+00:00')
                with open(os.path.join(app_path, f"last_alert.txt"), 'w') as file:
                    file.write(now)
            pass
    pass


if __name__ == "__main__":
    log = ag_log.get_log()

    parser = argparse.ArgumentParser()
    parser.add_argument('-morning_report', action='store', dest='morning_report', default='False', help='Is this occurrence of the job the morning report')
    parser.add_argument('-env', action='store', dest='env', default=se.environment, help='pick environment of script')

    args_ = parser.parse_args(sys.argv[1:])
    env = args_.env

    exit(main(args_))

