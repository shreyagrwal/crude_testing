import os
import sys
import numpy as np
import pandas as pd
from datetime import datetime, timedelta, date

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder


# Run automatically at 9am each day by ActiveBatch to pull most recent power data
# First define a function to download power data from website
def download_es_power(dt):
    url = "https://www.ree.es/en/balance-diario/peninsula/" + dt
    # This website is easy to scrape: don't need to use scrapy, selenium or requests libraries. Can import directly into a dataframe using pandas.
    # The output is a list composed of many nested dataframes, which we will later extract
    df = pd.read_html(url)

    # Define ddate & pdate
    ddate = datetime.strftime(datetime.strptime(dt, "%Y/%m/%d"), "%Y%m%d")
    pdate = datetime.strftime(datetime.now(), "%Y%m%d")

    # Define a function which takes in a dataframe, inserts PDate column into first column & inserts DDate column into second column
    def format_dataframes(dfx):
        dfx.insert(0, 'PDate', '')
        dfx['PDate'] = [pdate] * len(dfx.index)
        dfx.insert(1, 'DDate', '')
        dfx['DDate'] = [ddate] * len(dfx.index)

    # Apply function to every nested dataframe within df list. Perhaps variable name df is confusing as here df is actually a list. Most other times, df implies a dataframe.
    for item in df:
        format_dataframes(item)

    # Rename columns for all dataframes
    bal_cols = ['PDate', 'DDate', 'Source', 'Day', 'Month', 'ChangeMonth', 'Annual', 'ChangeAnnual', 'RollingYear',
                'ChangeRollingYear']
    renew_cols = ['PDate', 'DDate', 'RenEnergy', 'Day', 'Month', 'ChangeMonth', 'Annual', 'ChangeAnnual', 'RollingYear',
                  'ChangeRollingYear']
    maxdmd_cols = ['PDate', 'DDate', 'MaxDemand', 'Day', 'Month', 'Year', 'Historical']
    hydro_cols = ['PDate', 'DDate', 'Hydro', 'MaxCap', 'Today', 'PercentMax', 'ChangeDay', 'DatePrevYear',
                  'YearOnYearPercent', 'DateStartMonth', 'PercentStartMonth']

    df[0].columns = bal_cols
    df[1].columns = renew_cols
    df[2].columns = maxdmd_cols
    df[3].columns = hydro_cols

    # Define path we will use to save these csv files
    power_path = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\Spain\es_power'

    bal = df[0].to_csv(power_path + '\es_power_balance_' + ddate + '.csv', index=False)
    renew = df[1].to_csv(power_path + '\es_power_renewables_' + ddate + '.csv', index=False)
    maxdmd = df[2].to_csv(power_path + '\es_power_maxdemand_' + ddate + '.csv', index=False)
    hydro = df[3].to_csv(power_path + '\es_power_hydro_' + ddate + '.csv', index=False)


# Now that we have scraped power we need into four separate csv files, we can extract this data and manipulate further to compile one final csv which we need
def espwr_to_dataframe(ddate):
    # Set up paths
    path = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\Spain'
    db_path = bulkUploaderFolder
    # Read in the csv data we need  into a dataframe -  we only need two of the four csv files which we downloaded above, but the other two were downloaded anyway for completion.
    df_bal = pd.read_csv(path + '\es_power\es_power_balance_' + ddate + '.csv')
    values_list = list(df_bal.iloc[:-3, 4])
    daily_list = list(df_bal.iloc[:-3, 3])

    df_hydro = pd.read_csv(path + '\es_power\es_power_hydro_' + ddate + '.csv')
    values_list.append(np.nan)
    daily_list.append(df_hydro.iloc[2, 4])

    # Create list of field headers
    headers_list = ['HydroExclPumps', 'HydroPumps', 'Nuclear', 'Coal', 'CCGT', 'Wind', 'SolarPV', 'SolarThermal',
                    'OtherRen', 'CHP', 'NonRenWaste', 'RenWaste', 'Generation', 'HydroPumpConsump', 'Balearis',
                    'ExchBal', 'Demand', 'HydroStocks']

    # Define ddate and pdate
    ddate2 = datetime.strptime(ddate, "%Y%m%d")
    ddate3 = datetime.strftime(ddate2, "%Y-%m-%d")
    ddate_list = len(values_list) * [ddate3]
    pdate_list = len(values_list) * [datetime.strftime(datetime.now(), "%Y-%m-%d")]

    # Create the dataframe
    es_pwr_df = pd.DataFrame(
        {'PDate': pdate_list,
         'DDate': ddate_list,
         'Fields': headers_list,
         'ValuesMonth': values_list,
         'ValuesDaily': daily_list
         })

    # Export the dataframe as a csv into the desired folders, keeping a local version and then also pushing directly into database
    es_pwr_df.to_csv(path + r'\es_power_for_database' + r'\Upload_LNG_SpanishPowerData-' + ddate + '.csv', index=False)
    es_pwr_df.to_csv(db_path + r'\Upload_LNG_SpanishPowerData-' + ddate + '.csv', index=False)

    su.upload_to_database(es_pwr_df, 'Upload_LNG_SpanishPowerData-')


# New method - APPLY FUNCTIONS ABOVE FOR LAST 10 DAYS IN CASE ANY DAYS OF MISSED DATA UPLOAD, AS THIS WAS THE CASE DURING TESTING STAGE OF THE SCRAPER
# Create list of last ten days
dt_list = [date.today() - timedelta(days=day) for day in range(10)]
# Create two new lists, each with a specific date format of the last 10 days. The first is used to download the data, the second is used to extract csv data and output final csv
dt_list1 = [datetime.strftime(dt, "%Y/%m/%d") for dt in dt_list]
dt_list2 = [datetime.strftime(dt, "%Y%m%d") for dt in dt_list]

# Use for loop to iterate over the two date lists and apply both functions above.
# Use try/except in case we fail for any single date in the trailing ten-day range.
# Otherwise, the whole code would just fail at that stage for that date, and we could miss data that actually existed.
for dt1 in dt_list1:
    for dt2 in dt_list2:
        try:
            download_es_power(dt1)
            espwr_to_dataframe(dt2)
        except:
            pass


print('Ran successfully')
