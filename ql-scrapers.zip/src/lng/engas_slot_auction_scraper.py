import os
import sys
import time
import dotenv
import datetime
from selenium.webdriver.common.by import By
from selenium import webdriver

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_secrets import SecretsClient
from src.scraper_utils import scraper_environment as se
dotenv.load_dotenv()

env = os.environ['environment']
enagas_secret = SecretsClient().get_secret('enagas')
username = enagas_secret.username
password = enagas_secret.password


plant_selections = [
    'PR.BBG <> Planta de Bilbao',
    'PR.BCN <> Planta de Barcelona',
    'PR.CAR <> Planta de Cartagena',
    'PR.HUE <> Planta de Huelva',
    'PR.MUS <> Planta de El Musel',
    'PR.REG <> Planta de Mugardos',
    'PR.SAG <> Planta de Sagunto'
]

# Form Details
start_date = '1/05/2024'
end_date = '30/05/2024'
delivery_day = '20/05/24'    # 13/02/2024
product = '20231101_D_LS_SLOT_01134C'
service = 'Carga de Buque'   # Cartegena  Descargo de Busques
plant_selection = plant_selections[2]
capacity = '1.000.000.000'
url_data = 'https://www.atrgas.com/'
xpath_product_checkbox_w = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/ena-block-collapsable/div/div[2]/div/div/div/div[2]/ena-complextable/div/table/tbody/tr[4]/td[1]/div/label/span'


# xpath_product_checkbox_w = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/ena-block-collapsable/div/div[2]/div/div/div/div[2]/ena-complextable/div/table/tbody/tr[3]/td[1]/div/label/span'
def load_chrome_settings():
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_experimental_option("prefs", {
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type")
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("--js-flags=--expose-gc")
    chrome_options.add_argument("--enable-precise-memory-info")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--enable-automation")
    chrome_options.add_argument("test-type=browser")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-extensions")
    browser = webdriver.Chrome(executable_path="..\\tools\\chromedriver.exe", chrome_options=chrome_options)
    return browser


# XPATH manually gathered locations (may change auction to auction <- it's hard to detect autonomously)
def login_to_enagas(browser, url_data_item):
    browser.get(url_data_item)  # go to website
    time.sleep(1)
    # username and password
    browser.find_element('xpath', '/html/body/div/div/div[2]/form/div[1]/input').send_keys(username)
    time.sleep(0.1)
    browser.find_element('xpath', '/html/body/div/div/div[2]/form/div[2]/input').send_keys(password)
    time.sleep(0.1)
    # Accept
    browser.find_element('xpath', '/html/body/div/div/div[2]/form/div[3]/input').click()
    time.sleep(15)
    pass


def navigate_to_slot_registration_page(browser):
    # Processes
    time.sleep(1)
    browser.find_element('xpath', '/html/body/div[1]/div/div/div/div/div/div/header/div/div[2]/div[2]/nav/ul/li[1]/a').click()
    time.sleep(0.8)
    # Procurement Platform
    browser.find_element('xpath', '/html/body/div[1]/div/div/div/div/div/div/header/div/div[2]/div[2]/nav/ul/li[1]/div/div/ul/li[3]/a').click()
    time.sleep(0.8)
    # Access to Capacity Auction
    browser.find_element('xpath', '/html/body/div[1]/div/div/div/div/div/div/header/div/div[2]/div[2]/nav/ul/li[1]/div/div/ul/li[3]/div/div/ul/li[1]/a').click()
    time.sleep(1)
    # Slot Registration Request Management
    browser.find_element('xpath', '/html/body/div[1]/div/div/div/div/div/div/header/div/div[2]/div[2]/nav/ul/li[1]/div/div/ul/li[3]/div/div/ul/li[1]/div/div/ul/li[2]/a').click()
    time.sleep(1)


def request_search_criteria_fill_form(browser):
    # Start Date & End Date
    xpath_start_date = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/div/div[1]/ena-block-collapsable/div/div[2]/div/div/div[1]/div[1]/ena-inputdate/div/div/input'
    browser.find_element('xpath', xpath_start_date).clear()
    browser.find_element('xpath', xpath_start_date).send_keys(start_date)
    xpath_end_date = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/div/div[1]/ena-block-collapsable/div/div[2]/div/div/div[1]/div[2]/ena-inputdate/div/div/input'
    browser.find_element('xpath', xpath_end_date).clear()
    browser.find_element('xpath', xpath_end_date).send_keys(end_date)
    # Product status
    # todo: check this input Abierto/Publicado for auction setup.
    xpath_product_status = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/div/div[1]/ena-block-collapsable/div/div[2]/div/div/div[1]/div[4]/ena-multiselect/div/span'
    xpath_product_status_search = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/div/div[1]/ena-block-collapsable/div/div[2]/div/div/div[1]/div[4]/ena-multiselect/div/ul/li[1]/input'
    xpath_product_status_search_click = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/div/div[1]/ena-block-collapsable/div/div[2]/div/div/div[1]/div[4]/ena-multiselect/div/ul/li[2]/a/i'
    browser.find_element('xpath', xpath_product_status).click()
    browser.find_element('xpath', xpath_product_status_search).send_keys('Abierto')
    browser.find_element('xpath', xpath_product_status_search_click).click()
    time.sleep(0.2)
    browser.find_element('xpath', xpath_product_status_search).clear()
    browser.find_element('xpath', xpath_product_status_search).send_keys('Publicado')
    browser.find_element('xpath', xpath_product_status_search_click).click()
    time.sleep(0.2)
    # Search
    xpath_search_botton = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/div/div[1]/ena-block-collapsable/div/div[2]/div/div/div[5]/div[2]/ena-button/button'
    browser.find_element('xpath', xpath_search_botton).click()
    time.sleep(0.3)
    pass


def fill_in_request_forms(browser):
    # New Request
    # xpath_new_request = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/ena-block-collapsable/div/div[2]/div/div/div/div[1]/ena-menuaction/div/ul/li/a'
    # browser.find_element('xpath', xpath_new_request).click()
    # time.sleep(0.7)
    # 4. Slot availability management: Selection of available slot Page
    # Checkbox Month
    # todo: maybe different when month rolling, may need more work for multi-months, unable to test atm.
    xpath_checkbox_month = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-mantenimiento-productos-slots/ena-card-container/div/div[2]/div[2]/div[1]/ena-block-collapsable/div/div[2]/div/div/div/div[2]/div[2]/ena-complextable/div/table/tbody/tr/td[1]/div/label/span'
    # browser.find_element('xpath', xpath_checkbox_month).click()
    try_to_access_element(browser, xpath_checkbox_month, 'click', '\nNew Request Page Refresh Time')
    time.sleep(0.2)
    # Show Detail bottom
    xpath_show_details = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-mantenimiento-productos-slots/ena-card-container/div/div[2]/div[2]/div[1]/ena-block-collapsable/div/div[2]/div/div/div/div[2]/div[1]/ena-menuaction/div/ul/li/a/span'
    browser.find_element('xpath', xpath_show_details).click()
    # time.sleep(0.6)
    # pick plant from list
    # todo: need decide plant in advance
    xpath_select_plant = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-mantenimiento-productos-slots/ena-card-container/div/div[2]/div[3]/ena-block-collapsable/div/div[2]/div/div/div/div[1]/ena-combobox/div/select'
    # browser.find_element('xpath', xpath_select_plant).send_keys(plant_selection)
    try_to_access_element(browser, xpath_select_plant, 'send_keys', value=plant_selection,
                          name='\nDetail Page Refresh Time')
    time.sleep(0.01)
    # pick day
    # todo: Can we decide the delivery day in advance?
    xpath_select_day = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-mantenimiento-productos-slots/ena-card-container/div/div[2]/div[3]/ena-block-collapsable/div/div[2]/div/div/div/div[3]/ena-combobox/div/select'
    browser.find_element('xpath', xpath_select_day).send_keys(delivery_day)
    time.sleep(0.01)
    # Accept
    xpath_accept2 = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-mantenimiento-productos-slots/ena-card-container/div/div[2]/div[3]/ena-block-collapsable/div/div[2]/div/div/div/div[4]/ena-button/button'
    browser.find_element('xpath', xpath_accept2).click()
    # time.sleep(0.5)
    # 5. Request Page
    # Service
    xpath_service = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-formulario-solicitudes-slots/ena-card-container/div/div[2]/div[2]/div[1]/ena-block-collapsable[1]/div/div[2]/div/div/div/div[11]/ena-combobox/div/select'
    # browser.find_element('xpath', xpath_service).send_keys(service)
    try_to_access_element(browser, xpath_service, 'send_keys', value=service, name='\nRequest Page Refresh Time')
    time.sleep(0.01)
    # Capacity
    xpath_capacity = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-formulario-solicitudes-slots/ena-card-container/div/div[2]/div[2]/div[1]/ena-block-collapsable[2]/div/div[2]/div/div/div/div[2]/ena-inputformat/div/input'
    browser.find_element('xpath', xpath_capacity).send_keys(capacity)
    time.sleep(0.01)
    # Buque Metanero
    xpath_buque_metanero = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-formulario-solicitudes-slots/ena-card-container/div/div[2]/div[2]/div[1]/ena-block-collapsable[2]/div/div[2]/div/div/div/div[5]/ena-combobox/div/select'
    browser.find_element('xpath', xpath_buque_metanero).send_keys('DESCONOCIDO')
    time.sleep(0.01)
    # Origin
    xpath_origin = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-formulario-solicitudes-slots/ena-card-container/div/div[2]/div[2]/div[1]/ena-block-collapsable[2]/div/div[2]/div/div/div/div[8]/ena-combobox/div/select'
    browser.find_element('xpath', xpath_origin).send_keys('DESCONOCIDO')
    time.sleep(0.01)
    # Destination    <- some
    # TODO: this option sometimes does not appear, add a try except cluase
    xpath_destination = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-formulario-solicitudes-slots/ena-card-container/div/div[2]/div[2]/div[1]/ena-block-collapsable[2]/div/div[2]/div/div/div/div[9]/ena-combobox/div/select'
    try:
        browser.find_element('xpath', xpath_destination).send_keys('DESCONOCIDO')
        time.sleep(0.01)
    except Exception as e:
        pass
    print('Ready to submit.')


def try_to_access_element(browser, xpath, action='click', value=None, name=''):
    element_accessed = False
    while not element_accessed:
        try:
            if action == 'click':
                browser.find_element('xpath', xpath).click()
            elif action == 'send_keys':
                browser.find_element('xpath', xpath).send_keys(value)
            else:
                raise NotImplemented('Action not recognised')
            element_accessed = True
        except Exception as e:
            time.sleep(0.02)


def access_to_the_webpage(browser, url_data_item):
    # 1. login  -> wait for 2-factor auth
    login_to_enagas(browser, url_data_item)
    # 2. Landing Page
    navigate_to_slot_registration_page(browser)
    # site2 = browser.find_elements(By.XPATH, "//*[contains(text(), '"+product+"')]")
    # todo: do we need locate the checkbox using product name instead of direct xpath? e.g. can we know the xpath in advance.

    # # INPUT BEFOREHAND
    # xpath_new_request = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/ena-block-collapsable/div/div[2]/div/div/div/div[1]/ena-menuaction/div/ul/li/a'
    xpath_new_request = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/ena-block-collapsable/div/div[2]/div/div/div/div[1]/ena-menuaction/div/ul/li/a'

    # WAIT, CHECK FOR OPEN AUCTION
    i = 0
    refresh_time = 0.01  # depends on machine/website
    auction_open = False
    start_time_worst = datetime.datetime.now()
    request_search_criteria_fill_form(browser)
    print('Waiting...')
    while not auction_open:
        print(f'Count: {i}, {datetime.datetime.now()}')
        try:
            if i < 2:
                raise Exception('Manual fail')
            # SELECT THE CORRECT XPATH FOR DESIRED AUCTION
            browser.find_element('xpath', xpath_product_checkbox_w).click()
            print('checked')
            time.sleep(0.2)
            browser.find_element('xpath', xpath_new_request).click()
            print('clicked')
            # if new request avialable but error message displayed:
            # xpath_error_box = /html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/div/div[2]/ena-block-notification/div/ena-notification[2]/div/div
            auction_open = True
            start_time = datetime.datetime.now()
            print('Worked')
        except Exception as e:
            i += 1
            # browser.refresh()
            xpath_search_botton = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/div/div[1]/ena-block-collapsable/div/div[2]/div/div/div[5]/div[2]/ena-button/button'
            # xpath_search_botton = '/html/body/app/main/ena-gestion-solicitudes-slot/ena-card-container/div/div[2]/div/div[1]/ena-block-collapsable/div/div[2]/div/div/div[5]/div[2]/ena-button/button'
            browser.find_element('xpath', xpath_search_botton).click()
            time.sleep(0.3)
            # time.sleep(refresh_time)
            start_time_worst = datetime.datetime.now()
            print('Auction not open yet')
            pass
        if i > 10:
            print('Manual exit')
            break
        pass
    fill_in_request_forms(browser)
    end_time = datetime.datetime.now()
    print('Worst Start Time: ', start_time_worst)
    print('Form Fill Start Time: ', start_time)
    print('Submit Time: ', end_time)
    print(f'Form Fill Time taken: seconds={(end_time - start_time).seconds + (end_time - start_time).microseconds / 10 ** 6}')
    print(f'Worst Case: Time taken: seconds={(end_time - start_time_worst).seconds + (end_time - start_time_worst).microseconds / 10 ** 6}')

    # Send Request Button
    # xpath_send_request = ''
    # browser.find_element('xpath', xpath_send_request).click()
    # time.sleep(0.2)
    # TODO: submit the format
    # After send, you will send confirmation box
    # xpath_confirmation_yes  = '/html/body/app/main/ena-flexibilidad-slot/ena-formulario-solicitudes-flex/ena-modal[3]/div/div/div/div[3]/button[1]'
    # browser.find_element('xpath', xpath_confirmation_yes).click()
    time.sleep(100)
    print('Success')


def main():
    try:
        # Initiate Chrome Driver
        log.debug("Initiate Chrome Driver.")
        browser = load_chrome_settings()
        # Start Scraping
        log.debug("Let's start bid for the auction")
        access_to_the_webpage(browser, url_data)
        # close and close chrone webdriver
        browser.close()
        browser.quit()
        return 0
    except Exception as e:
        log.error(e)
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())
