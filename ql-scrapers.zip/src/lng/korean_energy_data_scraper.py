import os, sys
sys.path.append(os.getcwd())
import requests
from bs4 import BeautifulSoup
import lxml
import os.path
import time
from ag_log import ag_log
from scraper_utils import scraper_environment as se
from ag_data_access import blueocean_access as bo

env = se.environment
bulkUploaderFolder = se.ingestion_folder

log = ag_log.get_log()

url = 'https://www.kpx.or.kr/www/selectBbsNttList.do?key=21&bbsNo=150&searchCtgry=&pageUnit=10&searchCnd=all&searchKrwd=&integrDeptCode=&pageIndex=1'
url_root = 'https://www.kpx.or.kr/'
appfolder = 'C:\Public\KoreanEnergy\\'

log.debug("Start scraping Korean Power Limitation data")
log.debug("URL Link: {0}".format(url))

response = requests.get(url)
if not response.ok:
    log.debug("Error found when requesting webpage "+url)
    exit(1)

soup = BeautifulSoup(response.text, 'lxml')

#log.debug(soup.prettify())

anchors = soup.find_all('a')
for anchor in anchors:
    log.debug("Anchor Found.")
    #getting title attribute of one example of ancher from inspect
    #<a href="/www/downloadBbsFile.do?atchmnflNo=33986" title="2021년 3월 1주차 발전기별 예방정비계획.pdf 다운로드">
    if anchor.has_attr('title'):
        log.debug("Title Found in Anchor.")
        title = anchor['title']
        if 'pdf' in title:
            log.debug("PDF Found in Title.")
            title = title[:title.index("pdf") + 3]
            # UnicodeEncodeError Message will appear during execution, no impact to the scraper
            log.debug("Report Found: {0}.".format(title))
            #getting href link address from inspect
            href = anchor['href']
            filename = appfolder + title

            if not os.path.exists(filename):
                res = requests.get(r'https://www.kpx.or.kr/'+href)
                pdf = open(filename, 'wb')
                pdf.write(res.content)
                pdf.close()
                log.debug("Report Downloaded.")
                time.sleep(10)
            else:
                log.debug("Report Already Downloaded.")

log.debug("Job Completed.")
#log.debug(anchors)




