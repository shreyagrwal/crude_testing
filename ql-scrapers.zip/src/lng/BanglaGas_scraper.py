import os
import sys
import time
import pandas as pd
import urllib.request
from random import randint
from tabula import read_pdf
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment

bulkUploaderFolder = se.ingestion_folder
# Define the webpage we will be scraping with selenium, and also the pdate that we will use in the script
webpage = r"http://www.petrobangla.org.bd/site/view/reports/%E0%A6%A6%E0%A7%88%E0%A6%A8%E0%A6%BF%E0%A6%95%20%E0%A6%97%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%B8%20%E0%A6%87%E0%A6%A8%E0%A6%9F%E0%A7%87%E0%A6%95-%E0%A6%85%E0%A6%AB%E0%A6%9F%E0%A7%87%E0%A6%95%20%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A4%E0%A6%BF%E0%A6%AC%E0%A7%87%E0%A6%A6%E0%A6%A8/-?page=31&rows=20"
pdate = datetime.strftime(datetime.today(), "%Y-%m-%d")

# Step 1 - navigate to the correct url

# initialise selenium chromedriver
chrome_options = Options()
chrome_options.headless = True
driver = webdriver.Chrome(ChromeDriverManager().install())
driver.get(webpage)
time.sleep(randint(2, 5))

log = ag_log.get_log()

# create a list of all the @href elements, i.e. all the urls on the page
elems = driver.find_element('xpath', '"//a[@href]"').click()
url_list = []
for elem in elems:
    url_list.append(elem.get_attribute("href"))

# keep only the url's which contain the url below, as these are the ones we want to scrape. also pull out a list of dates by slicing the remaining urls - as they contain date in the url
url_type = 'http://www.petrobangla.org.bd/sites/default/files/files/petrobangla.portal.gov.bd/reports/'
url_list = list(filter(lambda x: url_type in x, url_list))
dt_list = list(url[127:137] for url in url_list)

# We only want the first entry - i.e. the most recent data which will be scraped daily - the rest will already be in the database
url = url_list[0]
dt = dt_list[0]

# convert the raw date string to a datetime object, and then back to a date with the desired format of %Y%m%d
ddate_file = datetime.strftime(datetime.strptime(dt, "%Y-%m-%d"),"%Y%m%d")
driver.close()


# Step 2 - download the data as pdf
# Define a function which uses urllib.request to download a pdf using a given url which we have already scraped in the step above
def download_file(download_url, filename):
    response = urllib.request.urlopen(download_url)
    file = open(filename + ".pdf", "wb")
    file.write(response.read())
    file.close()


abs_path = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\Bangla\bd_gas_scrape'
# Apply rhe function above to download and save the pdf to the path defined using the absolute path
download_file(url, abs_path + r'\pdf_archive\BanglaGasDataPdf_' + ddate_file)

# Define the path to the database output for later on, when we push the final csv directly into the database
db_path = bulkUploaderFolder


# Step 3 - extract the data from pdf and output csv

# try/except as sometimes we will be missing some dates (as data source is inconsistent)
try:
    # use tabula library read_pdf function to directly read the downloaded pdf into a dataframe
    data = read_pdf(abs_path + r'\pdf_archive\BanglaGasDataPdf_' + ddate_file + '.pdf')
    # create a new version of ddate which must adhere to the database format of %Y-%m-%d - will be used in the PDate & DDate columns of the final csv
    ddate_data = datetime.strftime(datetime.strptime(ddate_file, "%Y%m%d"),"%Y-%m-%d")

    # Define a function which only pulls out digits (e.g. 01234) from a given string
    def pull_digits(s):
        digits = []
        for d in s.split():
            try:
                digits.append(float(d))
            except ValueError:
                pass
        return digits

    # Often the source pdf will not be formatted properly as per the rules below
    # When this happens, need to capture these, pass and output error
    # Hence use another try/except

    try:
        # We define two separate lists, for production and distritubtion data from the pdf, i.e. supply and demand data
        # The production data in the pdf can often be formatted in two different ways, hence we must accoutn for this with an if/else statement
        if str(data[0].iloc[23, 2]) == 'nan':
            prod = list(data[0].iloc[23, 4:6]) + list(data[0].iloc[29, 4:6]) + list(data[0].iloc[31, 4:6]) + list(
                data[0].iloc[-1, 4:6])
        else:
            prod = list(data[0].iloc[23, 3:5]) + list(data[0].iloc[29, 3:5]) + list(data[0].iloc[31, 3:5]) + list(
                data[0].iloc[-1, 3:5])

        dist = list(data[1].iloc[-8,:-1])

        # Pull together all list values into a single string
        prod_str = ' '.join(str(x) for x in prod)
        dist_str = ' '.join(str(x) for x in dist)

        # Remove any string element that isn't a digit, and also remove all nan values, finally converting back to lists
        prod = [x for x in pull_digits(prod_str) if str(x) != 'nan']
        dist = [x for x in pull_digits(dist_str) if str(x) != 'nan']

        # Combine all lists together
        output_list = [pdate] + [ddate_data] + prod + dist
        # Define dataframe headers
        headers = [
            'PDate','DDate','DomGasCap','DomGasProd','DomConProd','IOCGasCap','IOCGasProd','IOCConProd','LNGGasCap',
            'LNGGasProd','LNGConProd','TotGasCap','TotGasProd','TotConProd','PowDmd','PowSup','FertDmd', 'FertSup',
            'OthSup','TotSup'
        ]
        # Define the final dataframe & apply new headers
        df = pd.DataFrame([output_list])
        df.columns = headers
        # Keep a record in our own folders
        df.to_csv(abs_path + r'\for_database\Upload_LNG_BanglaGasData-' + ddate_file + '.csv' , index=False)
        # Automatically push into database
        su.upload_to_database(df, 'Upload_LNG_BanglaGasData-')
    except:
        # This error will happen when we are able to read the pdf into a dataframe, but are unable to capture all the data due to inconsistent data formatting
        log.debug(ddate_data + ' - something has gone wrong - doesnt let me download pdf and output csv automatically')
        pass
except:
    pass

log.info('Ran successfully')