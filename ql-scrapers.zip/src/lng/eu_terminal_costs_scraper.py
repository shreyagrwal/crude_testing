"""
Author: Bobby Hemming
Scheduled: Custom
"""
import os
import sys
import math
import time
import shutil
import argparse
import numpy as np
import pandas as pd
import xlwings as xw
from contextlib import suppress
from openpyxl import load_workbook
from collections import OrderedDict
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_data_access import data_upload as du
from ag_datagenic_rest_client import DataGenic
from ag_data_access import blueocean_access as bo
from scraper_utils import scraper_environment as se

temp_path = r'H:\dev\temp'
pd.set_option('display.max_columns', 50)
pd.set_option('display.max_colwidth', 50)
pd.set_option('display.expand_frame_repr', False)
pd.set_option('display.max_rows', 70)

terminal_curve_mapping = {
    'Adriatic': 'PSV',
    'Dragon': 'NBP',
    'Dunkirk': 'PEG',
    'Eemshaven': 'TTF',
    'Fos Cavaou': 'PEG',
    'Gate': 'TTF',
    'German FSRUs': 'N/A',
    'Grain': 'NBP',
    'Lubmin': 'THE',
    'Montoir': 'PEG',
    'OLT Toscana': 'PSV',
    'South Hook': 'NBP',
    'Spain': 'PVB',
    'Zeebrugge': 'ZTP'
}

thermal_unit_conversion = {
    'therm/MMBtu': 0.1
}


def read_unpivoted_data(data):
    data = data.dropna(axis=0, how='all')
    data = data.drop(index=data[data['Unnamed: 1'] == '#NAME?'].index)
    data = data.rename(columns={'Unnamed: 0': 'Terminal', 'Unnamed: 1': 'Units'})
    print(data)
    df_units = data.copy(deep=True)[['Terminal', 'Units']]
    df_units = df_units.dropna(axis=0, how='all')
    df_units = df_units
    df_units = df_units.iloc[1:17]  # .set_index('Terminal', drop=True)
    print(df_units)
    df_units = df_units.ffill(axis=0)
    print(df_units)

    df_costs = data.drop(columns=['Units'])
    df_costs['Terminal'] = df_costs['Terminal'].ffill(axis=0)
    df_costs = df_costs.drop(index=2)
    df_costs = df_costs.set_index('Terminal').T
    print(df_costs)
    df_costs = df_costs.drop(index=['Unnamed: 16'], columns=[np.nan])
    print(df_costs.columns)
    df_country = df_costs[['Country']]
    df_costs = df_costs.drop(columns=['Country'])

    print('\n')
    print(df_costs.reset_index())
    df_costs = df_costs.reset_index().melt(id_vars='index', var_name='Measure',
                                           value_vars=[col for col in df_costs.columns if col != 'index'])
    # df_costs.to_csv(os.path.join(temp_path, 'costs_template.csv'))

    df_units.to_csv(os.path.join(temp_path, 'units_template.csv'))
    pass


def fetch_terminal_costs(terminal: str = None, pdate: str = None):
    if not pdate:
        pdate_query = "SELECT MAX(PDate) as pdate FROM workspace.bobbyhemming.lng_terminal_costs_v1 where isActive = true"
        pdate = bo.get_data(pdate_query).loc[0, 'pdate']
    if not terminal:
        return bo.get_data(f"""
            SELECT Terminal, CostType, Cost, Unit
            FROM workspace.bobbyhemming.lng_terminal_costs_v1
            WHERE PDate = '{pdate}' AND isActive = True
        """)
    else:
        return bo.get_data(f"""
            SELECT Terminal, CostType, Cost, Unit
            FROM workspace.bobbyhemming.lng_terminal_costs_v1
            WHERE Terminal = '{terminal}' and PDate = '{pdate}' AND isActive = True
        """)


def fetch_ng_forward_curve(curve: str, pdate: str = None):
    if not pdate:
        pdate_query = """
            SELECT MAX(PDate) as pdate 
            FROM workspace.bobbyhemming.natural_gas_futures_curves_v1 
            WHERE isActive = True"""
        pdate = bo.get_data(pdate_query).loc[0, 'pdate']

    return bo.get_data(f"""
        SELECT Curve, Source, Contract, Price, ExpiryDate, Period, ContractType, PriceType, PricingDays, Unit, Currency, 
        CurrencyUnit,EnergyUnit, PDate
        FROM workspace.bobbyhemming.natural_gas_futures_curves_v1
        WHERE Curve = '{curve}' and PDate = '{pdate}' and IsActive = True
        ORDER BY ExpiryDate ASC
    """)


def fetch_fx_forward_curve(fx: str, contract, pdate: str):
    if fx == 'GBP/USD':
        model_id = f'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0017523.{contract}/RATE/ALL'
    elif fx == 'EUR/USD':
        model_id = f'model://RTR_FX_PETRO/EU.FX.RTRS.FWD.USD.EUR.{contract}/MID/ALL'
    else:
        print(f'FX: {fx} does not have model id assigned yet (for DG)')
        raise NotImplemented

    datagenic_env = DataGenic.create_from_environment()
    data = datagenic_env.get_time_series(
        model_url=model_id,
        from_date=datetime.now()-relativedelta(years=5, days=40),
        to_date=datetime.now().date()
    )

    if fx == 'EUR/USD':
        spot_data = datagenic_env.get_time_series(
            model_url='model://PLATTS_FX/PLATTS.EXCH.FX.AACOP00/INDEX/ALL',
            from_date=datetime.now() - relativedelta(years=5, days=40),
            to_date=datetime.now().date()
        )
        spot_fx = spot_data.loc[pdate, 'PRICE']
        return 1.0794 + data.loc[pdate, 'PRICE']/10000
    return data.loc[pdate, 'PRICE']


def trial_fx_fetch():
    fx_contracts = ['M01', 'M02', 'M03', 'M04', 'M05', 'M06', 'M09']
    fx = 'EUR/USD'
    coi_fx = [fetch_fx_forward_curve(fx, cfx, '2023-12-12') for cfx in fx_contracts]
    fx = pd.DataFrame({'Contract': fx_contracts, 'fx_rate': coi_fx})
    print(fx)
    pass


def main():
    data_pdate = None    # None = take the max pdate
    terminal = None  # Select terminal of interest

    # Terminal Fixed Costs
    terminal_costs = fetch_terminal_costs(terminal=terminal, pdate=data_pdate)

    terminal_costs['Unit'] = terminal_costs['Unit'].apply(lambda x: x.strip()).replace(' ', '')  # .strip()
    terminal_costs['Cost'] = terminal_costs['Cost'].apply(lambda x: x.replace(',', '') if isinstance(x, str) else x)
    terminal_costs['Cost'] = terminal_costs['Cost'].apply(lambda x: float(x.replace('%', ''))/100 if '%' in str(x) else float(x))
    # print(terminal_costs, terminal_costs['Unit'].unique())

    # Curve
    forward_curve = fetch_ng_forward_curve(curve=terminal_curve_mapping[terminal], pdate=data_pdate)
    # Select contracts -> contracts of interest: months range M1-M5
    m1, m5 = datetime.now().replace(day=1) + timedelta(days=31), datetime.now().replace(day=1) + timedelta(days=5*31)
    coi = pd.date_range(m1, m5, freq='MS').strftime("%b-%y").tolist()  # contracts of interest
    forward_curve = forward_curve[forward_curve['Contract'].isin([x.upper() for x in coi])]

    # Units Conversion
    currency_unit, thermal_unit = forward_curve.loc[0, 'Unit'].split('/')
    fx, thermal_conv = 'GBP/USD', thermal_unit_conversion[thermal_unit+'/MMBtu']
    fx_contracts = [x.strftime("%Y")+f'M{x.strftime("%m")}' for x in pd.date_range(m1, m5, freq='MS').tolist()]
    coi_fx = [fetch_fx_forward_curve(fx, cfx, '2023-12-07') for cfx in fx_contracts]
    print(fx_contracts, coi, coi_fx)

    conversion_matrix = pd.DataFrame({'Contract': [x.upper() for x in coi], 'FX Curve': fx_contracts, 'fx_rate': coi_fx, 'thermal_conv': [thermal_conv]*5})

    forward_curve = pd.merge(forward_curve, conversion_matrix, how='inner', on='Contract')
    forward_curve['cPrice'] = (forward_curve['Price'])/(forward_curve['thermal_conv']*forward_curve['fx_rate']*100)

    print(terminal_costs, terminal_costs['CostType'].unique())
    tfc = terminal_costs[terminal_costs['Unit'] == 'eur/mmbtu'].pivot(index='Terminal', columns='CostType', values='Cost').fillna(0)
    print(tfc)
    print(forward_curve.head(10))
    fc = tfc['Fixed Costs'] + tfc['Grid Entry']
    variable_price = forward_curve.copy(deep=True)
    variable_price['Fixed Costs'] = fc
    variable_price['Variable Costs'] = (variable_price['cPrice']*tfc.loc[terminal, 'Fuel Gas']) + (tfc.loc[terminal, 'Basis'] + tfc.loc[terminal, 'Electricity'] + tfc.loc[terminal, 'Thermal Energy'] + tfc.loc[terminal, 'Additional Fees'])*variable_price['fx_rate']
    print(fc)
    print(variable_price)
    exit()

    print(tfc)
    print(conversion_matrix)
    print(coi_fx)
    print(terminal_costs.head(10))
    pass


if __name__ == '__main__':
    env = se.environment
    log = ag_log.get_log()

    # trial_fx_fetch()
    main()

    pass
