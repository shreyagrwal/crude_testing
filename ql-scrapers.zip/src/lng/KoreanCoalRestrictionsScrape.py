import os, sys
sys.path.append(os.getcwd())
from bs4 import BeautifulSoup
import requests
import time
import smtplib
import win32com.client as win32
from ag_log import ag_log
from scraper_utils import scraper_environment as se
from ag_data_access import blueocean_access as bo

log = ag_log.get_log()
env = se.environment
bulkUploaderFolder = se.ingestion_folder

while True:

    url = "https://www.kpx.or.kr/www/selectBbsNttList.do?key=21&bbsNo=150&searchCtgry=&pageUnit=10&searchCnd=all&searchKrwd=&integrDeptCode=&pageIndex=1"
    # Change basis what you're searching for
    searchnumber = '218'

    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "lxml")
    date = soup.find("td").getText()
    log.debug(date)

    if str(date).find(searchnumber) == -1:
        log.debug("Failed")
        time.sleep(10800)
        continue
    else:
        msg = 'Subject: Korean Coal Restrictions Data Published'
        fromaddr = 'oliver.maddox@petrochinaintl.co.uk'
        # set the 'to' addresses,
        toaddrs = ['oliver.maddox@petrochinaintl.co.uk']
        log.debug("Found")
        outlook = win32.Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
        mail.To = "oliver.maddox@petrochinaintl.co.uk"
        mail.Subject = msg
        mail.Body = msg

        mail.Send()

        # Print the email's contents
        log.debug('From: ' + fromaddr)
        log.debug('To: ' + str(toaddrs))
        log.debug('Message: ' + msg)


        break
log.debug('Job Completed.')
