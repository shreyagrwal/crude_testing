import os, sys
sys.path.append(os.getcwd())
import pandas as pd
import requests
import urllib
import tabula
from datetime import datetime, timedelta, date
from ag_log import ag_log
from scraper_utils import scraper_environment as se
from ag_data_access import blueocean_access as bo
env = se.environment
bulkUploaderFolder = se.ingestion_folder
pan_url = 'https://www.pancanal.com/eng/maritime/transit/TransitTimeProjections.pdf'
#path = 'I:/Gas Power and Emission Dept/LNG/LNG Analytics/Country models/ScrapeFolder/PanCan'
path = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\PanCan'

# Step 1 - download the pdf

date_name = datetime.strftime(datetime.now(), "%Y%m%d")

def download_file(download_url, filename):
    response = urllib.request.urlopen(download_url)
    file = open(filename + ".pdf", "wb")
    file.write(response.read())
    file.close()

try:
    #download_file(pan_url, path + '/pancan_daydelays-' + date_name)
    download_file(pan_url, path + r'\pancan_daydelays-' + date_name)
except:
    pass

# Step 2 - pull out data from pdf

table = tabula.read_pdf(path + '/pancan_daydelays-' + date_name + '.pdf',pages=1)
pc_df = table[0].loc[:,['Vessel Size', 'Northbound', 'Southbound']]
pc_df['PDate'] = [datetime.strftime(datetime.now(), "%Y-%m-%d")] * len(pc_df)
pc_df = pc_df[['PDate','Vessel Size','Northbound','Southbound']]
pc_df.columns = ['PDate','VesselSize','Northbound','Southbound']
pc_df['Average'] = (pc_df['Northbound']+pc_df['Southbound'])/2

# Step 3 - export data as csv
#pc_df.to_csv(path + '/ForDatabase/Upload_LNG_PanCanDayDelays-' + date_name + '.csv', index=False )
pc_df.to_csv(path + r'\ForDatabase\Upload_LNG_PanCanDayDelays-' + date_name + '.csv', index=False )

print('Ran successfully')