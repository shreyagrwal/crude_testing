import os
import sys

sys.path.append(os.getcwd())
from ag_log import ag_log
from scraper_utils import scraper_upload as su
from ag_data_access import blueocean_access as bo

temp_loc = r'C:\Users\bobbyhemming\temp\kpler_tables'

# UTILIZATION
rename_dict = {
    'vessel_imo': 'vessel_imo',
    'vessel_name': 'vessel',
    'vessel_capacity_cubic_meters': 'vessel_capacity_m3',
    'vessel_type': 'vessel_type',
    11: 'vessel_state',  # Ballast, Null, Loaded, Maintenance
    12: 'current_continent',
    13: 'current_sub_continent',
    14: 'current_country',
    15: 'current_sea',
    16: 'current_sea_entry_date',
    17: 'current_sea_exit_date',
    18: 'current_sea_duration',
    19: 'voyage_id',
    'last_port_call_id': 'last_port_call_id',
    'last_port_call_location_name': 'last_port',
    22: 'last_country',
    'next_forecasted_port_call_id': 'next_port_call_id',
    'next_destination_zone_name': 'next_port',
    25: 'next_country',
    'heading': 'vessel_direction',
    'is_floating_storage':	'is_floating_storage',
    28:	'vessel_fpso',
    29:	'next_subcontinent',
    30:	'next_continent',
    'nextdestinationeta':	'next_eta',
    32:	'fleet_product_id',
    33:	'shipyard',
    34:	'shipyard_arrival',
    35:	'shipyard_departure',
    36:	'shipyard_duration',
    'pdate': 'pdate',
    'ddate': 'ddate',
    39:	'current_sea_entry_ddate',
    40: 'current_sea_exit_ddate',
}


def get_vessel_position_data():
    query = f"""
        SELECT * FROM fundamental.shipping.kpler_lng_vesselposition
        WHERE '2023-06-19' <= pdate 
            AND HOUR(pdate) == 18
    """
    data = bo.get_data(query)
    return data


def get_kpler_trades_data():
    query = f"""
        SELECT * FROM workspace.bobbyhemming.lng_kpler_tradesdaily
        WHERE '2023-06-19' <= pdate 
            AND IsActive = True
        ORDER BY PDate ASC
    """
    data = bo.get_data(query)
    return data


def get_kpler_vessel_utilization():
    query = f"""
        SELECT *
        FROM fundamental.shipping.lng_kpler_vessel_fleet_utilization_backfill
        WHERE '2023-06-19' <= PDATE 
        ORDER BY ddate DESC
    """
    data = bo.get_data(query)
    return data


def engineer_features(data):
    data['ddate'] = data['pdate']
    return data


def main():
    data_position = get_vessel_position_data()
    data_trades = get_kpler_trades_data()
    target = get_kpler_vessel_utilization()

    data_position.to_csv(os.path.join(temp_loc, 'position.csv'), index=False, encoding='utf-8-sig')
    data_trades.to_csv(os.path.join(temp_loc, 'trades.csv'), index=False, encoding='utf-8-sig')
    target.to_csv(os.path.join(temp_loc, 'target.csv'), index=False, encoding='utf-8-sig')

    exit()

    list1 = sorted(list(data_position.columns))
    list2 = sorted(list(data_trades.columns))
    target_cols = sorted(list(target.columns))
    print(list1)
    print(list2)
    print('='*10)
    print(target_cols)
    print('\n')
    a = list(set(list1).intersection(target_cols))
    b = list(set(list2).intersection(target_cols))
    print(a)
    print(b)
    # print(sorted(list(target.columns)))

    exit()

    data = engineer_features(data)

    data = data.rename(columns=rename_dict)
    su.upload_to_database(data, 'kplervesselutilization')


if __name__ == '__main__':
    main()
    pass
