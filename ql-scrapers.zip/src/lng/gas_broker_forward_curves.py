"""
    Author: Bobby Hemming
    Created: 2024-04-20
    Modified: 2024-05-06
    Description:
        Script to process LNG Broker Contract Prices and upload to BlueOcean / Database.
        Some important notes:
        - Two brokers used so far are 'TP' and 'ICAP' (maybe later 'GFI').
        - The Excel files should always be processed with Pandas, we  don't want to lock
        the files on the serves with something like excel wings.
        - The curve is organised to approach the data per Broker file, per curve in
        extracted data. Since each broker, and even each curve for each broker is stored
        and structured differently making the extraction specific to each broker-curve
        pair.
        - The specific values and targets for each broker and curve are specified in the
        dictionaries in the global scope before methods. Please adjust these if data in
        the underlying file changes.
        - OR if the structure has changed please review the methods 'parse_raw_..._data'
        and adjust. Try and avouid

"""

import os
import sys
import math
import time
import shutil
import dotenv
import argparse
import datetime
import calendar
import numpy as np
import pandas as pd
from functools import reduce
from dateutil.relativedelta import relativedelta

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_data_access import data_upload as du
from ag_datagenic_rest_client import DataGenic
from src.tools.set_pandas_view_options_max import set_pandas_options_to_max
dotenv.load_dotenv()

env_var = os.environ.get('environment', None)
env = 'UAT' if os.environ['environment'] is None else env_var

BROKER_FILENAME_PATTERNS = {
    'TP': ['TP LNG EOD Report'],
    'ICAP': ['LNG Closing Run']
}

BROKER_DATE_FORMAT = {
    'TP': '%Y%m%d',
    'ICAP': '%Y %m %d',
}

BROKER_SPLIT_CHAR = {
    'TP': ' ',
    'ICAP': '- '
}

BROKER_PRICE_COL = {
    'TP': {'JKM': 'Mid-point', 'JKM/TFU': 'JKM/TFU', 'PVB/TTF': 'PVB/TTF'},
    'ICAP': {'JKM': 'Last', 'JKM/TFU': 'Last', 'PVB': 'Last', 'PVB/TTF': 'vs TTF'}
}

BROKER_CURVE_PRICE_TYPE = {
    'TP': {'JKM': 'mid', 'JKM/TFU': 'mid', 'PVB/TTF': 'mid'},
    'ICAP': {'JKM': 'mid', 'JKM/TFU': 'mid', 'PVB': 'Last', 'PVB/TTF': 'Last'}
}

BROKER_CURVE_UNITS = {
    'TP': {
        'JKM': {'Unit': 'USD/MMBtu', 'Currency': 'USD', 'CurrencyUnit': 'dollar', 'EnergyUnit': 'MMBtu'},
        'JKM/TFU': {'Unit': 'USD/MMBtu', 'Currency': 'USD', 'CurrencyUnit': 'dollar', 'EnergyUnit': 'MMBtu'},
        'PVB/TTF': {'Unit': 'EUR/MWh', 'Currency': 'EUR', 'CurrencyUnit': 'euro', 'EnergyUnit': 'MWh'},
    },
    'ICAP': {
        'JKM': {'Unit': 'USD/MMBtu', 'Currency': 'USD', 'CurrencyUnit': 'dollar', 'EnergyUnit': 'MMBtu'},
        'JKM/TFU': {'Unit': 'USD/MMBtu', 'Currency': 'USD', 'CurrencyUnit': 'dollar', 'EnergyUnit': 'MMBtu'},
        'PVB': {'Unit': 'EUR/MWh', 'Currency': 'EUR', 'CurrencyUnit': 'euro', 'EnergyUnit': 'MWh'},
        'PVB/TTF': {'Unit': 'EUR/MWh', 'Currency': 'EUR', 'CurrencyUnit': 'euro', 'EnergyUnit': 'MWh'},
    }
}


class CHelper:
    @staticmethod
    def get_contract_date_type(x: str, pdate, curve):
        # print('\n', x)
        x = x.replace('SEPT', 'SEP')
        if '/' in x and '-' in x:
            month, year = x.split('-')
            month = month.split('/')[0]
            if month.upper() == 'DEC':
                year = str(int(year) - 1)
            x = month + '-' + year

        try:
            date_ = pd.to_datetime(x, format='%b-%y')
            period = 'Monthly'
        except Exception:
            if 'Q' in x:
                if '/' in x:
                    x = x[:4]
                if '-' not in x:
                    quarter, year = x[:2], x[2:]
                else:
                    quarter, year = x.split('-')
                date_ = pd.to_datetime(year, format='%y')
                period = 'Quarterly'
                if quarter == "Q1":
                    date_ = date_.replace(month=1)
                elif quarter == "Q2":
                    date_ = date_.replace(month=4)
                elif quarter == "Q3":
                    date_ = date_.replace(month=7)
                elif quarter == "Q4":
                    date_ = date_.replace(month=10)
                else:
                    date_ = x
            elif x.strip() == 'BOM':
                date_ = pd.to_datetime(pdate, format='%Y-%m-%d')
                if date_.day >= 16:
                    month_new = date_.month + 1 if date_.month + 1 <= 12 else 1
                    date_ = pd.to_datetime(pdate, format='%Y-%m-%d').replace(day=1, month=month_new)
                else:
                    date_ = pd.to_datetime(pdate, format='%Y-%m-%d').replace(day=1)
                period = 'Monthly'
            elif '/' in x and all([len(i) == 3 for i in x.split('/')]):
                current_year = datetime.datetime.now().year
                date_ = pd.to_datetime(x.split('/')[0], format='%b').replace(year=current_year)
                period = 'Monthly'
            elif 'CAL' in x:
                date_ = pd.to_datetime(x[-2:], format='%y')
                period = 'Annual'
            elif all([char.isalpha() for char in x]) and len(x) == 3:
                current_year = datetime.datetime.now().year
                date_ = pd.to_datetime(x, format='%b').replace(year=current_year)
                period = 'Monthly'
            elif 'W' in x:
                date_ = pd.to_datetime(x[-2:], format='%y').replace(day=1, month=10)
                period = 'Seasonal'
            elif 'S' in x:
                date_ = pd.to_datetime(x[-2:], format='%y').replace(day=1, month=4)
                period = 'Seasonal'
            else:
                log.info(ValueError(f'Value "{x}" does not match any date pattern used in conversion'))
                date_ = x
                period = ''
        if '/' in x or '/' in curve:
            contract_type = 'Spread'
        else:
            contract_type = 'Future'
        # print(date_)
        return date_.strftime('%Y-%m-%d') if isinstance(date_, datetime.datetime) else date_, period, contract_type

    @staticmethod
    def clean_contract(contract, broker, curve):
        if isinstance(contract, str):
            contract = contract.strip()

        if broker == 'ICAP':
            return contract.replace('WIN', 'W').replace('SUM', 'S').replace('Cal ', 'CAL')

        elif broker == 'TP':
            print(f'"{contract}"')
            if not isinstance(contract, datetime.datetime):
                return contract.replace('WIN', 'W').replace('SUM', 'S').replace(' ', '-')
            else:
                return contract.strftime('%b-%y').upper()
        else:
            return ''


def parse_raw_tp_data(dataframe: pd.DataFrame, data_dict: dict) -> dict:
    split_index = [i for i, value in enumerate(dataframe[dataframe.columns[0]].to_list()) if value == 'PERIOD']  # dataframe.index[dataframe[dataframe.columns[0]] == 'PERIOD']

    df_jkm = dataframe.iloc[:split_index[0]].dropna(axis=1, how='all')
    df_jkm.columns = df_jkm.iloc[0].to_list()
    df_jkm = df_jkm.rename(columns={'JKM Swap': 'Period'})
    df_jkm = df_jkm[df_jkm['Period'] != 'BOM ']
    data_dict['JKM'] = df_jkm[['Period', BROKER_PRICE_COL['TP']['JKM']]].iloc[1:].reset_index(drop=True)
    data_dict['JKM/TFU'] = df_jkm[['Period', BROKER_PRICE_COL['TP']['JKM/TFU']]].iloc[1:].reset_index(drop=True)

    df_pvb_ttf = dataframe.iloc[split_index[0]:]
    df_pvb_ttf.columns = [x.replace(r'Premium (€/MWh)', '').strip() if isinstance(x, str) else x for x in df_pvb_ttf.iloc[0].to_list()]
    df_pvb_ttf = df_pvb_ttf.rename(columns={r'PVB/TTF \nPremium (€/MWh)': 'PVB/TTF', 'PERIOD': 'Period'})
    df_pvb_ttf = df_pvb_ttf.dropna(subset=['PVB/TTF'])
    df_pvb_ttf = df_pvb_ttf.drop(np.nan, axis=1)
    data_dict['PVB/TTF'] = df_pvb_ttf.iloc[1:].reset_index(drop=True).dropna(axis=1, how='all')
    return data_dict


def parse_raw_icap_data(dataframe: pd.DataFrame, data_dict: dict) -> dict:
    jkm_loc, period_loc, table2_loc = None, None, None

    for row, value in dataframe.iterrows():  # Find locations to split table into Upper and Lower
        for col in dataframe.columns:
            if dataframe.loc[row, col] == 'Table2':
                table2_loc = row, col
            if dataframe.loc[row, col] == 'JKM':
                jkm_loc = row, col
            if dataframe.loc[row, col] == 'Period':
                period_loc = row, col

    df_table1 = dataframe.loc[:table2_loc[0] - 1].copy()  # .reset_index(drop=True)
    df_table2 = dataframe.loc[table2_loc[0]:].copy()

    # ICAP Table 1 (Upper)
    df1 = df_table1.loc[jkm_loc[0] + 1:].copy()
    df1.columns = df_table1.loc[jkm_loc[0]].ffill().values
    for col in set(df1.columns):
        df = df1[[df1.columns[0]] + [col]].copy()
        df.columns = df.iloc[0]
        data_dict[col] = df[1:].dropna(axis=0, how='all').reset_index(drop=True)

    # ICAP Table 2 (Lower)
    dataframe_pvb = df_table2.loc[period_loc[0] + 1:].copy()
    columns = df_table2.loc[period_loc[0]].values
    dataframe_pvb.columns = columns

    dataframe_pvb = dataframe_pvb[~dataframe_pvb['Period'].isin(['Within Day', 'Day Ahead', 'Weekend', 'BOM'])]
    data_dict['PVB/TTF'] = dataframe_pvb.dropna(axis=1, how='all')[['Period', 'vs TTF']]
    data_dict['PVB'] = dataframe_pvb.dropna(axis=1, how='all')[['Period', 'Last']]
    return data_dict


def read_broker_file(filename: str, broker: str) -> tuple[pd.DataFrame, pd.Timestamp]:
    """Given a filename and a designated Broker to search for, read data to DataFrame,
    IF it matches broker selected. Files will always be .xlsx """
    if not any([pattern in filename for pattern in BROKER_FILENAME_PATTERNS[broker]]):
        return None, None               # Do not try and process files that do not match the selected broker

    data = {}
    filepath = os.path.join(target_dir, filename)
    dataframe = pd.read_excel(filepath, header=None).dropna(axis=1, how='all').dropna(axis=0, how='all')
    report_date = pd.to_datetime(filename.split(BROKER_SPLIT_CHAR[broker])[-1].strip('.xlsx'), format=BROKER_DATE_FORMAT[broker])

    data = {                            # Select the correct method to Parse the data (per Broker
        'TP': parse_raw_tp_data,
        'ICAP': parse_raw_icap_data
    }[broker](dataframe, data)          # Parse the data into a data_dict curve: dataframe pairs
    return data, report_date


def transform_data(data: pd.DataFrame, broker: str, curve: str, report_date: pd.Timestamp) -> pd.DataFrame:
    # do transformation  data -> result = pd.DataFrame(columns=['Pdate', 'Contract', 'Source', 'PriceType', 'Price'])
    final_cols = [
        'PDate', 'Curve', 'Source', 'Contract', 'Price', 'ExpiryDate', 'Period', 'ContractType',
        'PriceType', 'PricingDays', 'Unit', 'Currency', 'CurrencyUnit', 'EnergyUnit'
    ]

    print('\n', curve, broker)
    if broker in ('TP', 'ICAP') and curve in ('JKM/TFU', 'JKM', 'PVB', 'PVB/TTF'):
        data.columns = [x.strip() for x in data.columns]
        data['Period'] = data['Period'].apply(lambda x: CHelper.clean_contract(x, broker, curve))

        data[['PDate', 'Curve', 'Source', 'Contract']] = report_date, curve, broker, data['Period']
        data[['Price',  'PriceType', 'PricingDays']] = data[BROKER_PRICE_COL[broker][curve]], BROKER_CURVE_PRICE_TYPE[broker][curve], np.nan
        data[['Currency', 'CurrencyUnit']] = BROKER_CURVE_UNITS[broker][curve]['Currency'], BROKER_CURVE_UNITS[broker][curve]['CurrencyUnit']
        data[['Unit', 'EnergyUnit']] = BROKER_CURVE_UNITS[broker][curve]['Unit'], BROKER_CURVE_UNITS[broker][curve]['EnergyUnit']
        print(data)
        data[['ExpiryDate', 'Period', 'ContractType']] = data.apply(
            lambda x: CHelper.get_contract_date_type(x['Contract'], x['PDate'], x['Curve']), axis=1, result_type='expand'
        )
        return data[final_cols]
    pass


def main(broker):
    """ Executes Broker File Scraping and exports NG Contract Prices to BlueOcean
    """
    for file_ in os.listdir(target_dir):

        # read file -> ignore if filename != broker pattern,
        # extract data in dataframe(s?)
        data_dict, report_date = read_broker_file(file_, broker.upper())

        if data_dict is not None:
            frames = []
            for curve, frame in data_dict.items():
                final = transform_data(frame, broker, curve, report_date)
                frames.append(final)
            frames = pd.concat(frames)
            du.upload_to_database(frames, 'Upload_natural_gas_broker_futures_curves-', env=environment, upload_destination='BO')

            if args.backfill == 'True':
                du.upload_to_database(frames, 'Upload_natural_gas_broker_futures_curves-', environment, upload_destination=[os.path.join(target_dir, 'processed')])
            time.sleep(3)
            archive_dir = os.path.join(target_dir, 'archive')
            shutil.move(os.path.join(target_dir, file_), os.path.join(archive_dir, file_))
        pass
    pass


if __name__ == "__main__":
    log = ag_log.get_log()
    set_pandas_options_to_max()

    parser = argparse.ArgumentParser()
    parser.add_argument('-env', action='store', dest='env', default='PROD', help='PROD or UAT for testing')
    parser.add_argument('-broker', action='store', dest='broker', default='TP', help='TP, ICAP or GFI')
    parser.add_argument('-backfill', action='store', dest='backfill', default='False', help='Choose to backfill data')
    args = parser.parse_args(sys.argv[1:])

    target_dir = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\JKM Broker Curves'
    if args.backfill == 'True':
        target_dir = os.path.join(target_dir, 'backfill')  # r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\JKM Broker Curves\test'

    log.info(f'Environment: {args.env}')
    log.info(f'Backfill: {args.backfill}')
    environment = args.env

    main(args.broker)
    exit(0)

