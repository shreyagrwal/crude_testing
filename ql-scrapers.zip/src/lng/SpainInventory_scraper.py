import os, sys
sys.path.append(os.getcwd())
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
import time
from random import randint
from ag_log import ag_log
from scraper_utils import scraper_environment as se
from ag_data_access import blueocean_access as bo
import os
env = se.environment
bulkUploaderFolder = se.ingestion_folder

# Code will be run automatically by ActiveBatch every morning at 9am, to download yesterday's inventory data (i.e. DDate will always be thday prior to PDate)

# Create function to input the date of every morning, and then let code try and pull yesterday's final inventory data
def get_inv_data(pdate):
    # Define the url for the webpage we want to scrape with selenium
    webpage = r"https://www.enagas.es/enagas/es/Gestion_Tecnica_Sistema/Operacion_del_Sistema_Gasista/SeguimientoDiarioDelSistema#"

    # Define the dataframe which we will be filling in with data (only one row per day)
    df_inv = pd.DataFrame(columns=["PDate", "DDate", "Inventory"])

    # Place everything into try/except to capture any errors
    try:

        # reformat pdate for later on
        pdate2 = datetime.strftime(pdate, "%Y-%m-%d")
        # create ddate to pull in data & also for later on
        ddate = (datetime.today() - timedelta(days=1)).strftime("%Y-%m-%d")
        # reformat ddate in order to input into webpage and begin scraping
        searchterm = datetime.strftime(datetime.strptime(ddate, "%Y-%m-%d"), "%d/%m/%Y")  # need in str format %d/%m/%Y for the website

        # Attempting to make browser headless - doesnt work at the moment hence comment out

        # This doesnt work yet - i.e. headless scrape doesnt work ??
        #         def create_driver():
        #             chrome_options = webdriver.ChromeOptions()
        #             try:
        #                 chrome_options.add_argument("--headless")
        #                 chrome_options.headless = True
        #             except:
        #                 pass
        #             chrome_options.add_argument("--log-level=3")
        #             chrome_options.add_argument('--window-size=1920,1080')


        # Initalise chromedriver for scraping
        chrome_options = Options()
        chrome_options.headless = True
        driver = webdriver.Chrome(ChromeDriverManager().install())
        driver.get(webpage)

        # Insert random wait clause to avoid being banned by website - just a precaution. Will be repeated again below between stages.
        time.sleep(randint(5, 10))

        # Clear the search box and enter the date we want to scrape for
        driver.find_element_by_class_name("hasDatepicker").clear()
        sbox = driver.find_element_by_class_name("hasDatepicker")
        sbox.send_keys(searchterm)

        time.sleep(randint(5, 10))

        # Click on enter button to update the webpage
        submit = driver.find_element_by_xpath("//*[@id='content']/div[2]/div/div[1]/div[3]/form/fieldset/input")
        submit.click()

        time.sleep(randint(5, 10))

        # On the loaded page, we want to pull out inventory data with its specific xpath
        eod_stocks = driver.find_element_by_xpath(
            '//*[@id="content"]/div[2]/div/div[1]/div[5]/div/div[2]/table/tbody[4]/tr[14]/th[2]/table/tbody/tr[3]/td[4]')
        eod_stocks = float(eod_stocks.text.replace('.', '').replace(',', '.'))

        # Append data to dataframe we defined above
        data = [pdate2, ddate, eod_stocks]
        data_s = pd.Series(data, index=df_inv.columns)
        df_inv = df_inv.append(data_s, ignore_index=True)

        # Finally close the webdriver as we are finished with the selenium/scraping part of script
        driver.close()

        # Set up paths
        path = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\Spain'
        db_path = bulkUploaderFolder
        # Export the dataframe as a csv into the desired folders
        # Keep local version
        df_inv.to_csv(path + r'\es_gas_for_database' + r'\Upload_LNG_SpanishInvData-' + datetime.strftime(pdate,"%Y%m%d") + '.csv',
                      index=False)
        # Push directly into database
        df_inv.to_csv(db_path +  r'\Upload_LNG_SpanishInvData-' + datetime.strftime(pdate,"%Y%m%d") + '.csv',
                      index=False)

        time.sleep(randint(10, 20))

    except:
        # If the code fails, we set the stocks value as 'NaN'
        eod_stocks = np.nan

        # append data to dataframe
        data = [pdate2, ddate, eod_stocks]
        data_s = pd.Series(data, index=df_inv.columns)
        df_inv = df_inv.append(data_s, ignore_index=True)

        driver.close()

        time.sleep(randint(10, 20))

# Try/except to run the function above and scrape the data, outputting the csv if successful
try:
    get_inv_data(datetime.now())
except:
    print('Failed to complete function')
    pass

print('Ran successfully')