"""
    Author: Dong Xia
    Adapted By: Bobby Hemming, Yash (Summer Intern 2023)
    Scheduled: Weekly
"""
import os
import sys
import math
import time
import shutil
import argparse
import numpy as np
import pandas as pd
import xlwings as xw
from contextlib import suppress
from openpyxl import load_workbook
from collections import OrderedDict
from datetime import datetime, timedelta, date

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_data_access import data_upload as du


# # dir = 'I:\\Analysis Department\\Projects\\Global Gas Model\\Broker Curve\\AllFiles\\ICap\\'
# bulkUploaderFolder = 'I:\\Analysis Department\\Projects\\Global Gas Model\\Broker Curve\\AllFiles\\to_process_ICAP'
# csvFolder = bulkUploaderFolder
date_formats = ['%d %m %Y', '%d %m %y', '%d.%m.%Y']
default_dir = ''


# CLASS helper class for generic reusable methods
class BrokerFileHelper:
    @staticmethod
    def monthlist_short(dates):
        return list(OrderedDict(
            ((dates[0] + timedelta(_)).strftime(r"%b-%y").upper(), None) for _ in
            range((dates[1] - dates[0]).days)).keys())

    @staticmethod
    def get_pi_period(period, index, piMonthList):
        while piMonthList[index][0:3] != period[0:3] and index < len(piMonthList):
            index = index + 1
        return index

    @staticmethod
    def is_float(string):
        if not string:
            return False
        try:
            result = float(string)
            if not math.isnan(result):
                return True  # True if string is a number contains a dot
            else:
                return False
        except ValueError:  # String is not a number
            return False

    @staticmethod
    def merge_existing_data(df, filefullname):
        df_exist = pd.read_csv(filefullname, delimiter=',')  # , index_col='Ddate')
        # df_exist['Pdate'] = pd.to_datetime(df_exist['Pdate'])
        df_exist = df_exist[~df_exist['Pdate'].isin(df['Pdate'])]
        df = pd.concat([df_exist, df])
        df = df.sort_values(by=['Pdate'])
        return df

    @staticmethod
    def check_date_format(raw_date, date_formats):
        for date_format in date_formats:
            try:
                formated_date = datetime.strptime(raw_date, date_format).date()
                return formated_date
            except:
                pass
        raise ValueError("date format doesn't match, please check 'date_formats' list")

    @staticmethod
    def get_contract_date_type(x: str, pdate, curve):

        print('\n', x)
        x = x.replace('SEPT', 'SEP')
        if '/' in x and '-' in x:
            month, year = x.split('-')
            month = month.split('/')[0]
            if month.upper() == 'DEC':
                year = str(int(year) - 1)
            x = month + '-' + year

        try:
            date_ = pd.to_datetime(x, format='%b-%y')
            period = 'Monthly'
        except Exception:
            if 'Q' in x:
                if '/' in x:
                    x = x[:4]
                if '-' not in x:
                    quarter, year = x[:2], x[2:]
                else:
                    quarter, year = x.split('-')
                date_ = pd.to_datetime(year, format='%y')
                period = 'Quarterly'
                if quarter == "Q1":
                    date_ = date_.replace(month=1)
                elif quarter == "Q2":
                    date_ = date_.replace(month=4)
                elif quarter == "Q3":
                    date_ = date_.replace(month=7)
                elif quarter == "Q4":
                    date_ = date_.replace(month=10)
                else:
                    date_ = x
            elif x.strip() == 'BOM':
                # print(pdate)
                date_ = pd.to_datetime(pdate, format='%Y-%m-%d')
                # print(date_.day)
                # print(date_.month)
                if date_.day >= 16:
                    month_new = date_.month+1 if date_.month+1 <= 12 else 1
                    date_ = pd.to_datetime(pdate, format='%Y-%m-%d').replace(day=1, month=month_new)
                else:
                    date_ = pd.to_datetime(pdate, format='%Y-%m-%d').replace(day=1)
                period = 'Monthly'
            elif '/' in x and all([len(i) == 3 for i in x.split('/')]):
                current_year = datetime.now().year
                date_ = pd.to_datetime(x.split('/')[0], format='%b').replace(year=current_year)
                period = 'Monthly'
            elif 'CAL' in x:
                date_ = pd.to_datetime(x[-2:], format='%y')
                period = 'Annual'
            elif all([char.isalpha() for char in x]) and len(x) == 3:
                current_year = datetime.now().year
                date_ = pd.to_datetime(x, format='%b').replace(year=current_year)
                period = 'Monthly'
            elif 'W' in x:
                date_ = pd.to_datetime(x[-2:], format='%y').replace(day=1, month=10)
                period = 'Seasonal'
            elif 'S' in x:
                date_ = pd.to_datetime(x[-2:], format='%y').replace(day=1, month=4)
                period = 'Seasonal'
            else:
                log.info(ValueError(f'Value "{x}" does not match any date pattern used in conversion'))
                date_ = x
                period = ''
        if '/' in x or '/' in curve:
            contract_type = 'Spread'
        else:
            contract_type = 'Future'
        print(date_)
        return date_.strftime('%Y-%m-%d') if isinstance(date_, datetime) else date_, period, contract_type


# CLASS helpful functions to target specific broker file formats
class BrokerScraper:
    def __init__(self, filename, workbook, report_date, file_dir=default_dir):
        self.file = filename
        self.file_path = os.path.join(file_dir, filename)
        self.pDate = report_date.strftime("%Y-%m-%d")
        self.report_date = report_date
        self.wb = workbook

    def scrape_icap_updated(self):
        # pDate = report_date.strftime("%Y-%m-%d")
        wb_obj = load_workbook(filename=self.file_path)
        wsheet = wb_obj['Info']

        cell_val = wsheet.cell(2, 28).value

        sht = self.wb.sheets["Info"]
        if cell_val == "" or not cell_val:
            if wsheet.cell(2, 23).value == '' or not cell_val or cell_val == 'None':
                dataframe = sht.range("B7:O22").options(pd.DataFrame).value
            else:
                dataframe = sht.range("B7:O23").options(pd.DataFrame).value
        else:
            dataframe = sht.range("B7:S31").options(pd.DataFrame).value

        if self.report_date >= pd.to_datetime('2024-01-10'):
            dataframe = sht.range("B7:O26").options(pd.DataFrame).value

        # dataframe_pvb = sht.range("B28:H46").options(pd.DataFrame).value
        # if list(dataframe_pvb.columns)[0] != 'Yesterday':
        #     dataframe_pvb = sht.range("B26:H43").options(pd.DataFrame).value

        start_col = 22
        while list(sht.range(f"B{start_col}:H{start_col + 16}").options(pd.DataFrame).value.columns)[0] != 'Yesterday':
            start_col += 1
        dataframe_pvb = sht.range(f"B{start_col}:H{start_col + 20}").options(pd.DataFrame).value

        dataframe = dataframe[[x for x in dataframe.columns if x is not None]]
        dataframe_pvb = dataframe_pvb[[x for x in dataframe_pvb.columns if x is not None]]
        for i in ['Within Day', 'Day Ahead', 'Weekend', 'BOM']:
            if i in dataframe_pvb.index:
                dataframe_pvb = dataframe_pvb.drop(index=[i])
        dataframe_pvb = dataframe_pvb.dropna(subset=['Yesterday', 'vs TTF'])

        print(dataframe)
        print(dataframe_pvb)

        with suppress(KeyError):
            del dataframe['Yesterday']
            del dataframe_pvb['Yesterday']
        with suppress(KeyError):
            del dataframe['d/d €']
        with suppress(KeyError):
            del dataframe['d/d $']
        with suppress(KeyError):
            del dataframe['FX']
        with suppress(KeyError):
            del dataframe['Spread']
        with suppress(KeyError):
            del dataframe['EU/USD RATES ']
        monthlyContractList = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]
        seasonalContractList = ["Q1", "Q2", "Q3", "Q4"]
        yearlyContractList = ["SUM", "WIN", "CAL"]
        markets = ['TTF (Euros)', 'TFU', 'JKM', 'JKM/TFU']

        piMonthList = BrokerFileHelper.monthlist_short([self.report_date, self.report_date + timedelta(weeks=104)])
        print(piMonthList)
        result = pd.DataFrame(columns=['Pdate', 'Contract', 'Source', 'PriceType', 'Price', 'Market'])
        result1 = pd.DataFrame(columns=['Pdate', 'Contract', 'Source', 'PriceType', 'Price', 'Market'])
        result2 = pd.DataFrame(columns=['Pdate', 'Contract', 'Source', 'PriceType', 'Price', 'Market'])
        result3 = pd.DataFrame(columns=['Pdate', 'Contract', 'Source', 'PriceType', 'Price', 'Market'])

        index = 0
        resultIndex = 0
        for period, last in dataframe.iterrows():
            if period and last[0] and not math.isnan(last[0]):
                if period[0:3].upper() in monthlyContractList:
                    index = BrokerFileHelper.get_pi_period(period.upper(), index, piMonthList)
                    period = piMonthList[index]
                    result.loc[resultIndex] = [self.pDate, period, 'ICAP', 'mid', last[0], 'TTF']
                    resultIndex = resultIndex + 1
                if period[0:2].upper() in seasonalContractList:
                    period = period.upper().replace(" ", "-")
                    result.loc[resultIndex] = [self.pDate, period, 'ICAP', 'mid', last[0], 'TTF']
                    resultIndex = resultIndex + 1
                if period[0:3].upper() in yearlyContractList:
                    period = period.upper().replace("SUM", "S").replace("WIN", "W").replace(" ", "")
                    result.loc[resultIndex] = [self.pDate, period, 'ICAP', 'mid', last[0], 'TTF']
                    resultIndex = resultIndex + 1

        index1 = 0
        resultIndex1 = 0
        for period, last in dataframe.iterrows():
            if period and last[1] and not math.isnan(last[1]):
                if period[0:3].upper() in monthlyContractList:
                    index1 = BrokerFileHelper.get_pi_period(period.upper(), index1, piMonthList)
                    period = piMonthList[index1]
                    result1.loc[resultIndex1] = [self.pDate, period, 'ICAP', 'mid', last[1], 'TFU']
                    resultIndex1 = resultIndex1 + 1
                if period[0:2].upper() in seasonalContractList:
                    period = period.upper().replace(" ", "-")
                    result1.loc[resultIndex1] = [self.pDate, period, 'ICAP', 'mid', last[1], 'TFU']
                    resultIndex1 = resultIndex1 + 1
                if period[0:3].upper() in yearlyContractList:
                    period = period.upper().replace("SUM", "S").replace("WIN", "W").replace(" ", "")
                    result1.loc[resultIndex1] = [self.pDate, period, 'ICAP', 'mid', last[1], 'TFU']
                    resultIndex1 = resultIndex1 + 1

        index2 = 0
        resultIndex2 = 0
        for period, last in dataframe.iterrows():
            if period and last[2] and not math.isnan(last[2]):
                if period[0:3].upper() in monthlyContractList:
                    index2 = BrokerFileHelper.get_pi_period(period.upper(), index2, piMonthList)
                    period = piMonthList[index2]
                    result2.loc[resultIndex2] = [self.pDate, period, 'ICAP', 'mid', last[2], 'JKM']
                    resultIndex2 = resultIndex2 + 1
                if period[0:2].upper() in seasonalContractList:
                    period = period.upper().replace(" ", "-")
                    result2.loc[resultIndex2] = [self.pDate, period, 'ICAP', 'mid', last[2], 'JKM']
                    resultIndex2 = resultIndex2 + 1
                if period[0:3].upper() in yearlyContractList:
                    period = period.upper().replace("SUM", "S").replace("WIN", "W").replace(" ", "")
                    result2.loc[resultIndex2] = [self.pDate, period, 'ICAP', 'mid', last[2], 'JKM']
                    resultIndex2 = resultIndex2 + 1

        index3 = 0
        resultIndex3 = 0
        for period, last in dataframe.iterrows():
            if period and last[3] and not math.isnan(last[3]):
                if period[0:3].upper() in monthlyContractList:
                    index3 = BrokerFileHelper.get_pi_period(period.upper(), index3, piMonthList)
                    period = piMonthList[index3]
                    result3.loc[resultIndex3] = [self.pDate, period, 'ICAP', 'mid', last[3], 'JKM/TFU']
                    resultIndex3 = resultIndex3 + 1
                if period[0:2].upper() in seasonalContractList:
                    period = period.upper().replace(" ", "-")
                    result3.loc[resultIndex3] = [self.pDate, period, 'ICAP', 'mid', last[3], 'JKM/TFU']
                    resultIndex3 = resultIndex3 + 1
                if period[0:3].upper() in yearlyContractList:
                    period = period.upper().replace("SUM", "S").replace("WIN", "W").replace(" ", "")
                    result3.loc[resultIndex3] = [self.pDate, period, 'ICAP', 'mid', last[3], 'JKM/TFU']
                    resultIndex3 = resultIndex3 + 1

        def get_curve_data(row):
            period_ = row.name
            if period_ and not math.isnan(row['Last']):
                if period_[0:3].upper() in monthlyContractList:
                    index_ = BrokerFileHelper.get_pi_period(period_.upper(), 0, piMonthList)
                    period_ = piMonthList[index_]
                    return period_
                elif period_[0:2].upper() in seasonalContractList:
                    period_ = period_.upper().replace(" ", "-")
                    return period_
                elif period_[0:3].upper() in yearlyContractList:
                    period_ = period_.upper().replace("SUM", "S").replace("WIN", "W").replace(" ", "")
                    return period_
                else:
                    return np.nan
            else:
                return np.nan

        dataframe_pvb = dataframe_pvb
        dataframe_pvb['Contract'] = dataframe_pvb.apply(lambda x: get_curve_data(x), axis=1)
        dataframe_pvb[['Pdate', 'Source', 'PriceType']] = self.pDate, 'ICAP', 'mid'

        cols = ['Pdate', 'Contract', 'Source', 'PriceType', 'Price', 'Market']

        # PVB Price
        dataframe_pvb_price = dataframe_pvb.copy()
        dataframe_pvb_price['Price'] = dataframe_pvb_price['Last']
        dataframe_pvb_price['Market'] = 'PVB'

        # Get Spead (vs TTF)
        dataframe_pvb_spread = dataframe_pvb.copy()
        dataframe_pvb_spread['Price'] = dataframe_pvb_spread['vs TTF']
        dataframe_pvb_spread['Market'] = 'PVB/TTF'

        frames = [result, result1, result2, result3, dataframe_pvb_price[cols], dataframe_pvb_spread[cols]]
        final = pd.concat(frames)
        final = final.drop_duplicates(subset=['Pdate', 'Contract', 'Source', 'PriceType', 'Price', 'Market'])
        # final.to_csv(get_csv_file_name('icap'), index=False)
        final['Curve'] = final['Market']
        return final

    def scrape_icap(self):
        try:
            sht = self.wb.sheets["Info"]
            dataframe = sht.range("B7:E34").options(pd.DataFrame).value
            del dataframe['Yesterday']
            del dataframe['d/d $']
        except:
            sht = self.wb.sheets["Sheet1"]
            dataframe = sht.range("I5:J24").options(pd.DataFrame).value

        # dataframe_pvb = sht.range("B68:H91").options(pd.DataFrame).value
        # if list(dataframe_pvb.columns)[0] != 'Yesterday':
        #     dataframe_pvb = sht.range("B74:H97").options(pd.DataFrame).value

        start_col = 62
        while list(sht.range(f"B{start_col}:H{start_col+20}").options(pd.DataFrame).value.columns)[0] != 'Yesterday':
            start_col += 1
        dataframe_pvb = sht.range(f"B{start_col}:H{start_col+20}").options(pd.DataFrame).value
        print(dataframe_pvb)

        monthlyContractList = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]
        seasonalContractList = ["Q1", "Q2", "Q3", "Q4"]
        yearlyContractList = ["SUM", "WIN", "CAL"]

        piMonthList = BrokerFileHelper.monthlist_short([self.report_date, self.report_date + timedelta(weeks=104)])
        result = pd.DataFrame(columns=['Pdate', 'Contract', 'Source', 'PriceType', 'Price'])

        index = 0
        resultIndex = 0
        for period, last in dataframe.iterrows():
            if period and last[0] and not math.isnan(last[0]):
                if period[0:3].upper() in monthlyContractList:
                    index = BrokerFileHelper.get_pi_period(period.upper(), index, piMonthList)
                    period = piMonthList[index]
                    result.loc[resultIndex] = [self.pDate, period, 'ICAP', 'mid', last[0]]
                    resultIndex = resultIndex + 1
                if period[0:2].upper() in seasonalContractList:
                    period = period.upper().replace(" ", "-")
                    result.loc[resultIndex] = [self.pDate, period, 'ICAP', 'mid', last[0]]
                    resultIndex = resultIndex + 1
                if period[0:3].upper() in yearlyContractList:
                    period = period.upper().replace("SUM", "S").replace("WIN", "W").replace(" ", "")
                    result.loc[resultIndex] = [self.pDate, period, 'ICAP', 'mid', last[0]]
                    resultIndex = resultIndex + 1

        result['Market'] = 'JKM'

        def get_curve_data(row):
            period_ = row.name
            if period_ and not math.isnan(row['Last']):
                if period_[0:3].upper() in monthlyContractList:
                    index_ = BrokerFileHelper.get_pi_period(period_.upper(), 0, piMonthList)
                    period_ = piMonthList[index_]
                    return period_
                elif period_[0:2].upper() in seasonalContractList:
                    period_ = period_.upper().replace(" ", "-")
                    return period_
                elif period_[0:3].upper() in yearlyContractList:
                    period_ = period_.upper().replace("SUM", "S").replace("WIN", "W").replace(" ", "")
                    return period_
                else:
                    return np.nan
            else:
                return np.nan

        dataframe_pvb = dataframe_pvb.drop(index=['Within Day', 'Day Ahead', 'Weekend', 'BOM'])
        dataframe_pvb = dataframe_pvb.dropna()
        dataframe_pvb['Contract'] = dataframe_pvb.apply(lambda x: get_curve_data(x), axis=1)
        dataframe_pvb[['Pdate', 'Source', 'PriceType']] = self.pDate, 'ICAP', 'mid'

        cols = ['Pdate', 'Contract', 'Source', 'PriceType', 'Price', 'Market']

        # PVB Price
        dataframe_pvb_price = dataframe_pvb.copy()
        dataframe_pvb_price['Price'] = dataframe_pvb_price['Last']
        dataframe_pvb_price['Market'] = 'PVB'

        # Get Spead (vs TTF)
        dataframe_pvb_spread = dataframe_pvb.copy()
        dataframe_pvb_spread['Price'] = dataframe_pvb_spread['vs TTF']
        dataframe_pvb_spread['Market'] = 'PVB/TTF'

        final = pd.concat([result, dataframe_pvb_price[cols], dataframe_pvb_spread[cols]])

        final['Curve'] = final['Market']
        final = final.drop_duplicates(subset=['Pdate', 'Contract', 'Source', 'PriceType', 'Price', 'Market'])
        log.debug(result)
        return final

    def scrape_gfi(self):
        # pDate = reportDate.strftime("%Y-%m-%d")
        wb_obj = load_workbook(filename=self.file_path)
        wsheet = wb_obj['Report']

        # for key, *values in wsheet.iter_cols():
        #     dataDict[key.value] = [v.value for v in values]

        cell_val = wsheet.cell(3, 5).value  # for some file formats
        if cell_val == 'Period':
            sht = self.wb.sheets["Report"]
            dataframe = sht.range("E4:G22").options(pd.DataFrame).value
        else:
            sht = self.wb.sheets["Report"]
            dataframe = sht.range("F4:H22").options(pd.DataFrame).value

        result = pd.DataFrame(columns=['Pdate', 'Contract', 'Source', 'PriceType', 'Price'])
        monthlyContractList = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]

        resultIndex = 0
        monthIndex = 0
        piMonthList = BrokerFileHelper.monthlist_short([self.report_date, self.report_date + timedelta(weeks=104)])

        for index, row in dataframe.iterrows():
            if index and index is not None:
                if isinstance(index, date):
                    period = index.strftime(r"%b-%y").upper()
                else:
                    period = index
                period = period.upper().replace(' ', '').replace("SUM-", "S").replace("SUM", "S").replace("WIN-",
                                                                                                          "W").replace(
                    "WIN", "W").replace("CAL-", "CAL")

                if period in monthlyContractList:
                    monthIndex = BrokerFileHelper.get_pi_period(period, monthIndex, piMonthList)

                    period = piMonthList[monthIndex]

                result.loc[resultIndex] = [self.pDate, period, 'GFI', 'bid', row[0]]
                resultIndex = resultIndex + 1
                result.loc[resultIndex] = [self.pDate, period, 'GFI', 'offer', row[1]]
                resultIndex = resultIndex + 1

        #         print(period)
        #         #print(monthIndex)
        #         print(resultIndex)
        # print(monthIndex)

        result = result[result['Price'].apply(lambda x: BrokerFileHelper.is_float(str(x)))]
        # result.to_csv(get_csv_file_name('gfi'), index=False)
        result['Curve'] = 'JKM'
        return result

    def scrape_tp(self):
        wb_obj = load_workbook(filename=self.file_path)
        wsheet = wb_obj['Sheet1']
        cell_val = wsheet.cell(2, 29)
        # cell_val_2 = wsheet.cell(2, 6)

        if self.file.find('2018'):
            sht = self.wb.sheets["sheet1"]
            dataframe = sht.range("B7:C27").options(pd.DataFrame).value
        elif self.file.find('2019'):
            sht = self.wb.sheets["sheet1"]
            dataframe = sht.range("B7:C28").options(pd.DataFrame).value
        elif self.file.find('2020'):
            if cell_val == 'Mid-Point':
                sht = self.wb.sheets["sheet1"]
                dataframe = sht.range("B7:C28").options(pd.DataFrame).value
            else:
                sht = self.wb.sheets["sheet1"]
                dataframe = sht.range("B7:C30").options(pd.DataFrame).value
        elif self.file.find('2021'):
            sht = self.wb.sheets["sheet1"]
            dataframe = sht.range("B7:C30").options(pd.DataFrame).value
        else:
            raise NotImplemented('The file does not contain any matching sheets, please check scraper "scraper_tp()"')

        monthlyContractList = ["BOM", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV",
                               "DEC"]
        seasonalContractList = ["Q1", "Q2", "Q3", "Q4"]
        yearlyContractList = ["SUM", "WIN", "CAL"]

        result = pd.DataFrame(columns=['Pdate', 'Contract', 'Source', 'PriceType', 'Price'])
        resultIndex = 0

        for period, last in dataframe.iterrows():
            if period and last[0] != '-' and not math.isnan(last[0]):
                if isinstance(period, date):
                    period = period.strftime(r"%b-%y").upper()
                else:
                    period = period
                if period[0:3].upper() in monthlyContractList:
                    result.loc[resultIndex] = [self.pDate, period, 'TP', 'mid', last[0]]
                    resultIndex = resultIndex + 1
                if period[0:2].upper() in seasonalContractList:
                    period = period.upper().replace(" ", "-")
                    result.loc[resultIndex] = [self.pDate, period, 'TP', 'mid', last[0]]
                    resultIndex = resultIndex + 1
                if period[0:3].upper() in yearlyContractList:
                    period = period.upper().replace("SUM", "S").replace("WIN", "W").replace(" ", "")
                    result.loc[resultIndex] = [self.pDate, period, 'TP', 'mid', last[0]]
                    resultIndex = resultIndex + 1
        log.debug(result)
        # result.to_csv(BrokerFileHelper.get_csv_file_name('tp'), index=False)
        result['Curve'] = 'JKM'
        return result

    def scrape_tp_spread(self):
        # filefullname = os.path.join(dir, 'TP_JKMTFU_Spread.csv')
        # pDate = reportDate.strftime("%Y-%m-%d")
        sht = self.wb.sheets["sheet1"]
        dataframe = sht.range("B7:E31").options(pd.DataFrame).value

        # for some 2018 files
        # dataframe = sht.range("B8:C26").options(pd.DataFrame).value

        monthlyContractList = ["BOM", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV",
                               "DEC"]
        seasonalContractList = ["Q1", "Q2", "Q3", "Q4"]
        yearlyContractList = ["SUM", "WIN", "CAL"]

        result = pd.DataFrame(
            columns=['Pdate', 'Contract', 'Source', 'PriceType', 'PricingDays', 'Price', 'JKM/TFU', 'Unit'])
        resultIndex = 0

        for period, last in dataframe.iterrows():
            if period and last[0] != '-' and not math.isnan(last[0]):
                if isinstance(period, date):
                    period = period.strftime(r"%b-%y").upper()
                else:
                    period = period
                if period[0:3].upper() in monthlyContractList:
                    result.loc[resultIndex] = [self.pDate, period, 'TP', 'mid', last[0], last[1], last[2], '$/mmbtu']
                    resultIndex = resultIndex + 1
                if period[0:2].upper() in seasonalContractList:
                    period = period.upper().replace(" ", "-")
                    result.loc[resultIndex] = [self.pDate, period, 'TP', 'mid', last[0], last[1], last[2], '$/mmbtu']
                    resultIndex = resultIndex + 1
                if period[0:3].upper() in yearlyContractList:
                    period = period.upper().replace("SUM", "S").replace("WIN", "W").replace(" ", "")
                    result.loc[resultIndex] = [self.pDate, period, 'TP', 'mid', last[0], last[1], last[2], '$/mmbtu']
                    resultIndex = resultIndex + 1

        result = result.round({'Price': 5, 'JKM/TFU': 5})
        result['Curve'] = 'JKM'
        result_spread = result.copy(deep=True)
        result = result.drop(columns=['JKM/TFU'])
        result_spread = result_spread.drop(columns=['Price'])
        result_spread['Curve'] = 'JKM/TFU'
        result_spread = result_spread.rename(columns={'JKM/TFU': 'Price'})
        result = pd.concat([result, result_spread])
        log.debug(result)
        # result.to_csv(get_csv_file_name('tp'), index=False)
        return result


# FUNC scraping function -> extracts information from files
def scrape(app_dir, file):
    app = xw.App(add_book=False, visible=False)
    app.display_alerts = False
    app.books.api.Open(app_dir + "\\" + file, UpdateLinks=False)
    wb = app.books[0]

    # ICAP BROKER FILES
    if file.find('Closing Run') != -1:
        broker_type = 'ICAP'

        # ICAP Filename Type 1
        if file.find("LNG Closing Run") != -1 and file[0:20] != "LNG Closing Run 2021":
            log.debug('ICAP File Found, Start to Scrap: {0}.'.format(file))
            filename_temp = file.replace(" -", "")
            strReportDate = filename_temp.split(" ")[3] + filename_temp.split(" ")[4] + filename_temp.split(" ")[5].strip(".xlsx")
            try:
                reportDate = datetime.strptime(strReportDate, '%Y%m%d').date()
            except Exception as e:
                reportDate = datetime.strptime(strReportDate, '%d.%m.%Y').date()
            log.debug(reportDate)
            df_final = BrokerScraper(file, wb, reportDate, app_dir).scrape_icap_updated()

        # ICAP Filename Type 1
        elif file[0:11] == "Closing Run" or file[0:20] == "LNG Closing Run 2021":
            log.debug('ICAP File Found, Start to Scrap: {0}.'.format(file))
            # strReportDate = file.split(" ")[2].strip(".xlsx")

            strReportDate = file.replace('Closing ', '').replace('Run ', '').replace('LNG ', '').strip('.xlsx').strip()
            if '.' in strReportDate:
                reportDate = datetime.strptime(strReportDate, '%d.%m.%Y').date()
            else:
                reportDate = datetime.strptime(strReportDate, '%Y %m %d').date()
            log.debug(reportDate)
            df_final = BrokerScraper(file, wb, reportDate, target_dir).scrape_icap()
            log.debug('Scraping ICAP File {0} Completed.'.format(file))
        else:
            raise NotImplementedError('New type of ICAP file provided, please update the scraper')

    # GFI BROKER FILES
    elif file.find("GFI EOD") != -1 or file[:10] == 'EOD Report':
        broker_type = 'GFI'
        log.debug('GFI EOD File Found, Start to Scrap: {0}.'.format(file))
        strReportDate = file.replace("EOD ", "").replace("Report ", " ").replace("GFI", "").strip(".xlsx").replace('-', ' ').strip()[0:10]
        reportDate = BrokerFileHelper.check_date_format(strReportDate, date_formats)
        df_final = BrokerScraper(file, wb, reportDate, target_dir).scrape_gfi()
        log.debug('Scraping GFI EOD File {0} Completed.'.format(file))

    # TP BROKER FILES
    elif file.find("TP LNG EOD Report") != -1:
        broker_type = 'TP'
        log.debug('TP LNG EOD Report File Found, Start to Scrap: {0}.'.format(file))
        strReportDate = file.replace("TP LNG EOD Report ", "").strip(".xlsx")
        reportDate = datetime.strptime(strReportDate, '%Y%m%d').date()

        if reportDate < date(2021, 3, 16):
            log.info('Report date < 2021-3-16')
            df_final = BrokerScraper(file, wb, reportDate, target_dir).scrape_tp()
        else:
            log.info('Report date => 2021-3-16')
            df_final = BrokerScraper(file, wb, reportDate, target_dir).scrape_tp_spread()

    else:
        raise NotImplementedError(f'File="{file}" is not recognised, please fix scraper to ignore or include this file')

    app.quit()
    log.debug(f'Scraping broker={broker_type}, Report File {file} Completed.')
    time.sleep(2)

    df_final[['StartDate', 'Period', 'ContractType']] = df_final.apply(
        lambda x: BrokerFileHelper.get_contract_date_type(x['Contract'], x['Pdate'], x['Curve']), axis=1, result_type='expand'
    )

    # Final adjustments to dataset
    df_final = df_final[df_final['Price'] != '-']
    df_final['Currency'] = 'USD'
    df_final['CurrencyUnit'] = 'dollar'
    df_final['EnergyUnit'] = 'MMBtu'
    if 'PricingDays' not in df_final.columns:
        df_final['PricingDays'] = np.nan
    if 'Unit' not in df_final.columns:
        df_final['Unit'] = 'USD/MMBtu'
    df_final['Unit'] = df_final['Unit'].replace('$/mmbtu', 'USD/MMBtu').replace('$/MMBtu', 'USD/MMBtu')
    df_final = df_final.rename(columns={'Pdate': 'PDate', 'StartDate': 'ExpiryDate'})
    columns = [
        'PDate', 'Curve', 'Source', 'Contract', 'Price', 'ExpiryDate', 'Period', 'ContractType', 'PriceType',
        'PricingDays', 'Unit', 'Currency', 'CurrencyUnit', 'EnergyUnit'
    ]
    df_final = df_final[columns]
    # Flag -> Future or Spread
    return df_final, broker_type


# FUNC main logic to loop through broker raw files -> uploads processed to BO
def main():
    """
    Loop through target files - extract JKM (and other) broker curve figures. There are multiple types of formats so use
    different functions to extract the different formats of data - be aware the format may change in the future.
    ICAP GFI TP - these are separate files to be scraped
    Upload the files to be ingested in BlueOcean
    """
    for file_ in os.listdir(target_dir):
        if os.path.isfile(os.path.join(target_dir, file_)):
            if 'TP' in file_ or 'LNG Closing Run' in file_:   # TEMPORARY LINE OF CODE -> target TP
                try:
                    log.info(f'Target File "{file_}"')
                    df, broker = scrape(target_dir, file_)
                    exit()
                    # filename_prefix = f'Upload_LNG_broker_curves_{broker}_gas-'
                    filename_prefix = f'Upload_natural_gas_futures_curves-'
                    du.upload_to_database(df, filename_prefix, env, upload_destination='BO')
                    print(backfill)
                    if backfill != 'True':
                        du.upload_to_database(df, filename_prefix, env, upload_destination=[os.path.join(target_dir, 'processed')])
                        archive_dir = os.path.join(target_dir, 'archive')
                        time.sleep(3)
                        shutil.move(os.path.join(target_dir, file_), os.path.join(archive_dir, file_))
                    log.debug(f'File Completed: {file_}')
                    log.debug('OK')
                    time.sleep(1)
                except Exception as e:
                    log.debug(e)
                    print(e)
                    if xw:
                        wb = xw.books[0]
                        wb.app.quit()
                    error_dir = os.path.join(target_dir, 'error')
                    shutil.move(os.path.join(target_dir, file_), os.path.join(error_dir, file_))
                    time.sleep(1)
    pass


if __name__ == '__main__':
    import dotenv
    dotenv.load_dotenv()
    env = os.environ['environment']
    log = ag_log.get_log()

    parser = argparse.ArgumentParser()
    parser.add_argument('-backfill', action='store', dest='backfill', default='False', help='backfill historical data')
    args = parser.parse_args(sys.argv[1:])

    target_dir = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\JKM Broker Curves'

    backfill = args.backfill
    if backfill == 'True':
        target_dir = r'\\petroineos.local\dfs\AnalysisFunctional\ApplicationFolder\AzureScrapers\JKM Broker Curves\test'

    log.info(f'Environment: {env}')
    log.info(f'Backfill: {backfill}')

    main()
    pass

