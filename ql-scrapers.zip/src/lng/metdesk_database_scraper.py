import os
import sys
from datetime import datetime, timedelta

sys.path.append(os.getcwd())
from ag_log import ag_log
import ag_data_access.blueocean_access as bo
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se


env = se.environment
bulkUploaderFolder = se.ingestion_folder
log = ag_log.get_log()

format_datetime = '%y%m%d%H%M%S'
time_stamp = datetime.now().strftime("%y%m%d%H%M%S")
upload_name_actual = 'Upload_LNG_LNGWeatherActual-' + time_stamp + '.csv'
upload_name_forecast = 'Upload_LNG_LNGWeatherForecast-' + time_stamp + '.csv'
bulk_uploader_folder = bulkUploaderFolder
regions = ['CN', 'JP', 'KR', 'TR', 'ES', 'PT']
days_back = 500


def list_to_string(regions):
    string = ""
    for region in regions:
        string += "'" + region + "', "
    string = string[:-2]
    return string


def get_weather_actual_query(region_list, min_date):
    query = '''
        SELECT 
            PDate, DDate, type, Element, Region, Value
        FROM 
            hive_metastore.dataengineering.gas_metdesk_weatheractual
        where 
            IsActive = True
            AND PDate >= ''' + "'" + min_date + "'" + ''' 
            AND region IN (''' + region_list + ''')'''
    return bo.get_data(query)


def get_weather_forecast_query(region_list, min_date):
    query = '''
        select 
            PDate, DDate, Model, Element, Region, Member, Value
        FROM 
            hive_metastore.dataengineering.gas_metdesk_weatherforecast
        where 
            ((model = 'EC46' and member = 'mean') or  (model = 'magma' and member = '0')) 
            AND (element ='tt' and region IN (''' + region_list + '''))
            AND IsActive = True
            AND PDate >= ''' + "'" + min_date + "'"
    return bo.get_data(query)


as_of_date = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
min_date = as_of_date - timedelta(days=days_back)
min_date = min_date.strftime('%Y-%m-%d')
log.debug('Data Starting Date: {0}'.format(str(min_date)))

region_list = list_to_string(regions)
log.debug('List of Countries: {0}'.format(region_list))

df_actual = get_weather_actual_query(region_list, min_date)
su.upload_to_database(df_actual, 'Upload_LNG_LNGWeatherActual-')


log.debug('Actual Temperature CSV File Exported: {0}'.format(os.path.join(bulk_uploader_folder, upload_name_actual)))
df_forecast = get_weather_forecast_query(region_list, min_date)
su.upload_to_database(df_forecast, 'Upload_LNG_LNGWeatherForecast-')

log.debug('Forecast Temperature CSV File Exported: {0}'.format(os.path.join(bulk_uploader_folder, upload_name_forecast)))
