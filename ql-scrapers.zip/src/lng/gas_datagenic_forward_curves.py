import os
import sys
import math
import dotenv
import argparse
import datetime
import calendar
import numpy as np
import pandas as pd
from functools import reduce
from dateutil.relativedelta import relativedelta

sys.path.append(os.getcwd())
from ag_log import ag_log
from ag_data_access import data_upload as du
from ag_datagenic_rest_client import DataGenic
dotenv.load_dotenv()

datagenic_rest_server = "http://lon-qdev-ap11"
upload_folder = r"\\petroineos.local\DFS\User Home Drive\bobbyhemming\Documents\LNG Model\datagenic_curves"
MONTH, YEAR = datetime.datetime.now().strftime('%m-%Y').split('-')
print('Current Month: ', MONTH, 'Current Year: ', YEAR)


def increment_month(current_month: str, increment: int) -> str:
    current_month = int(current_month) + increment
    if current_month > 12:
        print(f'Month: {current_month}, Increment: {increment}, remainder: {current_month%12}')
        current_month = current_month % 12 if current_month % 12 != 0 else 12
    return f"{current_month:02}"


def increment_year(current_year: str, month, increment: int) -> str:
    if int(month) + increment > 12:
        current_year = int(current_year) + int(math.floor((int(month)+increment)/12))
    return str(current_year)


def increment_month_relative_to_date(current_year: str, current_month: str, current_dom: str, increment: int,
                                     rollover_day=16):
    if int(current_dom) >= rollover_day:  # Month ahead (M1), rollover on 16th: 15/04/2024 Apr-24 then 16/04/2024 May-24
        increment = increment + 1

    print(increment_month(current_month, increment), increment_year(current_year, current_month, increment))
    return increment_month(current_month, increment), increment_year(current_year, current_month, increment)


curves_test_case = {
    'common_meta_data': {
        'market': 'NBP',
        'source': 'ICE',
        'data_type': 'curve',
        'price_type': 'SETTLE/ALL',
        'meta_data': {
            'curve': 'NBP',
            'contract_type': 'Future',
            'source': 'ICE',
            'price_type': 'GMT-close',
            'unit': 'p/therm',
            'currency': 'GBP',
            'currency_units': 'pence',
            'energy_units': 'therm'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://ICE_NBP_FUT/EU.NG.NBP.ICE.NATGAS.FUT.',
            'contracts': [f'{increment_year(YEAR, MONTH, -1)}M{increment_month(MONTH, -1)}-{increment_year(YEAR, MONTH, 1)}M{increment_month(MONTH, 1)}'],
            'period': 'Monthly',
        }
    ]
}

curves_nbp = {
    'common_meta_data': {
        'market': 'NBP',
        'source': 'ICE',
        'data_type': 'curve',
        'price_type': 'SETTLE/ALL',
        'meta_data': {
            'curve': 'NBP',
            'contract_type': 'Future',
            'source': 'ICE',
            'price_type': 'GMT-close',
            'unit': 'p/therm',
            'currency': 'GBP',
            'currency_units': 'pence',
            'energy_units': 'therm'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://ICE_NBP_FUT/EU.NG.NBP.ICE.NATGAS.FUT.',
            'contracts': ['2019M01-2026M01'],
            'period': 'Monthly',
        },
        {
            'model_url': 'model://ICE_NBP_FUT/EU.NG.NBP.ICE.NATGAS.FUT.',
            'contracts': ['2019SS-2026SS'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ICE_NBP_FUT/EU.NG.NBP.ICE.NATGAS.FUT.',
            'contracts': ['2019SW-2026SW'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ICE_NBP_FUT/EU.NG.NBP.ICE.NATGAS.FUT.',
            'contracts': ['2019Q1-2026Q4'],
            'period': 'Quarterly',
        },
        {
            'model_url': 'model://ICE_NBP_FUT/EU.NG.NBP.ICE.NATGAS.FUT.',
            'contracts': ['2020Y-2029Y'],
            'period': 'Annual',
        }
    ]
}

curves_ttf = {
    'common_meta_data': {
        'market': 'TTF',
        'source': 'ICE',
        'data_type': 'curve',
        'price_type': 'SETTLE/ALL',
        'meta_data': {
            'curve': 'TTF',
            'contract_type': 'Future',
            'source': 'ICE',
            'price_type': 'CET-close',
            'unit': 'EUR/MWh',
            'currency': 'EUR',
            'currency_units': 'euro',
            'energy_units': 'MWh'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://ICE_TTF/EU.NG.TTF.ICE.FUT.B.',
            'contracts': ['2019M01-2026M01'],
            'period': 'Monthly',
        },
        {
            'model_url': 'model://ICE_TTF/EU.NG.TTF.ICE.FUT.B.',
            'contracts': ['2019SS-2026SS'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ICE_TTF/EU.NG.TTF.ICE.FUT.B.',
            'contracts': ['2019SW-2026SW'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ICE_TTF/EU.NG.TTF.ICE.FUT.B.',
            'contracts': ['2019Q1-2026Q4'],
            'period': 'Quarterly',
        },
        {
            'model_url': 'model://ICE_TTF/EU.NG.TTF.ICE.FUT.B.',
            'contracts': ['2020Y-2029Y'],
            'period': 'Annual'
        }
    ]
}

curves_the = {
    'common_meta_data': {
        'market': 'THE',
        'source': 'ICE',
        'data_type': 'curve',
        'price_type': 'SETTLE/ALL',
        'meta_data': {
            'curve': 'THE',
            'contract_type': 'Future',
            'source': 'ICE',
            'price_type': 'GMT-close',
            'unit': 'EUR/MWh',
            'currency': 'EUR',
            'currency_units': 'euro',
            'energy_units': 'MWh'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://ICE_THE/EU.NG.THE.ICE.NATGAS.FUT.',
            'contracts': ['2022M01-2029M01'],
            'period': 'Monthly',
        },
        {
            'model_url': 'model://ICE_THE/EU.NG.THE.ICE.NATGAS.FUT.',
            'contracts': ['2022SW-2028SW'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ICE_THE/EU.NG.THE.ICE.NATGAS.FUT.',
            'contracts': ['2022SS-2028SS'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ICE_THE/EU.NG.THE.ICE.NATGAS.FUT.',
            'contracts': ['2022Q1-2028Q4'],
            'period': 'Quarterly',
        },
        {
            'model_url': 'model://ICE_THE/EU.NG.THE.ICE.NATGAS.FUT.',
            'contracts': ['2022Y-2028Y'],
            'period': 'Annual'
        }
    ]
}

curves_pvb = {
    'common_meta_data': {
        'market': 'PVB',
        'source': 'ARGUS',
        'data_type': 'curve',
        'price_type': 'MID/ALL',
        'meta_data': {
            'curve': 'PVB',
            'contract_type': 'Future',
            'source': 'ARGUS',
            'price_type': 'GMT-mid',
            'unit': 'EUR/MWh',
            'currency': 'EUR',
            'currency_units': 'euro',
            'energy_units': 'MWh'
            }
        },
    'iterative_elements': [
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0015254.',
            'contracts': [f'2018M01-{increment_year(YEAR, MONTH, 2)}M{increment_month(MONTH, 2)}'],
            'period': 'Monthly',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0024996.',
            'contracts': ['2019SS-2024SS'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0024996.',
            'contracts': ['2019SW-2023SW'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0017640.',
            'contracts': ['2019Q01-2024Q03'],
            'period': 'Quarterly',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0024997.',
            'contracts': ['2019Y-2025Y'],
            'period': 'Annual',
        },
    ]
}  # start of this month + 3, (3 months out)   model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0015254.2018M01/MID/ALL

curves_psv = {
    'common_meta_data': {
        'market': 'PSV',
        'source': 'ARGUS',
        'data_type': 'curve',
        'price_type': 'MID/ALL',
        'meta_data': {
            'curve': 'PSV',
            'contract_type': 'Future',
            'source': 'ARGUS',
            'price_type': 'GMT-mid',
            'unit': 'EUR/MWh',
            'currency': 'EUR',
            'currency_units': 'euro',
            'energy_units': 'MWh'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009256.',
            'contracts': [f'2018M01-{increment_year(YEAR, MONTH, 3)}M{increment_month(MONTH, 3)}'],
            'period': 'Monthly'
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009257.',
            'contracts': ['2018SW-2024SW'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009257.',
            'contracts': ['2018SS-2024SS'],
            'period': 'Seasonal'
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0017641.',
            'contracts': ['2019Q01-2024Q04'],
            'period': 'Quarterly'
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0017642.',
            'contracts': ['2019Y-2026Y'],
            'period': 'Annual',
        },
    ]
}  # 3 months out   model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009256.2023M04/MID/ALL

curves_peg = {
    'common_meta_data': {
        'market': 'PEG',
        'source': 'ARGUS',
        'data_type': 'curve',
        'price_type': 'MID/ALL',
        'meta_data': {
            'curve': 'PEG',
            'contract_type': 'Future',
            'source': 'ARGUS',
            'price_type': 'GMT-mid',
            'unit': 'EUR/MWh',
            'currency': 'EUR',
            'currency_units': 'euro',
            'energy_units': 'MWh'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0003761.',
            'contracts': [f'2019M01-{increment_year(YEAR, MONTH, 3)}M{increment_month(MONTH, 3)}'],
            'period': 'Monthly',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009493.',
            'contracts': ['2019SS-2024SS'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009493.',
            'contracts': ['2019SW-2024SW'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009492.',
            'contracts': ['2019Q01-2024Q04'],
            'period': 'Quarterly',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0017639.',
            'contracts': ['2019Y-2025Y'],
            'period': 'Annual',
        },
    ]
}  # 4 months put from initial month model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0003761.

curves_ncg = {
    'common_meta_data': {
        'market': 'NCG',
        'source': 'ARGUS',
        'data_type': 'curve',
        'price_type': 'MID/ALL',
        'meta_data': {
            'curve': 'NCG',
            'contract_type': 'Future',
            'source': 'ARGUS',
            'price_type': 'GMT-mid',
            'unit': 'EUR/MWh',
            'currency': 'EUR',
            'currency_units': 'euro',
            'energy_units': 'MWh'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009554.',
            'contracts': ['2019SS-2024SS'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009554.',
            'contracts': ['2019SW-2023SW'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009552.',
            'contracts': ['2019Q01-2024Q04'],
            'period': 'Quarterly',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009553.',
            'contracts': ['2019Y-2025Y'],
            'period': 'Annual',
        },
    ]
}  # 4 months put from initial month model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0003761.

curves_psv_ttf_spread = {
    'common_meta_data': {
        'market': 'PSV/TTF',
        'source': 'ARGUS',
        'data_type': 'curve',
        'price_type': 'MID/ALL',
        'meta_data': {
            'curve': 'PSV/TTF',
            'contract_type': 'Future',
            'source': 'ARGUS',
            'price_type': 'GMT-mid',
            'unit': 'EUR/MWh',
            'currency': 'EUR',
            'currency_units': 'euro',
            'energy_units': 'MWh'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009261.',
            'contracts': [f'2024M01-{increment_year(YEAR, MONTH, 2)}M{increment_month(MONTH, 2)}'],
            'period': 'Monthly'
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009266.',
            'contracts': ['2018SW-2024SW'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009266.',
            'contracts': ['2018SS-2024SS'],
            'period': 'Seasonal'
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0010648.',
            'contracts': ['2019Q01-2024Q04'],
            'period': 'Quarterly'
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0017691.',
            'contracts': ['2019Y-2026Y'],
            'period': 'Annual',
        },
    ]
}  # 3 months out   model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009256.2023M04/MID/ALL

curves_peg_ttf_spread = {
    'common_meta_data': {
        'market': 'PEG/TTF',
        'source': 'ARGUS',
        'data_type': 'curve',
        'price_type': 'MID/ALL',
        'meta_data': {
            'curve': 'PEG/TTF',
            'contract_type': 'Future',
            'source': 'ARGUS',
            'price_type': 'GMT-mid',
            'unit': 'EUR/MWh',
            'currency': 'EUR',
            'currency_units': 'euro',
            'energy_units': 'MWh'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0003659.',
            'contracts': [f'2018M01-{increment_year(YEAR, MONTH, 3)}M{increment_month(MONTH, 3)}'],
            'period': 'Monthly'
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009497.',
            'contracts': ['2018SW-2024SW'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009497.',
            'contracts': ['2018SS-2024SS'],
            'period': 'Seasonal'
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0009496.',
            'contracts': ['2018Q01-2024Q04'],
            'period': 'Quarterly'
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0017705.',
            'contracts': ['2019Y-2025Y'],
            'period': 'Annual',
        },
    ]
}

curves_nbp_ttf_spread = {
    'common_meta_data': {
        'market': 'NBP/TTF',
        'source': 'ARGUS',
        'data_type': 'curve',
        'price_type': 'MID/ALL',
        'meta_data': {
            'curve': 'NBP/TTF',
            'contract_type': 'Future',
            'source': 'ARGUS',
            'price_type': 'GMT-close',
            'unit': 'p/therm',
            'currency': 'GBP',
            'currency_units': 'pence',
            'energy_units': 'therm'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0025095.',
            'contracts': [f'2018M01-{increment_year(YEAR, MONTH, 6)}M{increment_month(MONTH, 6)}'],
            'period': 'Monthly'
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0025098.',
            'contracts': ['2019SW-2027SW'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0025098.',
            'contracts': ['2019SS-2027SS'],
            'period': 'Seasonal'
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0025096.',
            'contracts': ['2019Q01-2026Q03'],
            'period': 'Quarterly'
        },
        {
            'model_url': 'model://ARGUS_DNG/EU.NG.DNG.ARGUS.PA0019515.',
            'contracts': ['2019Y-2027Y'],
            'period': 'Annual',
        },
    ]
}

curves_the_ttf_spread = {
    'common_meta_data': {
        'market': 'THE/TTF',
        'source': 'ARGUS',
        'data_type': 'curve',
        'price_type': 'SETTLE/ALL',
        'meta_data': {
            'curve': 'THE/TTF',
            'contract_type': 'Future',
            'source': 'ARGUS',
            'price_type': 'GMT-close',
            'unit': 'EUR/MWh',
            'currency': 'EUR',
            'currency_units': 'euro',
            'energy_units': 'MWh'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://ICE_THE/EU.NG.THE.ICE.NATGAS.FUT.',
            'contracts': ['2022M01-2029M01'],
            'period': 'Monthly',
        },
        {
            'model_url': 'model://ICE_THE/EU.NG.THE.ICE.NATGAS.FUT.',
            'contracts': ['2022SW-2028SW'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ICE_THE/EU.NG.THE.ICE.NATGAS.FUT.',
            'contracts': ['2022SS-2028SS'],
            'period': 'Seasonal',
        },
        {
            'model_url': 'model://ICE_THE/EU.NG.THE.ICE.NATGAS.FUT.',
            'contracts': ['2022Q1-2028Q4'],
            'period': 'Quarterly',
        },
        {
            'model_url': 'model://ICE_THE/EU.NG.THE.ICE.NATGAS.FUT.',
            'contracts': ['2022Y-2028Y'],
            'period': 'Annual'
        }
    ]
}

curves_des_nwe = {
    'common_meta_data': {
        'market': 'DES-NWE',
        'source': 'Petroineos',
        'data_type': 'curve',
        'price_type': 'FINAL',
        'meta_data': {
            'curve': 'DES-NWE/TTF',
            'contract_type': 'Spread',
            'source': 'Petroineos',
            'price_type': 'GMT-close',
            'unit': 'USD/MMBtu',
            'currency': 'USD',
            'currency_units': 'dollar',
            'energy_units': 'MMBtu'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://LNG_DESNWE_TTF/PC.DESNWE.TTF.SPD.MID.USD.MMBTU.C/CURVE/',
            'contracts': ['M01-M12'],
            'period': 'Monthly',
        }
    ]
}

# M01/SETTLE

curves_hh = {
    'common_meta_data': {
        'market': 'HH',
        'source': 'CME',
        'data_type': 'curve',
        'price_type': 'SETTLE',
        'meta_data': {
            'curve': 'HH',
            'contract_type': 'Future',
            'source': 'CME',
            'price_type': 'EST-Settle',
            'unit': 'USD/MMBtu',
            'currency': 'USD',
            'currency_units': 'dollar',
            'energy_units': 'MMBtu'
        }
    },
    'iterative_elements': [
        {
            'model_url': 'model://CME_NYMEX_NG/US.NYMEX.CME.ELECTRONIC.FUT.NG.',
            'contracts': [f'2019M01-2027M12'],
            'period': 'Monthly',
        }
    ]
}


# All Curves
curve_types = {
    'test-case': curves_test_case,
    'nbp': curves_nbp,
    'ttf': curves_ttf,
    'the': curves_the,
    'psv': curves_psv,
    'pvb': curves_pvb,
    'peg': curves_peg,
    'ncg': curves_ncg,
    'psv-ttf': curves_psv_ttf_spread,
    'peg-ttf': curves_peg_ttf_spread,
    'nbp-ttf': curves_nbp_ttf_spread,
    'the-ttf': curves_the_ttf_spread,
    'des-nwe': curves_des_nwe,
    'hh': curves_hh,
}


# Class: Takes curve meta data/url and fetches curve from DataGenic
class GasMarketCurves:
    """GasMarketCurves: Specifically for retrieving (and cleaning) forward curves for Gas Market
    """
    def __init__(self, date_from=None):
        self.datagenic_env = DataGenic.create_from_environment()
        pass

    def get_market_data_from_curves(self, curves_dict: dict) -> pd.DataFrame:
        dfs = [self.get_series_from_datagenic(model_id) for model_id in curves_dict['model_ids']]
        data = reduce(lambda df1, df2: pd.merge(df1, df2, how='outer', left_index=True, right_index=True), dfs)
        data = data.dropna(how='all')

        # Build data range, using "frequency='B'", to only land on business days
        range_dates = pd.date_range(
            start=data.index[0],
            end=data.index[-1],
            freq='B'
        )
        data = data.reindex(range_dates)  # Ensure consistent daterange to original work
        data.insert(0, 'Date', data.index)  # Make the datetime index a column also
        data = data.reset_index(drop=True)
        data.index.name = f'{curves_dict["market"]}-{curves_dict["source"]}'
        return data

    def get_series_from_datagenic(self, model_id, date_from_=datetime.datetime.now()-relativedelta(years=5, days=40)):
        data = self.datagenic_env.get_time_series(
            model_url=model_id,
            from_date=date_from_,
            to_date=datetime.datetime.now().date()
        )
        data.columns = [model_id]
        print(data.head())
        return data

    def get_curve_from_datagenic(self, model_id):
        data = self.datagenic_env.get_curve(
            model_url=model_id
        )
        data.columns = [model_id]
        return data

    def parse_curves_from_json(self, curve_dict: dict) -> dict:
        # Do some checks
        # Get all the model_ids for eah contract
        market, source, model_url = curve_dict['market'], curve_dict['source'], curve_dict['model_url']
        data_type, price_type = curve_dict['data_type'],  curve_dict['price_type']
        curve_list = []
        print(curve_dict['contracts'])

        for contract_range in curve_dict['contracts']:
            contracts = self._parse_contracts_from_range(contract_range)

            model_ids = [f'{model_url}{contract}/{price_type}' for contract in contracts]  # /{price_type}
            curve_list += model_ids
        curve_dict['model_ids'] = curve_list
        return curve_dict

    def _parse_contracts_from_range(self, contract_range: str) -> list:
        # e.g. 'M01-M54' -> ['M01', 'M02', ... 'M54']
        if contract_range[0].isalpha():
            start, stop = int(contract_range.split('-')[0][1:]), int(contract_range.split('-')[1][1:])
            return [contract_range[0] + "{0:0=2d}".format(i) for i in range(start, stop+1)]
        elif self._validate_string_is_year(contract_range[0:4]):
            c_start, c_end = contract_range.split('-')[0], contract_range.split('-')[1]
            if c_start[4] == 'M':   # Monthly Contract
                start = datetime.datetime(year=int(c_start[0:4]), month=int(c_start[5:7]), day=1)
                end = datetime.datetime(year=int(c_end[0:4]), month=int(c_end[5:7]), day=1)
                month_range = pd.date_range(start, end, freq='MS')  # .tolist()
                return month_range.format(formatter=lambda x: x.strftime(f'%Y{contract_range[4]}%m'))
            elif c_start[4:] == 'SS':  # Summer contract
                start = datetime.datetime(year=int(c_start[0:4]), month=1, day=1)
                end = datetime.datetime(year=int(c_end[0:4])+1, month=1, day=1)
                year_range = pd.date_range(start, end, freq='Y')  # .tolist()
                return year_range.format(formatter=lambda x: x.strftime(f'%YSS'))
            elif c_start[4:] == 'SW':  # Winter contract
                start = datetime.datetime(year=int(c_start[0:4]), month=1, day=1)
                end = datetime.datetime(year=int(c_end[0:4])+1, month=1, day=1)
                year_range = pd.date_range(start, end, freq='Y')  # .tolist()
                return year_range.format(formatter=lambda x: x.strftime(f'%YSW'))
            elif c_start[4] == 'Q':
                start = datetime.datetime(year=int(c_start[0:4]), month=int(c_start[5:7]), day=1)
                end = datetime.datetime(year=int(c_end[0:4]), month=int(c_end[5:7])*3, day=1)
                quarter_range = pd.date_range(start, end, freq='Q')   # .shift(-2)  # .tolist()
                quarter_map = {3: '01', 6: '02', 9: '03', 12: '04'}
                return [str(x.year) + 'Q' + quarter_map[x.month] for x in list(quarter_range)]
            elif c_start[4] == 'Y':
                start = datetime.datetime(year=int(c_start[0:4]), month=1, day=1)
                end = datetime.datetime(year=int(c_end[0:4])+1, month=1, day=1)
                year_range = pd.date_range(start, end, freq='Y')  # .tolist()
                return year_range.format(formatter=lambda x: x.strftime(f'%YY'))
        else:
            raise NotImplemented(f'The contract range passed "{contract_range}" does not match implemented patterns')

    @staticmethod
    def _validate_string_is_year(text: str):
        try:
            if text != datetime.datetime.strptime(text, "%Y").strftime('%Y'):
                raise ValueError
            return True
        except ValueError:
            return False

    @staticmethod
    def reformat_contract_value(contract):
        """  e.g., contract='2019M01' covert to JAN-19 """
        year = contract[2:4]
        if 'M' in contract:
            month = calendar.month_abbr[int(contract[5:])].upper()
            return month + '-' + year
        if 'SW' in contract:
            return 'W' + year
        if 'SS' in contract:
            return 'S' + year
        if 'Q' in contract:
            return 'Q' + contract[6] + '-' + year
        if 'Y' in contract:
            return 'CAL' + year

    @staticmethod
    def reformat_relative_contract_value(contract, pdate):
        """  e.g., contract='2019M01' covert to JAN-19 """

        if contract.startswith('M'):  # M01
            publ_month, publ_year, publ_day = str(pd.to_datetime(pdate).month), str(pd.to_datetime(pdate).year), str(pd.to_datetime(pdate).day)
            print(contract, pdate)
            month, year = increment_month_relative_to_date(publ_year, publ_month, publ_day, int(contract[1:]))
            month = calendar.month_abbr[int(month)].upper()
            return month + '-' + year[2:4]

        year = contract[2:4]
        if 'M' in contract:
            month = calendar.month_abbr[int(contract[5:])].upper()
            return month + '-' + year
        if 'SW' in contract:
            return 'W' + year
        if 'SS' in contract:
            return 'S' + year
        if 'Q' in contract:
            return 'Q' + contract[6] + '-' + year
        if 'Y' in contract:
            return 'CAL' + year

    @staticmethod
    def extract_expiry_date(contract):
        try:
            return pd.to_datetime(contract, format='%b-%y').replace(day=1)
        except Exception as e:
            year = contract[-2:]
            if 'Q1' in contract:
                return pd.to_datetime(year + '-01-01', format='%y-%m-%d')
            if 'Q2' in contract:
                return pd.to_datetime(year + '-04-01', format='%y-%m-%d')
            if 'Q3' in contract:
                return pd.to_datetime(year + '-07-01', format='%y-%m-%d')
            if 'Q4' in contract:
                return pd.to_datetime(year + '-10-01', format='%y-%m-%d')
            if 'S' in contract:
                return pd.to_datetime(year + '-4-01', format='%y-%m-%d')
            if 'W' in contract:
                return pd.to_datetime(year + '-10-01', format='%y-%m-%d')
            if 'CAL' in contract:
                return pd.to_datetime(year + '-01-01', format='%y-%m-%d')

    @staticmethod
    def extract_meta_features(data: pd.DataFrame, contract_type: str, period: str, currency: str, energy_units: str,
                              currency_units: str, source: str, price_type: str, curve: str, unit: str):
        data['Curve'] = curve
        data['ContractType'] = contract_type
        data['Period'] = period
        data['Source'] = source
        data['PriceType'] = price_type
        data['Unit'] = unit
        data['Currency'] = currency
        data['CurrencyUnit'] = currency_units
        data['EnergyUnit'] = energy_units
        return data


def transform_curve_data(curve_manager, curve_json):
    curve_json_parsed = curve_manager.parse_curves_from_json(curve_json)
    print(curve_json_parsed)
    market_data = curve_manager.get_market_data_from_curves(curve_json_parsed)
    #     Date      C1   C2   ...  CFinal
    # 2018-01-01   7.1   8.1        7.9
    # 2018-01-02   7.2   8.3        8.0
    #  .....       ...   ...        ...
    # 2023-11-21   9.1   11.2       10.9
    print(market_data.head())
    if 'LNG_DESNWE_TTF' in market_data.columns[1]:
        # market_data = market_data.set_index('Date')
        market_data.columns = [col.split('/CURVE/')[-1].split('/')[0] for col in market_data.columns]  # Melt data into format
    else:
        market_data.columns = [col.split('.')[-1].split('/')[0] for col in market_data.columns]  # Melt data into format
    data = pd.melt(market_data, id_vars=['Date'], value_vars=[col for col in market_data.columns if col != 'Date'])
    data = data.rename(columns={'variable': 'Contract', 'value': 'Price'})
    data = curve_manager.extract_meta_features(data, period=curve_json['period'], **curve_json['meta_data']).dropna()
    return data


if __name__ == '__main__':
    pd.set_option('display.max_columns', 50)
    pd.set_option('display.max_colwidth', 50)
    pd.set_option('display.expand_frame_repr', False)

    env = os.environ['environment']
    log = ag_log.get_log()

    parser = argparse.ArgumentParser()
    parser.add_argument('-env', action='store', dest='env', default=env, help='Production environment')
    parser.add_argument('-curve', action='store', dest='curve', default='test-case', help='Curve to scrape')

    args = parser.parse_args(sys.argv[1:])
    env = 'UAT'  # args.env
    curve = 'psv-ttf'  # args.curve
    # curve = 'test-case'  # args.curve

    # Some example usages (note curves_of_interest is a list, might be better as a dictionary, but fine for now I think)
    gmc = GasMarketCurves()   # .get_market_data_from_curves()

    df_all_curves = []
    for curve_type in curve_types[curve]['iterative_elements']:
        curve_json_ = {}
        curve_json_.update(curve_types[curve]['common_meta_data'])
        curve_json_.update(curve_type)
        curve_extracted = transform_curve_data(gmc, curve_json_)
        df_all_curves.append(curve_extracted)
    df_all_curves = pd.concat(df_all_curves)

    df_all_curves = df_all_curves.rename(columns={'Date': 'PDate'})
    final_table_columns = [
        'PDate', 'Curve', 'Source', 'Contract', 'Price', 'ExpiryDate',
        'Period', 'ContractType', 'PriceType', 'PricingDays', 'Unit',
        'Currency', 'CurrencyUnit', 'EnergyUnit'
    ]
    df_all_curves['PricingDays'] = np.nan
    print(df_all_curves.head())
    if curve == 'des-nwe':
        df_all_curves['Contract'] = df_all_curves.apply(lambda x: gmc.reformat_relative_contract_value(x['Contract'], x['PDate']), axis=1)
    else:
        df_all_curves['Contract'] = df_all_curves['Contract'].apply(lambda x: gmc.reformat_contract_value(x))

    # print(df_all_curves.head())
    # exit()
    df_all_curves['ExpiryDate'] = df_all_curves['Contract'].apply(lambda x: gmc.extract_expiry_date(x))

    # Upload data to BlueOcean!
    du.upload_to_database(df_all_curves, 'Upload_natural_gas_futures_curves-', index=False, env='UAT')

    # print(df_all_curves.head(20))
    # print(df_all_curves.shape)

    # df_all_curves.to_csv(os.path.join(upload_folder, 'nbp_curve.csv'))
    exit()





