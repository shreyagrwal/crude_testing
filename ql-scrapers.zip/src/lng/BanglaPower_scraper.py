import os
import re
import sys
import time
import PyPDF2
import pandas as pd
import urllib.request
from random import randint
from selenium import webdriver
from datetime import datetime, timedelta
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

sys.path.append(os.getcwd())
from scraper_utils import scraper_upload as su
from scraper_utils import scraper_environment as se

env = se.environment
bulkUploaderFolder = se.ingestion_folder
# define the webpage that we will be scraping with selenium
webpage = r"http://119.40.95.168/bpdb/daily_generation"

# define pdate & different types of ddate as below:
pdate = datetime.strftime(datetime.today(),"%Y-%m-%d") # we will use this when outputting the csv for database
dt = datetime.strftime(datetime.today() - timedelta(2),"%d/%m/%Y") # we will use this to enter date into website search box below - current day's data doesnt publish until two days after, so we have to go backwards by two days
ddate = datetime.strptime(dt,"%d/%m/%Y") - timedelta(1) # we will use this to create ddate_file and ddate_data - data published is always for the day prior
ddate_file = datetime.strftime(ddate,"%Y%m%d") # we use this in pdf & csv file name convention
ddate_data = datetime.strftime(ddate,"%Y-%m-%d") # we use this within the dataframe when outputting the csv for database, as have to adhere to %Y-%m-%d format

# Step 1 - navigate to the correct url

# Initialise selenium chromedriver
chrome_options = Options()
chrome_options.headless = True
driver = webdriver.Chrome(ChromeDriverManager().install())
driver.get(webpage)
time.sleep(randint(2,5))

# Enter into start and end date boxes the date we want to scrape.
# By doing this, the idea is that we return only a single result which we then scrape
sdate = driver.find_element('id', "datepicker1")
sdate.send_keys(dt)
time.sleep(randint(2,5))
edate = driver.find_element('id', "datepicker2")
edate.send_keys(dt)

# Click away from the search box to reveal the 'submit' button
driver.find_element('xpath', '//*[@id="search_table"]/tbody/tr[1]/td[1]/b').click()
time.sleep(randint(2,5))
# Submit the dates and wait for website to reload with single dataset we want to scrape
driver.find_element('xpath', '//*[@id="search_table"]/tbody/tr[3]/td[2]/button').click()
time.sleep(randint(2,5))

# We are able to locate the url that we want to scrape, and save to a variable
pdf_url = driver.find_element('xpath', '//*[@id="primary"]/table[2]/tbody/tr/td[6]/a').get_attribute('href')


# Define a function which uses urllib.request to download a pdf using a given url which we have already scraped in the step above
def download_file(download_url, filename):
    response = urllib.request.urlopen(download_url,timeout=10)
    file = open(filename + ".pdf", "wb")
    file.write(response.read())
    file.close()


# Define absolute path which we will use to save the pdf and later save local version of final csv
abs_path = r'\\petroineos.local\dfs\Department Private Folders\Gas Power and Emission Dept\LNG\LNG Analytics\Country models\ScrapeFolder\Bangla\bd_power_scrape'

# Apply function to download the pdf and save where desired
download_file(pdf_url, abs_path + r'\pdf_archive\BanglaPowerDataPdf_' + ddate_file)
driver.close()


# Step 2 - pull out data from pdf

# We use PyPDF2 library to scrape the pdf. This is different to BanglaGas_scraper where we use tabula to directly convert pdf to dataframe
# PyPDF2 is more complicated - it outputs a string of text from the PDF which we have to extract from using clever string slicing techniques
# Unfortunately tabula does not work on the Bangaldesh Power data PDF's, hence we are forced to use PyPDF2.
# However, is still a powerful approach which also works.

# Open the pdf, extract the second page (index 1), then assign to variable called text
pdf_file_obj = open(abs_path + r'\pdf_archive\BanglaPowerDataPdf_' + ddate_file + '.pdf', 'rb')
pdf_reader = PyPDF2.PdfFileReader(pdf_file_obj)
page_obj = pdf_reader.getPage(1)
text = page_obj.extractText()
pdf_file_obj.close()


# Define function where for a given string and start/end string character, we extract everything inbetween
def find_between( s, first, last ):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""


# Define a function which only pulls out digits (e.g. 01234) from a given string
def pull_digits(s):
    digits = []
    for d in s.split():
        try:
            digits.append(float(d))
        except ValueError:
            pass
    return digits


# Define the ending point which we will use for string slicing
end = "M"
# NEW STRING SLICING METHOD - WORKS ON AP7 i.e. via ActiveBatch
# Apply the functions above where needed, to derive all the data we need
gas = pull_digits(find_between(text,"By Gas",end))[0]
coal = pull_digits(find_between(text,"By Coal",end))[0]
oil = re.sub('[^0-9.]','',str(find_between(text, "By Oil", end)))  # use regex function
solar = re.sub('[^0-9.]','',str(find_between(text,"By Solar",end)))  # use regex function
hydro = re.sub('[^0-9.]','',str(find_between(text,"By Hydro",end)))  # use regex function
gas_sup = pull_digits(find_between(text,"Total Gas Supplied",end))[0]
date = find_between(text,"Actual data of","(Yesterday)").strip('\n').split()[0].replace('.','')


# OLD STRING SLICING METHOD - DOESN'T WORK ON AP7 FOR SOME REASON, BUT WORKED ON JUPYTER NOTEBOOK WHEN FIRST BUILDING AND TESTING THIS SCRAPER
# gas = pull_digits(find_between(text,"By Gas",end).strip('\n'))[0]
# coal = pull_digits(find_between(text,"By Coal",end).strip('\n'))[0]
# oil = pull_digits(find_between(text, "By Oil", end).strip('\n'))[0]
# solar = pull_digits(find_between(text,"By Solar",end).strip('\n'))[0]
# hydro = pull_digits(find_between(text,"By Hydro",end).strip('\n'))[0]
# gas_sup = pull_digits(find_between(text,"Total Gas Supplied",end).strip('\n'))[0]
# date = find_between(text,"Actual data of","(Yesterday)").strip('\n').split()[0].replace('.','')


# Step 3 - pull out data from pdfExport the final data as csv, which will eventually be pushed into the database

# Combine all the data into a single list, define the headers, and then build out a dataframe and assign the headers
data = [pdate, ddate_data, gas, coal, oil, solar, hydro, gas_sup]
headers = ['PDate','DDate','Gas','Coal','Oil','Solar','Hydro','GasSupplied']
df = pd.DataFrame([data])
df.columns = headers

# Keep a record in our own folder
df.to_csv(abs_path + r'\for_database\Upload_LNG_BanglaPowerData-' + ddate_file + '.csv' , index=False)

# Automatically push into database
db_path = bulkUploaderFolder

su.upload_to_database(df, 'Upload_LNG_BanglaPowerData-')
print('Ran successfully')