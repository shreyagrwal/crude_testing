import os, sys
sys.path.append(os.getcwd())
from selenium import webdriver
import requests
import sys
import os
import pandas as pd
import time
from datetime import datetime
from ag_log import ag_log
from scraper_utils import scraper_environment as se
from ag_data_access import blueocean_access as bo

env = se.environment
bulkUploaderFolder = se.ingestion_folder
run_unit_test = False
log = ag_log.get_log()


def load_chorme_settings():
    temp_path = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Scrapers\LNG'
    chrome_options = webdriver.ChromeOptions()

    if sys.gettrace() is None:
        chrome_options.add_argument('--headless')

    chrome_options.add_experimental_option("useAutomationExtension", False);
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": os.path.join(temp_path, '_download'),
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    chrome_options.add_argument("test-type");
    chrome_options.add_argument("start-maximized");
    chrome_options.add_argument("--js-flags=--expose-gc");
    chrome_options.add_argument("--enable-precise-memory-info");
    chrome_options.add_argument("--disable-popup-blocking");
    chrome_options.add_argument("--disable-default-apps");
    chrome_options.add_argument("--enable-automation");
    chrome_options.add_argument("test-type=browser");
    chrome_options.add_argument("disable-infobars");
    chrome_options.add_argument("--disable-extensions");
    chrome_options.add_argument('--allow-running-insecure-content')
    chrome_options.add_argument('--ignore-certificate-errors')

    browser = webdriver.Chrome(executable_path="..\\Tools\\chromedriver.exe", chrome_options=chrome_options)

    return browser


def bypass_certificate_warning(browser):
    try:
        visit_site_anyway = browser.find_element_by_name("Override")
        log.debug("Certificate warning detected, click anyway")
        visit_site_anyway.click()
        time.sleep(2)

    except:
        log.debug("No certificate warning detected")


def sanity_check(df_natgas):
    if df_natgas.empty:
        log.debug("Nat gas production table is empty")
        return False

    if len(df_natgas) < 2:
        log.debug("The number of rows are not as expected")
        return False

    return True


def cleansing_data(df_natgas):
    #Homework
    #Transform dataframe here

    #df_natgas.to_csv(r'C:\temp\test\china_gas.csv',header=True,index=False)

    df_result = df_natgas.set_index('Indicators').T
    df_result.reset_index(inplace=True)

    del df_result['Output of Natural Gas, Growth Rate (The same period last year=100)(%)']
    del df_result['Output of Natural Gas, Accumulated Growth Rate(%)']

    df_result = df_result.rename(columns={'index':'DDate', 'Output of Natural Gas, Current Period(100 million cu.m)':'Outputbcm', 'Output of Natural Gas, Accumulated(100 million cu.m)':'AccOutputbcm'})

    df_result['Outputbcm'] = df_result['Outputbcm'] / 10
    df_result['AccOutputbcm'] = df_result['AccOutputbcm'] / 10
    df_result['DDate'] = '1 ' + df_result['DDate']
    df_result['DDate'] = pd.to_datetime(df_result['DDate'])
    df_result['PDate'] = datetime.today()
    df_result['Country'] = 'China'
    return df_result


def get_upload_filename(env):
    bulk_uploader_folder = bulkUploaderFolder
    filename = 'Upload_LNG_NatGasProduction-'
    format_datetime = '%y%m%d%H%M%S'
    full_filename = bulk_uploader_folder + "\\" + filename + datetime.now().strftime(format_datetime) + ".csv"
    return full_filename


def unittest_cleansing_data():
    df = pd.read_csv(r'C:\temp\test\china_gas.csv')
    cleansing_data(df)


if run_unit_test:
    log.debug("Running Job Cleansing CSV File in Temp Folder.")
    unittest_cleansing_data()

try:
    log.debug("Initialising Chrome.")
    chrome = load_chorme_settings()
    begin_url = "https://data.stats.gov.cn/english/easyquery.htm?cn=A01"
    log.debug("Beginning URL: {0}".format(begin_url))

    log.debug("Getting the Beginning URL.")
    chrome.get(begin_url)
    log.debug("Bypass the Certificate Warning.")
    bypass_certificate_warning(chrome)

    log.debug("Get to the Target HTML Page.")
    monthly = chrome.find_element_by_xpath('//*[@id="topmenu"]/ul/li[2]/a')
    monthly.click()
    time.sleep(5)

    energy = chrome.find_element_by_xpath('//*[@id="treeZhiBiao_4_a"]')
    energy.click()

    time.sleep(5)

    output_of_energy_products = chrome.find_element_by_xpath('//*[@id="treeZhiBiao_16_a"]')

    output_of_energy_products.click()
    time.sleep(5)

    natural_gas = chrome.find_element_by_xpath('//*[@id="treeZhiBiao_19_a"]')

    natural_gas.click()
    time.sleep(5)

    log.debug("Read HTML Page.")
    dataframe_list = pd.read_html(chrome.page_source)

    if len(dataframe_list) > 0:
        df_natgas = dataframe_list[0]
        #Sanity Check
        log.debug("Running Sanity Check.")
        if sanity_check(df_natgas):
            #Cleansing Data
            log.debug("Sanity Check Passed.")
            log.debug("Cleansing the DataFrame.")
            df_result = cleansing_data(df_natgas)
            file_fullname = get_upload_filename(env)
            df_result.to_csv(path_or_buf=file_fullname,header=True,index=False)
            log.debug("CSV File Saved to: {0}.".format(file_fullname))
            log.debug("Job Completed.")
        else:
            log.debug("Sanity Check failed. Data is not uploaded")
        log.debug(df_result)
    else:
        log.debug("Failed to find any relevant data. The web page has been changed.")
        exit(1)

except Exception as e:
    log.debug(e)
finally:
    chrome.close() # close chrome
    chrome.quit() #close chrome driver

log.debug("Done!")

