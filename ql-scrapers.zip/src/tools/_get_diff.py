import os
import pandas as pd

temp_path = r'\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\Scrapers\Temp\Dong\gassco'
df_pre_name = 'Upload_Gas_GasscoFlow-201217125357.csv'
df_curr_name = 'Upload_Gas_GasscoFlow-201222094142.csv'
df_pre = pd.read_csv(os.path.join(temp_path, df_pre_name))
df_curr = pd.read_csv(os.path.join(temp_path, df_curr_name))
del temp_path, df_pre_name, df_curr_name


def get_added_and_removed(dataframe_left, dataframe_right, columns, join_on):

    compare_event = dataframe_left[columns].merge(dataframe_right[columns], on=join_on, indicator=True, how='outer')
    df_added_list = compare_event[compare_event['_merge'] == 'left_only'].drop(columns='_merge')
    df_deleted_list = compare_event[compare_event['_merge'] == 'right_only'].drop(columns='_merge')
    df_existing_list = compare_event[compare_event['_merge'] == 'both'].drop(columns='_merge')

    df_added = df_added_list.merge(dataframe_left, on=join_on, indicator=True, how='inner').drop(columns='_merge')
    df_deleted = df_deleted_list.merge(dataframe_right, on=join_on, indicator=True, how='inner').drop(columns='_merge')

    df_existing_old = df_existing_list.merge(dataframe_right, on=join_on, indicator=True, how='inner').drop(columns='_merge')
    df_existing_new = df_existing_list.merge(dataframe_left, on=join_on, indicator=True, how='inner').drop(columns='_merge')

    del compare_event, df_added_list, df_deleted_list, df_existing_list
    return df_added, df_deleted, df_existing_old, df_existing_new


def get_updates_and_unchanged(df2, df1, df_existing_new, df_existing_old, columns, join_on):

    compare_updates = df_existing_new[columns].merge(df_existing_old[columns], on=join_on, indicator=True, how='outer')
    df_updates_after_list = compare_updates[compare_updates['_merge'] == 'left_only'].drop(columns='_merge')
    df_updates_before_list = compare_updates[compare_updates['_merge'] == 'right_only'].drop(columns='_merge')
    df_no_change_list = compare_updates[compare_updates['_merge'] == 'both'].drop(columns='_merge')

    df_updates_after = df_updates_after_list.merge(df2, on=['event_id', 'revision'], indicator=True, how='inner').drop(
        columns='_merge')
    df_updates_before = df_updates_before_list.merge(df1, on=['event_id', 'revision'], indicator=True, how='inner').drop(
        columns='_merge')
    df_no_change_after = df_no_change_list.merge(df2, on=['event_id', 'revision'], indicator=True,
                                                     how='inner').drop(columns='_merge')
    df_no_change_before = df_no_change_list.merge(df1, on=['event_id', 'revision'], indicator=True,
                                                     how='inner').drop(columns='_merge')
    return df_updates_after, df_updates_before, df_no_change_after, df_no_change_before

### Column Names and Join_on on distinct elemnt, e.g. event ID
### Return 4 DataFrame: Added, Deleted, Existings from previous DataFrame, Existings from existing DataFrame
df_added, df_deleted, df_existing_pre, df_existing_curr \
    = get_added_and_removed(df_curr, df_pre, ['event_id'], ['event_id'])

### Column Names and Join_on on distinct elemnt, e.g. event ID and updates, e.g. Version
### Return 4 DataFrame: Updated from previsous DataFrame Updated from current DataFrame,
### Unchanged from previous DataFrame, Unchanged from existing DataFrame
df_updates_curr, df_updates_pre, df_no_change_curr, df_no_change_pre \
    = get_updates_and_unchanged(df_curr, df_pre, df_existing_curr, df_existing_pre, ['event_id', 'revision'], ['event_id', 'revision'])

del df_existing_pre, df_existing_curr

pass


