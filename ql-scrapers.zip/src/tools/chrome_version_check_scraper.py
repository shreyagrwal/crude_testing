from win32com.client import Dispatch
from selenium import webdriver
from ag_email import ag_email_helper as aeh
import platform
import ag_log

env = 'UAT'
# env = 'PROD'

if env == 'PROD':
    # Server Location
    chrome_path = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
    recipients = "Charles.Cai@petroineos.com;Dong.Xia@petroineos.com"
else:
    # Local Machine
    chrome_path = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
    recipients = "Dong.Xia@petroineos.com"


def send_alert_email(email_from, emails, vm_name, chrome_version, webdriver_version):

    sub = "Server Chrome WebDriver Alert - " + vm_name
    body = "<b>Device Name: " + vm_name + "</b>" \
           + "<br>" \
           + "<br>" \
           + "Google Chrome Version: " + chrome_version + "</b>" \
           + "<br>" \
           + "Chrome Driver File Version: " + webdriver_version + "</b>" \
           + "<br>" \

    imgList = []

    email_sender = aeh.AgEmailHelper()
    email_sender.send_mail_with_embedded_images(email_from, emails, sub, body, imgList)


def send_error_email(email_from, emails, vm_name, error):

    sub = "Server Chrome WebDriver Scraper Error!"
    body = "<b>Device Name: " + vm_name + "</b>" \
           + "<br>" \
           + "<br>" \
           + "<b>Error Message: </b>" \
           + "<br>" \
           + "<br>" \
           + error.msg + "</b>" \
           + "<br>" \

    imgList = []

    email_sender = aeh.AgEmailHelper()
    email_sender.send_mail_with_embedded_images(email_from, emails, sub, body, imgList)


def get_version_via_com(filename):
    parser = Dispatch("Scripting.FileSystemObject")
    try:
        version = parser.GetFileVersion(filename)
    except Exception:
        return None
    return version


def main():
    try:
        log.debug("Env: " + env)

        # Get Machine Name
        vm_name = platform.node()
        log.debug("Device Name: " + vm_name)

        # Get Google Chrome Version
        paths = [chrome_path]
        chrome_version = list(filter(None, [get_version_via_com(p) for p in paths]))[0]
        log.debug("Google Chrome Version: " + chrome_version)

        # Get Google Webdriver Version
        log.debug("Initiate Chrome Driver.")
        # Setup Chrome Driver Options
        chrome_options = webdriver.ChromeOptions()
        #chrome_options.add_argument('--headless')
        browser = webdriver.Chrome(executable_path="..\\Tools\\chromedriver.exe", chrome_options=chrome_options)
        webdriver_version = browser.capabilities['chrome']['chromedriverVersion'].split(' ')[0]
        log.debug("Chrome Driver File Version: " + webdriver_version)
        browser.close()
        browser.quit()

        # Compare the versions
        if chrome_version.split(".")[0] != webdriver_version.split(".")[0]:
            log.debug("Version Mismatch Detected.")
            log.debug("Sending Alert Email.")
            send_alert_email("dong.xia@petroineos.com", recipients, vm_name, chrome_version, webdriver_version)

            log.debug("Alert Email Sent.")
            log.debug("Job Completed.")
        else:
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            log.debug("Version Matches")
            log.debug("Device Name: " + vm_name)
            log.debug("Google Chrome Version: " + chrome_version)
            log.debug("Chrome Driver File Version: " + webdriver_version)
            log.debug("No Action Required.")
            log.debug("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            log.debug("Job Completed.")

        return 0

    except Exception as e:
        log.error(e)
        send_error_email("dong.xia@petroineos.com", recipients, vm_name, e)
        log.debug("Job Ended with Error!!!")
        return 1


if __name__ == "__main__":
    log = ag_log.get_log()
    exit(main())