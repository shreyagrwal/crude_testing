import pandas as pd


def set_pandas_options_to_max():
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', 2000)
    pd.set_option('display.max_colwidth', None)
    pd.options.display.float_format = "{:,.3f}".format
    pass

