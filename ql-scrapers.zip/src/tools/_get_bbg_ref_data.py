import blpapi
import pandas as pd
#Excel BBG Add-in: BDP get the latest

tickers = ['NG1 Comdty', 'TZT1 Comdty']
fields = ['PX_LAST', 'LAST_TRADEABLE_DT', 'FUT_ACT_DAYS_EXP', 'LAST_TRADE', 'PX_VOLUME', 'LAST_PRICE']


def get_bbg_ref_data(tickers, fields):

    # Array for efficient data processing
    ar = []
    # Dictionary to hold single line of data
    security_data = {}
    # 1. Establish a connection
    # 1.1 Session init
    session = blpapi.Session()
    # 1.2 Start a Session
    if not session.start():
        print("Failed to start session.")
        exit(0)
    # 2. Open service
    if not session.openService("//blp/refdata"):
        print("Failed to open //blp/refdata")
        exit(0)
    # 3. Get service
    refDataService = session.getService("//blp/refdata")
    # 4. Set request
    request = refDataService.createRequest("ReferenceDataRequest")
    # 4.1 Tickers
    for value in tickers:
        request.getElement("securities").appendValue(value)
    # 4.2 Fields
    for value in fields:
        request.getElement("fields").appendValue(value)
    # 5. Send request
    cid = session.sendRequest(request)
    # 6. Print data
    # Process received events
    while (True):
        ev = session.nextEvent(500)
        if ev.eventType() == blpapi.Event.RESPONSE or ev.eventType() == blpapi.Event.PARTIAL_RESPONSE:
            for msg in ev:
                if cid in msg.correlationIds():
                    security_arr = msg.getElement("securityData")
                    for security in security_arr.values():
                        security_data = {}
                        # Ticker name
                        security_name = security.getElement("security").getValue()
                        # Fields Data
                        field_arr = security.getElement("fieldData").elements()
                        for field in field_arr:
                            # print({str(field.name()) :field.getValueAsString() })
                            if str(field.name()) == 'VOLUME':
                                security_data[str(field.name())] = field.getValueAsInteger()
                            else:
                                security_data[str(field.name())] = field.getValueAsString()
                        # security_data  = {str(field.name()) :field.getValueAsString() for field in field_arr}
                        security_data['Ticker'] = security_name
                        ar.append(security_data.copy())
                else:
                    pass
        if ev.eventType() == blpapi.Event.RESPONSE:
            break
    # 7. Stop the session
    session.stop()
    # 8. print(ar)
    df = pd.DataFrame(ar, columns=[*fields, "Ticker"]).set_index(['Ticker'])
    del ar
    del security_data

    return df


df = get_bbg_ref_data(tickers, fields)
print(df)