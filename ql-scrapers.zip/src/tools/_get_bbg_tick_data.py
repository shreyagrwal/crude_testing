import blpapi
import datetime
import pandas as pd
#note: Excel BBG Add-in: Intraday Tick Data

ticker = "CO1 Comdty"
srt_time = datetime.datetime(2021, 2, 17, 13)
end_time = datetime.datetime(2021, 2, 17, 13, 1)
cond_code = None


def get_bbg_tick_data(ticker, srt_time, end_time, cond_code):

    # Array for efficient data processing
    ar = []
    # Dictionary to hold single line of data
    security_data = {}
    # 1. Establish a connection
    # 1.1 Session initialise
    session = blpapi.Session()
    # 1.2 Start a Session
    if not session.start():
        print("Failed to start session.")
        exit(0)
    # 2. Open service
    if not session.openService("//blp/refdata"):
        print("Failed to open //blp/refdata")
        exit(0)
    # 3. Get service
    refDataService = session.getService("//blp/refdata")
    # 4. Set request
    request = refDataService.createRequest("IntradayTickRequest")
    request.set("security", ticker)
    request.getElement("eventTypes").appendValue("TRADE")
    request.getElement("eventTypes").appendValue("BEST_ASK")
    request.getElement("eventTypes").appendValue("BEST_BID")
    request.set("includeConditionCodes", True)
    request.set("includeNonPlottableEvents", True)
    request.set("startDateTime", srt_time)
    request.set("endDateTime", end_time)
    # 5. Send request
    print("Sending Request:\n", request)
    session.sendRequest(request)
    # 6. Print data
    # Process received events
    while (True):
        ev = session.nextEvent(500)

        if ev.eventType() == blpapi.Event.RESPONSE or ev.eventType() == blpapi.Event.PARTIAL_RESPONSE:
            for msg in ev:
                tick_data = msg.getElement('tickData').getElement('tickData')
                for item in tick_data.values():
                    security_data['Time'] = item.getElementAsDatetime("time")
                    security_data['Type'] = item.getElementAsString("type")
                    security_data['Value'] = item.getElementAsFloat("value")
                    security_data['Size'] = item.getElementAsInteger("size")

                    if item.hasElement("conditionCodes"):
                        security_data['Cond Code'] = item.getElementAsString("conditionCodes")
                    else:
                        security_data['Cond Code'] = ""

                    # Append the data to list
                    if cond_code is None:
                        ar.append(security_data.copy())
                    else:
                        if cond_code in security_data['Cond Code']:
                            ar.append(security_data.copy())
                        else:
                            pass
        if ev.eventType() == blpapi.Event.RESPONSE:
            break
    # 7. Stop the session
    session.stop()
    df = pd.DataFrame(ar)
    # 8. print(ar)
    if not df.empty:
        df = df.set_index('Time')
    del ar
    del security_data

    return df


df = get_bbg_tick_data(ticker, srt_time, end_time, cond_code)
print(df)


