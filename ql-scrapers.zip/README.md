[[_TOC_]]
# Introduction 


# requirements.txt file
Please ensure that you keep this file up to date. The CI/CD on Azure Devops will use this file to re-create the environment.
https://pip.pypa.io/en/stable/reference/requirements-file-format/

# Creating a VENV when using Visual Studio Code
https://code.visualstudio.com/docs/python/environments

# Creating a VENV when using PyCharm
https://www.jetbrains.com/help/pycharm/creating-virtual-environment.html


# How to use environment variables ?
- Step 1 - Create a **.ENV** file under ql-scrapers
- Step 2 - Add your environment variable in this file (e.g. somepassword=1233434)
- Step 3 - Use the `dotenv` module to load the environment variables form the .ENV file and inject into the running process
- Step 4 - Use the `os.environ["somepassword"]` to read the secret value
- 
See the sample `src/hello_world/main1.py` 


# CPDP Scrapers
[Click here for CPDP scrapers](docs/cpdp_scrapers.md)

# Manage reference tables
[Click here for understanding how to manage Reference tables](docs/reference_data.md)
