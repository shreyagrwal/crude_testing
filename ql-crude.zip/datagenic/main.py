import datetime

from pymarketdata.datagenic import DataGenic

def time_series(dg: DataGenic, model_url: str):
    from_date = datetime.date(2021, 7, 29)
    to_date = datetime.date(2021, 7, 30)
    ts = dg.get_time_series(model_url, from_date, to_date)
    print(ts)


if __name__ == '__main__':
    import pymarketdata
    print(pymarketdata.datagenic.__file__)
    dg_url = "http://test.petro.datagenic.net:8080/"
    dg_user = "petro.admin"
    dg_password = "N48XF4ty"
    dg = DataGenic(dg_url)
    if not dg.connect(dg_user, dg_password):
        print("ERROR failed to connect to DataGenic")
        exit(1)
    print(f"GDM version: {dg.version}")
    time_series(dg, "model://BELPX_AUC/EU.EL.BE.BELPX.DA.FD")
    dg.disconnect()