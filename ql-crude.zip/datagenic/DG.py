import os
from datetime import datetime as dt
import pandas as pd

# # py 3.7.0
# from datagenic_rest_client.datagenic import DataGenic
# datagenic_rest_server = "http://lon-qdev-ap11"
# d = DataGenic(
#     url_rest_wrapper=datagenic_rest_server, datagenic_url=os.environ["datagenicserver"],
#   datagenic_username=os.environ["datagenicusername"], datagenic_password=os.environ["datagenicpassword"])

# py 3.9.7
from ag_datagenic_rest_client import DataGenic
d = DataGenic.create_from_environment()


def get_prices_df(model_dict, start):
    prices_list = []
    for x in model_dict.values():
        y = d.get_time_series(model_url = x, from_date=start, to_date=dt.today())
        prices_list.append(y)
    df = pd.concat(prices_list, axis=1)
    df.columns = model_dict.keys()
    return df

def get_monthly_prices_df(model_dict, start):
    prices_list = []
    for x in model_dict.values():
        y = d.get_time_series(model_url = x, from_date=start, to_date=dt.today()).resample('MS').mean()
        prices_list.append(y)
    df = pd.concat(prices_list, axis=1)
    df.columns = model_dict.keys()
    return df

def test():
    drivers = {
    'futm1':"model://ICE_BRENT/EU.OIL.NSEA.ICE.BRENT.FUT.M01",
    'futm2':"model://ICE_BRENT/EU.OIL.NSEA.ICE.BRENT.FUT.M02",
    }

    df = get_prices_df(drivers,dt(2022,1,1))
    assert len(df.columns) == 2
    print(df.tail())
    print('daily test successful')
    df_m = get_monthly_prices_df(drivers,dt(2022,1,1))
    assert len(df_m.columns) == 2
    print(df_m.tail())
    print('monthly test successful')

if __name__ == '__main__':
   test() 