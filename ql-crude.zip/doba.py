import os
import datetime
from datetime import datetime as dt
from datagenic_rest_client.datagenic import DataGenic
import pandas as pd
import statsmodels.api as sm

# todo regress vs structure, freight and crack

datagenic_rest_server = "http://lon-qdev-ap11"

dg = DataGenic(
    url_rest_wrapper=datagenic_rest_server, datagenic_url=os.environ["datagenicserver"],
  datagenic_username=os.environ["datagenicusername"], datagenic_password=os.environ["datagenicpassword"])

# doba_diff_url = r'I:\Crude Oil Department\Analytics\_WAF\Doba Diffs.xlsx'
# traded_diffs = pd.read_excel(doba_diff_url, sheet_name='Prog')

def get_traded_diffs_cleaned():
    doba_diff_url = r'C:\Users\syedahmad\Documents\doba\doba_traded_diffs.csv'
    traded_diffs = pd.read_csv(doba_diff_url)
    traded_diffs['trade_date'] = pd.to_datetime(traded_diffs['trade_date'])
    diffs_unique = traded_diffs.groupby('trade_date').mean()
    diffs_unique.fillna(method='ffill', inplace=True)
    diffs_daily = diffs_unique.resample('D').ffill()
    return diffs_daily

def get_regressors():
    from_date = datetime.date(2015, 1, 1)
    to_date = datetime.date.today()

    
    nwe_lsfo_model = 'model://PI_OIL_PROD_HEA/PI.FO10.CCIFNWE.USD.MT.C/CURVE/M01/FINAL'
    ice_brent_m1_model = 'model://PI_OIL_CRU_ICE/PI.BRENT.ICESWAP.USD.BBL.C/CURVE/M01/FINAL'
    ice_brent_m2_model = 'model://PI_OIL_CRU_ICE/PI.BRENT.ICESWAP.USD.BBL.C/CURVE/M02/FINAL'
    freight_model = 'model://PLATTS_TD/PLATTS.FR.TD.TDACR00'

    dg_nwe_lsfo = dg.get_time_series(nwe_lsfo_model, from_date, to_date).resample('D').ffill()
    m1 = dg.get_time_series(ice_brent_m1_model, from_date, to_date).resample('D').ffill()
    m2 = dg.get_time_series(ice_brent_m2_model, from_date, to_date).resample('D').ffill()
    freight = dg.get_time_series(freight_model, from_date, to_date).resample('D').ffill()
    df = pd.concat([dg_nwe_lsfo,m1,m2, freight], axis=1)
    df.columns = ['lsfo', 'm1', 'm2', 'freight']
    df['spread'] = df['m1'] - df['m2']
    df['lsfo_bbl'] = df['lsfo']/6.33
    df['crack'] = df['lsfo_bbl'] - df['m1']
    df_new = df[['crack', 'spread', 'freight']].copy()
    return df_new