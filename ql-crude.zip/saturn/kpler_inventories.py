import os
from datetime import date
from kpler.sdk import Platform
from kpler.sdk.configuration import Configuration
from kpler.sdk.resources.inventories import Inventories
from kpler.sdk.resources.fleet_metrics import FleetMetrics
from kpler.sdk import InventoriesSplit, FleetMetricsAlgo, FleetMetricsSplit, FleetMetricsPeriod, FleetMetricsMeasurementUnit
from dotenv import load_dotenv
import pandas as pd
from tshistory.api import timeseries

load_dotenv()

def get_oecd_daily_inventory(tsa):
    config = Configuration(
        Platform.Liquids, 
        os.environ.get("KPLER_EMAIL"), 
        os.environ.get("KPLER_PASSWORD")
    )
    inventories_client = Inventories(config)
    inventories = inventories_client.get(
        start_date=date(2017,1,1),
        end_date=pd.Timestamp.now(),
        zones=["OECD"],
        split=InventoriesSplit.ByTankType
    )
    commercial = inventories.set_index('Date')['commercial and refinery'].astype(float) / 1000
    strategic = inventories.set_index('Date')['SPR'].astype(float) / 1000
    tsa.update(
        'crude.kpler.oecd_total.commercial_stocks.mb.daily',
        commercial,
        author='uploader'
    )
    tsa.update(
        'crude.kpler.oecd_total.strategic_stocks.mb.daily',
        strategic,
        author='uploader'
    )

def get_global_daily_inventory(tsa):
    config = Configuration(
        Platform.Liquids, 
        os.environ.get("KPLER_EMAIL"), 
        os.environ.get("KPLER_PASSWORD")
    )
    inventories_client = Inventories(config)
    inventories = inventories_client.get(
        start_date=date(2017,1,1),
        end_date=pd.Timestamp.now(),
        split=InventoriesSplit.ByTankType
    )
    commercial = inventories.set_index('Date')['commercial and refinery'].astype(float) / 1000
    strategic = inventories.set_index('Date')['SPR'].astype(float) / 1000
    tsa.update(
        'crude.kpler.global.commercial_stocks.mb.daily',
        commercial,
        author='uploader'
    )
    tsa.update(
        'crude.kpler.global.strategic_stocks.mb.daily',
        strategic,
        author='uploader'
    )

def get_fs(tsa):
    config = Configuration(
        Platform.Liquids, 
        os.environ.get("KPLER_EMAIL"), 
        os.environ.get("KPLER_PASSWORD")
    )
    fleet_metrics_client = FleetMetrics(config)
    fs = fleet_metrics_client.get(
        metric=FleetMetricsAlgo.FloatingStorage,
        unit=FleetMetricsMeasurementUnit.BBL,
        period=FleetMetricsPeriod.Daily,
        split=FleetMetricsSplit.Total,
        floating_storage_duration_min='7',
        floating_storage_duration_max='inf',
        products=['Crude/Condensate']
    ).set_index('Date')
    tsa.update(
        'crude.kpler.global.floating_storage.mb.daily', 
        fs['Total']/1000000, 
        'uploader'
    )

if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api/')
    # get_oecd_daily_inventory(tsa)
    # get_global_daily_inventory(tsa)
    get_fs(tsa)