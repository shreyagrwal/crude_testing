import statsmodels.formula.api as sm
from tshistory.api import timeseries

def regress_stocks():
    kpler_inv = tsa.get('crude.kpler.global.commercial_stocks.mb.daily')
    iea_inv = tsa.get()