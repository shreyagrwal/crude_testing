from exchangelib import DELEGATE, Account, Credentials, Message, Mailbox, HTMLBody, Configuration, FileAttachment
import os
import email
import ag_encryption as ae


class AgEmailHelper:
    creds = None
    server = None
    config = None
    account = None
    user = 'SVC-QDEV-TST'
    password = 'JFCFJCMGNCGCNGGGPFJGMFCFICJFNHEHBHHCOCPE'
    sender = 'SVC-QDEV-TST@petroineos.com'
    alert_sender = 'AnalysisDataAlert@petroineos.com'

    def __init__(self):
        self.creds = Credentials(
            username='petroineos\\'+ self.user,
            password=ae.decrypt(self.password)  # put down encrypted password here
        )
        self.server = 'mail.petroineos.com'
        self.config = Configuration(server=self.server, credentials=self.creds)
        self.account = Account(
            primary_smtp_address=self.sender,
            autodiscover=True,
            config = self.config,
            access_type=DELEGATE
        )

    def send_mail(self, from_, to_, subject, body):
        self.send_mail_with_embedded_images(self, from_, to_, subject, body)
    
    def send_mail_with_embedded_images(self, from_, to_, subject, body, images=None, auto=True):
        if auto:
            body = '<b>This report is sent on behalf of '+from_+'</b><br><br>' + body
        else:
            body = '<b><font color="red">Please add comments to this report and send to: <br>' + to_ + '</font></b><br><br><br>' + body

        m = Message(
            account=self.account,
            subject=subject,
            body=HTMLBody(body),
            to_recipients=[Mailbox(email_address=e) for e in to_.split(';')],
            cc_recipients=[Mailbox(email_address=e) for e in from_.split(';')]
        )

        if not auto:
            m.to_recipients = [Mailbox(email_address=e) for e in from_.split(';')]
            m.cc_recipients = None

        if images is not None:
            self.attach(images, m)

        m.send()

    def send_alert_email(self, to_, app, subject, body):

        #body = body + '<br><br>StackTrace:<br>' + traceback.print_exc()

        m = Message(
            account=self.account,
            subject=subject + " ("+app+")",
            body=HTMLBody(body),
            to_recipients=[Mailbox(email_address=e) for e in to_.split(';')],
            author=self.alert_sender,
        )

        m.send()


    def attach(self, images, m):
        for img in images:
            with open(img, 'rb') as fp:
                folder, img_filename = os.path.split(img)
                logoimg = FileAttachment(name=img_filename, content=fp.read(), is_inline=True)
                m.attach(logoimg)

    def scan(self, folder, emailDate):
        mail = self.login()
        mail.select(folder)
        result, data = mail.search(None, '(SENTSINCE {date})'.format(date=emailDate.strftime("%d-%b-%Y")))
        mail_ids = data[0]
        id_list = mail_ids.split()
        return id_list

    def download_attachments(self, mailIds, folder):
        for num in mailIds[0].split():
            typ, data = mailIds.fetch(num, '(RFC822)')
            raw_email = data[0][1]
            # converts byte literal to string removing b''
            raw_email_string = raw_email.decode('utf-8')
            email_message = email.message_from_string(raw_email_string)
            # downloading attachments
            for part in email_message.walk():
                # this part comes from the snipped I don't understand yet...
                if part.get_content_maintype() == 'multipart':
                    continue
                if part.get('Content-Disposition') is None:
                    continue
                fileName = part.get_filename()
                if bool(fileName):
                    filePath = os.path.join(folder, fileName)
                    if not os.path.isfile(filePath):
                        fp = open(filePath, 'wb')
                        fp.write(part.get_payload(decode=True))
                        fp.close()
