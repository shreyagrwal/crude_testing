import requests
import pandas as pd
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

OECD_EU_COUNTRIES = [
        'Austria',
        'Belgium',
        'Denmark',
        'Finland',
        'France',
        'Germany',
        'Greece',
        'Ireland',
        'Italy',
        'Netherlands',
        'Norway',
        'Portugal',
        'Spain',
        'Sweden',
        'United Kingdom',
        'Turkey',
        'Czech Republic',
        'Hungary',
        'Poland',
        'Slovakia',
        'Switzerland'
    ]

def ag_get_data(server, database, query):
    params = {"Database": database, "Query": query}
    resp = requests.post(f"{server}/genericdata/Fetch/",
                         json=params, verify=False)
    jsonResult = resp.json()
    data = pd.DataFrame(jsonResult)
    return data


OUTAGES = {
    'Total': "'Planned','Unplanned'",
    'Planned': "'Planned'",
    'Unplanned': "'Unplanned'",
}


def enum_keys(server, key: int) -> tuple:
    query = f"""
            select {key}
            from [OIL].[Refinery].[RefineryPlant]
            group by {key}
            """
    value = ag_get_data(server, 'Oil', query).iloc[:, 0].to_list()
    return tuple(value)


def make_query(
        server: str,
        key: str = 'COUNTRY',
        value: tuple = None,
        unit_type: str = 'CDU',
        outage_type: str = 'Total',
        exclude_cause: tuple = None,
        pdate: pd.Timestamp = pd.Timestamp.utcnow()) -> str:
    # Make sure value is proper for injecting in the SQL statement
    if value is None:
        value = enum_keys(server, key)
    elif len(value) == 1:
        value = f"('{value[0]}')"
    if isinstance(value, list):
        value = tuple(value)
    # Make sure exclude cause is proper for injecting in the SQL statement
    if not exclude_cause:
        exclude_cause = tuple()
    if len(exclude_cause) == 1:
        exclude_cause = f"('{exclude_cause[0]}')"
    if isinstance(exclude_cause, list):
        exclude_cause = tuple(exclude_cause)

    query = f"""
            SELECT t.EVENT_ID, t.UNIT_NAME, t.UNIT_ID, t.PLANT_ID, t.PLANT_NAME, COUNTRY, [CAP_OFFLINE]
                  ,StartDate, EndDate, [EVENT_TYPE], [START_DATE], [END_DATE], Capacity
              FROM [OIL].[Refinery].[RefineryMaintenanceBest] t
              inner join (
                  SELECT MaxDate = max([PDate]), EVENT_ID, tu.UNIT_ID, COUNTRY
                  FROM [OIL].[Refinery].[RefineryMaintenanceBest] t
                  inner join (
                        select PLANT_ID, PLANT_NAME, COUNTRY
                        from [OIL].[Refinery].[RefineryPlant]
                        where {key} in {value}
                  ) tp on t.PLANT_ID = tp.PLANT_ID
                  inner join (
                        select UNIT_ID
                        from [OIL].[Refinery].[RefineryUnit]
                        where UNIT_GROUP in ('{unit_type}')
                  ) tu on t.UNIT_ID = tu.UNIT_ID
                  where PDate <= '{pdate:%Y-%m-%d}'
                  group by EVENT_ID, tu.UNIT_ID, tp.COUNTRY
              ) tm on tm.EVENT_ID = t.EVENT_ID and t.UNIT_ID = tm.UNIT_ID and t.PDate = tm.MaxDate
              right join(
                select tcapa.Unit_ID, tcapa.StartDate, tcapa.EndDate, tcapamax.Capacity
                from [OIL].[Refinery].[RefineryUnitCapacitySchedule] tcapa
                    inner join(
                        select maxDate = max(Pdate), StartDate, EndDate, Unit_ID, Capacity = max(Capacity)
                        from [OIL].[Refinery].[RefineryUnitCapacitySchedule]
                        group by Unit_ID, StartDate, EndDate
                    ) tcapamax on tcapa.PDate = tcapamax.maxDate 
                    and tcapa.Unit_ID = tcapamax.Unit_ID 
                    and tcapa.StartDate = tcapamax.StartDate 
                    and tcapa.EndDate = tcapamax.EndDate
              ) tbounds on t.UNIT_ID = tbounds.Unit_ID 
              where EVENT_TYPE in ({OUTAGES[outage_type]}) and E_STATUS not in ('Cancelled', 'ManualCancel', 'ManualInactive') 
            """
    if exclude_cause:
        query += f"and (E_CAUSE not in {exclude_cause} or E_CAUSE is NULL)"
    return query


def get_refinery_table(server, database, key='COUNTRY', value: list = None,
                       unit_type='CDU', outage_type='Total', exclude_cause=None, pdate=pd.Timestamp.utcnow(), verbose=False):
    query = make_query(server, key, value, unit_type,
                       outage_type, exclude_cause, pdate)
    if verbose:
        print(query)
    return ag_get_data(server, database, query)


def _generate_ids(data):
    plants = data.sort_values('START_DATE').groupby(
        'PLANT_ID')['PLANT_NAME'].first().to_dict()
    units = data.sort_values('START_DATE').groupby(
        'UNIT_ID')['UNIT_NAME'].first().to_dict()
    return plants, units


def _generate_date_range(data, fieldstart, fieldend, maxdate=pd.Timestamp.now()):
    try:
        _max = pd.to_datetime(data[fieldend].max())
    except:
        _max = maxdate
    _min = pd.to_datetime(data[fieldstart].min())
    return pd.date_range(_min, _max, freq='D')


def flatten_refinery_outage(data):
    plants, units = _generate_ids(data)
    index = _generate_date_range(data, 'START_DATE', 'END_DATE')
    data['DATE'] = data.apply(lambda x: pd.date_range(
        x['START_DATE'], x['END_DATE'], freq='D'), axis=1)
    pivoted = (
        data
        .explode('DATE')
        .groupby(
            ['COUNTRY', 'PLANT_ID', 'UNIT_ID', 'DATE'],
        )['CAP_OFFLINE'].max()
    )
    cols = pivoted.index.names[:-1]
    result = (
        pivoted
        .unstack(cols)
        .reindex(index)
        .fillna(0)
    )
    proper_names = [(c, plants[x], units[y]) for c, x, y in result.columns]
    result.columns = pd.MultiIndex.from_tuples(
        proper_names, names= ['COUNTRY', 'PLANT_NAME', 'UNIT_NAME'])
    return result


def flatten_refinery_capacity(data, maxdate=pd.Timestamp.now()):
    plants, units = _generate_ids(data)
    index = _generate_date_range(data, 'StartDate', 'EndDate', maxdate)
    units_life = data.groupby(['COUNTRY','PLANT_ID', 'UNIT_ID', 'StartDate', 'EndDate']).last()[
        ['Capacity']]

    def define_range(data):
        try:
            __max = pd.to_datetime(data.name[-1])
        except:
            __max = index[-1]
        return pd.date_range(data.name[-2], __max, freq='D')
    units_life['RANGE'] = units_life.apply(lambda x: define_range(x), axis=1)
    pivoted = (
        units_life
        .explode('RANGE')
        .groupby(
            ['COUNTRY','PLANT_ID', 'UNIT_ID', 'RANGE'],
        )['Capacity'].last()
    )
    cols = pivoted.index.names[:-1]
    ids = [i for i, _ in enumerate(cols)]
    result = (
        pivoted
        .unstack(ids)
        .reindex(index)
        .fillna(0)
    )
    proper_names = [(c, plants[x], units[y]) for c, x, y in result.columns]
    result.columns = pd.MultiIndex.from_tuples(
        proper_names, names= ['COUNTRY', 'PLANT_NAME', 'UNIT_NAME'])
    return result


class RefineryData():
    server = 'https://TST-QDEV-AP1.petroineos.local:5001'
    database = 'OIL'

    def get_outage(self,
                   key: str,
                   values: list,
                   unit_type,
                   outage_type=None,
                   exclude_cause=None,
                   pdate=None,
                   verbose=False):
        """
        Get refining outages
        """
        table = get_refinery_table(
            self.server,
            self.database,
            key,
            values,
            unit_type,
            outage_type or 'Total',
            exclude_cause,
            pdate or pd.Timestamp.utcnow(),
            verbose,
        )
        return flatten_refinery_outage(table) / 1e3

    def get_capacity(self,
                     key: str,
                     values: list,
                     unit_type,
                     pdate=None,
                     max_date=pd.Timestamp('2030-1-1'),
                     verbose=False):
        """
        Get refining capacity
        """
        table = get_refinery_table(
            self.server,
            self.database,
            key,
            values,
            unit_type,
            'Total',
            None,
            pdate or pd.Timestamp.utcnow(),
            verbose,
        )
        return flatten_refinery_capacity(table, max_date) / 1e3

def _test_df(data, country, refinery, unit, date, value):
    test = (data.xs((country, refinery, unit), axis=1)[date] == value)
    if test:
        print(f"{refinery}, {unit}, {date}, {value} kb/d passed")
    return test 

def test_capacities():
    refinery_data = RefineryData()
    data = refinery_data.get_capacity("COUNTRY", ["United Kingdom", "Greece", "France"], "CDU", max_date=pd.Timestamp("2023-1-1")).resample('AS').mean().astype(int)
    tests = [
        ('United Kingdom', 'Grangemouth Refinery', 'CDU 1', "2017-1-1",  65),
        ('United Kingdom', 'Grangemouth Refinery', 'CDU 1', "2022-1-1",  0),
        ('Greece', 'Corinth Refinery', 'Crude U-1100 (Crude 1)', "2022-1-1",  110),
        ('France', 'Grandpuits Refinery', 'DA (Atmospheric Distillation Unit)', "2020-1-1",  100),
        ('France', 'Grandpuits Refinery', 'DA (Atmospheric Distillation Unit)', "2023-1-1",  0),
    ]
    assert all(list(map(lambda x: _test_df(data, *x), tests)))

def test_outages():
    refinery_data = RefineryData()
    data = refinery_data.get_outage("COUNTRY", ["France"], "CDU").astype(int)
    tests = [
        ('France', 'Donges Refinery', 'DA (D2E) (Atmospheric Distillation)', "2021-10-2",  230),
        ('France', 'PetroIneos Lavera Refinery', 'Topping 5 (Distillation-Crude)', "2022-8-2",  0),
        ('France', 'PetroIneos Lavera Refinery', 'Topping 5 (Distillation-Crude)', "2022-6-20",  218),

    ]
    assert all(list(map(lambda x: _test_df(data, *x), tests)))

if __name__ == '__main__':
    test_outages()
    test_capacities()
