from refinery import RefineryData

def plot_outage_cumsum(ctry_list: list, type : str):
    refinery = RefineryData()
    total_outage = refinery.get_outage(unit_type='CDU', outage_type=type, key='COUNTRY', values=ctry_list).groupby(axis=1, level=0).sum()
    return total_outage.cumsum().plot(title=type)

fr_outage = RefineryData().get_outage('COUNTRY',['France'],'CDU', 'unplanned')
fr_outage = RefineryData().get_outage('CDU', outage_type='unplanned', key='COUNTRY', values=['France'])