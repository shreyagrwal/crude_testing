from datetime import datetime as dt
from typing import Dict, Tuple
import pandas as pd
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
plt.style.use('bmh')


def name_stats(name, date_range):
    return f'{name} {date_range[0]:%y}-{date_range[-1]:%y}'


def generate_seasonal_frame(
        series: pd.DataFrame,
        freq: str = 'W',
        agg: str = 'mean',
        interpolation=None,
) -> pd.DataFrame:

    now = dt.utcnow()

    resampled = (series.resample(freq).agg(agg))

    if interpolation is not None:
        resampled = resampled.interpolate(method=interpolation)

    df = (resampled
          .reset_index()
          .assign(year=lambda x: x['index'].dt.year,
                  index=lambda x: x['index'].dt.strftime(f'%d-%m-{now.year}'))
          .set_index(['index', 'year'])
          .unstack(1)
          )
    df.index = pd.to_datetime(df.index, format="%d-%m-%Y", errors='coerce')
    df = df.sort_index().resample(freq).agg(agg)
    return df[series.columns[0]]


def compute_seasonal_stats_unfolded(
    series,
    freq: str = 'D',
    agg: str = 'mean', 
    interpolation=None, 
    cutoff_year: int = dt.utcnow().year
) -> Tuple[pd.DataFrame, Dict]:

    resampled = (series.resample(freq).agg(agg))
    if interpolation is not None:
        resampled = resampled.interpolate(method=interpolation)

    selected_formated = [resampled.index[0], dt(cutoff_year, 1, 1)]
    stats = {
        'min': {
            'name': name_stats('Min', selected_formated),
            'func': 'min',
        },
        'max': {
            'name': name_stats('Max', selected_formated),
            'func': 'max',
        },
        'mean': {
            'name': name_stats('Mean', selected_formated),
            'func': 'mean',
        }
    }
    _stats = {k: v['name'] for k, v in stats.items()}

    seasonal = resampled.loc[:dt(cutoff_year, 1, 1)]
    unfold_grouping = {
        'D': seasonal.index.dayofyear,
        'B': seasonal.index.dayofyear,
        'W': seasonal.index.isocalendar()["week"],
        'M': seasonal.index.month
    }
    f_unfold = {
        'D': lambda x: x.index.dayofyear,
        'B': lambda x: x.index.dayofyear,
        'W': lambda x: x.index.isocalendar()["week"],
        'M': lambda x: x.index.month

    }
    seasonal = (seasonal
                .groupby(unfold_grouping[freq])
                .agg(("min", "max", "mean"))
                .rename(columns=_stats)
                [series.columns[0]])

    result = (resampled
              .assign(key=f_unfold[freq])
              .merge(seasonal, left_on='key', right_index=True)
              .drop("key", axis=1))
    return result, stats


def compute_seasonal_stats(
        frame: pd.DataFrame,
        cutoff_year: int = dt.utcnow().year) -> Tuple[pd.DataFrame, Dict]:

    selected = frame.columns[frame.columns < cutoff_year]
    selected_formated = [dt(year, 1, 1) for year in selected]
    stats = {
        'min': {
            'name': name_stats('Min', selected_formated),
            'func': lambda x: x[selected].min(axis=1),
        },
        'max': {
            'name': name_stats('Max', selected_formated),
            'func': lambda x: x[selected].max(axis=1),
        },
        'mean': {
            'name': name_stats('Mean', selected_formated),
            'func': lambda x: x[selected].mean(axis=1),
        }
    }
    _stats = {x['name']: x['func'] for x in stats.values()}
    return frame.assign(**_stats).drop(selected, axis=1), stats

def reshape_data(series, cutoff_year, freq='D', agg='mean', interpolation=None):
    _data_stats = None
    if series is not None:
        _data = generate_seasonal_frame(series, freq, agg, interpolation)
        _data_stats, _ = compute_seasonal_stats(
            _data, cutoff_year=cutoff_year)
        _data_stats = _data_stats.reset_index()
    return _data_stats

def reshape_data_unfolded(series, cutoff_year, freq='D', agg='mean', interpolation=None):
    _data_stats = None
    if series is not None:
        _data_stats, _ = compute_seasonal_stats_unfolded(
            series, freq, agg, interpolation)
        _data_stats = _data_stats.reset_index()
    return _data_stats

def seasonal_plot(series, cutoff_year=2019, freq='D', agg='mean', interpolation=None):
    reshaped = reshape_data(series.to_frame(), cutoff_year, freq, agg, interpolation).set_index('index')
    fig, ax = plt.subplots(figsize=(5,5))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
    for i, col in enumerate(reshaped.columns[:-3]):
        ax.plot(reshaped.index, reshaped[col],label=col,linewidth=1+0.2*i)
    ax.plot(reshaped.index, reshaped.iloc[:,-1],label=reshaped.columns[-1], color='black',linewidth=0.5)
    plt.legend()
    ax.fill_between(reshaped.index, reshaped.iloc[:,-3],reshaped.iloc[:,-2], alpha=0.3, color='grey',linewidth=0)
    ax.axvline(x=pd.Timestamp.now(), linewidth=0.75, linestyle=':',color='black')
    plt.tight_layout(pad=0.0)
    plt.margins(x=0,y=0)
    plt.show()

def seasonal_plot_unfolded(series, cutoff_year=2019, freq='D', agg='mean', interpolation=None):
    reshaped = reshape_data_unfolded(series.to_frame(), cutoff_year, freq, agg, interpolation).set_index('index').sort_index()
    fig, ax = plt.subplots(figsize=(5,5))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b-%y'))
    ax.plot(reshaped.iloc[:, 0],linewidth=2,color='#A60628')
    ax.plot(reshaped.index, reshaped.iloc[:,-1],label=reshaped.columns[-1], color='black',linewidth=0.5)
    ax.fill_between(reshaped.index, reshaped.iloc[:,-3],reshaped.iloc[:,-2], alpha=0.3, color='grey',linewidth=0)
    plt.tight_layout(pad=0.2)
    plt.margins(x=0,y=0)
    plt.show()

if __name__ == '__main__':
    days = 9_000
    data = np.random.randn(days)
    range_date = pd.date_range(start='2001-1-1', freq='D', periods=days)
    series = pd.Series(np.exp(-0.01 * np.cumsum(data)), index=range_date)
    seasonal_plot(series, 2019)
    seasonal_plot_unfolded(series, 2019)