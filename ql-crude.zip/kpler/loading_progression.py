from datetime import datetime as dt
from dateutil.relativedelta import relativedelta
import numpy as np
import pandas as pd
import requests, warnings
from matplotlib import pyplot as plt

from kpler.sdk.configuration import Configuration
from kpler.sdk import Platform


config = Configuration(Platform.Liquids, "syed.ahmad@petrochinaintl.co.uk", "petroineos")

from kpler.sdk.resources.flows import Flows
from kpler.sdk import FlowsDirection, FlowsSplit, FlowsPeriod, FlowsMeasurementUnit
flows_client = Flows(config)

def split_date_seasonal(df):
    df['year'] = df['Date'].dt.year
    df['month'] = df['Date'].dt.month
    df['day'] = df['Date'].dt.day
    df.drop(columns='Date', inplace=True)
    return df

def month_comparison(month: int, origin=[],dest=[]):
    '''
    function to compare a specific calendar month progress against previous years
    '''
    df = split_date_seasonal(flows_client.get(
        from_zones=origin, 
        to_zones=dest, 
        granularity=[FlowsPeriod.Daily],
        start_date=dt(2013,1,1), end_date=dt.today(),unit=[FlowsMeasurementUnit.KBD],
        with_intra_country=False, flow_direction=[FlowsDirection.Export], split=[FlowsSplit.Total]
            ).drop(columns='Period End Date'))
    same_month_df = df[df['month']==month].copy()
    same_month_pivot = same_month_df.pivot(index='day', columns='year', values='Total')
    years_rolling_sum = same_month_pivot.cumsum()
    return years_rolling_sum.plot()

def year_comparison(year: int, origin=[],dest=[]):
    '''
    Function to compare calendar months loading progression of a specific year
    '''
    df = split_date_seasonal(flows_client.get(
        from_zones=origin, 
        to_zones=dest, 
        granularity=[FlowsPeriod.Daily],
        start_date=dt(2013,1,1), end_date=dt.today(),unit=[FlowsMeasurementUnit.KBD],
        with_intra_country=False, flow_direction=[FlowsDirection.Export], split=[FlowsSplit.Total]
            ).drop(columns='Period End Date'))
    year_df = df[df['year']==year].copy()
    year_pivot = year_df.pivot(index='day', columns='month', values='Total')
    rolling_sum_year = year_pivot.cumsum()
    return rolling_sum_year.plot()

def progression_multi_plot(year: int, path):
    '''
    Function to compare calendar months loading progression of a specific year
    '''
    origin_dest = pd.read_csv(path)
    fig, ax = plt.subplots(ncols=len(origin_dest))
    for i, origin, dest in zip(origin_dest.index.to_list(), origin_dest.origin, origin_dest.destination):
        df = split_date_seasonal(flows_client.get(
            from_zones=origin, 
            to_zones=dest, 
            granularity=[FlowsPeriod.Daily],
            start_date=dt(year,1,1), end_date=dt.today(),unit=[FlowsMeasurementUnit.KBD],
            with_intra_country=False, flow_direction=[FlowsDirection.Export], split=[FlowsSplit.Total]
                ).drop(columns='Period End Date'))
        year_df = df[df['year']==year].copy()
        year_pivot = year_df.pivot(index='day', columns='month', values='Total')
        rolling_sum_year = year_pivot.cumsum()
        rolling_sum_year.plot(ax=ax[i], figsize=(20,5), title = origin)
    return plt.show()

# urals_exports = flows_client.get(
#     from_zones='Russia', products='Urals', granularity=[FlowsPeriod.Daily],
#     start_date=dt(2013,1,1), end_date=dt.today(),unit=[FlowsMeasurementUnit.KBD],
#     with_intra_country=False, flow_direction=[FlowsDirection.Export], split=[FlowsSplit.Total]
#     ).drop(columns='Period End Date')

# nsea_asia_exports = split_date_seasonal(flows_client.get(
#     from_zones='North Sea',to_zones='Asia', products='Crude/Condensate', granularity=[FlowsPeriod.Daily],
#     start_date=dt(2013,1,1), end_date=dt.today(),unit=[FlowsMeasurementUnit.KBD],
#     with_intra_country=False, flow_direction=[FlowsDirection.Export], split=[FlowsSplit.Total]
#     ).drop(columns='Period End Date')
# )

# nwe_imports = split_date_seasonal(flows_client.get(
#     to_zones='North West Europe Zone', products='Crude/Condensate', granularity=[FlowsPeriod.Daily],
#     start_date=dt(2013,1,1), end_date=dt.today(),unit=[FlowsMeasurementUnit.KBD],
#     with_intra_country=False, flow_direction=[FlowsDirection.Export], split=[FlowsSplit.Total]
#     ).drop(columns='Period End Date')
# )

# if __name__ == '__main__':
    # year_comparison_list(2023,'origin_dest.csv')
    # year_comparison(2023,'United States', 'OECD Europe')
    # month_comparison(1,'United States', 'OECD Europe')