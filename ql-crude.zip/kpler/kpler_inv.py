import os
from datetime import date
import pandas as pd
from dotenv import load_dotenv
from kpler.sdk import Platform
from kpler.sdk.configuration import Configuration
from kpler.sdk.resources.inventories import Inventories
from kpler.sdk import InventoriesSplit
from tshistory.api import timeseries
# import pdb
# pdb.set_trace()

# tsa = timeseries(f'{os.environ.get("SATURN_API")}')
load_dotenv()

# def safe_register_formula(tsa, name, formula):
#     if tsa.exists(name):
#         tsa.delete(name)
#     tsa.register_formula(name, formula)

def get_regional_daily_inventory(tsa):
    regions = {
        'united_states':'United States',
        # 'china':'China',
        # 'russia':'Russia'
    }
    config = Configuration(
        Platform.Liquids, 
        os.environ.get("KPLER_EMAIL"), 
        os.environ.get("KPLER_PASSWORD")
    )
    inventories_client = Inventories(config)
    for name, region in regions.items():
        print(f'getting data for {name}')
        inventories = inventories_client.get(
            start_date=date(2017,1,1),
            end_date=pd.Timestamp.now(),
            zones=[region],
            split=InventoriesSplit.ByTankType
        )
        print(inventories.columns)
        # commercial = inventories.set_index('Date')['commercial and refinery'].astype(float) / 1000
        # strategic = inventories.set_index('Date')['SPR'].astype(float) / 1000
        # tsa.update(
        #     f'crude.kpler.{name}.commercial_stocks.mb.daily',
        #     commercial,
        #     author='uploader'
        # )
        # tsa.update(
        #     f'crude.kpler.{name}.strategic_stocks.mb.daily',
        #     strategic,
        #     author='uploader'
        # )
        print(f'{name} series uploaded')
        # safe_register_formula(
        #     tsa, 
        #     f'crude.kpler.{name}.ending_stocks.mb.daily', 
        #     f'(add (series "crude.kpler.{name}.commercial_stocks.mb.daily") (series "crude.kpler.{name}.strategic_stocks.mb.daily"))'
        #     )
        # print(f'{name} formula uploaded')
    return print(f'{len(regions)} series uploaded')

def get_refinery_commercial_daily_inventory(tsa):
    regions = {
        'china':'China',
        'russia':'Russia'
    }
    config = Configuration(
        Platform.Liquids, 
        os.environ.get("KPLER_EMAIL"), 
        os.environ.get("KPLER_PASSWORD")
    )
    inventories_client = Inventories(config)
    for name, region in regions.items():
        print(f'getting data for {name}')
        inventories = inventories_client.get(
            start_date=date(2017,1,1),
            end_date=pd.Timestamp.now(),
            zones=[region],
            split=InventoriesSplit.ByTankType
        )
        commercial = inventories.set_index('Date')['Commercial'].astype(float) / 1000
        refinery = inventories.set_index('Date')['Refinery'].astype(float) / 1000
        meta = {
            'source':'kpler',
            'type':'stocks',
            'country':region,
            }
        tsa.update(
            f'crude.kpler.{name}.commercial_stocks.mb.daily',
            commercial,
            author='uploader',
            metadata=meta
        )
        tsa.update(
            f'crude.kpler.{name}.refinery_stocks.mb.daily',
            refinery,
            author='uploader',
            metadata=meta
        )
        print(f'{name} series uploaded')
        # safe_register_formula(
        #     tsa, 
        #     f'crude.kpler.{name}.ending_stocks.mb.daily', 
        #     f'(add (series "crude.kpler.{name}.commercial_stocks.mb.daily") (series "crude.kpler.{name}.strategic_stocks.mb.daily"))'
        #     )
        # print(f'{name} formula uploaded')
    return print(f'{len(regions)} series uploaded')

tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')

if __name__ == '__main__':
    tsa = timeseries('http://tst-qdev-ap9.petroineos.local/api')
    get_refinery_commercial_daily_inventory(tsa)