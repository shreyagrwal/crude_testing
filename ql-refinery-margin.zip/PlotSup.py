import numpy as np
import pandas as pd
import datetime
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
import MarginSup as ms
import sys

title_font_sz = 20
x_font_sz = 16
y_font_sz = 16
 
def format_fwd_margin(df_fwd_margin):

    inds = [datetime.date(1972, 1, 1) + datetime.timedelta(i) for i in range(366)]    
    df_new_fwd_margin = pd.DataFrame([], index = inds) 
    for ind, row in df_fwd_margin.iterrows():
        if ind.year == 1:
            next_day = ms.get_next_trading_day(row.index[0])
            x = datetime.date(1972, next_day.month, next_day.day)
            y = next_day.year
        else:
            x = datetime.date(1972, ind.month, ind.day)
            y = ind.year            
        df_new_fwd_margin.loc[x, y] = row[0]
    df_new_fwd_margin = df_new_fwd_margin.fillna(method='ffill')
    
    return df_new_fwd_margin    

def get_q1_months(given_date):

    if given_date.month < 4:
        my_q1_months = [datetime.date(given_date.year, 4, 1), 
                        datetime.date(given_date.year, 5, 1), 
                        datetime.date(given_date.year, 6, 1)]
    elif given_date.month < 7:
        my_q1_months = [datetime.date(given_date.year, 7, 1), 
                        datetime.date(given_date.year, 8, 1), 
                        datetime.date(given_date.year, 9, 1)]
    elif given_date.month < 10:
        my_q1_months = [datetime.date(given_date.year, 10, 1), 
                        datetime.date(given_date.year, 11, 1), 
                        datetime.date(given_date.year, 12, 1)]    
    else:
        my_q1_months = [datetime.date(given_date.year + 1, 1, 1), 
                        datetime.date(given_date.year + 1, 2, 1), 
                        datetime.date(given_date.year + 1, 3, 1)]    
    return my_q1_months   
    
    
# Get Prompt Quarterly Average
def get_prompt_quarterly_margin(df):
    
    ser_quar = pd.Series([], dtype='float64' )
    for col, ser_col in df.items():
        q1_values = []
        for ind, value in ser_col.items():
            if ind in get_q1_months(col) and not np.isnan(value):
                q1_values.append(value)
        if len(q1_values) > 0:
            ser_quar.loc[col] = sum(q1_values) / len(q1_values)            
        else:
            print(col, q1_values)    
    ser_quar = ser_quar.fillna(method='backfill')
    return ser_quar
    
# Get Prompt Quarterly and Yearly Average
def get_prompt_yearly_margin(df):
    
    ser_year = pd.Series([], dtype='float64' )
    for col, ser_col in df.items():
        y1_values = []
        for ind, value in ser_col.items():
            if ind.year == col.year + 1:
                y1_values.append(value)
        if len(y1_values) > 0:
            ser_year.loc[col] = sum(y1_values) / len(y1_values)
        else:
            print(col, y1_values)
    ser_year = ser_year.fillna(method='backfill')
    return ser_year
    
#Get Evolution Data
def get_margin_evolution(df, yields):
    # 1. Params
    # Margin
    df = df.loc[lambda df: df.index >= datetime.date(2015, 1, 1)]

    # 2. Calculate components  
    ser_lmm = df['LMM']   
    for key, value in yields.items():
        df[key] = df[key] + ser_lmm * value
    
    df['Loss'] =  ser_lmm * (1 - sum(yields.values()))
    df = df.drop('LMM', axis=1)

    return df 
    
def get_weekly_evolution_component(df):
    inds = []
    last_day = df.index[-1]
    for i_date in df.index:
        i_days = (last_day - i_date).days
        if i_days % 7 == 0:
            if not ms.is_bank_holiday(i_date):
                inds.append(i_date)
            else:
                inds.append(ms.get_previous_trading_day(i_date))
    df = df.loc[inds]
    
    return df    

def get_monthly_margin_component(df):
    
    inds = [datetime.date(ind.year, ind.month, 1) for ind in df.index]
    df.index = inds
    grouped = df.groupby(df.index, axis = 0, sort = False)
    df_m = grouped.mean()
    # df_m = pd.DataFrame([], columns=df.columns)
    # for name, group in grouped:
        # df_m.loc[name] = group.mean()
    return df_m
   
def plot_margin(df_com_margin, df_fwd, figs, figs_title, types):
    #1. Definitions
    # Margin
    if df_fwd is not None:
        df_com_fwd = df_fwd
    # figsure
    figs.clf()
    ax = figs.add_subplot(111)
    # Type
    ## s:spot, q:quarterly, y:yearly
    
    #2. Plot Margin Chart
    ind = np.arange(df_com_margin.index.size)    
    # 2.1 x
    x_data = df_com_margin.index 
    # 2.2 y  
    #Historical
    df_his_margin = df_com_margin.loc[:, 2015:2019]
    df_his_margin = df_his_margin.fillna(method='ffill')
    
    y_data_min = df_his_margin.min(axis=1)
    y_data_max = df_his_margin.max(axis=1)
    y_data_ave = df_his_margin.mean(axis=1)
    
    #2020
    ser_data_2020 = df_com_margin.loc[:, 2020:2020]
    
    #2021
    ser_data_2021 = df_com_margin.loc[:, 2021:2021]

    #2022
    ser_data_2022 = df_com_margin.loc[:, 2022:2022]

    #2023
    ser_data_2023 = df_com_margin.loc[:, 2023:2023]
    
    #This Year
    ser_data_this_year = df_com_margin.iloc[:, -1:]
    
    #Forward
    if types == 's':
        df_com_fwd = df_com_fwd.iloc[:, -1:]
        df_com_fwd = df_com_fwd.dropna(how="any")
        df_com_fwd = format_fwd_margin(df_com_fwd)
        
        y_data_fwd0 = df_com_fwd.iloc[:, 0:1]
        y_data_fwd1 = df_com_fwd.iloc[:, 1:2]
    
    # 2.3 Plot
    # 2020
    labels = str(ser_data_2020.columns[0]%100)
    y_data = ser_data_2020.to_numpy()
    ax.plot(ind, y_data, c = 'blueviolet', linewidth=1.5, label = labels)   
    
    # 2021
    labels = str(ser_data_2021.columns[0]%100)
    y_data = ser_data_2021.to_numpy()
    ax.plot(ind, y_data, c = 'darkcyan', linewidth=1.5, label = labels)

    # 2022
    labels = str(ser_data_2022.columns[0] % 100)
    y_data = ser_data_2022.to_numpy()
    ax.plot(ind, y_data, c='royalblue', linewidth=1.5, label=labels)

    # 2023
    labels = str(ser_data_2023.columns[0] % 100)
    y_data = ser_data_2023.to_numpy()
    ax.plot(ind, y_data, c='deeppink', linewidth=1.5, label=labels)

    # This Year
    labels = str(ser_data_this_year.columns[0]%100)
    y_data = ser_data_this_year.to_numpy()
    ax.plot(ind, y_data, c ='firebrick', linewidth=2.5, label = labels)

    # Forward
    if types == 's':
        # This Year Forward
        labels = str(y_data_fwd0.columns[0]%100) + ' Fwd'
        y_data = y_data_fwd0.to_numpy()
        ax.plot(ind, y_data, color = 'crimson', linestyle = '--', linewidth=2.5, label = labels)    
        # Next Year Forward
        labels = str(y_data_fwd1.columns[0]%100) + ' Fwd'
        y_data = y_data_fwd1.to_numpy()
        ax.plot(ind, y_data, color = 'darkorange', linestyle = '--', label = labels)
    # 5 year Average
    # labels = str(df_his_margin.columns[0]) + '-' + str(df_his_margin.columns[-1]) + ' Average'
    labels = str(df_his_margin.columns[0]%100) + '-' + str(df_his_margin.columns[-1]%100) + ' Avg'
    y_data = y_data_ave.to_numpy()
    ax.plot(ind, y_data, 'k-.', label = labels) 
    
    # 5 Year Range
    # labels = str(df_his_margin.columns[0]) + '-' + str(df_his_margin.columns[-1]) + ' Range'
    labels = str(df_his_margin.columns[0]%100) + '-' + str(df_his_margin.columns[-1]%100) + '\n Range'
    ax.fill_between(ind, y_data_min, y_data_max, alpha=0.4, color = 'cadetblue', label = labels)

    # 2.4 Chart Setting
    # Title
    # ax.set_title(figs_title, fontdict={'fontsize':title_font_sz, 'fontfamily':'Calibri'})
    a = ax.set_title(figs_title, fontdict={'fontsize':title_font_sz})
 
    # X tick label
    x_ticks = []
    x_tick_labels = []
    y_min, y_max = ax.get_ylim()
    if y_min >= -1:
        y_min = -1
    for i in range(len(x_data)):
        if x_data[i].day == 1:
            x_ticks.append(i)
            x_tick_labels.append(x_data[i].strftime('%b'))  
              
            # Setting x grid for quarterly chart
            if x_data[i].month in [1, 4, 7, 10]:
                ax.plot([i, i], [y_min, y_max], 'k', alpha = 0.4)
            # else:
                # ax.plot([i, i], [y_min, y_max], 'k', alpha = 0.2)    
    ax.plot([ind[-1], ind[-1]], [y_min, y_max], 'k', alpha = 0.4)  
        
    ax.set_xticks(x_ticks, minor = False)
    ax.set_xticklabels(x_tick_labels, fontdict={'fontsize':x_font_sz}, minor = False)  
    
    # Y Ticks
    ax.tick_params(axis='y', labelsize = y_font_sz)
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))

     
    # Show Legend
    # ax.legend(ncol=10, loc = 'lower left', fontsize = 'x-large')
    ax.legend(bbox_to_anchor=(1, 0.60), ncol=1, loc = 'lower left', fontsize = 'x-large')
    
    # Setting y grid
    x_min, x_max = ax.get_xlim()
    ax.plot([x_min, x_max], [0, 0], 'k', linewidth=1, alpha = 0.4)
    
    # Set y limit
    ax.set_ylim(y_min, y_max)
    return figs
    
def plot_fwd_margin(df_fwd, figs, figs_title, flag=False):
    #### 1. Definitions
    m_date = df_fwd.columns[-1]
    m_date_d = df_fwd.columns[-2]
    m_date_w = m_date - datetime.timedelta(days=7)
    if ms.is_bank_holiday(m_date_w):
        m_date_w = ms.get_previous_trading_day(m_date_w)  
    m_date_m = df_fwd.columns[-21]
    m_date_3m = df_fwd.columns[-63]
    m_date_6m = df_fwd.columns[-126]
    
    # df_fwd = df_fwd[[m_date_6m, m_date_3m, m_date_m, m_date_w, m_date_d, m_date]].copy()       
    df_fwd = df_fwd[[m_date_6m, m_date_3m, m_date_m, m_date_w, m_date]].copy()       
    df_fwd = df_fwd.iloc[1:, :]     
    # df_com_fwd = df_com_fwd.iloc[1:, [-126, -63, -21, -6, -1]] #3 month, 1 month, 1 week, Last day
    df_fwd = df_fwd.dropna(how='all')
    
    if flag != True:
        df_fwd = df_fwd.iloc[3:26, :]
    figs.clf()
    ax = figs.add_subplot(111)
    
    #### 2. Plot Margin Curve
    # 2.1 x
    ind = np.arange(df_fwd.index.size) 
    x_data = df_fwd.index
    # 2.2 y  
    #Last
    y_data_last = df_fwd.iloc[:, -1]    
    #Last week
    y_data_1w = df_fwd.iloc[:, -2] 
    #Last Month
    y_data_1m = df_fwd.iloc[:, -3]    
    #3 Month    
    y_data_3m = df_fwd.iloc[:, -4]    
    #6 Month    
    y_data_6m = df_fwd.iloc[:, -5]

    labels = y_data_last.name.strftime('%b %d')
    ax.plot(ind, y_data_last, 'D-', c = 'blueviolet', linewidth=3, label = labels)    
    
    labels = '1 week\n' + y_data_1w.name.strftime('%b %d')
    ax.plot(ind, y_data_1w, 'o--', label = labels) 
    
    labels = '1 month\n' + y_data_1m.name.strftime('%b %d')
    ax.plot(ind, y_data_1m, 'o--', label = labels)    
    
    labels = '3 months\n' + y_data_3m.name.strftime('%b %d')
    ax.plot(ind, y_data_3m, 'o--', label = labels)    
    
    labels = '6 months\n' + y_data_6m.name.strftime('%b %d')
    ax.plot(ind, y_data_6m, 'o--', label = labels)
    
    # 2.4 Chart Setting
    # Title
    ax.set_title(figs_title, fontdict={'fontsize':title_font_sz})
    
    # X tick label
    x_ticks = []
    x_tick_labels = []
    
    y_min, y_max = ax.get_ylim()
    if y_min >= -1:
        y_min = -1
    for i in range(len(x_data)):
        if x_data[i].month in [1, 4, 7, 10]:
            x_ticks.append(i) 
            x_tick_labels.append(x_data[i].strftime('%b %y'))
        # Setting x grid for quarterly chart
        if x_data[i].month in [1, 4, 7, 10]:
            ax.plot([i, i], [y_min, y_max], 'k', alpha = 0.4)
        # else:
            # ax.plot([i, i], [y_min, y_max], 'k', alpha = 0.2)    
    # ax.plot([ind[-1], ind[-1]], [y_min, y_max], 'k', alpha = 0.4)  
            
    ax.set_xticks(x_ticks, minor = False)
    ax.set_xticklabels(x_tick_labels, fontdict={'fontsize':x_font_sz}, minor = False)  
    
    # Y Ticks
    ax.tick_params(axis='y', labelsize = y_font_sz)
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    
    # Setting y grid
    # y_data_yline = [0 for i in ind]
    x_min, x_max = ax.get_xlim()
    ax.plot([x_min, x_max], [0, 0], 'k', linewidth=1, alpha = 0.4)
     
    # Show Legend
    ax.legend(bbox_to_anchor=(1, 0.9), ncol=1, fontsize = 'x-large', loc='upper left')    
    return figs    
    
def plot_margin_evolution(df, figs, figs_title, types='d'):
    # 1. Definitions   
    figs.clf()
    ax = figs.add_subplot(111)
    
    type = types[0].lower()
    
    if type == 'd': # daily --- 2 month
        df = df.iloc[-43:, :]       
    elif type == 'w': # weekly --- 12 weeks
        df = df.iloc[-16:, :]    
    elif type == 'm': # monthly --- 24 months
        df = df.iloc[-24:, :]
    else:
        raise ValueError('Bad Type')
    
    #### 2. Plot stacks bar chart
    #x axis
    ind = np.arange(len(df.index)) 
    x_data = df.index
    
    #The Bottom of stacks
    bar_bottom = np.zeros(len(df.index)) 
    bar_bottom_plus = np.zeros(len(df.index)) 
    bar_bottom_minus = np.zeros(len(df.index)) 
   
    x_len = len(df.index)
    y_len = len(df.columns)

    # color_list = ['navy', 'violet',  'green', 'brown', 'gold',  'pink', 'silver', 'cyan']
    palette = plt.get_cmap('tab20')
    palt_dict = {'Propane': 0, 'Butane': 1, 'Naphtha': 2, 'Gasoline': 3, 'Jet': 4, 'ULSD': 5, 
                'Gasoil': 6, 'LSFO': 7, 'HSFO': 8, 'LSVGO': 9, 'LSSR': 10, 'HSSR': 11, 
                 'Other' : 12, 'GasCost':13, 'DFL':14, 'Crude Diffs': 15, 'Freight': 16, 'Loss':17}
    for k, value in palt_dict.items():
        if value < 10:
            palt_dict[k] = value * 2
        else:
            palt_dict[k] = value % 10 * 2 + 1
    
    for i_col, col_name in enumerate(df.columns):
        y_data = df[col_name]

        for i, i_y in enumerate(y_data):
            if i_y > 0:
                bar_bottom[i] = bar_bottom_plus[i]
            else:
                bar_bottom[i] = bar_bottom_minus[i]

        labels = col_name
        ax.bar(ind, y_data, bottom = bar_bottom, alpha = 0.8, color=palette(palt_dict[col_name]), label = labels) 

        for j in range(x_len):
            if abs(ax.patches[i_col*x_len + j].get_height()) >= 500:
                x_pos = j
                if ax.patches[i_col*x_len + j].get_height() > 0:
                    y_pos = bar_bottom[x_pos] + ax.patches[i_col*x_len + x_pos].get_height() / 4
                else:
                    if abs(ax.patches[i_col*x_len + j].get_height()) < 1000:
                        y_pos = bar_bottom[x_pos] + ax.patches[i_col*x_len + x_pos].get_height()
                    else:
                        y_pos = bar_bottom[x_pos] + ax.patches[i_col*x_len + x_pos].get_height() / 3 * 2
                #ax.text(x_pos, y_pos, legends[i_col] + '\n' + str(y_data[x_pos]) + ' x', ha = 'center')   # TODO: what's legends?
                
        for i, i_y in enumerate(y_data):
            if i_y > 0:
                bar_bottom_plus[i] += i_y
            else:
                bar_bottom_minus[i] += i_y

    # 3. Plot Line Chart
    df_tmp = df.drop(['GasCost'], axis=1)
    y_date_sum = df_tmp.sum(axis=1)
    labels = 'Margin Without Gas Cost'
    ax.plot(ind, y_date_sum, 'D-', c = 'seagreen', linewidth=3, label = labels)    
    
    y_date_sum = df.sum(axis=1)
    labels = 'Margin With Gas Cost'
    ax.plot(ind, y_date_sum, 'D-', c = 'blueviolet', linewidth=3, label = labels)
    
    # 4 Chart Setting
    # Title
    ax.set_title(figs_title, fontdict={'fontsize':title_font_sz})
    
    # X tick label
    x_ticks = []
    x_tick_labels = []
    for i in range(len(x_data)):
        i_date = x_data[i]
        if type == 'd':
            if i % 4 == 0:
                x_ticks.append(i) 
                x_tick_labels.append(i_date.strftime('%b-%d'))            
        elif type == 'w':
            if i % 2 == 0:
                x_ticks.append(i) 
                x_tick_labels.append(i_date.strftime('%b-%d'))            
        elif type == 'm':
            x_ticks.append(i) 
            if i_date.month == 1 or i == 0:
                x_tick_labels.append(i_date.strftime('%b\n%Y'))
            else:
                x_tick_labels.append(i_date.strftime('%b'))                
        else:
            raise ValueError('Bad Type')
    ax.set_xticks(x_ticks, minor = False)
    ax.set_xticklabels(x_tick_labels, fontdict={'fontsize':x_font_sz}, minor = False)  

    # Setting x grid
    x_min, x_max = ax.get_xlim()
    ax.plot([x_min, x_max], [0, 0], 'k', linewidth=1.5, alpha = 1)
    
    # Y Ticks
    ax.tick_params(axis='y', labelsize = y_font_sz)
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    
    # Show Legend
    ax.legend(bbox_to_anchor=(1, 0.95), ncol=1, fontsize = 'x-large', loc = 'upper left')
    return figs  
 
def plot_margin_weekly_change(df, figs, figs_title):
    # 1. Varibles
    figs.clf()
    figs.set_constrained_layout(True)
    ax = figs.add_subplot(111)

    # 2. Plot
    ser_diff = df.loc[df.index[-1]] - df.loc[df.index[-2]]
    
    margin1 = df.loc[df.index[-2]].sum()
    date1 = df.index[-2]
    
    margin2 = df.loc[df.index[-1]].sum()
    date2 = df.index[-1]
    
    # 2.2 Plot Margin of Last Friday
    i = 0
    x_axis = []
    y_value = margin1
    labels = date1.strftime('%b-%d')    
    x_axis.append(labels)
    ax.bar(i, y_value, alpha = 0.8, color='purple', label = labels)    
    i += 1
    # 2.3 Plot Margin Component change
    palette = plt.get_cmap('tab20')
    palt_dict = {'Propane': 0, 'Butane': 1, 'Naphtha': 2, 'Gasoline': 3, 'Jet': 4, 'ULSD': 5, 
                'Gasoil': 6, 'LSFO': 7, 'HSFO': 8, 'LSVGO': 9, 'LSSR': 10, 'HSSR': 11, 
                 'Other' : 12, 'DFL':13, 'Crude Diffs': 14, 'Freight': 15, 'Loss':16}    
    for k, value in palt_dict.items():
        if value < 10:
            palt_dict[k] = value * 2
        else:
            palt_dict[k] = value % 10 * 2 + 1 
    for ind, value in ser_diff.items():
        bar_bottom = y_value
        y_value += value
        labels = ind
        x_axis.append(labels)
        # ax.bar(i, value, bottom = bar_bottom, alpha = 0.8, color=palette(palt_dict[ind]), label = labels)
        if value >= 0:
            ax.bar(i, value, bottom = bar_bottom, alpha = 0.8, color='cornflowerblue', label = labels)
        else:
            ax.bar(i, value, bottom = bar_bottom, alpha = 0.8, color='indianred', label = labels)
        i += 1
    # 2.3 Plot Margin of this friday
    labels = date2.strftime('%b-%d') 
    x_axis.append(labels)    
    ax.bar(i, margin2, alpha = 0.8, color='purple', label = labels)
    i += 1
 
    # 3 Chart Setting
    # Title
    ax.set_title(figs_title, fontdict={'fontsize':title_font_sz})
    
    # X tick labels
    
    ax.set_xticks(range(i), minor = False)
    ax.set_xticklabels(x_axis, fontdict={'fontsize':x_font_sz}, minor = False, rotation=45)      
    # Y limit
    y_min, y_max = ax.get_ylim()
    ax.set_ylim(y_min*1.1, y_max*1.2)
    
    # Y Ticks
    ax.tick_params(axis='y', labelsize = y_font_sz)
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    
    return figs
    
def plot_margin_contributors(df, figs, figs_title):
    # 1. Varibles
    figs.clf()
    ax = figs.add_subplot(111)

    # 2. Plot
    ser_diff = df.loc[df.index[-1]] - df.loc[df.index[-2]]
    
    # 2.3 Plot Margin Component change
    palette = plt.get_cmap('tab20')
    palt_dict = {'Propane': 0, 'Butane': 1, 'Naphtha': 2, 'Gasoline': 3, 'Jet': 4, 'ULSD': 5, 
                'Gasoil': 6, 'LSFO': 7, 'HSFO': 8, 'LSVGO': 9, 'LSSR': 10, 'HSSR': 11, 
                 'Other' : 12, 'GasCost':13, 'DFL':14, 'Crude Diffs': 15, 'Freight': 16, 'Loss':17}
                 
    for k, value in palt_dict.items():
        if value < 10:
            palt_dict[k] = value * 2
        else:
            palt_dict[k] = value % 10 * 2 + 1 
    x_axis = []
    i = 0
    for ind, value in ser_diff.items():
        labels = ind
        x_axis.append(labels)
        ax.bar(i, value, alpha = 0.8, color=palette(palt_dict[ind]), label = labels)
        i += 1
 
    # 3 Chart Setting
    # Title
    ax.set_title(figs_title, fontdict={'fontsize':title_font_sz})
    
    # X tick labels
    ax.set_xticks(range(i), minor = False)
    ax.set_xticklabels(x_axis, fontdict={'fontsize':x_font_sz}, minor = False, rotation=45)      

    # Y limit
    y_min, y_max = ax.get_ylim()
    ax.set_ylim(y_min*1.1, y_max*1.2)
    
    # Y Ticks
    ax.tick_params(axis='y', labelsize = y_font_sz)
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    
    return figs    
    