import datetime
import os
import numpy as np
import pandas as pd
import sys
import time
import config
import matplotlib as mpl
import matplotlib.pyplot as plt

from MarginSup import *

title_font_sz = 20
x_font_sz = 16
y_font_sz = 16

def format_crude(df):

    df = df.dropna(how='all')

    inds = [datetime.date(1972, 1, 1) + datetime.timedelta(i) for i in range(366)] 
    df1 = pd.DataFrame([], index = inds)

    for ind, row in df.items():
        x = datetime.date(1972, ind.month, ind.day)
        y = ind.year
        df1.loc[x, y] = round(row, 2)
    
    df1 = df1.fillna(method='backfill', limit = 5)

    return df1

def format_fwd_crack(df_fwd_margin):

    inds = [datetime.date(1972, 1, 1) + datetime.timedelta(i) for i in range(366)]
     
    df_new_fwd_margin = pd.DataFrame([], index = inds) 
    
    for ind, row in df_fwd_margin.iterrows():
        if ind.year == 1:
            next_day = get_next_trading_day(row.index[0])
            x = datetime.date(1972, next_day.month, next_day.day)
            y = next_day.year
        else:
            x = datetime.date(1972, ind.month, ind.day)
            y = ind.year            
        df_new_fwd_margin.loc[x, y] = row[0]
    df_new_fwd_margin = df_new_fwd_margin.fillna(method='ffill')
    
    return df_new_fwd_margin


def cal_fwd_crack(df_prod, df_brt, cf):
    
    df_prod = df_prod.iloc[:, -1:]
    df_prod = df_prod.dropna(how="any")    
    
    df_brt = df_brt.iloc[:, -1:]
    df_brt = df_brt.dropna(how="any")
    
    for ind in df_prod.index:
        df_prod.loc[ind] = df_prod.loc[ind] / cf - df_brt.loc[ind]
    df_prod = df_prod.round(2)
    df_prod = format_fwd_crack(df_prod)

    return df_prod
    
    
            



#Get Monthly Average and Rearrange
def get_month_ave_crack(df):

    inds = [datetime.date(ind.year, ind.month, 1) for ind in df.index]
    df.index = inds
    
    gp = df.groupby(df.index, axis = 0, sort = False)
    df_m = gp.mean()
    ser_m = df_m.mean(axis=1)
    
    inds = [datetime.date(1972, 1, 1) + datetime.timedelta(i) for i in range(366)]
    
    my_dict = {}
    for ind in inds:
        tmp_date = datetime.date(ind.year, ind.month, 1)
        value = ser_m[tmp_date]
        my_dict[ind] = value
    ser1 = pd.Series(my_dict)
    
    return ser1

def plot_crude(df_crude, fig, fig_title):
    mpl.style.use(['seaborn-darkgrid'])

    #1. Definitions
    fig.clf()
    ax = fig.add_subplot(111)
    
    #2. Plot Margin Chart
    ind = np.arange(df_crude.index.size) 
    
    # 2.1 x
    x_data = df_crude.index
 
    # 2.2 y  
    #Historical
    df_his = df_crude.loc[:, 2015:2019]
    df_his = df_his.fillna(method='ffill')
    
    if df_his.columns.min() <= 2015:
        y_data_min = df_his.min(axis=1)
        y_data_max = df_his.max(axis=1)
        y_data_ave = get_month_ave_crack(df_his)
    else:
        y_data_his = df_his
    
    #2020
    ser_data_2020 = df_crude.loc[:, 2020:2020]

    #2021
    ser_data_2021 = df_crude.loc[:, 2021:2021]

    #2022
    ser_data_2022 = df_crude.loc[:, 2022:2022]

    #2023
    ser_data_2023 = df_crude.loc[:, 2023:2023]
    
    #This Year
    ser_data_this_year = df_crude.iloc[:, -1:]
    

    # 2.3 Plot
    if df_his.columns.min() > 2015:
        for col in y_data_his.columns:
            ax.plot(ind, y_data_his[col], label = col%100) 
            
    # 2020
    labels = str(ser_data_2020.columns[0]%100)
    y_data = ser_data_2020.to_numpy()
    ax.plot(ind, y_data, c = 'blueviolet', linewidth=1.5, label = labels)

    # 2021
    labels = str(ser_data_2021.columns[0]%100)
    y_data = ser_data_2021.to_numpy()
    ax.plot(ind, y_data, c = 'darkcyan', linewidth=1.5, label = labels)

    # 2022
    labels = str(ser_data_2022.columns[0] % 100)
    y_data = ser_data_2022.to_numpy()
    ax.plot(ind, y_data, c='royalblue', linewidth=1.5, label=labels)

    # 2023
    labels = str(ser_data_2023.columns[0] % 100)
    y_data = ser_data_2023.to_numpy()
    ax.plot(ind, y_data, c='deeppink', linewidth=1.5, label=labels)
    
    # This Year
    labels = str(ser_data_this_year.columns[0]%100)
    y_data = ser_data_this_year.to_numpy()
    ax.plot(ind, y_data, c ='firebrick', linewidth=2.5, label = labels)
    
    if df_his.columns.min() <= 2015:
        # 5 year Average
        labels = str(df_his.columns[0]%100) + '-' + str(df_his.columns[-1]%100) + ' Avg'
        ax.plot(ind, y_data_ave, 'k-.', label = labels) 
        # 5 Year Range
        labels = str(df_his.columns[0]%100) + '-' + str(df_his.columns[-1]%100) + '\n Range'
        ax.fill_between(ind, y_data_min, y_data_max, alpha=0.4, color = 'cadetblue', label = labels)

        

    # 2.4 Chart Setting
    # Title
    ax.set_title(fig_title, fontdict={'fontsize':title_font_sz})
    
    # X tick label
    x_ticks = []
    x_tick_labels = []
    y_min, y_max = ax.get_ylim()
    if y_min >= -1:
        y_min = -1
    for i in range(len(x_data)):
        if x_data[i].day == 1:
            x_ticks.append(i)
            x_tick_labels.append(x_data[i].strftime('%b'))  
            
            # Setting x grid for quarterly chart
            if x_data[i].month in [1, 4, 7, 10]:
                ax.plot([i, i], [y_min, y_max], 'k', alpha = 0.4)
            # else:
                # ax.plot([i, i], [y_min, y_max], 'k', alpha = 0.2)

    ax.plot([ind[-1], ind[-1]], [y_min, y_max], 'k', alpha = 0.4)    
        
    ax.set_xticks(x_ticks, minor = False)
    ax.set_xticklabels(x_tick_labels, fontdict={'fontsize':x_font_sz}, minor = False)  
    
    # Y Ticks
    ax.tick_params(axis='y', labelsize = y_font_sz)
     
    # Show Legend
    ax.legend(bbox_to_anchor=(1, 0.70), ncol=1, loc = 'lower left', fontsize = 'x-large')

    # Setting y grid
    x_min, x_max = ax.get_xlim()
    ax.plot([x_min, x_max], [0, 0], 'k', linewidth=1, alpha = .4)
    
    # Set y limit
    ax.set_ylim(y_min, y_max)
        
    plt.tight_layout() 
    return fig
 
def plot_all_crude():
    path = config.path_margin
    path_fwd = config.path_margin_fwd
    chart_path = config.chart_path

    fig = plt.figure(figsize=(16.5, 11.3 * 0.6))
    
    #1.1 Raw Data
    pkl_nwe_raw = path + 'NWERawData.pickle'
    df_nwe_raw = pd.read_pickle(pkl_nwe_raw)
    df_nwe_raw = df_nwe_raw.loc[lambda df: df.index >= datetime.date(2015, 1, 1)]    
    
    pkl_med_raw = path + 'MedRawData.pickle'
    df_med_raw = pd.read_pickle(pkl_med_raw)
    df_med_raw = df_med_raw.loc[lambda df: df.index >= datetime.date(2015, 1, 1)]
    
    # Crude Structure
    df_cru_stc = df_nwe_raw['NSStrip'] - df_nwe_raw['LMM']
    df_cru_stc = format_crude(df_cru_stc)  

    # NWE Freight
    df_nwe_fre = df_nwe_raw['NWEFreight']
    df_nwe_fre = format_crude(df_nwe_fre)  
    
    # Med Freight
    df_med_fre = df_med_raw['MedFreight']
    df_med_fre = format_crude(df_med_fre) 
    
    # NWE Crude Diffs
    df_nwe_diff = df_nwe_raw[['Oseberg', 'Forties', 'Ekofisk', 'Urals']].mean(axis=1)
    df_nwe_diff = format_crude(df_nwe_diff)     
    
    # Med Crude Diffs
    df_med_diff = df_med_raw[['Urals', 'CPC', 'Saharan', 'Azeri']].mean(axis=1)
    df_med_diff = format_crude(df_med_diff) 

    
    ####
    ###2. Plot
    ####
 
    # Plot Crude Structure
    fig_title = 'North Sea Strip vs Brent London Minute Marker'
    fig = plot_crude(df_cru_stc, fig, fig_title)
    fig_name = chart_path + 'CrudeChart-NWEStructure.png'
    fig.savefig(fig_name, format = 'png')     
    
    # Plot NWE Freight
    fig_title = 'NWE Freight(UKC-UKC 80kt)'
    fig = plot_crude(df_nwe_fre, fig, fig_title)
    fig_name = chart_path + 'CrudeChart-NWEFreight.png'
    fig.savefig(fig_name, format = 'png')         
    
    # Plot NWE Diffs
    fig_title = 'NWE Diff (Average of Oseberg, Forties, Ekofisk and Urals)'
    fig = plot_crude(df_nwe_diff, fig, fig_title)
    fig_name = chart_path + 'CrudeChart-NWEDiff.png'
    fig.savefig(fig_name, format = 'png')     

    # Plot Med Freight
    fig_title = 'Med Freight(Med-Med 80kt)'
    fig = plot_crude(df_med_fre, fig, fig_title)
    fig_name = chart_path + 'CrudeChart-MedFreight.png'
    fig.savefig(fig_name, format = 'png')     
    
    # Plot Med Diffs
    fig_title = 'Med Diff (Average of Urals, CPC, Saharan and Azeri)'
    fig = plot_crude(df_med_diff, fig, fig_title)
    fig_name = chart_path + 'CrudeChart-MedDiff.png'
    fig.savefig(fig_name, format = 'png')   
    
def main():
    plot_all_crude()
    
if __name__ == "__main__":
    print("Example")
    try:
        start = time.time()
        main()
        end = time.time()
        print('Task runs %0.2f seconds.' %(end - start))
    except KeyboardInterrupt:
        print("Ctrl+C pressed. Stopping...")        