import pandas as pd
import time
import config
from datetime import date, datetime
from dateutil.relativedelta import relativedelta
import SaveDataSup as sds
# from MarginSup import *
import warnings
warnings.filterwarnings("ignore")

path = config.path_margin
path_ttf = config.path_margin + 'GasCost/'
path_fwd = config.path_margin_fwd
path_hani = config.path_margin_hani

def save_csv_data(start_date, end_date):
    #Models
    xls_name = '\\\petroineos.local\dfs\Department Private Folders\Analysis Department\Crude\Automation\DG.xlsm'
    df_model = pd.read_excel(xls_name, sheet_name = 'Model', index_col = 3)
    df_model = df_model[df_model['RelatedProject'] == 'European Margin']
    df_model_nwe = df_model[(df_model['SubProject'] == 'NWE Margin') | (df_model['SubProject'] == 'NWE Margin & Med Margin')]
    df_model_med = df_model[(df_model['SubProject'] == 'Med Margin') | (df_model['SubProject'] == 'NWE Margin & Med Margin')]
    df_model_sg = df_model[df_model['SubProject'] == 'SG Margin']
    df_model_gasttf = df_model[df_model['Name'].str.contains("TTFM")]
    df_model_nwe_fwd = df_model[(df_model['SubProject'] == 'NWE Forward Margin')]
    df_model_med_fwd = df_model[(df_model['SubProject'] == 'Med Forward Margin')]

    # NWE Spot Margin
    nwe_name = 'NWERawData'
    sds.save_spot_data(df_model_nwe, nwe_name, start_date, end_date) 

    
    
    # Med Spot Margin
    med_name = 'MedRawData'
    sds.save_spot_data(df_model_med, med_name, start_date, end_date)     
    
    #exit()
    
    # SG Spot Margin
    sg_name = 'SGRawData'
    sds.save_spot_data(df_model_sg, sg_name, start_date, end_date)  
    
    # NWE Forward
    nwe_name = 'NWEForwardData'
    sds.save_fwd_data_by_day(df_model_nwe_fwd, nwe_name)    
    sds.save_fwd_data_by_product(df_model_nwe_fwd)    
    
    # Med Forward
    med_name = 'MedForwardData'
    sds.save_fwd_data_by_day(df_model_med_fwd, med_name)    
    sds.save_fwd_data_by_product(df_model_med_fwd)

    # TTF
    sds.save_ttf_data(df_model_gasttf, start_date, end_date)    
    sds.save_gas_cost()  
    
def main(): 
    # Read and Save Source Data
    from_date = date(2018, 1, 2)
    to_date = date.today() - relativedelta(days=+1)
    save_csv_data(from_date, to_date)

if __name__ == "__main__":
    print("Example")
    try:
        start = time.time()
        main()
        end = time.time()
        print('Task runs %0.2f seconds.' %(end - start))
    except KeyboardInterrupt:
        print("Ctrl+C pressed. Stopping...")