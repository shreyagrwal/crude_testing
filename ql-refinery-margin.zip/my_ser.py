import time
import datetime
import pandas as pd
import config

def main():

    path = config.path_margin
    
    # 1 Variable Definitions
    # 1.1 NWE Cracks
    pkl_cracks = path + 'NWECracksData.pickle'
    df_nwe_cracks = pd.read_pickle(pkl_cracks)
    ser_pro = df_nwe_cracks['Propane']
    
    my_index = []
    start_date = datetime.date(1972, 1, 1)
    for i in range(366):
        my_index.append(start_date)
        start_date += datetime.timedelta(days=1)
    
    df = pd.DataFrame([], index = my_index)
    
    for ind, value in ser_pro.iteritems():
        ind_date = datetime.date(1972, ind.month, ind.day)
        df.loc[ind_date, ind.year] = value
    
    print(df)

 
if __name__ == "__main__":
    print("Example")
    try:
        start = time.time()
        main()
        end = time.time()
        print('Task runs %0.2f seconds.' %(end - start))
    except KeyboardInterrupt:
        print("Ctrl+C pressed. Stopping...")  