import datetime
import os
import numpy as np
import pandas as pd
import requests
import time
import vobject

from enum import IntEnum

def download_data(url, dst_file_name):
    response = requests.get(url)
    if response.status_code == 200 and not response.content.isspace():
        with open(dst_file_name, 'wb') as f:
            f.write(response.content)
    else:
        raise ValueError('Bad Url: ' + url)    

def parse_ics(ics_data):

    cal_list = []
    for cal in vobject.readComponents(ics_data):
        for component in cal.components():
            if component.name == "VEVENT":
                cal = {}
                cal['name'] = component.summary.valueRepr()
                cal['str_date'] = component.dtstart.valueRepr()
                cal['end_date'] = component.dtend.valueRepr()
                cal['time_stamp'] = component.dtstamp.valueRepr()
                cal['uid'] = component.uid.valueRepr()
                
                cal_list.append(cal.copy())    
    df = pd.DataFrame(cal_list) 
    return df


def get_holiday_frame():
    pkl_name = 'london_bank_holidays.pkl'
    if os.path.exists(pkl_name):
        df_ics = pd.read_pickle(pkl_name)  
        if datetime.date.today().year > df_ics['time_stamp'][0].year:
            url = r'https://www.gov.uk/bank-holidays/england-and-wales.ics'
            ics_name = 'london_bank_holidays.ics'
            download_data(url, ics_name)
            data = open(ics_name).read()
            df_ics = parse_ics(data)
            df_ics.to_pickle(pkl_name)
    else: 
        url = r'https://www.gov.uk/bank-holidays/england-and-wales.ics'
        ics_name = 'london_bank_holidays.ics'
        download_data(url, ics_name)
        data = open(ics_name).read()
        df_ics = parse_ics(data)
        df_ics.to_pickle(pkl_name)
    return df_ics

df_ics = get_holiday_frame()
    
def is_bank_holiday(bh_date):

    additional_holidays = [datetime.date(2022, 9, 19)]
    if bh_date in additional_holidays:
        return True
    
    for i in range(len(df_ics['str_date'])):
        if bh_date == df_ics.at[i, 'str_date']:
            return True
    else:
        return False
 
def get_previous_trading_day(ptd_date):
    
    # print(ptd_date)
    ptd_date -= datetime.timedelta(days=1)
    while ptd_date.weekday() in [5, 6] or is_bank_holiday(ptd_date):
        ptd_date -= datetime.timedelta(days=1)
     
    return ptd_date

def get_next_trading_day(ntd_date):
    
    ntd_date += datetime.timedelta(days=1)
    while ntd_date.weekday() in [5, 6] or is_bank_holiday(ntd_date):
        ntd_date += datetime.timedelta(days=1)
     
    return ntd_date

#The same day of next month
def get_next_month(nm_date):

    if nm_date.month == 12:
        nm_date = datetime.date(nm_date.year+1, 1, 1)
    else:
        nm_date = datetime.date(nm_date.year, nm_date.month+1, 1)
    return nm_date        
            
#Format to Yearly
def format_margin(ser):
    
    my_inds = [datetime.date(1972, 1, 1) + datetime.timedelta(i) for i in range(366)]
    df = pd.DataFrame([], index = my_inds)  
    for ind, value in ser.items():
        x = datetime.date(1972, ind.month, ind.day)
        y = ind.year
        df.loc[x, y] = value
    df = df.fillna(method='backfill')
    return df

def main(): 
    start_date = datetime.date(2021, 5, 3)
    
    # print(get_previous_trading_day(my_date))
    for i in range(1000):
        start_date = get_previous_trading_day(start_date)
        print(start_date)

if __name__ == "__main__":
    print("Example")
    try:
        start = time.time()
        main()
        end = time.time()
        print('Task runs %0.2f seconds.' %(end - start))
    except KeyboardInterrupt:
        print("Ctrl+C pressed. Stopping...")