import datetime
import os
import pandas as pd
import sys
import time

import matplotlib.pyplot as plt

import SaveDataSup as sds
import MarginSup as ms
import config
# from MarginSup import *
import SaveDataSup as sds

path = config.path_margin
path_ttf = config.path_margin + 'GasCost/'
path_fwd = config.path_margin_fwd
path_hani = config.path_margin_hani

def get_component(df, yields):
    # 1. Params
    df = df[yields.keys()]
    conversion_factor = config.conversion_factor   

    # 2. Calculation
    ser_mul = pd.Series([], dtype='float64')
    for key, value in yields.items():
        i_cf = 1
        if key in conversion_factor.keys():
            i_cf = conversion_factor[key]        
        i_mul = (1 / i_cf) * value
        ser_mul[key] = i_mul
    df_comp = df.mul(ser_mul)
    return df_comp

def get_margin_comp(df, prod_yield, crude_slate, crude_slate_new=None):

    # 2. Get Components
    # 2.1 Products Components
    df_comp_prod = get_component(df, prod_yield)
    # 2.2 Strip
    df_comp_strip = pd.DataFrame([])
    crude_strip_yield = crude_slate['Strip']
    strip = list(crude_strip_yield.keys())[0]
    df_comp_strip['LMM'] = -df['LMM']
    df_comp_strip['DFL'] = -(df[strip] - df['LMM'])
    # print(df_comp_strip)
    # sys.exit()
    # ser_strip = get_component(df, crude_strip_yield)
    # ser_strip = df_comp_strip.iloc[:, 0]
    # ser_strip.name = 'Strip'
    
    # 2.3 Crude Diff
    crude_slate_yield = crude_slate['Slate']
    if crude_slate_new is None:
        df_comp_diff = get_component(df, crude_slate_yield)
        ser_comp_diff = df_comp_diff.sum(axis=1)
    else:
        str_date_new_slate = crude_slate_new['Date']
        crude_slate_yield_new = crude_slate_new['Slate']
        df_pre = df.loc[:(str_date_new_slate-datetime.timedelta(days=1))]
        df_new = df.loc[str_date_new_slate:]
        df_comp_diff_pre = get_component(df_pre, crude_slate_yield)   
        df_comp_diff_new = get_component(df_new, crude_slate_yield_new)

        ser_comp_diff_pre = df_comp_diff_pre.sum(axis=1)
        ser_comp_diff_new = df_comp_diff_new.sum(axis=1)
        ser_comp_diff = ser_comp_diff_pre.append(ser_comp_diff_new)
        #ser_comp_diff = = pd.concat([ser_comp_diff_pre,ser_comp_diff_new], axis=0) # TODO: axis 0 or 1
    ser_comp_diff.name = 'Crude Diffs'
    # 2.4 Freight
    crude_freight_yield = crude_slate['Freight']
    df_comp_freight = get_component(df, crude_freight_yield)       
    ser_freight = df_comp_freight.iloc[:, 0]
    ser_freight.name = 'Freight'    
    # 2.5 Gas Cost
    crude_gascost_yield = crude_slate['GasCost']
    df_comp_gas = get_component(df, crude_gascost_yield) 
    df_comp_gas = df_comp_gas.round(2)
    ser_gas = df_comp_gas.iloc[:, 0]
    ser_gas = ser_gas.round(2)
    ser_gas.name = 'GasCost'    
    
    # 3. Concat
    df_list = [df_comp_prod, df_comp_strip, ser_comp_diff, ser_freight, ser_gas]
    df_margin_comp = pd.concat(df_list, axis=1)
    
    return df_margin_comp

def save_component_margin(df_comp, name_prefix):

    # 1. Save Component
    pkl_name = path + f'{name_prefix}MarginComponentData.pickle'
    csv_name = path + f'{name_prefix}MarginComponentData.csv'  
    df_comp.to_pickle(pkl_name)
    df_comp.to_csv(csv_name)

    # 2. Save Margin With GasCost
    ser_margin = df_comp.sum(axis=1)
    ser_margin = ser_margin.round(2)
    ser_margin.name = name_prefix
    pkl_name = path + f'{name_prefix}MarginDataWithGasCost.pickle'
    csv_name = path + f'{name_prefix}MarginDataWithGasCost.csv'  
    ser_margin.to_pickle(pkl_name)
    ser_margin.to_csv(csv_name)        
    
    # 2. Save Margin Without GasCost
    ser_margin = df_comp.drop('GasCost', axis=1).sum(axis=1)
    ser_margin = ser_margin.round(2)
    ser_margin.name = name_prefix
    pkl_name = path + f'{name_prefix}MarginDataNoGasCost.pickle'
    csv_name = path + f'{name_prefix}MarginDataNoGasCost.csv'  
    ser_margin.to_pickle(pkl_name)
    ser_margin.to_csv(csv_name)   
 

def get_margin_fwd(df, ser_gas, prod_yield, crude_slate, crude_other, prod_other, freight, freight_mean):
    # 2. Get Components
    # 2.1 Products Components
    my_yield = prod_yield
    df_comp_prod = get_component(df, my_yield)
    
    # 2.2 Crude
    my_yield = crude_slate
    df_comp_crude = get_component(df, my_yield)
    ser_crude = df_comp_crude.iloc[:, 0]
    ser_crude.name = list(my_yield.keys())[0]

    # 2.3 Crude Other
    ser_crude_other = pd.Series([], dtype='float64')
    ser_crude_other.name = 'Crude Other'
    ser_freight = pd.Series([], dtype='float64')
    ser_freight.name = 'Freight'
    decay_factor = config.decay_factor
    for i, ind in enumerate(df.index):
        if i in decay_factor.keys():
            ser_crude_other.loc[ind] = round(crude_other * decay_factor[i], 2)
            ser_freight.loc[ind] = round(freight_mean + (freight-freight_mean)* decay_factor[i], 2)
        else:
            ser_crude_other.loc[ind] = 0
            ser_freight.loc[ind] = freight_mean
   
    # 2.4 Product Other
    ser_prod_other = pd.Series([], dtype='float64')
    ser_prod_other.name = 'Product Other'
    for ind in df.index:
        ser_prod_other.loc[ind] = prod_other   

    # 2.5 Gas Cost    
    ser_gas_cost = pd.Series([], dtype='float64')
    ser_gas_cost.name = 'GasCost'
    ind0 = ser_gas.index[0]
    ind1 = ser_gas.index[-1]
    for i, ind in enumerate(df.index):
        if i == 0:
            ser_gas_cost.loc[ind] = ser_gas.loc[ind0] 
        elif ind <= ind0:
            ser_gas_cost.loc[ind] = ser_gas.loc[ind0]          
        elif ind >= ind1:
            ser_gas_cost.loc[ind] = ser_gas.loc[ind0]           
        else:
            ser_gas_cost.loc[ind] = ser_gas.loc[ind] 
    gas_factor = config.mgw_bbl
    ser_gas_cost = ser_gas_cost * gas_factor

    # 3. Concat
    df_list = [df_comp_prod, ser_crude, ser_crude_other, ser_freight, ser_prod_other, ser_gas_cost]
    df_margin_comp = pd.concat(df_list, axis=1)

    return df_margin_comp  

def main(): 
    # 1. Calculate and Save Gas Cost
    sds.save_gas_cost() 
    pass

if __name__ == "__main__":
    print("Example")
    try:
        start = time.time()
        main()
        end = time.time()
        print('Task runs %0.2f seconds.' %(end - start))
    except KeyboardInterrupt:
        print("Ctrl+C pressed. Stopping...")    