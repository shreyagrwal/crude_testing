import datetime
import os
import pandas as pd
import sys
import time

import matplotlib.pyplot as plt

import SaveDataSup as sds
import MarginSup as ms
import CalcMarginSup as cms
import config
import numpy as np
from pathlib import Path
# from MarginSup import *

path = config.path_margin
path_ttf = config.path_margin + 'GasCost/'
path_fwd = config.path_margin_fwd
path_hani = config.path_margin_hani
#path_ali = config.path_margin_ali
start_date = datetime.date(2015, 1, 1)

def get_gas_cost_spot():
    # Ver 1. 100% NatGas
    pkl_name = path_ttf + 'TTF-Rolling.pkl'
    df_gas_spot = pd.read_pickle(pkl_name)
    df_gas_spot = df_gas_spot.astype('float64')
    ser_gas_spot = df_gas_spot.iloc[:, 0]

    # Ver 2. 60% NatGas
    # pkl_name = path_ttf + 'GasCost.pkl'
    # df_gas_spot = pd.read_pickle(pkl_name)
    # df_gas_spot = df_gas_spot.astype('float64')
    # ser_gas_spot = df_gas_spot.loc[:, ['NatGas', '40-60']].min(axis=1)
    # Ver 3. 25% NatGas
    # ser_gas_spot = df_gas_spot.loc[:, ['NatGas', '75-25']].min(axis=1)

    ser_gas_spot.name = 'GasCost'

    return ser_gas_spot
    
    
def get_gas_cost_fwd():
    # Ver 1. 100% NatGas
    pkl_name = path_ttf + 'TTF-Abs.pkl'
    # Ver 2. 60% NatGas
    # pkl_name = path_ttf + 'GasCost-40best.pkl'
    # Ver 3. 25% NatGas
    # pkl_name = path_ttf + 'GasCost-75best.pkl'

    # Read Data
    df_gas = pd.read_pickle(pkl_name)
    df_gas = df_gas.loc[start_date:]
    df_gas = df_gas.T

    return df_gas


def calc_margin():
    # Read Gas
    ser_gas_spot = get_gas_cost_spot()
    df_gas_fwd = get_gas_cost_fwd()

    # 1. NWE Spot Margin
    print('-' * 20)
    print('NWE Margin')
    print('-' * 20)
    pkl_name = path + 'NWERawData.pickle'
    df_raw = pd.read_pickle(pkl_name)
    df_raw = df_raw.loc[start_date:]
    # df_raw = df_raw.drop(columns=['VLSFO', 'LMM'])
    df_raw = df_raw.drop(columns=['VLSFO'])
    df_raw = df_raw.dropna(how='all', axis=0)
    df_raw = df_raw.fillna(method='ffill')
    df_raw['Other'] = df_raw['HSVGO']
    ser_gas_spot = ser_gas_spot.loc[df_raw.index]
    df_raw = pd.concat([df_raw, ser_gas_spot], axis=1)

    # Curde Slate
    crude_slate = config.nwe_crud_basket
    crude_slate_new = config.nwe_crud_basket_new
    crude_wti = config.nwe_wti_basket
    crude_wti_new = config.nwe_wti_basket_new
    # crude_slate_new = None

    # 1.1 NWE Complex Margin
    prod_yield = config.nwe_com_yield
    # Component
    df_comp_com = cms.get_margin_comp(df_raw, prod_yield, crude_slate, crude_slate_new)
    cms.save_component_margin(df_comp_com, 'NWEComplex')

    # 1.2 NWE Simple Margin
    prod_yield = config.nwe_sim_yield
    df_comp_sim = cms.get_margin_comp(df_raw, prod_yield, crude_slate, crude_slate_new)
    cms.save_component_margin(df_comp_sim, 'NWESimple')

    # 1.3 NWE Hyrdoskim WTI Margin

    prod_yield = config.nwe_hydroskim_wti_yield
    df_hydro_wti = cms.get_margin_comp(df_raw, prod_yield, crude_wti, crude_wti_new)
    df_hydro_wti['Freight'] = np.where(df_hydro_wti.index > pd.Timestamp('2021-07-21'), np.nan, df_hydro_wti['Freight'])
    #df_hydro_wti.loc[df_hydro_wti.index <= pd.Timestamp('2018-02-28'), 'Freight'] = df_freight_hist['Freight Rates BBL']
    cms.save_component_margin(df_hydro_wti, 'HydroskimWTI')

    # 1.4 NWE Topping WTI Margin
    prod_yield = config.nwe_topping_wti_yield
    df_topp_wti = cms.get_margin_comp(df_raw, prod_yield, crude_wti, crude_wti_new)
    df_topp_wti['Freight'] = np.where(df_topp_wti.index > pd.Timestamp('2021-07-21'), np.nan, df_topp_wti['Freight'])
    #df_topp_wti.loc[df_topp_wti.index <= pd.Timestamp('2018-02-28'), 'Freight'] = df_freight_hist['Freight Rates BBL']
    cms.save_component_margin(df_topp_wti, 'ToppingWTI')

    # 1.5 Save Complex and Simple Margin as DataFrame
    # Without GasCost
    df_comp_com_tmp = df_comp_com.drop(['GasCost'], axis=1)
    ser_com = df_comp_com_tmp.sum(axis=1)
    ser_com.name = 'NWE Complex'
    df_comp_hydro_tmp = df_hydro_wti.drop(['GasCost'], axis=1)
    ser_hydro_nogas = df_comp_hydro_tmp.sum(axis=1)
    ser_hydro_nogas.name = 'NWE Hyrdoskim'
    df_comp_top_tmp = df_topp_wti.drop(['GasCost'], axis=1)
    ser_top_nogas = df_comp_top_tmp.sum(axis=1)
    ser_top_nogas.name = 'NWE Topping'
    df_comp_sim_tmp = df_comp_sim.drop(['GasCost'], axis=1)
    ser_sim = df_comp_sim_tmp.sum(axis=1)
    ser_sim.name = 'NWE Simple'
    df_margin = pd.concat([ser_com, ser_hydro_nogas, ser_top_nogas, ser_sim], axis=1)

    pkl_name = path + 'NWEMarginDataNoGasCost.pickle'
    csv_name = path + 'NWEMarginDataNoGasCost.csv'
    df_margin.to_pickle(pkl_name)
    df_margin.to_csv(csv_name)

    # With GasCost
    ser_com = df_comp_com.sum(axis=1)
    ser_com.name = 'NWE Complex'
    ser_sim = df_comp_sim.sum(axis=1)
    ser_sim.name = 'NWE Simple'
    ser_hydro = df_hydro_wti.sum(axis=1)
    ser_hydro.name = 'NWE Hyrdoskim'
    ser_top = df_topp_wti.sum(axis=1)
    ser_top.name = 'NWE Topping'
    df_margin = pd.concat([ser_com, ser_hydro_nogas, ser_top_nogas, ser_sim], axis=1)

    pkl_name = path + 'NWEMarginData.pickle'
    csv_name = path + 'NWEMarginData.csv'
    df_margin.to_pickle(pkl_name)
    df_margin.to_csv(csv_name)
    df_margin_NWE= df_margin
    # For other Project
    # csv_name = path_ali + 'NWEMarginData.csv'
    # df_margin.to_csv(csv_name)
    csv_name = path_hani + 'NWEMarginData.csv'
    df_margin.to_csv(csv_name)

    # 2. NWE Forward Margin
    # 2.1 Read Forward Margin
    pkl_name = path_fwd + "NWEComplexForwardMargin-abs.pkl"
    pub_date = datetime.date(2015, 1, 2)
    if os.path.exists(pkl_name):
        df_com_abs = pd.read_pickle(pkl_name)
        pub_date = df_com_abs.columns[-1]
    else:
        df_com_abs = pd.DataFrame([])
        pub_date = datetime.date(2015, 1, 2)

    # 2.2 Other Data
    # Crude
    ser_dfl = 0
    # ser_dfl = df_raw['Dated'] - df_raw['NSStrip']
    # ser_dfl = -df_comp_com['DFL']
    ser_diff = df_comp_com['Crude Diffs']
    ser_other_crude = ser_dfl + ser_diff
    ser_freight = df_comp_com['Freight']
    ser_freight_mean = ser_freight.rolling(200).mean()
    ser_freight_mean.name = 'Mean'

    # ser_other_crude = ser_diff + ser_freight
    # Product
    prod_yield = config.nwe_com_yield_fwd
    list_other_prod = ['LSVGO', 'LSSR', 'HSSR', 'Other']
    ser_other_prod = df_comp_com.loc[:, list_other_prod].sum(axis=1)

    # 2.3. Calculation
    # Deciding Date
    deciding_date = datetime.date.today()
    if ms.is_bank_holiday(deciding_date):
        deciding_date = ms.get_previous_trading_day(deciding_date)
    # pub_date = datetime.date(2022, 2, 1)
    # deciding_date = get_next_trading_day(pub_date)
    while pub_date < deciding_date:
        # 2.3.1 Read Data
        path_fwd_daily = path_fwd + str(pub_date.year) + "/" + pub_date.strftime('%Y-%m-%d') + "/"
        pkl_name = path_fwd_daily + "NWEForwardData.pkl"
        if os.path.exists(pkl_name):
            df_fwd_raw = pd.read_pickle(pkl_name)
            #print(df_fwd_raw)
            #print(1)
        else:
            pub_date = ms.get_next_trading_day(pub_date)
            #print(2)
            continue
        # 2.3.2 Data PreProcessing
        # Drop and Fill NA
        df_fwd_raw = df_fwd_raw.drop(columns='Brent')
        df_fwd_raw = df_fwd_raw.dropna(subset=(["Gasoline"]))
        df_fwd_raw = df_fwd_raw.fillna(method='ffill')
        df_fwd_raw = df_fwd_raw.fillna(method='backfill')
        df_fwd_raw = df_fwd_raw.round(2)
        # Rename Balance Month Index
        tmp_date = df_fwd_raw.index[0]
        df_fwd_raw = df_fwd_raw.rename(index={tmp_date: datetime.date(1, 1, 1)})
        # 2.3.3 Other Data
        # Product
        fwd_yield = config.nwe_com_yield_fwd  # Yield
        i_other_prod = ser_other_prod.loc[pub_date]  # Other Product
        # Crude
        crude_slate = {'Dated': -1}  # Slate
        i_crude_other = ser_other_crude.loc[pub_date]  # Other Crude
        # Freight
        i_freight = ser_freight.loc[pub_date]
        i_freight_mean = ser_freight_mean.loc[pub_date]
        # Gas Cost
        ser_ttf = df_gas_fwd[pub_date]
        ser_ttf = ser_ttf.dropna()

        # 2.3.4 Calculate Component
        df_comp_fwd = cms.get_margin_fwd(df_fwd_raw, ser_ttf, fwd_yield, crude_slate, i_crude_other, i_other_prod,
                                         i_freight, i_freight_mean)
        # print(df_comp_fwd)
        # sys.exit()

        # 2.3.5 Save Margin Component for each day
        pkl_name = path_fwd_daily + 'NWEComplexMarginComponentData.pickle'
        csv_name = path_fwd_daily + 'NWEComplexMarginComponentData.csv'
        df_comp_fwd.to_pickle(pkl_name)
        df_comp_fwd.to_csv(csv_name)

        # 2.3.6 Margin With GasCost
        ser_margin_fwd = df_comp_fwd.sum(axis=1)
        ser_margin_fwd = ser_margin_fwd.round(2)
        ser_margin_fwd.name = pub_date
        if pub_date in df_com_abs.columns:
            df_com_abs = df_com_abs.drop(columns=pub_date)
        df_com_abs = pd.concat([df_com_abs, ser_margin_fwd], axis=1, sort=False)
        df_com_abs = df_com_abs.round(2).sort_index(axis=1)

        # Next Iteration
        print(f'NWE Forward Margin: {pub_date}')
        pub_date = ms.get_next_trading_day(pub_date)
        # 2.4 Save Margin
    pkl_name = path_fwd + "NWEComplexForwardMargin-abs.pkl"
    csv_name = path_fwd + "NWEComplexForwardMargin-abs.csv"
    df_com_abs.to_pickle(pkl_name)
    df_com_abs.to_csv(csv_name)
    # For other project
    # csv_name = path_ali + 'NWEComplexForwardMargin.csv'
    # df_com_abs.to_csv(csv_name)
    csv_name = path_hani + 'NWEComplexForwardMargin-abs.csv'
    df_com_abs.to_csv(csv_name)
    df_com_abs_nwe = df_com_abs

    # 2. NWE Hyrdoskim WTI Forward Margin
    # 2.1 Read Forward Margin
    pkl_name = path_fwd + "HydroskimWTIComplexForwardMargin-abs.pkl"
    pub_date = datetime.date(2015, 1, 2)
    if os.path.exists(pkl_name):
        df_com_abs = pd.read_pickle(pkl_name)
        pub_date = df_com_abs.columns[-1]
    else:
        df_com_abs = pd.DataFrame([])
        pub_date = datetime.date(2015, 1, 2)

    # 2.2 Other Data
    # Crude
    ser_dfl = 0
    # ser_dfl = df_raw['Dated'] - df_raw['MedStrip']
    # ser_dfl = -df_comp_com['DFL']
    ser_diff = df_comp_com['Crude Diffs']
    ser_other_crude = ser_dfl + ser_diff
    ser_freight = df_comp_com['Freight']
    ser_freight_mean = ser_freight.rolling(200).mean()
    ser_freight_mean.name = 'Mean'
    # Product
    prod_yield = config.nwe_hydroskim_wti_yield
    list_other_prod = ['LSSR']
    ser_other_prod = df_comp_com.loc[:, list_other_prod].sum(axis=1)

    # 2.3. Calculation
    # Deciding Date
    deciding_date = datetime.date.today()
    if ms.is_bank_holiday(deciding_date):
        deciding_date = ms.get_previous_trading_day(deciding_date)
    # pub_date = datetime.date(2021, 9, 8)
    # deciding_date = get_next_trading_day(pub_date)
    while pub_date < deciding_date:
        # 2.3.1 Read Data
        path_fwd_daily = path_fwd + str(pub_date.year) + "/" + pub_date.strftime('%Y-%m-%d') + "/"
        pkl_name = path_fwd_daily + "NWEForwardData.pkl"
        if os.path.exists(pkl_name):
            df_fwd_raw = pd.read_pickle(pkl_name)
            pkl_name = path_fwd_daily + "NWEForwardData.pkl"
            df_fwd_raw_nwe = pd.read_pickle(pkl_name)
        else:
            pub_date = ms.get_next_trading_day(pub_date)
            continue
        # 2.3.2 Data PreProcessing
        # Drop and Fill NA
        df_fwd_raw = df_fwd_raw.dropna(subset=(["Jet"]))
        prod_list = ['Propane', 'Gasoline', 'LSFO', 'HSFO']
        for i_prod in prod_list:
            if i_prod in ['LSFO', 'HSFO']:
                prod_nwe = 'HSFO'
            if i_prod in ['Propane']:
                prod_nwe = 'Gasoline'
            else:
                prod_nwe = i_prod
            avg_diff = (df_fwd_raw_nwe[prod_nwe] - df_fwd_raw[i_prod]).mean()
            for ind in df_fwd_raw.index:
                value_med = df_fwd_raw.loc[ind, i_prod]
                value_nwe = df_fwd_raw_nwe.loc[ind, prod_nwe]

                if pd.isna(value_med) and (not pd.isna(value_nwe)):
                    df_fwd_raw.loc[ind, i_prod] = value_nwe - avg_diff
                else:
                    pass
        df_fwd_raw = df_fwd_raw.fillna(method='ffill')
        df_fwd_raw = df_fwd_raw.fillna(method='backfill')
        df_fwd_raw = df_fwd_raw.round(2)

        # Rename Balance Month Index
        tmp_date = df_fwd_raw.index[0]
        df_fwd_raw = df_fwd_raw.rename(index={tmp_date: datetime.date(1, 1, 1)})
        # 2.3.3 Other Data
        # Product
        fwd_yield = config.nwe_hydroskim_wti_yield  # Yield
        i_other_prod = ser_other_prod.loc[pub_date]  # Other Product
        # Crude
        crude_slate = {'Dated': -1}  # Slate
        i_crude_other = ser_other_crude.loc[pub_date]  # Other Crude
        # Freight
        i_freight = ser_freight.loc[pub_date]
        i_freight_mean = ser_freight_mean.loc[pub_date]
        # Gas Cost
        ser_ttf = df_gas_fwd[pub_date]
        ser_ttf = ser_ttf.dropna()

        # 2.3.4 Calculate Component
        df_comp_fwd = cms.get_margin_fwd(df_fwd_raw, ser_ttf, fwd_yield, crude_slate, i_crude_other, i_other_prod,
                                         i_freight, i_freight_mean)
        df_comp_fwd = df_comp_fwd.drop(['Freight', 'Product Other', 'GasCost'], axis=1)

        # 2.3.5 Save Margin Component for each day
        pkl_name = path_fwd_daily + 'HydroskimWTIComplexMarginComponentData.pickle'
        csv_name = path_fwd_daily + 'HydroskimWTIComplexMarginComponentData.csv'
        df_comp_fwd.to_pickle(pkl_name)
        df_comp_fwd.to_csv(csv_name)

        # 2.3.6 Margin With GasCost
        ser_margin_fwd = df_comp_fwd.sum(axis=1)
        ser_margin_fwd = ser_margin_fwd.round(2)
        ser_margin_fwd.name = pub_date
        if pub_date in df_com_abs.columns:
            df_com_abs = df_com_abs.drop(columns=pub_date)
        df_com_abs = pd.concat([df_com_abs, ser_margin_fwd], axis=1, sort=False)
        df_com_abs = df_com_abs.round(2).sort_index(axis=1)

        # Next Iteration
        print(f'HydroskimWTI Forward Margin: {pub_date}')
        pub_date = ms.get_next_trading_day(pub_date)
        # 2.4 Save Margin
    pkl_name = path_fwd + "HydroskimWTIComplexForwardMargin-abs.pkl"
    csv_name = path_fwd + "HydroskimWTIComplexForwardMargin-abs.csv"
    df_com_abs.to_pickle(pkl_name)
    df_com_abs.to_csv(csv_name)
    # For other project
    # csv_name = path_ali + 'HyrdoskimWTIComplexForwardMargin.csv'
    # df_com_abs.to_csv(csv_name)
    csv_name = path_hani + 'HydroskimWTIComplexForwardMargin-abs.csv'
    df_com_abs.to_csv(csv_name)
    df_hydro_abs_nwe = df_com_abs

    # 2. NWE Topping WTI Forward Margin
    # 2.1 Read Forward Margin
    pkl_name = path_fwd + "ToppingWTIComplexForwardMargin-abs.pkl"
    pub_date = datetime.date(2015, 1, 2)
    if os.path.exists(pkl_name):
        df_com_abs = pd.read_pickle(pkl_name)
        pub_date = df_com_abs.columns[-1]
    else:
        df_com_abs = pd.DataFrame([])
        pub_date = datetime.date(2015, 1, 2)

    # 2.2 Other Data
    # Crude
    ser_dfl = 0
    # ser_dfl = df_raw['Dated'] - df_raw['MedStrip']
    # ser_dfl = -df_comp_com['DFL']
    ser_diff = df_comp_com['Crude Diffs']
    ser_other_crude = ser_dfl + ser_diff
    ser_freight = df_comp_com['Freight']
    ser_freight_mean = ser_freight.rolling(200).mean()
    ser_freight_mean.name = 'Mean'
    # Product
    prod_yield = config.nwe_topping_wti_yield
    list_other_prod = ['LSSR']
    ser_other_prod = df_comp_com.loc[:, list_other_prod].sum(axis=1)

    # 2.3. Calculation
    # Deciding Date
    deciding_date = datetime.date.today()
    if ms.is_bank_holiday(deciding_date):
        deciding_date = ms.get_previous_trading_day(deciding_date)
    # pub_date = datetime.date(2021, 9, 8)
    # deciding_date = get_next_trading_day(pub_date)
    while pub_date < deciding_date:
        # 2.3.1 Read Data
        path_fwd_daily = path_fwd + str(pub_date.year) + "/" + pub_date.strftime('%Y-%m-%d') + "/"
        pkl_name = path_fwd_daily + "NWEForwardData.pkl"
        if os.path.exists(pkl_name):
            df_fwd_raw = pd.read_pickle(pkl_name)
            pkl_name = path_fwd_daily + "NWEForwardData.pkl"
            df_fwd_raw_nwe = pd.read_pickle(pkl_name)
        else:
            pub_date = ms.get_next_trading_day(pub_date)
            continue
        # 2.3.2 Data PreProcessing
        # Drop and Fill NA
        df_fwd_raw = df_fwd_raw.dropna(subset=(["Jet"]))
        prod_list = ['Propane', 'Gasoline', 'LSFO', 'HSFO']
        for i_prod in prod_list:
            if i_prod in ['LSFO', 'HSFO']:
                prod_nwe = 'HSFO'
            if i_prod in ['Propane']:
                prod_nwe = 'Gasoline'
            else:
                prod_nwe = i_prod
            avg_diff = (df_fwd_raw_nwe[prod_nwe] - df_fwd_raw[i_prod]).mean()
            for ind in df_fwd_raw.index:
                value_med = df_fwd_raw.loc[ind, i_prod]
                value_nwe = df_fwd_raw_nwe.loc[ind, prod_nwe]

                if pd.isna(value_med) and (not pd.isna(value_nwe)):
                    df_fwd_raw.loc[ind, i_prod] = value_nwe - avg_diff
                else:
                    pass
        df_fwd_raw = df_fwd_raw.fillna(method='ffill')
        df_fwd_raw = df_fwd_raw.fillna(method='backfill')
        df_fwd_raw = df_fwd_raw.round(2)

        # Rename Balance Month Index
        tmp_date = df_fwd_raw.index[0]
        df_fwd_raw = df_fwd_raw.rename(index={tmp_date: datetime.date(1, 1, 1)})
        # 2.3.3 Other Data
        # Product
        fwd_yield = config.nwe_topping_wti_yield  # Yield
        i_other_prod = ser_other_prod.loc[pub_date]  # Other Product
        # Crude
        crude_slate = {'Dated': -1}  # Slate
        i_crude_other = ser_other_crude.loc[pub_date]  # Other Crude
        # Freight
        i_freight = ser_freight.loc[pub_date]
        i_freight_mean = ser_freight_mean.loc[pub_date]
        # Gas Cost
        ser_ttf = df_gas_fwd[pub_date]
        ser_ttf = ser_ttf.dropna()

        # 2.3.4 Calculate Component
        df_comp_fwd = cms.get_margin_fwd(df_fwd_raw, ser_ttf, fwd_yield, crude_slate, i_crude_other, i_other_prod,
                                         i_freight, i_freight_mean)
        df_comp_fwd = df_comp_fwd.drop(['Freight', 'Product Other', 'GasCost'], axis=1)

        # 2.3.5 Save Margin Component for each day
        pkl_name = path_fwd_daily + 'ToppingWTIComplexMarginComponentData.pickle'
        csv_name = path_fwd_daily + 'ToppingWTIComplexMarginComponentData.csv'
        df_comp_fwd.to_pickle(pkl_name)
        df_comp_fwd.to_csv(csv_name)

        # 2.3.6 Margin With GasCost
        ser_margin_fwd = df_comp_fwd.sum(axis=1)
        ser_margin_fwd = ser_margin_fwd.round(2)
        ser_margin_fwd.name = pub_date
        if pub_date in df_com_abs.columns:
            df_com_abs = df_com_abs.drop(columns=pub_date)
        df_com_abs = pd.concat([df_com_abs, ser_margin_fwd], axis=1, sort=False)
        df_com_abs = df_com_abs.round(2).sort_index(axis=1)

        # Next Iteration
        print(f'ToppingWTI Forward Margin: {pub_date}')
        pub_date = ms.get_next_trading_day(pub_date)
        # 2.4 Save Margin
    pkl_name = path_fwd + "ToppingWTIComplexForwardMargin-abs.pkl"
    csv_name = path_fwd + "ToppingWTIComplexForwardMargin-abs.csv"
    df_com_abs.to_pickle(pkl_name)
    df_com_abs.to_csv(csv_name)
    # For other project
    # csv_name = path_ali + 'ToppingWTIComplexForwardMargin.csv'
    # df_com_abs.to_csv(csv_name)
    csv_name = path_hani + 'ToppingWTIComplexForwardMargin-abs.csv'
    df_com_abs.to_csv(csv_name)
    df_top_abs_nwe = df_com_abs

    ############################
    #### Med Margin Data######
    ############################
    print('-' * 20)
    print('Med Margin')
    print('-' * 20)
    # 1. Med Spot Margin
    df_nwe_raw = df_raw
    pkl_name = path + 'MedRawData.pickle'
    df_raw = pd.read_pickle(pkl_name)
    df_raw = df_raw.loc[start_date:]
    df_raw['Other'] = df_nwe_raw['HSVGO']
    df_raw = df_raw.dropna(subset=['Jet'], how='any', axis=0)
    df_raw = df_raw.fillna(method='backfill')

    ser_gas_spot = ser_gas_spot.loc[df_raw.index]
    df_raw = pd.concat([df_raw, ser_gas_spot], axis=1)

    # 1.1 Med Complex Margin
    prod_yield = config.med_com_yield
    crude_slate = config.med_crud_basket
    crude_slate_new = config.med_crud_basket_new
    # Component
    df_comp_com = cms.get_margin_comp(df_raw, prod_yield, crude_slate, crude_slate_new)
    cms.save_component_margin(df_comp_com, 'MedComplex')

    # 1.2 Med Simple Margin
    prod_yield = config.med_sim_yield
    crude_slate = config.med_crud_basket
    crude_slate_new = config.med_crud_basket_new
    df_comp_sim = cms.get_margin_comp(df_raw, prod_yield, crude_slate, crude_slate_new)
    cms.save_component_margin(df_comp_sim, 'MedSimple')

    # 1.3 Save Complex and Simple Margin as DataFrame
    # Without GasCost
    df_comp_com_tmp = df_comp_com.drop(['GasCost'], axis=1)
    ser_com = df_comp_com_tmp.sum(axis=1)
    ser_com.name = 'Med Complex'
    df_comp_sim_tmp = df_comp_sim.drop(['GasCost'], axis=1)
    ser_sim = df_comp_sim_tmp.sum(axis=1)
    ser_sim.name = 'Med Simple'
    df_margin = pd.concat([ser_com, ser_sim], axis=1)

    pkl_name = path + 'MedMarginDataNoGasCost.pickle'
    csv_name = path + 'MedMarginDataNoGasCost.csv'
    df_margin.to_pickle(pkl_name)
    df_margin.to_csv(csv_name)

    # With GasCost
    ser_com = df_comp_com.sum(axis=1)
    ser_com.name = 'Med Complex'
    ser_sim = df_comp_sim.sum(axis=1)
    ser_sim.name = 'Med Simple'
    df_margin = pd.concat([ser_com, ser_sim], axis=1)

    pkl_name = path + 'MedMarginData.pickle'
    csv_name = path + 'MedMarginData.csv'
    df_margin.to_pickle(pkl_name)
    df_margin.to_csv(csv_name)
    df_margin_Med = df_margin
    # For other project
    # csv_name = path_ali + 'MedMarginData.csv'
    # df_margin.to_csv(csv_name)
    csv_name = path_hani + 'MedMarginData.csv'
    df_margin.to_csv(csv_name)

    # 2. Med Forward Margin
    # 2.1 Read Forward Margin
    pkl_name = path_fwd + "MedComplexForwardMargin-abs.pkl"
    pub_date = datetime.date(2015, 1, 2)
    if os.path.exists(pkl_name):
        df_com_abs = pd.read_pickle(pkl_name)
        pub_date = df_com_abs.columns[-1]
    else:
        df_com_abs = pd.DataFrame([])
        pub_date = datetime.date(2015, 1, 2)

    # 2.2 Other Data
    # Crude
    ser_dfl = 0
    # ser_dfl = df_raw['Dated'] - df_raw['MedStrip']
    # ser_dfl = -df_comp_com['DFL']
    ser_diff = df_comp_com['Crude Diffs']
    ser_other_crude = ser_dfl + ser_diff
    ser_freight = df_comp_com['Freight']
    ser_freight_mean = ser_freight.rolling(200).mean()
    ser_freight_mean.name = 'Mean'
    # Product
    prod_yield = config.nwe_com_yield_fwd
    list_other_prod = ['HSSR', 'Other']
    ser_other_prod = df_comp_com.loc[:, list_other_prod].sum(axis=1)

    # 2.3. Calculation
    # Deciding Date
    deciding_date = datetime.date.today()
    if ms.is_bank_holiday(deciding_date):
        deciding_date = ms.get_previous_trading_day(deciding_date)
    # pub_date = datetime.date(2021, 9, 8)
    # deciding_date = get_next_trading_day(pub_date)
    while pub_date < deciding_date:
        # 2.3.1 Read Data
        path_fwd_daily = path_fwd + str(pub_date.year) + "/" + pub_date.strftime('%Y-%m-%d') + "/"
        pkl_name = path_fwd_daily + "MedForwardData.pkl"
        if os.path.exists(pkl_name):
            df_fwd_raw = pd.read_pickle(pkl_name)
            pkl_name = path_fwd_daily + "NWEForwardData.pkl"
            df_fwd_raw_nwe = pd.read_pickle(pkl_name)
        else:
            pub_date = ms.get_next_trading_day(pub_date)
            continue
        # 2.3.2 Data PreProcessing
        # Drop and Fill NA
        df_fwd_raw = df_fwd_raw.dropna(subset=(["Jet"]))
        prod_list = ['Propane', 'Gasoline', 'LSFO', 'HSFO']
        for i_prod in prod_list:
            if i_prod in ['LSFO', 'HSFO']:
                prod_nwe = 'HSFO'
            if i_prod in ['Propane']:
                prod_nwe = 'Gasoline'
            else:
                prod_nwe = i_prod
            avg_diff = (df_fwd_raw_nwe[prod_nwe] - df_fwd_raw[i_prod]).mean()
            for ind in df_fwd_raw.index:
                value_med = df_fwd_raw.loc[ind, i_prod]
                value_nwe = df_fwd_raw_nwe.loc[ind, prod_nwe]

                if pd.isna(value_med) and (not pd.isna(value_nwe)):
                    df_fwd_raw.loc[ind, i_prod] = value_nwe - avg_diff
                else:
                    pass
        df_fwd_raw = df_fwd_raw.fillna(method='ffill')
        df_fwd_raw = df_fwd_raw.fillna(method='backfill')
        df_fwd_raw = df_fwd_raw.round(2)

        # Rename Balance Month Index
        tmp_date = df_fwd_raw.index[0]
        df_fwd_raw = df_fwd_raw.rename(index={tmp_date: datetime.date(1, 1, 1)})
        # 2.3.3 Other Data
        # Product
        fwd_yield = config.med_com_yield_fwd  # Yield
        i_other_prod = ser_other_prod.loc[pub_date]  # Other Product
        # Crude
        crude_slate = {'MedDated': -1}  # Slate
        i_crude_other = ser_other_crude.loc[pub_date]  # Other Crude
        # Freight
        i_freight = ser_freight.loc[pub_date]
        i_freight_mean = ser_freight_mean.loc[pub_date]
        # Gas Cost
        ser_ttf = df_gas_fwd[pub_date]
        ser_ttf = ser_ttf.dropna()

        # 2.3.4 Calculate Component
        df_comp_fwd = cms.get_margin_fwd(df_fwd_raw, ser_ttf, fwd_yield, crude_slate, i_crude_other, i_other_prod,
                                         i_freight, i_freight_mean)

        # 2.3.5 Save Margin Component for each day
        pkl_name = path_fwd_daily + 'MedComplexMarginComponentData.pickle'
        csv_name = path_fwd_daily + 'MedComplexMarginComponentData.csv'
        df_comp_fwd.to_pickle(pkl_name)
        df_comp_fwd.to_csv(csv_name)

        # 2.3.6 Margin With GasCost
        ser_margin_fwd = df_comp_fwd.sum(axis=1)
        ser_margin_fwd = ser_margin_fwd.round(2)
        ser_margin_fwd.name = pub_date
        if pub_date in df_com_abs.columns:
            df_com_abs = df_com_abs.drop(columns=pub_date)
        df_com_abs = pd.concat([df_com_abs, ser_margin_fwd], axis=1, sort=False)
        df_com_abs = df_com_abs.round(2).sort_index(axis=1)

        # Next Iteration
        print(f'Med Forward Margin: {pub_date}')
        pub_date = ms.get_next_trading_day(pub_date)
        # 2.4 Save Margin
    pkl_name = path_fwd + "MedComplexForwardMargin-abs.pkl"
    csv_name = path_fwd + "MedComplexForwardMargin-abs.csv"
    df_com_abs.to_pickle(pkl_name)
    df_com_abs.to_csv(csv_name)
    # For other project
    # csv_name = path_ali + 'MedComplexForwardMargin.csv'
    # df_com_abs.to_csv(csv_name)
    csv_name = path_hani + 'MedComplexForwardMargin-abs.csv'
    df_com_abs.to_csv(csv_name)

    #Fix for getting the forward curves in the batchuploader (LOIC)

    df_com_abs_med = df_com_abs
    forwards = transform_forwards_to_long_format([df_com_abs_nwe, df_hydro_abs_nwe, df_top_abs_nwe, df_com_abs_med])
    spot = transform_spot_margins([df_margin_NWE, df_margin_Med])
    monthly_balance = transform_complex_margins([df_com_abs_nwe, df_hydro_abs_nwe, df_top_abs_nwe, df_com_abs_med])
    frames = [forwards, spot, monthly_balance]
    result = pd.concat(frames)
    now = pd.Timestamp.now().floor('S')
    if config.env == 'UAT':
        root = Path(r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\BatchUploader\UAT")
        batch_upload_path = f"Upload_OIL_EuroMargin-{now:%Y%m%d%H%M%S}.csv"
        a_year_ago = pd.Timestamp.now() - pd.DateOffset(years=1)
        result[result.ddate > a_year_ago].to_csv(root / batch_upload_path, index=0)
    else:
        root = Path(r"\\petroineos.local\dfs\Department Shared Folders\~Analysis Department\ApplicationFolder\BatchUploader\PROD")
        batch_upload_path = f"Upload_OIL_EuroMargin-{now:%Y%m%d%H%M%S}.csv"
        a_year_ago = pd.Timestamp.now() - pd.DateOffset(years=1)
        result[result.ddate > a_year_ago].to_csv(root / batch_upload_path, index=0)

def transform_forwards_to_long_format(dfs):
    stacked_dfs = [df.iloc[1:].stack() for df in dfs]
    data = pd.concat(stacked_dfs, axis=1).reset_index()
    data.columns = ['pdate', 'ddate', 'nwecomplex', 'nwehydroskim', 'nwetopping', 'medcomplex'] 
    data['nwesimple'] = np.nan
    data['medsimple'] = np.nan
    data['type'] = 2
    return data

def transform_spot_margins(dfs):
    simple_dfs = [df for df in dfs]
    data2 = pd.concat(simple_dfs, axis=1).reset_index()
    data2.columns = ['pdate', 'nwecomplex','nwehydroskim', 'nwetopping', 'nwesimple', 'medcomplex', 'medsimple']
    data2['type'] = 0
    data2['ddate'] = data2['pdate']
    return data2

def transform_complex_margins(dfs):
    complex_dfs = [df.iloc[0] for df in dfs]
    data3 = pd.concat(complex_dfs, axis=1).reset_index()
    data3.columns = ['pdate', 'nwecomplex', 'nwehydroskim', 'nwetopping', 'medcomplex']
    data3['nwesimple'] = np.nan
    data3['medsimple'] = np.nan
    data3['type'] = 1
    data3['ddate'] = data3['pdate']
    return data3

def main():
    # Calculate
    calc_margin()
    # calc_med_margin()


if __name__ == "__main__":
    print("Example")
    try:
        start = time.time()
        main()
        end = time.time()
        print('Task runs %0.2f seconds.' % (end - start))
    except KeyboardInterrupt:
        print("Ctrl+C pressed. Stopping...")