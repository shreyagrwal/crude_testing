from exchangelib import DELEGATE, Account, Credentials, Message, Mailbox, HTMLBody, Configuration, FileAttachment
import os
import re
import email
# import ag_encryption as ae
   
def df2table(df, df_color, title=None, thres = 0):
    
    if df_color is not None:            
        no_color = False
    else:
        no_color = True
    
    df_table = '''
    <table border="2" cellpadding=3 style="width:1200">
        {caption}
        {header}
        {body}
    </table>
    '''
    table_caption = ''
    table_header = ''
    table_body = ''
    
    #Table title
    table_cap = '''
        <caption style="text-align:left">
            <em><b>
            <p style="font-family:Calibri;font-size:14pt">{cell}</p>
            </b></em>
        </caption>
    '''
    if title is not None:
        table_caption = table_cap.format(cell = str(title))
    else:
        table_caption = ''
        
    #Table header
    table_header = '''
        <tr>
            {content}
        </tr>        
    '''
    
    content = ''
    table_header_col = '''
            <th align="center">
                <p style="font-family:Calibri;font-size:14pt">{cell}</p>
            </th>\n
    '''
    if df.index.name is not None:
        content += table_header_col.format(cell=str(df.index.name))
    else:
        content += table_header_col.format(cell='')

    for i_col in df.columns:
        content += table_header_col.format(cell=str(i_col))
        
    table_header = table_header.format(content = content)
    
    #Table Body
    table_body = ''
    table_row = '''
        <tr>
            {content}
        </tr>        
    '''
    # const textColor = l < 35 ? '#FFF' : '#000';
    # table += '<td style="background: hsl(200, 100%, ' + l + '%); color: ' + textColor + '">' + value.toFixed(2) + '</td>';
    color1 = (33, 102, 172)
    color2 = (247, 247, 247)
    color3 = (178, 24, 43)
    
    table_cell = '''
            <td bgcolor={bgd_color}  align="center">
                <p style="font-family:Calibri;font-size:14pt">{cell}</p>
            </td>\n
            '''
    # table_cell_neg = '<td style="background: hsl(10, 100%, {bgd_color}%)" align="center">{cell}</td>'
    # table_cell = r'<td align="center">{cell}</td>'
    for ind, row in df.iterrows():
        row_content = ''
        #Index
        color = '#' + format(color2[0], 'X') + format(color2[1], 'X') + format(color2[2], 'X')
        row_content += table_cell.format(bgd_color = color, cell=str(ind))
        
        for ind_row, item in row.items():
            if no_color == True:
                color = '#FFF'
            else:
                item_value = df_color.at[ind, ind_row]
                
                if item_value > 0:
                    color_r = int(color2[0] - (color2[0] - color1[0]) * (item_value/df_color.max().max()))
                    color_g = int(color2[1] - (color2[1] - color1[1]) * (item_value/df_color.max().max()))
                    color_b = int(color2[2] - (color2[2] - color1[2]) * (item_value/df_color.max().max()))
                else:
                    item_value = abs(item_value)
                    color_r = int(color2[0] - (color2[0] - color3[0]) * (item_value/abs(df_color.min().min())))
                    color_g = int(color2[1] - (color2[1] - color3[1]) * (item_value/abs(df_color.min().min())))
                    color_b = int(color2[2] - (color2[2] - color3[2]) * (item_value/abs(df_color.min().min())))
                
                color = '#' + format(color_r, 'X') + format(color_g, 'X') + format(color_b, 'X')
            row_content += table_cell.format(bgd_color=color, cell=str(item))
        table_body += table_row.format(content=row_content)  
        
    df_table = df_table.format(caption=table_caption, header=table_header, body=table_body)
    return df_table

class MyEmailBody:
    def __init__(self):
        self.__body = ''
    
    @property
    def body(self):
        email_body = r'''
            <body>
                {body}
            </body>
        '''
        email_body = email_body.format(body=self.__body)
        return  email_body
    
    def add_raw(self, content):
        self.__body += content
        
    def add_heading(self, content, level, head_id=""):
        heading = r'<h{level} id="{id}">{content}</h{level}>'.format(level=str(level), id = head_id, content=str(content))
        self.__body += heading
    
    def add_image(self, img_name):
        images = '''
        <br />
        <img src={img_name} alt="some_text">
        '''
        self.__body += images.format(img_name=img_name)
        
    def add_table(self, df, df_color, title=None, thres = 0):
        if df_color is not None:            
            no_color = False
        else:
            no_color = True
        # print(df)
        # print(df_color)
        
        df_table = r'''
                <table border="2" cellpadding=3 style="width:600">
                    {caption}
                    {header}
                    {body}
                </table>
        '''
        table_caption = ''
        table_header = ''
        table_body = ''
        
        #Table title
        if title is not None:
            table_caption = r'<caption style="text-align:left"><em><b>{table_title}</b></em></caption>'.format(table_title = str(title))
        else:
            table_caption = ''
            
        #Table header
        table_header = r'''
            <tr>
                {content}
            </tr>        
        '''
        content = ''
        if df.index.name is not None:
            content += r'<th>{header}</th>'.format(header=str(df.index.name))
        else:
            content += r'<th>{header}</th>'.format(header='')

        for i_col in df.columns:
            content += r'<th>{header}</th>'.format(header=str(i_col))
        table_header = table_header.format(content = content)
        
        #Table Body
        table_body = ''
        table_row = r'''
            <tr>
                {content}
            </tr>        
        '''
        # const textColor = l < 35 ? '#FFF' : '#000';
    
        # table += '<td style="background: hsl(200, 100%, ' + l + '%); color: ' + textColor + '">' + value.toFixed(2) + '</td>';
        color1 = (33, 102, 172)
        color2 = (247, 247, 247)
        color3 = (178, 24, 43)
        
        table_cell = '<td bgcolor={bgd_color}  align="center">{cell}</td>'
        # table_cell_neg = '<td style="background: hsl(10, 100%, {bgd_color}%)" align="center">{cell}</td>'
        # table_cell = r'<td align="center">{cell}</td>'
        for ind, row in df.iterrows():
            row_content = ''
            #Index
            color = '#' + format(color2[0], 'X') + format(color2[1], 'X') + format(color2[2], 'X')
            row_content += table_cell.format(bgd_color = color, cell=str(ind))
            
            for ind_row, item in row.iteritems():
                if no_color == True:
                    color = '#FFF'
                else:
                    item_value = df_color.at[ind, ind_row]
                    # item_value = 0
                    # print(item_value)
                    # print('*'*40)
                    # print(item_value)
                    # print(int(item_value/3000*100))
                    # item_value = int(re.search('(.*?)', item).group(1))
                    
                    if item_value > 0:
                        color_r = int(color2[0] - (color2[0] - color1[0]) * (item_value/df_color.max().max()))
                        color_g = int(color2[1] - (color2[1] - color1[1]) * (item_value/df_color.max().max()))
                        color_b = int(color2[2] - (color2[2] - color1[2]) * (item_value/df_color.max().max()))
                    else:
                        item_value = abs(item_value)
                        color_r = int(color2[0] - (color2[0] - color3[0]) * (item_value/abs(df_color.min().min())))
                        color_g = int(color2[1] - (color2[1] - color3[1]) * (item_value/abs(df_color.min().min())))
                        color_b = int(color2[2] - (color2[2] - color3[2]) * (item_value/abs(df_color.min().min())))
                    
                    color = '#' + format(color_r, 'X') + format(color_g, 'X') + format(color_b, 'X')
                row_content += table_cell.format(bgd_color=color, cell=str(item))
            table_body += table_row.format(content=row_content)    
        
        self.__body += df_table.format(caption=table_caption, header=table_header, body=table_body)

class AgEmailHelper:
    creds = None
    server = None
    config = None
    account = None
    user = 'wenqiangliu'
    password = 'Ineos456'
    sender = 'wenqiang.liu@petroineos.com'
    # alert_sender = 'AnalysisDataAlert@petroineos.com'

    def __init__(self):
        p_suffix = "*" #input("Please insert additional password!")
        self.creds = Credentials(
            username='petroineos\\'+ self.user,
            # password=ae.decrypt(self.password)  # put down encrypted password here
            password=self.password + p_suffix # put down encrypted password here
        )
        self.server = 'mail.petroineos.com'
        self.config = Configuration(server=self.server, credentials=self.creds)
        self.account = Account(
            primary_smtp_address=self.sender,
            autodiscover=True,
            config = self.config,
            access_type=DELEGATE
        )

    def send_mail(self, from_, to_, subject, body):
        self.send_mail_with_embedded_images(self, from_, to_, subject, body)
    
    def send_mail_with_embedded_images(self, from_, to_, subject, body, images=None, auto=True):
        if auto:
            # print(from_, to_, subject, body)
            body = '<b>This report is sent on behalf of '+from_+'</b><br><br>' + body
        else:
            body = '<b><font color="red">Please add comments to this report and send to: <br>' + to_ + '</font></b><br><br><br>' + body

        m = Message(
            account=self.account,
            subject=subject,
            body=HTMLBody(body),
            to_recipients=[Mailbox(email_address=e) for e in to_.split(';')],
            cc_recipients=[Mailbox(email_address=e) for e in from_.split(';')]
        )

        if not auto:
            m.to_recipients = [Mailbox(email_address=e) for e in from_.split(';')]
            m.cc_recipients = None

        if images is not None:
            self.attach(images, m)

        m.send()

    def send_alert_email(self, to_, app, subject, body):

        #body = body + '<br><br>StackTrace:<br>' + traceback.print_exc()

        m = Message(
            account=self.account,
            subject=subject + " ("+app+")",
            body=HTMLBody(body),
            to_recipients=[Mailbox(email_address=e) for e in to_.split(';')],
            author=self.alert_sender,
        )

        m.send()


    def attach(self, images, m):
        for img in images:
            with open(img, 'rb') as fp:
                folder, img_filename = os.path.split(img)
                logoimg = FileAttachment(name=img_filename, content=fp.read(), is_inline=True)
                m.attach(logoimg)

    def scan(self, folder, emailDate):
        mail = self.login()
        mail.select(folder)
        result, data = mail.search(None, '(SENTSINCE {date})'.format(date=emailDate.strftime("%d-%b-%Y")))
        mail_ids = data[0]
        id_list = mail_ids.split()
        return id_list

    def download_attachments(self, mailIds, folder):
        for num in mailIds[0].split():
            typ, data = mailIds.fetch(num, '(RFC822)')
            raw_email = data[0][1]
            # converts byte literal to string removing b''
            raw_email_string = raw_email.decode('utf-8')
            email_message = email.message_from_string(raw_email_string)
            # downloading attachments
            for part in email_message.walk():
                # this part comes from the snipped I don't understand yet...
                if part.get_content_maintype() == 'multipart':
                    continue
                if part.get('Content-Disposition') is None:
                    continue
                fileName = part.get_filename()
                if bool(fileName):
                    filePath = os.path.join(folder, fileName)
                    if not os.path.isfile(filePath):
                        fp = open(filePath, 'wb')
                        fp.write(part.get_payload(decode=True))
                        fp.close()
