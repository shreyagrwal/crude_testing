import datetime
import os
import pandas as pd
import sys
import time
#import win32com.client as win32

import matplotlib.pyplot as plt
import matplotlib.image as mpimg

from jinja2 import Environment, FileSystemLoader

from EmailSup import MyEmailBody, AgEmailHelper, df2table
from ag_email import ag_email_helper
from MarginSup import *

import config

my_width = 600
my_height = 329

def get_margin_table(df_margin):   
    # 1. Definitions
    # Margin

    # df_table = df_margin.iloc[[-1, -2, -6, -21, -63], :].copy()
    # df_table = df_margin.iloc[[-1, -2, -6, -21], :].copy()
    m_date = df_margin.index[-1]
    m_date_d = df_margin.index[-2]
    m_date_w = m_date - datetime.timedelta(days=7)
    if is_bank_holiday(m_date_w):
        m_date_w = get_previous_trading_day(m_date_w)  
    m_date_m = df_margin.index[-21]
    
    df_table = df_margin.loc[[m_date, m_date_d, m_date_w, m_date_m]].copy()
    # Historically margin
    ser_complex = df_margin.iloc[:, 0]
    ser_hydro = df_margin.iloc[:, 1]
    ser_top = df_margin.iloc[:, 2]
    ser_simple = df_margin.iloc[:, 3]
    df_com_his = format_margin(ser_complex) 
    df_hyd_his = format_margin(ser_hydro)
    df_top_his = format_margin(ser_top)
    df_sim_his = format_margin(ser_simple) 
    df_com_his = df_com_his.loc[:, 2015:2019]
    df_com_his = df_com_his.fillna(method='ffill')
    df_com_his = df_com_his.mean(axis=1)
    df_sim_his = df_sim_his.loc[:, 2015:2019]
    df_sim_his = df_sim_his.fillna(method='ffill')
    df_sim_his = df_sim_his.mean(axis=1)
    df_hyd_his = df_hyd_his.loc[:, 2015:2019]
    df_hyd_his = df_hyd_his.fillna(method='ffill')
    df_hyd_his = df_hyd_his.mean(axis=1)
    df_top_his = df_top_his.loc[:, 2015:2019]
    df_top_his = df_top_his.fillna(method='ffill')
    df_top_his = df_top_his.mean(axis=1)
    dates = datetime.date(1972, m_date.month, m_date.day)
    my_data = [df_com_his.loc[dates], df_hyd_his.loc[dates], df_top_his.loc[dates], df_sim_his.loc[dates]]
    df_table.loc['15-19 Avg'] = my_data
    
    df_table.loc['change d/d'] = df_table.loc[m_date] - df_table.loc[m_date_d]
    df_table.loc['change w/w'] = df_table.loc[m_date] - df_table.loc[m_date_w]
    df_table.loc['change m/m'] = df_table.loc[m_date] - df_table.loc[m_date_m]
    # df_table.loc['change 3m'] = df_table.loc[m_date] - df_table.loc[m_date_3m]
    df_table.loc['15-19 Avg diff'] = df_table.loc[m_date] - df_table.loc['15-19 Avg']
    
    inds = [m_date, m_date_d, 'change d/d', m_date_w, 'change w/w', 
                m_date_m, 'change m/m', '15-19 Avg', '15-19 Avg diff']
    
    df_table = df_table.reindex(index = inds)   
    inds = [ind.strftime('%d-%b-%y') if isinstance(ind, datetime.date) else ind  for ind in inds]
    df_table.index = inds
    df_table.columns = ['Complex', 'Hydroskim', 'Topping', 'Simple']
    df_table = df_table.T
    df_table = df_table.round(2)

    return df_table

def get_margin_table_med(df_margin):   
    # 1. Definitions
    # Margin
    
    # df_table = df_margin.iloc[[-1, -2, -6, -21, -63], :].copy()
    # df_table = df_margin.iloc[[-1, -2, -6, -21], :].copy()
    m_date = df_margin.index[-1]
    m_date_d = df_margin.index[-2]
    m_date_w = m_date - datetime.timedelta(days=7)
    if is_bank_holiday(m_date_w):
        m_date_w = get_previous_trading_day(m_date_w)  
    m_date_m = df_margin.index[-21]
    
    df_table = df_margin.loc[[m_date, m_date_d, m_date_w, m_date_m]].copy()
    
    # Historically margin
    ser_complex = df_margin.iloc[:, 0]
    ser_simple = df_margin.iloc[:, 1]
    df_com_his = format_margin(ser_complex) 
    df_sim_his = format_margin(ser_simple) 
    df_com_his = df_com_his.loc[:, 2015:2019]
    df_com_his = df_com_his.fillna(method='ffill')
    df_com_his = df_com_his.mean(axis=1)
    
    df_sim_his = df_sim_his.loc[:, 2015:2019]
    df_sim_his = df_sim_his.fillna(method='ffill')
    df_sim_his = df_sim_his.mean(axis=1)

    dates = datetime.date(1972, m_date.month, m_date.day)
    my_data = [df_com_his.loc[dates], df_sim_his.loc[dates]]
    df_table.loc['15-19 Avg'] = my_data
    
    df_table.loc['change d/d'] = df_table.loc[m_date] - df_table.loc[m_date_d]
    df_table.loc['change w/w'] = df_table.loc[m_date] - df_table.loc[m_date_w]
    df_table.loc['change m/m'] = df_table.loc[m_date] - df_table.loc[m_date_m]
    # df_table.loc['change 3m'] = df_table.loc[m_date] - df_table.loc[m_date_3m]
    df_table.loc['15-19 Avg diff'] = df_table.loc[m_date] - df_table.loc['15-19 Avg']
    
    inds = [m_date, m_date_d, 'change d/d', m_date_w, 'change w/w', 
                m_date_m, 'change m/m', '15-19 Avg', '15-19 Avg diff']
    
    df_table = df_table.reindex(index = inds)   
    inds = [ind.strftime('%d-%b-%y') if isinstance(ind, datetime.date) else ind  for ind in inds]
    df_table.index = inds
    df_table.columns = ['Complex', 'Simple']
    df_table = df_table.T
    df_table = df_table.round(2)

    return df_table
        
def get_cracks_table(df, region):

    m_date = df.index[-1]
    m_date_d = df.index[-2]
    m_date_w = m_date - datetime.timedelta(days=7)
    if is_bank_holiday(m_date_w):
        m_date_w = get_previous_trading_day(m_date_w)  
    m_date_m = df.index[-21]
    df_table = df.loc[[m_date, m_date_d, m_date_w, m_date_m]].copy()
    # m_date = df.index[-1]
    # m_date_d = df.index[-2]
    # m_date_w = df.index[-6]
    # m_date_m = df.index[-21]
    
    df_table.loc['change d/d'] = df_table.loc[m_date] - df_table.loc[m_date_d]
    df_table.loc['change w/w'] = df_table.loc[m_date] - df_table.loc[m_date_w]
    df_table.loc['change m/m'] = df_table.loc[m_date] - df_table.loc[m_date_m]

    df_table = df_table.round(2)
    if 'NWE' in region:
        com_yield = config.nwe_com_yield
        sim_yield = config.nwe_sim_yield
    elif 'Med' in region:
        com_yield = config.med_com_yield
        sim_yield = config.med_sim_yield
    else:
        raise ValueError('Bad Region')
        
    for col, item in df_table.iteritems():
        if col in com_yield.keys():
            df_table.loc['Complex Yield', col] = str(round(com_yield[col]*100)) + '%'
        else:
            df_table.loc['Complex Yield', col] = '0%'
            
        if col in sim_yield.keys():
            df_table.loc['Simple', col] = str(round(sim_yield[col]*100)) + '%'
        else:
            df_table.loc['Simple', col] = '0%'

    inds = ['Complex Yield', m_date, m_date_d, 'change d/d', m_date_w, 'change w/w', 
                m_date_m, 'change m/m']
    df_table = df_table.reindex(index = inds)  
    inds = [ind.strftime('%d-%b-%y') if isinstance(ind, datetime.date) else ind  for ind in inds]
    df_table.index = inds
    
    df_table = df_table.T

    return df_table
    
def get_crude_table(that_df_crude, that_df_com, that_region):
    # 1. Params
    df = that_df_crude.iloc[-500:, :]   
    df_com = that_df_com.iloc[-500:, :]
    
    # 2. Columns Selection
    if that_region == 'NWE':
        col_freight = 'NWEFreight'   
    elif that_region == 'Med':
        col_freight = 'MedFreight'
    else:
        raise ValueError('Bad Region')
        
    sub_cols = ['Dated', 'LMM', 'TAS', col_freight]
    df = df[sub_cols]
    sub_cols = ['Crude Diffs', 'GasCost']
    df_com = -df_com[sub_cols]
    # Merge Data
    df_table = pd.concat([df, df_com], axis=1)
    df_table = df_table.round(2)
    df_table.columns = ['Dated Brent', 'ICE Brent LMM (16:30)', 'ICE Brent Settlement (19:30)', 'Freight', 'Physical Basket Diffs Avg', 'Gas Cost']
    df_table['Freight'] = df_table['Freight']  / 7.5
    df_table['Dated Brent to LMM'] = df_table['Dated Brent'] - df_table['ICE Brent LMM (16:30)']
    
    # 3. Date Selection
    m_date = df.index[-1]
    m_date_d = df.index[-2]
    m_date_w = df.index[-6]
    m_date_m = df.index[-23]  
    df_table = df_table.loc[[m_date, m_date_d, m_date_w, m_date_m]]  

    # 4. Add Comparison
    df_table.loc['change d/d'] = df_table.loc[m_date] - df_table.loc[m_date_d]
    df_table.loc['change w/w'] = df_table.loc[m_date] - df_table.loc[m_date_w]
    df_table.loc['change m/m'] = df_table.loc[m_date] - df_table.loc[m_date_m]
    
    inds = [m_date, m_date_d, 'change d/d', m_date_w, 'change w/w', 
                m_date_m, 'change m/m']
    df_table = df_table.reindex(index = inds)  
    inds = [ind.strftime('%d-%b-%y') if isinstance(ind, datetime.date) else ind  for ind in inds]
    df_table.index = inds    
    
    # 5. Misc
    df_table = df_table.T
    df_table = df_table.round(2)
    
    return df_table

def cal_cracks_lmm(df):

    df = df.iloc[-50:, :]
    df = df.dropna(how='any')

    col_crude = 'LMM'  
    prod_list = ['Propane', 'Butane', 'Naphtha', 'Gasoline', 'Jet',	
                'ULSD',	'Gasoil', 'LSFO', 'HSFO', 'LSVGO', 'HSVGO', 'LSSR']
    ser_crude = df[col_crude]
    
    df_prod = df[prod_list]
    ser_conv = pd.Series([], dtype='float64')
    conversion_factor = config.conversion_factor
    for col in df_prod.columns:
        mult_prod = 0
        if col in conversion_factor:
            mult_prod = 1 / conversion_factor[col]
        else:
            raise ValueError('No Conversion Facotr for ' + col)
        ser_conv[col] = mult_prod    

    df_prod_bbl = df_prod.mul(ser_conv)
    df_cracks = df_prod_bbl.sub(ser_crude, axis=0)
    df_cracks = df_cracks.round(2)

    return df_cracks
    

def get_fwd_margin_table(df_fwd):
    
    m_date = df_fwd.columns[-1]
    m_date_d = df_fwd.columns[-2]
    m_date_w = df_fwd.columns[-5]
    # m_date_w = m_date - datetime.timedelta(days=7)
    # if is_bank_holiday(m_date_w):
        # m_date_w = get_previous_trading_day(m_date_w)  
    m_date_m = df_fwd.columns[-20]
    m_date_3m = df_fwd.columns[-63]
    m_date_6m = df_fwd.columns[-124]
    
    df_fwd = df_fwd[[m_date, m_date_d, m_date_w, m_date_m, m_date_3m, m_date_6m]].copy() 
    
    df_fwd = df_fwd.iloc[1:, :] #3 month, 1 month, 1 week, Last day
    df_fwd = df_fwd.dropna(how='all')
    df_fwd = df_fwd.dropna(how='any')
    df_fwd = df_fwd.sort_index(axis=1, ascending=False)
    df_fwd = df_fwd.iloc[:11, :]
    
    today = df_fwd.columns[-1]
    df_fwd['change d/d'] = df_fwd[m_date] - df_fwd[m_date_d]
    df_fwd['change w/w'] = df_fwd[m_date] - df_fwd[m_date_w]
    df_fwd['change m/m'] = df_fwd[m_date] - df_fwd[m_date_m]
    df_fwd['change 3m'] = df_fwd[m_date] - df_fwd[m_date_3m]
    df_fwd['change 6m'] = df_fwd[m_date] - df_fwd[m_date_6m]
    
    my_cols = [m_date, m_date_d, 'change d/d', m_date_w, 'change w/w', 
                m_date_m, 'change m/m', m_date_3m, 'change 3m', m_date_6m, 'change 6m']  
    df_fwd = df_fwd.reindex(columns = my_cols)   
    my_cols = [ind.strftime('%d-%b-%y') if isinstance(ind, datetime.date) else ind  for ind in my_cols]
    df_fwd.columns = my_cols
    
    if df_fwd.index[0].month == today.month:
        df_fwd = df_fwd.rename(index={df_fwd.index[0]:'Bal '+df_fwd.index[0].month})
    
    my_index = [ind.strftime('%b-%y') for ind in df_fwd.index]
    df_fwd.index = my_index
    
    df_fwd = df_fwd.round(2)

    return df_fwd

def get_recv_string():
    # Email Receiver
    with open('dist_list.txt', 'r') as f:
        recv_list = f.readlines()
    email_recv = []
    recv_string = ''
    for recv_line in recv_list:
        recv_line_list = recv_line.split(';')
        for i_recv in recv_line_list:
            i_recv = i_recv.strip()
            email_recv.append(i_recv)
            if len(i_recv) > 0:
                recv_string =  recv_string + i_recv + '; '    
    return ';'.join(email_recv).replace(';;;;;',';').replace(';;;;',';').replace(';;;',';').replace(';;',';')
    
def send_margin():
    today_date = datetime.date.today()
    
    path = config.path_margin
    #path_ttf = config.path_margin + 'GasCost\\'
    path_hani = config.path_margin_hani
    path_fwd = config.path_margin_fwd
    chart_path = config.chart_path
    crk_chart_path = config.chart_path + 'Cracks\\'
 
    e_subject = 'European Benchmark Refining Margins Report - ' + str(today_date)
    ## 1. Chart List
    img_list = []
    # NWE Spot Margin Chart
    fig_name = chart_path + 'NWEComplexMarginChart.png'
    img_list.append(fig_name) 
    # NWE Hydroskim Spot Margin Chart
    fig_name = chart_path + 'NWEHydroskimMarginChart.png'
    img_list.append(fig_name) 
    # NWE Topping Spot Margin Chart
    fig_name = chart_path + 'NWEToppingMarginChart.png'
    img_list.append(fig_name)    
    # Med Spot Margin Chart
    fig_name = chart_path + 'MedComplexMarginChart.png'
    img_list.append(fig_name)
    # NWE Margin Component Chart
    fig_name = chart_path + 'NWEComplexMarginDailyEvoChart.png'
    img_list.append(fig_name)  
    # Med Margin Component Chart
    fig_name = chart_path + 'MedComplexMarginDailyEvoChart.png'
    img_list.append(fig_name) 
    # fig_name = chart_path + 'MedComplexMarginDailyEvoChart.png'
    # img = mpimg.imread(fig_name)
    # imgplot = plt.imshow(img)
    # plt.show()

    # NWE Forward Margin Chart
    fig_name = chart_path + 'NWEComplexMarginCurveChart.png'
    img_list.append(fig_name) 
    # NWE Hydroskim Forward Margin Chart
    fig_name = chart_path + 'NWEHydroskimMarginCurveChart.png'
    img_list.append(fig_name) 
    # NWE Topping Forward Margin Chart
    fig_name = chart_path + 'NWEToppingMarginCurveChart.png'
    img_list.append(fig_name)   
    # Med Forward Margin Chart
    fig_name = chart_path + 'MedComplexMarginCurveChart.png'
    img_list.append(fig_name)
    # NWE Margin Chart of prompt quarter
    fig_name = chart_path + 'NWEComplexMarginPromptQuarter.png'
    img_list.append(fig_name)  
    # Med Margin Chart of prompt quarter
    fig_name = chart_path + 'MedComplexMarginPromptQuarter.png'
    img_list.append(fig_name)
    # NWE Margin Chart of prompt year
    fig_name = chart_path + 'NWEComplexMarginPromptYear.png'
    img_list.append(fig_name)  
    # Med Margin Chart of prompt year
    fig_name = chart_path + 'MedComplexMarginPromptYear.png'
    img_list.append(fig_name)
    
    # Crude
    # Crude Structure
    fig_name = chart_path + 'CrudeChart-NWEStructure.png'
    img_list.append(fig_name)        
    # NWE Crude Diff
    fig_name = chart_path + 'CrudeChart-NWEDiff.png'
    img_list.append(fig_name)       
    # NWE Freight
    fig_name = chart_path + 'CrudeChart-NWEFreight.png'
    img_list.append(fig_name)        
    # Med Crude Diff
    fig_name = chart_path + 'CrudeChart-MedDiff.png'
    img_list.append(fig_name)       
    # Med Freight
    fig_name = chart_path + 'CrudeChart-MedFreight.png'
    img_list.append(fig_name)    

    # NWE Cracks Charts
    pkl_nwe_cracks = path + 'NWECracksData.pickle'
    df_nwe_cracks = pd.read_pickle(pkl_nwe_cracks)
    for col in df_nwe_cracks.columns:
        if col in ['Butane', 'LSVGO', 'HSVGO', 'LSSR', 'HSSR']:
            continue
        fig_name = 'NWECrackChart' + col + '.png'
        img_list.append(crk_chart_path+fig_name)        
        fig_name = 'NWECrackCurve' + col + '.png'
        img_list.append(crk_chart_path+fig_name)

    ### 2. NWE Tables
    # 2.1 NWE Spot Margin
    # With Gas Cost
    pkl_margin = path + 'NWEMarginData.pickle'
    df_nwe_margin = pd.read_pickle(pkl_margin)
    df_table = get_margin_table(df_nwe_margin)
    df_table = df_table.drop(df_table[(df_table.index=='Hydroskim')|(df_table.index=='Topping')].index)
    table_nwe_spot_gas = df2table(df_table, None, 'NWE Spot Margin($/BBL)')
    
    my_margin = round(df_nwe_margin.iloc[-1, 0], 2)
    my_margin_change = round(df_nwe_margin.iloc[-1, 0] - df_nwe_margin.iloc[-2, 0], 2)
    if my_margin_change > 0.1:
        outline_nwe = 'NWE spot margin gained ' + str(my_margin_change) + ' to ' + str(my_margin)
    elif my_margin_change < -0.1:    
        outline_nwe = 'NWE spot margin declined ' + str(my_margin_change) + ' to ' + str(my_margin)
    else:
        outline_nwe = 'NWE spot margin remains at' + str(my_margin)

    # No Gas Cost
    pkl_margin = path + 'NWEMarginDataNoGasCost.pickle'
    df_nwe_margin = pd.read_pickle(pkl_margin)
    df_table = get_margin_table(df_nwe_margin)
    table_nwe_spot = df2table(df_table, None, 'NWE Spot Margin(Without Gas Cost, $/BBL)')            
        

    # 2.2 Margin Component Table
    pkl_raw = path + 'NWERawData.pickle'
    df_nwe_raw = pd.read_pickle(pkl_raw)
    pkl_name = path + 'NWEComplexMarginComponentData.pickle'
    df_com_margin = pd.read_pickle(pkl_name)  
    ser_gascost = -df_com_margin['GasCost']

    
    # Cracks Table
    df_cracks_nwe = cal_cracks_lmm(df_nwe_raw)
    df_table = get_cracks_table(df_cracks_nwe, 'NWE')
    
    df_color = df_table.copy()
    df_color.iloc[:, [0, 1, 2, 4, 6]] = 0
    ser_tmp = df_color.std()
    ser_tmp[ser_tmp==0] = 1
    df_color = (df_color - df_color.mean()) / ser_tmp
    df_color.iloc[:, [0, 1, 2, 4, 6]] = 0
    
    table_nwe_com = df2table(df_table, df_color, 'NWE Spot Cracks($/BBL)')    
    
    # Crude Table
    # print(ser_gascost)
    # ser_gascost = ser_gascost.round(2)
    
    # ser_diff = df_com_margin['Crude Diffs'].round(2)
    # ser_gascost = ser_gascost.round(2)
    df_table = get_crude_table(df_nwe_raw, df_com_margin, 'NWE')
    df_color = df_table.copy()
    df_color.iloc[:, [0, 1, 3, 5]] = 0
    ser_tmp = df_color.std()
    ser_tmp[ser_tmp==0] = 1
    df_color = (df_color - df_color.mean()) / ser_tmp
    df_color.iloc[:, [0, 1, 3, 5]] = 0
    
    table_nwe_crude = df2table(df_table, df_color, 'NWE Crude($/BBL)')

    # 2.3 MWE Forward Margin Table
    pkl_margin = path_fwd + "NWEComplexForwardMargin-abs.pkl"

    # pkl_margin = path_fwd + "NWEComplexForwardGasMargin-40best.pkl"
    df_nwe_fwd = pd.read_pickle(pkl_margin)  
    # print(df_nwe_fwd)
    df_table = get_fwd_margin_table(df_nwe_fwd)

    df_color = df_table.copy()
    df_color.iloc[:, [0, 1, 3, 5, 7, 9]] = 0
    ser_tmp = df_color.std()
    ser_tmp[ser_tmp==0] = 1
    df_color = (df_color - df_color.mean()) / ser_tmp
    df_color.iloc[:, [0, 1, 3, 5, 7, 9]] = 0
    table_nwe_fwd = df2table(df_table, df_color, 'NWE Forward Margin($/BBL)')
    
    pkl_margin = path_fwd + "HydroskimWTIComplexForwardMargin-abs.pkl"
    df_nwe_hydro_fwd = pd.read_pickle(pkl_margin)  
    # print(df_nwe_hydro_fwd)
    df_table = get_fwd_margin_table(df_nwe_hydro_fwd)

    df_color = df_table.copy()
    df_color.iloc[:, [0, 1, 3, 5, 7, 9]] = 0
    ser_tmp = df_color.std()
    ser_tmp[ser_tmp==0] = 1
    df_color = (df_color - df_color.mean()) / ser_tmp
    df_color.iloc[:, [0, 1, 3, 5, 7, 9]] = 0
    table_nwe_hydro_fwd = df2table(df_table, df_color, 'NWE Hydroskim Forward Margin($/BBL)')

    pkl_margin = path_fwd + "ToppingWTIComplexForwardMargin-abs.pkl"
    df_nwe_top_fwd = pd.read_pickle(pkl_margin)  
    # print(df_nwe_hydro_fwd)
    df_table = get_fwd_margin_table(df_nwe_top_fwd)

    df_color = df_table.copy()
    df_color.iloc[:, [0, 1, 3, 5, 7, 9]] = 0
    ser_tmp = df_color.std()
    ser_tmp[ser_tmp==0] = 1
    df_color = (df_color - df_color.mean()) / ser_tmp
    df_color.iloc[:, [0, 1, 3, 5, 7, 9]] = 0
    table_nwe_top_fwd = df2table(df_table, df_color, 'NWE Topping Forward Margin($/BBL)')

    ### 3. Med Tables
    # 3.1 Med Spot Margin
    # With Gas Cost
    pkl_margin = path + 'MedMarginData.pickle'
    df_med_margin = pd.read_pickle(pkl_margin)
    
    # Margin Table    
    df_table = get_margin_table_med(df_med_margin)   
    table_med_spot_gas = df2table(df_table, None, 'Med Spot Margin($/BBL)')

    my_margin = round(df_med_margin.iloc[-1, 0], 2)
    my_margin_change = round(df_med_margin.iloc[-1, 0] - df_med_margin.iloc[-2, 0], 2)
    if my_margin_change > 0.1:
        outline_med = 'Med spot margin gained ' + str(my_margin_change) + ' to ' + str(my_margin)
    elif my_margin_change < -0.1:    
        outline_med = 'Med spot margin declined ' + str(my_margin_change) + ' to ' + str(my_margin)
    else:
        outline_med = 'Med spot margin remains at' + str(my_margin)
        
    # Without Gas Cost
    pkl_margin = path + 'MedMarginDataNoGasCost.pickle'
    df_med_margin = pd.read_pickle(pkl_margin)
    df_table = get_margin_table_med(df_med_margin)   
    table_med_spot = df2table(df_table, None, 'Med Spot Margin(Without Gas Cost, $/BBL)')    
   

 
    # 3.2 Margin Component Table
    pkl_raw = path + 'MedRawData.pickle'
    df_med_raw = pd.read_pickle(pkl_raw)
    pkl_name = path + 'MedComplexMarginComponentData.pickle'
    df_com_margin = pd.read_pickle(pkl_name)

    # Cracks Table
    df_cracks_med = cal_cracks_lmm(df_med_raw)
    df_table = get_cracks_table(df_cracks_med, 'Med')

    df_color = df_table.copy()
    df_color.iloc[:, [0, 1, 2, 4, 6]] = 0
    ser_tmp = df_color.std()
    ser_tmp[ser_tmp==0] = 1
    df_color = (df_color - df_color.mean()) / ser_tmp
    df_color.iloc[:, [0, 1, 2, 4, 6]] = 0

    table_med_com = df2table(df_table, df_color, 'Med Spot Cracks($/BBL)') 
  
    # Crude Table
    # print(df_med_raw)
    # df_med_raw.iloc[-1,-1] = 69.62
    df_table = get_crude_table(df_med_raw, df_com_margin, 'Med')
    df_color = df_table.copy()
    df_color.iloc[:, [0, 1, 3, 5]] = 0
    ser_tmp = df_color.std()
    ser_tmp[ser_tmp==0] = 1
    df_color = (df_color - df_color.mean()) / ser_tmp
    df_color.iloc[:, [0, 1, 3, 5]] = 0
    
    # print(df_table)
    # print(df_color)
    table_med_crude = df2table(df_table, df_color, 'Med Crude($/BBL)')



    # 3.3 Med Forward Margin Table    
    pkl_margin = path_fwd + "MedComplexForwardMargin-Abs.pkl"
    df_med_fwd = pd.read_pickle(pkl_margin)  
    df_table = get_fwd_margin_table(df_med_fwd)

    df_color = df_table.copy()
    df_color.iloc[:, [0, 1, 3, 5, 7, 9]] = 0
    ser_tmp = df_color.std()
    ser_tmp[ser_tmp==0] = 1
    df_color = (df_color - df_color.mean()) / ser_tmp
    df_color.iloc[:, [0, 1, 3, 5, 7, 9]] = 0
    
    table_med_fwd = df2table(df_table, df_color, 'Med Forward Margin($/BBL)')

    # 4. Render the html template
    file_loader = FileSystemLoader('template')
    env = Environment(loader=file_loader)
    template = env.get_template('margin_base.html')
    
    my_table = {
        # NWE
        'nwe_spot' : table_nwe_spot,
        'nwe_spot_gas' : table_nwe_spot_gas,
        'nwe_component' : table_nwe_com,
        'nwe_crude' : table_nwe_crude,
        'nwe_fwd' : table_nwe_fwd,
        'nwe_hydro_fwd' : table_nwe_hydro_fwd,
        'nwe_top_fwd' : table_nwe_top_fwd, 
        # Med
        'med_spot' : table_med_spot,
        'med_spot_gas' : table_med_spot_gas,
        'med_component' : table_med_com,
        'med_crude' : table_med_crude,
        'med_fwd' : table_med_fwd,
        }
        
    my_string = {
        # NWE
        'nwe_outline' : outline_nwe,
        'med_outline' : outline_med,
    }
    
    img_html_path = rf'\\\\petroineos.local\dfs\\Department Shared Folders\\~Analysis Department\\ApplicationFolder\\RefineryMargin\\{config.env}'
    html_output = template.render(date = str(today_date), table=my_table, string = my_string, imgfilepath = img_html_path)

    # file_name = './template/EuropeanMargin-' + str(today_date) + '.html'
    # with open(file_name, 'w') as f:
    #     f.write(html_output)
  
    print("Going to test emails")
    helper = ag_email_helper.AgEmailHelper()
    if config.env == 'UAT':
        sender = 'behzadhosseini@petroineos.co.uk'
        recipient = 'behzadhosseini@petroineos.co.uk;ShreyAgarwal@petroineos.co.uk'
    else:
        sender = 'behzadhosseini@petroineos.co.uk'
        recipient = get_recv_string()
    if recipient[-1] == ';':
        recipient = recipient[:-1]
    
    helper.send_mail_with_embedded_images(from_=sender, to_=recipient, subject=e_subject, body=html_output, images=img_list, attachments=img_list)
    print(f"Mail was sent to {recipient}")

def main(): 
    send_margin()
    
if __name__ == "__main__":
    print("Example")
    try:
        start = time.time()
        main()
        end = time.time()
        print('Task runs %0.2f seconds.' %(end - start))
    except KeyboardInterrupt:
        print("Ctrl+C pressed. Stopping...")      