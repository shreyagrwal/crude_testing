import datetime
import os
import pandas as pd
import sys
import time

import config
import matplotlib.pyplot as plt

import SaveDataSup as sds
import MarginSup as ms
# from MarginSup import *

path = config.path_margin
path_fwd = config.path_margin_fwd
chart_path = config.chart_path

def calc_cracks():
    # 1. Read Data
    # Raw Data
    pkl_filename = path + 'NWERawData.pickle'
    df = pd.read_pickle(pkl_filename)
    df_cols = df.columns
    df_cols = df_cols.drop('LMM')
    df = df.dropna(subset = df_cols, how='all', axis=0)
    # LMM
    ser_lmm = df['LMM']
    
    # 2. Calculation
    nwe_yield = config.nwe_com_yield
    prod_list = list(nwe_yield.keys())
    prod_list.remove('Other')
    prod_list.append('VLSFO') 
    conversion_factor = config.conversion_factor 
    df_cracks = pd.DataFrame([])    
    for i_prod in prod_list:
        i_cf = conversion_factor[i_prod]
        df_cracks[i_prod] = (df[i_prod] / i_cf) - ser_lmm 
    df_cracks = df_cracks.round(2)

    # 3. Save Data
    pkl_filename = path + 'NWECracksData.pickle'
    csv_filename = path + 'NWECracksData.csv'   
    df_cracks.to_pickle(pkl_filename)
    df_cracks.to_csv(csv_filename)

def calc_med_cracks():
    # 1. Read Data
    # Raw Data
    pkl_filename = path + 'MedRawData.pickle'
    df = pd.read_pickle(pkl_filename)
    df_cols = df.columns
    df_cols = df_cols.drop('LMM')
    df = df.dropna(subset = df_cols, how='all', axis=0)
    # LMM
    ser_lmm = df['LMM']
    
    # 2. Calculation
    nwe_yield = config.med_com_yield
    conversion_factor = config.conversion_factor 
    df_cracks = pd.DataFrame([])    
    for key, value in nwe_yield.items():
        if key == 'Other':
            continue
        i_cf = conversion_factor[key]
        df_cracks[key] = (df[key] / i_cf) - ser_lmm 
    df_cracks = df_cracks.round(2)
    # print(df_cracks)

    # 3. Save Data
    pkl_filename = path + 'MedCracksData.pickle'
    csv_filename = path + 'MedCracksData.csv'   
    df_cracks.to_pickle(pkl_filename)
    df_cracks.to_csv(csv_filename)

def main(): 
    # 1. Calculate  
    calc_cracks()
    calc_med_cracks()

if __name__ == "__main__":
    print("Example")
    try:
        start = time.time()
        main()
        end = time.time()
        print('Task runs %0.2f seconds.' %(end - start))
    except KeyboardInterrupt:
        print("Ctrl+C pressed. Stopping...")