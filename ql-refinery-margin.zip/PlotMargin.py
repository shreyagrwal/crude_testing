import datetime
import os
import numpy as np
import pandas as pd
import sys
import time

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

import PlotSup as ps

import MarginSup as ms

import config

title_font_sz = 20
x_font_sz = 16
y_font_sz = 16


path = config.path_margin
path_ttf = config.path_margin + 'GasCost/'
chart_path = config.chart_path
path_fwd = config.path_margin_fwd
path_hani = config.path_margin_hani

def plot_nwe_margin():

    fig = plt.figure(figsize=(16.5, 11.3 * 0.6), constrained_layout=True)
    mpl.style.use(['seaborn-darkgrid'])
 
    ############################
    ####1. NWE Margin Data######
    ############################ 
    #1.1 Spot Margin Data
    pkl_name = path + 'NWEComplexMarginComponentData.pickle'
    df_comp = pd.read_pickle(pkl_name)
    df_comp = df_comp.loc[lambda df_comp: df_comp.index >= datetime.date(2015, 1, 1)]
    ser_margin = df_comp.sum(axis=1)
    df_com_margin = ms.format_margin(ser_margin) 
    # pkl_name = path + 'NWEComplexMarginYearly.pickle'
    # df_com_margin.to_pickle(pkl_name)

    #1.2 Spot Margin Hydroskim WTI Data
    pkl_name = path + 'HydroskimWTIMarginComponentData.pickle'
    df_hydro = pd.read_pickle(pkl_name)
    df_hydro = df_hydro.loc[lambda df_hydro: df_hydro.index >= datetime.date(2015, 1, 1)]
    df_hydro_nogas = df_hydro.drop(['GasCost'],axis=1)
    ser_margin = df_hydro_nogas.sum(axis=1)
    df_hydro_margin = ms.format_margin(ser_margin)       

    #1.3 Spot Margin Topping WTI Data
    pkl_name = path + 'ToppingWTIMarginComponentData.pickle'
    df_top = pd.read_pickle(pkl_name)
    df_top = df_top.loc[lambda df_top: df_top.index >= datetime.date(2015, 1, 1)]
    df_top_nogas = df_top.drop(['GasCost'],axis=1)
    ser_margin = df_top_nogas.sum(axis=1)
    df_top_margin = ms.format_margin(ser_margin)
 
    # 1.4 Forward Margin Data
    # pkl_name = path_fwd + "NWEComplexForwardGasMargin-40best.pkl"
    pkl_name = path_fwd + "NWEComplexForwardMargin-abs.pkl"
    df_com_fwd = pd.read_pickle(pkl_name)        
    # pkl_nwe_sim_margin_fwd_abs = path_fwd + "NWESimpleForwardMargin-abs.pkl"
    # df_sim_fwd = pd.read_pickle(pkl_nwe_sim_margin_fwd_abs)

    # 1.5 Forward Hydroskim Margin Data
    pkl_name = path_fwd + "HydroskimWTIComplexForwardMargin-abs.pkl"
    df_hydro_fwd = pd.read_pickle(pkl_name)

    # 1.6 Forward Topping Margin Data
    pkl_name = path_fwd + "ToppingWTIComplexForwardMargin-abs.pkl"
    df_top_fwd = pd.read_pickle(pkl_name) 
    
    # 1.7 Quarterly and yearly forward margin
    ser_quar = ps.get_prompt_quarterly_margin(df_com_fwd)
    ser_year = ps.get_prompt_yearly_margin(df_com_fwd)
    df_quar = ms.format_margin(ser_quar) 
    df_year = ms.format_margin(ser_year) 
    
    # 1.8 Margin Evolution Data
    # Daily
    prod_yield = config.nwe_com_yield
    df_comp_day = df_comp.iloc[-100:, :]
    df_evo_day = ps.get_margin_evolution(df_comp_day, prod_yield) 
    # Weekly
    df_evo_week = ps.get_weekly_evolution_component(df_evo_day)
    # Monthly
    df_comp_month = ps.get_monthly_margin_component(df_comp)
    df_evo_month = ps.get_margin_evolution(df_comp_month, prod_yield)
    
    ############################
    ####2. NWE Margin Chart#####
    ############################     
    # 2.1 Plot spot margin
    # NWE Complex
    fig_title = "NWE Complex Margin($/BBL)"
    fig_name = chart_path + 'NWEComplexMarginChart.png'
    fig = ps.plot_margin(df_com_margin, df_com_fwd, fig, fig_title, 's')
    fig.savefig(fig_name, format = 'png') 

    # NWE Simple
    # fig_title = "NWE Simple Margin($/BBL)"
    # fig_name = chart_path + 'NWESimpleMarginChart.png'
    # fig = plot_margin(df_sim_margin, df_sim_fwd, fig, fig_title, 's')
    # fig.savefig(fig_name, format = 'png')

    # NWE Hydroskim
    fig_title = "NWE Hydroskim WTI Margin($/BBL)"
    fig_name = chart_path + 'NWEHydroskimMarginChart.png'
    fig = ps.plot_margin(df_hydro_margin, df_hydro_fwd, fig, fig_title, 's')
    fig.savefig(fig_name, format = 'png') 

    # NWE Topping
    fig_title = "NWE Topping WTI Margin($/BBL)"
    fig_name = chart_path + 'NWEToppingMarginChart.png'
    fig = ps.plot_margin(df_top_margin, df_top_fwd, fig, fig_title, 's')
    fig.savefig(fig_name, format = 'png') 
   
    # 2.2 Plot Margin Evolution
    # Daily   
    fig_title = "NWE Complex Margin($/BBL) - Daily Components Evolution over 2 Months"
    fig_name = chart_path + 'NWEComplexMarginDailyEvoChart.png'     
    fig = ps.plot_margin_evolution(df_evo_day, fig, fig_title, 'd')    
    fig.savefig(fig_name, format = 'png')
    
    # Weekly
    fig_title = "NWE Complex Margin($/BBL) - Weekly Components Evolution over 16 Weeks"
    fig_name = chart_path + 'NWEComplexMarginWeeklyEvoChart.png'  
    fig = ps.plot_margin_evolution(df_evo_week, fig, fig_title, 'week')    
    fig.savefig(fig_name, format = 'png')   

    # Monthly
    fig_title = "NWE Complex Margin($/BBL) - Monthly Average Components Evolution over 2 Years"
    fig_name = chart_path + 'NWEComplexMarginMonthlyChart.png'   
    fig = ps.plot_margin_evolution(df_evo_month, fig, fig_title, 'm')    
    fig.savefig(fig_name, format = 'png')  
    
    # Weekly Change
    fig_title = "NWE Complex Margin - Weekly Components Changes"
    fig_name = chart_path + 'NWEComplexMarginWeeklyChangeChart.png'    
    fig = ps.plot_margin_weekly_change(df_evo_week, fig, fig_title)
    fig.savefig(fig_name, format = 'png') 
    
    # Weekly Contributors
    fig_title = "NWE Complex Margin - Weekly Changes Contributors"
    fig_name = chart_path + 'NWEComplexMarginWeeklyContributorChart.png'       
    fig = ps.plot_margin_contributors(df_evo_week, fig, fig_title)
    fig.savefig(fig_name, format = 'png')    

    # 2.4 Plot and save NWE Forward Curve
    # NWE Complex Curve
    fig_title = "NWE Complex Margin Forward Curve($/BBL)"
    fig_name = chart_path + 'NWEComplexMarginCurveChart.png'
    fig = ps.plot_fwd_margin(df_com_fwd, fig, fig_title)
    fig.savefig(fig_name, format = 'png') 

    # NWE Hydroskim Curve
    fig_title = "NWE Hydroskim Margin Forward Curve($/BBL)"
    fig_name = chart_path + 'NWEHydroskimMarginCurveChart.png'
    fig = ps.plot_fwd_margin(df_hydro_fwd, fig, fig_title, True)
    fig.savefig(fig_name, format = 'png') 

    # NWE Topping Curve
    fig_title = "NWE Topping Margin Forward Curve($/BBL)"
    fig_name = chart_path + 'NWEToppingMarginCurveChart.png'
    fig = ps.plot_fwd_margin(df_top_fwd, fig, fig_title, True)
    fig.savefig(fig_name, format = 'png') 

    # NWE Simple Curve
    # fig_title = "NWE Simple Margin Forward Curve($/BBL)"
    # fig_name = chart_path + 'NWESimpleMarginCurveChart.png'
    # fig = plot_fwd_margin(df_sim_fwd, fig, fig_title)
    # fig.savefig(fig_name, format = 'png') 
 
    # 2.5 Plot and save NWE Complex Margin of Promt Quarter and Year
    # Quarterly
    fig_title = 'NWE Complex Margin of Prompt Quarter($/BBL)'
    fig_name = chart_path + 'NWEComplexMarginPromptQuarter.png'
    fig = ps.plot_margin(df_quar, None, fig, fig_title, 'q')
    fig.savefig(fig_name, format = 'png') 
    # Yearly
    fig_title = 'NWE Complex Margin of Prompt Year($/BBL)'
    fig_name = chart_path + 'NWEComplexMarginPromptYear.png'
    fig = ps.plot_margin(df_year, None, fig, fig_title, 'y')
    fig.savefig(fig_name, format = 'png')     
    
def plot_med_margin():   
    fig = plt.figure(figsize=(16.5, 11.3 * 0.6), constrained_layout=True)
    mpl.style.use(['seaborn-darkgrid'])
    
    ############################
    ####1. Med Margin Data######
    ############################ 
    #1.1 Spot Margin Data
    pkl_name = path + 'MedComplexMarginComponentData.pickle'
    df_comp = pd.read_pickle(pkl_name)    
    # pkl_name = path + 'NWEComplexMarginComponentData.pickle'
    # df_comp_nwe = pd.read_pickle(pkl_name)
    df_comp = df_comp.loc[lambda df_comp: df_comp.index >= datetime.date(2015, 1, 1)]
    ser_margin = df_comp.sum(axis=1)
    df_com_margin = ms.format_margin(ser_margin) 
 
    # 1.2 Forward Margin Data
    # pkl_name = path_fwd + "MedComplexForwardGasMargin-40best.pkl"
    pkl_name = path_fwd + "MedComplexForwardMargin-abs.pkl"
    df_com_fwd = pd.read_pickle(pkl_name)        
    # pkl_nwe_sim_margin_fwd_abs = path_fwd + "MedSimpleForwardMargin-abs.pkl"
    # df_sim_fwd = pd.read_pickle(pkl_nwe_sim_margin_fwd_abs)
    
    # 1.3 Quarterly and yearly forward margin
    ser_quar = ps.get_prompt_quarterly_margin(df_com_fwd)
    ser_year = ps.get_prompt_yearly_margin(df_com_fwd)
    df_quar = ms.format_margin(ser_quar) 
    df_year = ms.format_margin(ser_year) 
   
    # 1.4 Margin Evolution Data
    # Daily
    prod_yield = config.med_com_yield
    df_comp_day = df_comp.iloc[-100:, :]
    df_evo_day = ps.get_margin_evolution(df_comp_day, prod_yield) 
    # Weekly
    df_evo_week = ps.get_weekly_evolution_component(df_evo_day)
    # Monthly
    df_comp_month = ps.get_monthly_margin_component(df_comp)
    df_evo_month = ps.get_margin_evolution(df_comp_month, prod_yield)
    
    ############################
    ####2. Med Margin Chart#####
    ############################     
    # 2.1 Plot spot margin
    # Med Complex
    fig_title = "Med Complex Margin($/BBL)"
    fig_name = chart_path + 'MedComplexMarginChart.png'
    fig = ps.plot_margin(df_com_margin, df_com_fwd, fig, fig_title, 's')
    fig.savefig(fig_name, format = 'png') 

    # Med Simple
    # fig_title = "Med Simple Margin($/BBL)"
    # fig_name = chart_path + 'MedSimpleMarginChart.png'
    # fig = plot_margin(df_sim_margin, df_sim_fwd, fig, fig_title, 's')
    # fig.savefig(fig_name, format = 'png')
   
    # 2.2 Plot Margin Evolution
    # Daily   
    fig_title = "Med Complex Margin($/BBL) - Daily Components Evolution over 2 Months"
    fig_name = chart_path + 'MedComplexMarginDailyEvoChart.png'     
    fig = ps.plot_margin_evolution(df_evo_day, fig, fig_title, 'd')    
    fig.savefig(fig_name, format = 'png')
    
    # Weekly
    fig_title = "Med Complex Margin($/BBL) - Weekly Components Evolution over 16 Weeks"
    fig_name = chart_path + 'MedComplexMarginWeeklyEvoChart.png'  
    fig = ps.plot_margin_evolution(df_evo_week, fig, fig_title, 'week')    
    fig.savefig(fig_name, format = 'png')   

    # Monthly
    fig_title = "Med Complex Margin($/BBL) - Monthly Average Components Evolution over 2 Years"
    fig_name = chart_path + 'MedComplexMarginMonthlyChart.png'   
    fig = ps.plot_margin_evolution(df_evo_month, fig, fig_title, 'm')    
    fig.savefig(fig_name, format = 'png')  
    
    # Weekly Change
    fig_title = "Med Complex Margin - Weekly Components Changes"
    fig_name = chart_path + 'MedComplexMarginWeeklyChangeChart.png'    
    fig = ps.plot_margin_weekly_change(df_evo_week, fig, fig_title)
    fig.savefig(fig_name, format = 'png') 
    
    # Weekly Contributors
    fig_title = "Med Complex Margin - Weekly Changes Contributors"
    fig_name = chart_path + 'MedComplexMarginWeeklyContributorChart.png'       
    fig = ps.plot_margin_contributors(df_evo_week, fig, fig_title)
    fig.savefig(fig_name, format = 'png')    

    # 2.4 Plot and save Med Forward Curve
    # Med Complex Curve
    fig_title = "Med Complex Margin Forward Curve($/BBL)"
    fig_name = chart_path + 'MedComplexMarginCurveChart.png'
    fig = ps.plot_fwd_margin(df_com_fwd, fig, fig_title)
    fig.savefig(fig_name, format = 'png') 

    # Med Simple Curve
    # fig_title = "Med Simple Margin Forward Curve($/BBL)"
    # fig_name = chart_path + 'MedSimpleMarginCurveChart.png'
    # fig = plot_fwd_margin(df_sim_fwd, fig, fig_title)
    # fig.savefig(fig_name, format = 'png') 
 
    # 2.5 Plot and save Med Complex Margin of Promt Quarter and Year
    # Quarterly
    fig_title = 'Med Complex Margin of Prompt Quarter($/BBL)'
    fig_name = chart_path + 'MedComplexMarginPromptQuarter.png'
    fig = ps.plot_margin(df_quar, None, fig, fig_title, 'q')
    fig.savefig(fig_name, format = 'png') 
    # Yearly
    fig_title = 'Med Complex Margin of Prompt Year($/BBL)'
    fig_name = chart_path + 'MedComplexMarginPromptYear.png'
    fig = ps.plot_margin(df_year, None, fig, fig_title, 'y')
    fig.savefig(fig_name, format = 'png') 

 
def test():
    path = 'I:/Crude Oil Department/Analytics/wq/DG_Data/European Margin/'
    
    pkl_raw = path + 'NWERawData.pickle'
    df_nwe_raw = pd.read_pickle(pkl_raw)
    ser_lmm = df_nwe_raw['LMM']

    
    pkl_med_com_margin_component = path + 'MedComplexMarginComponentData.pickle'
    df_med_com_margin_component = pd.read_pickle(pkl_med_com_margin_component) 
    
    df_component = df_med_com_margin_component.iloc[-100:, :]
    df_component = ps.get_margin_evolution(df_component, ser_lmm, 'MedComplex', 'd')  
    
    # df_component_week = get_weekly_margin_component(df_component)
    # df_component_month = ps.get_margin_evolution(df_med_com_margin_component, ser_lmm, 'MedComplex', 'm') 
    
def main():
    plot_nwe_margin()
    plot_med_margin()
    # test()
    # plot_crack()
    
if __name__ == "__main__":
    print("Example")
    try:
        start = time.time()
        main()
        end = time.time()
        print('Task runs %0.2f seconds.' %(end - start))
    except KeyboardInterrupt:
        print("Ctrl+C pressed. Stopping...")        