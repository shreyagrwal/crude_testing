import datetime
import os
import numpy as np
import pandas as pd
import sys
import time

import config

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

from MarginSup import *

title_font_sz = 20
x_font_sz = 16
y_font_sz = 16

def format_crack(df):

    df = df.dropna(how='all')

    inds = [datetime.date(1972, 1, 1) + datetime.timedelta(i) for i in range(366)] 
    df1 = pd.DataFrame([], index = inds)

    for ind, row in df.iterrows():
        x = datetime.date(1972, ind.month, ind.day)
        y = ind.year
        df1.loc[x, y] = row[0]
    
    df1 = df1.fillna(method='backfill')

    return df1

def format_fwd_crack(df_fwd_margin):

    inds = [datetime.date(1972, 1, 1) + datetime.timedelta(i) for i in range(366)]
     
    df_new_fwd_margin = pd.DataFrame([], index = inds) 
    
    for ind, row in df_fwd_margin.iterrows():
        if ind.year == 1:
            next_day = get_next_trading_day(row.index[0])
            x = datetime.date(1972, next_day.month, next_day.day)
            y = next_day.year
        else:
            x = datetime.date(1972, ind.month, ind.day)
            y = ind.year            
        df_new_fwd_margin.loc[x, y] = row[0]
    df_new_fwd_margin = df_new_fwd_margin.fillna(method='ffill')
    
    return df_new_fwd_margin

def cal_fwd_crack(df_prod, df_brt, cf):
    
    df_prod = df_prod.iloc[:, -1:]
    df_prod = df_prod.dropna(how="any")    
    
    df_brt = df_brt.iloc[:, -1:]
    df_brt = df_brt.dropna(how="any")
    # print(df_prod)
    # print(df_brt)
    for ind in df_prod.index:
        df_prod.loc[ind] = df_prod.loc[ind] / cf - df_brt.loc[ind]
    df_prod = df_prod.round(2)
    df_prod = format_fwd_crack(df_prod)

    return df_prod
    
    
#Get Monthly Average and Rearrange
def get_month_ave_crack(df):

    inds = [datetime.date(ind.year, ind.month, 1) for ind in df.index]
    df.index = inds
    
    gp = df.groupby(df.index, axis = 0, sort = False)
    df_m = gp.mean()
    ser_m = df_m.mean(axis=1)
    
    inds = [datetime.date(1972, 1, 1) + datetime.timedelta(i) for i in range(366)]
	
    dicts = {}
    for ind in inds:
        tmp_date = datetime.date(ind.year, ind.month, 1)
        value = ser_m[tmp_date]
        dicts[ind] = value
    ser1 = pd.Series(dicts)
    return ser1

def plot_crack(that_df_spot, that_df_fwd, fig, fig_title):
    mpl.style.use(['seaborn-darkgrid'])

    #1. Definitions
    df_crk = that_df_spot
    df_crk_fwd = that_df_fwd


    fig.clf()
    ax = fig.add_subplot(111)
    

    
    #2. Plot Margin Chart
    ind = np.arange(df_crk.index.size) 
    
    # 2.1 x
    x_data = df_crk.index
 
    # 2.2 y  
    #Historical
    df_his_crk = df_crk.loc[:, 2015:2019]
    df_his_crk = df_his_crk.fillna(method='ffill')
    
    if df_his_crk.columns.min() <= 2015:
        y_data_min = df_his_crk.min(axis=1)
        y_data_max = df_his_crk.max(axis=1)
        y_data_ave = get_month_ave_crack(df_his_crk)
    else:
        y_data_his = df_his_crk
    
    #2020
    ser_data_2020 = df_crk.loc[:, 2020:2020]

    #2021
    ser_data_2021 = df_crk.loc[:, 2021:2021]

    #2022
    ser_data_2022 = df_crk.loc[:, 2022:2022]

    #2023
    ser_data_2023 = df_crk.loc[:, 2023:2023]
    
    #This Year
    ser_data_this_year = df_crk.iloc[:, -1:]
    
    #Forward
    ser_data_fwd0 = df_crk_fwd.iloc[:, 0:1]
    ser_data_fwd1 = df_crk_fwd.iloc[:, 1:2]
    
    # 2.3 Plot
    if df_his_crk.columns.min() > 2015:
        for col in y_data_his.columns:
            ax.plot(ind, y_data_his[col], label = col%100) 
    # 2020
    labels = str(ser_data_2020.columns[0]%100)
    y_data = ser_data_2020.to_numpy()
    ax.plot(ind, y_data, c = 'blueviolet', linewidth=1.5, label = labels)

    # 2021
    labels = str(ser_data_2021.columns[0]%100)
    y_data = ser_data_2021.to_numpy()
    ax.plot(ind, y_data, c = 'darkcyan', linewidth=1.5, label = labels)

    # 2022
    labels = str(ser_data_2022.columns[0] % 100)
    y_data = ser_data_2022.to_numpy()
    ax.plot(ind, y_data, c='royalblue', linewidth=1.5, label=labels)
    
    # 2023
    labels = str(ser_data_2023.columns[0] % 100)
    y_data = ser_data_2023.to_numpy()
    ax.plot(ind, y_data, c='deeppink', linewidth=1.5, label=labels)

    # This Year
    labels = str(ser_data_this_year.columns[0]%100)
    y_data = ser_data_this_year.to_numpy()
    ax.plot(ind, y_data, c ='firebrick', linewidth=2.5, label = labels)
    
    # This Year Forward
    labels = str(ser_data_fwd0.columns[0]%100) + ' Fwd'
    y_data = ser_data_fwd0.to_numpy()
    ax.plot(ind, y_data, color = 'crimson', linewidth=2.5, linestyle = '--', label = labels)    
    # Next Year Forward
    if not ser_data_fwd1.empty:
        labels = str(ser_data_fwd1.columns[0]%100) + ' Fwd'
        y_data = ser_data_fwd1.to_numpy()
        ax.plot(ind, y_data, color = 'darkorange', linestyle = '--', label = labels)
    
    if df_his_crk.columns.min() <= 2015:
        # 5 year Average
        labels = str(df_his_crk.columns[0]%100) + '-' + str(df_his_crk.columns[-1]%100) + ' Avg'
        ax.plot(ind, y_data_ave, 'k-.', label = labels) 
        # 5 Year Range
        labels = str(df_his_crk.columns[0]%100) + '-' + str(df_his_crk.columns[-1]%100) + '\n Range'
        ax.fill_between(ind, y_data_min, y_data_max, alpha=0.4, color = 'cadetblue', label = labels)        

    # 2.4 Chart Setting
    # Title
    ax.set_title(fig_title, fontdict={'fontsize':title_font_sz})
    
    # X tick label
    x_ticks = []
    x_tick_labels = []
    y_min, y_max = ax.get_ylim()
    if y_min >= -1:
        y_min = -1
    for i in range(len(x_data)):
        if x_data[i].day == 1:
            x_ticks.append(i)
            x_tick_labels.append(x_data[i].strftime('%b'))  
            
            # Setting x grid for quarterly chart
            if x_data[i].month in [1, 4, 7, 10]:
                ax.plot([i, i], [y_min, y_max], 'k', alpha = 0.4)
            # else:
                # ax.plot([i, i], [y_min, y_max], 'k', alpha = 0.2)

    ax.plot([ind[-1], ind[-1]], [y_min, y_max], 'k', alpha = 0.4)    
        
    ax.set_xticks(x_ticks, minor = False)
    ax.set_xticklabels(x_tick_labels, fontdict={'fontsize':x_font_sz}, minor = False)  
    
    # Y Ticks
    ax.tick_params(axis='y', labelsize = y_font_sz)

    
    # Show Legend
    ax.legend(bbox_to_anchor=(1, 0.70), ncol=1, loc = 'lower left', fontsize = 'x-large')

    # Setting y grid
    x_min, x_max = ax.get_xlim()
    ax.plot([x_min, x_max], [0, 0], 'k', linewidth=1, alpha = .4)
    
    # Set y limit
    ax.set_ylim(y_min, y_max)
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    
    plt.tight_layout() 
    return fig

def plot_crack_curve(df_prod, df_brt, cf, fig, fig_title):
    mpl.style.use(['seaborn-darkgrid'])
    #### 1. Definitions
    fig.clf()
    ax = fig.add_subplot(111)    
    
    # 2. Calculate Crack on the curve
    m_date = df_prod.columns[-1]
    m_date_d = df_prod.columns[-2]
    m_date_w = df_prod.columns[-5]
    # m_date_w = m_date - datetime.timedelta(days=7)
    # if is_bank_holiday(m_date_w):
        # m_date_w = get_previous_trading_day(m_date_w)  
    m_date_m = df_prod.columns[-21]
    m_date_3m = df_prod.columns[-63]
    m_date_6m = df_prod.columns[-126]
    df_prod = df_prod[[m_date_6m, m_date_3m, m_date_m, m_date_w, m_date]].copy()        
    
    # df_prod = df_prod.iloc[1:, [-126, -63, -21, -6, -1]] #3 month, 1 month, 1 week, Last day
    df_prod = df_prod.iloc[1:, :] #3 month, 1 month, 1 week, Last day
    df_prod = df_prod.dropna(how='all')
    df_prod = df_prod.iloc[3:26, :] # For Curve of 6m, only show recent months
    
    df_crk = df_prod.copy()
    for col, col_ser in df_prod.items():
        df_crk[col] = df_prod[col]/cf - df_brt[col]

    
    #### 2. Plot Crack Curve
    # 2.1 x
    ind = np.arange(df_crk.index.size) 
    x_data = df_crk.index

    # 2.2 y  
    #Last
    y_data_last = df_crk.iloc[:, -1]    
    #Last week
    y_data_1w = df_crk.iloc[:, -2] 
    #Last Month
    y_data_1m = df_crk.iloc[:, -3]    
    #3 Month    
    y_data_3m = df_crk.iloc[:, -4]    
    #6 Month    
    y_data_6m = df_crk.iloc[:, -5]


    # labels = y_data_last.name.strftime('%b %d, %y') + '(Last)'
    labels = y_data_last.name.strftime('%b %d')
    ax.plot(ind, y_data_last, 'D-', c = 'blueviolet', linewidth=3, label = labels)    
    
    # labels = y_data_1w.name.strftime('%b %d, %y') + '(1 week)'
    labels = '1 week\n' + y_data_1w.name.strftime('%b %d')
    ax.plot(ind, y_data_1w, 'o--', label = labels) 
    
    # labels = y_data_1m.name.strftime('%b %d, %y') + '(1 month)'
    labels = '1 month\n' + y_data_1m.name.strftime('%b %d')
    ax.plot(ind, y_data_1m, 'o--', label = labels)    
    
    # labels = y_data_3m.name.strftime('%b %d, %y') + '(3 months)'
    labels = '3 months\n' + y_data_3m.name.strftime('%b %d')
    ax.plot(ind, y_data_3m, 'o--', label = labels)    
    
    # labels = y_data_6m.name.strftime('%b %d, %y') + '(6 months)'
    labels = '6 months\n' + y_data_6m.name.strftime('%b %d')
    ax.plot(ind, y_data_6m, 'o--', label = labels)
    
    # 2.4 Chart Setting
    # Title
    ax.set_title(fig_title, fontdict={'fontsize':title_font_sz})
    
    # X tick label
    x_ticks = []
    x_tick_labels = []
    
    y_min, y_max = ax.get_ylim()
    if y_min >= -1:
        y_min = -1
    for i in range(len(x_data)):
        if x_data[i].month in [1, 4, 7, 10]:
            x_ticks.append(i) 
            x_tick_labels.append(x_data[i].strftime('%b %y'))
        # Setting x grid for quarterly chart
        if x_data[i].month in [1, 4, 7, 10]:
            ax.plot([i, i], [y_min, y_max], 'k', alpha = 0.4)
        # else:
            # ax.plot([i, i], [y_min, y_max], 'k', alpha = 0.2)    
    # ax.plot([ind[-1], ind[-1]], [y_min, y_max], 'k', alpha = 0.4)  
            
    ax.set_xticks(x_ticks, minor = False)
    ax.set_xticklabels(x_tick_labels, fontdict={'fontsize':x_font_sz}, minor = False)  
    
    # Y Ticks
    ax.tick_params(axis='y', labelsize = y_font_sz)
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    
    
    # Setting y grid
    # y_data_yline = [0 for i in ind]
    x_min, x_max = ax.get_xlim()
    if y_min <= 0 and y_max >= 0:
        ax.plot([x_min, x_max], [0, 0], 'k', linewidth=1, alpha = 0.4)
     
    # Show Legend
    ax.legend(bbox_to_anchor=(1, 0.9), ncol=1, fontsize = 'x-large', loc='upper left')
    plt.tight_layout()  
    return fig
 
def plot_all_crack():
    mpl.style.use(['seaborn-darkgrid'])
    my_path = config.path_margin
    my_path_fwd = config.path_margin_fwd
    my_chart_path = config.chart_path + 'Cracks/'


    fig = plt.figure(figsize=(16.5, 11.3 * 0.6))
    
    # 1 Variable Definitions
    # 1.1 NWE Cracks
    pkl_cracks = my_path + 'NWECracksData.pickle'
    df_nwe_cracks = pd.read_pickle(pkl_cracks)
    df_nwe_cracks = df_nwe_cracks.loc[lambda df: df.index >= datetime.date(2015, 1, 1)]
    
    # 1.2 Med Cracks
    pkl_cracks = my_path + 'MedCracksData.pickle'
    df_med_cracks = pd.read_pickle(pkl_cracks)
    df_med_cracks = df_med_cracks.loc[lambda df: df.index >= datetime.date(2015, 1, 1)]    
    
    # 1.2 Brent Forward
    pkl_nwe_brt_fwd = my_path_fwd + "NWEForwardICEBrentSwap-abs.pkl"
    df_brt_fwd = pd.read_pickle(pkl_nwe_brt_fwd)     
    
    conversion_factor = config.conversion_factor
    # 2 Plot NWE Crack Charts
    for col in df_nwe_cracks.columns:
        if col in ['Butane', 'LSVGO', 'HSVGO', 'LSSR', 'HSSR']:
            continue
        
        # 2.1 Open Data
        pkl_nwe_prod_fwd = my_path_fwd + "NWEForward" + col + "-abs.pkl"
        df_prod_fwd = pd.read_pickle(pkl_nwe_prod_fwd)  
        if col == 'LSFO':
            df_prod_fwd = df_prod_fwd.sort_index()
            # print(df_prod_fwd)
       
        cf = conversion_factor[col] # conversion factor
        
        # 2.2 Plot Spot Cracks
        df_crk_fwd = cal_fwd_crack(df_prod_fwd, df_brt_fwd, cf)
        df_crk_spot = format_crack(df_nwe_cracks.loc[:, col:col])

        fig_title = 'NWE ' + col + ' Crack($/BBL)'
        fig = plot_crack(df_crk_spot, df_crk_fwd, fig, fig_title)
        fig_name = my_chart_path + 'NWECrackChart' + col + '.png'
        fig.savefig(fig_name, format = 'png') 
        
        # 2.3 Plot Crack Curve
        fig_title = 'NWE ' + col + ' Crack Curve($/BBL)'
        fig = plot_crack_curve(df_prod_fwd, df_brt_fwd, cf, fig, fig_title)
        fig_name = my_chart_path + 'NWECrackCurve' + col + '.png'
        fig.savefig(fig_name, format = 'png') 

 
    # # 3 Plot Med Crack Charts
    # for col in df_med_cracks.columns:
        # if col in ['Butane']:
            # continue
        # # 2.1 Open Data
        # pkl_name= my_path_fwd + "MedForward" + col + "-abs.pkl"
        # df_prod_fwd = pd.read_pickle(pkl_name)  
        # cf = conversion_factor[col] # conversion factor
        
        # # 2.2 Plot Spot Cracks
        # df_crk_fwd = cal_fwd_crack(df_prod_fwd, df_brt_fwd, cf)
        # df_crk_spot = format_crack(df_nwe_cracks.loc[:, col:col])
        # fig_title = 'Med ' + col + ' Crack($/BBL)'
        # fig = plot_crack(df_crk_spot, df_crk_fwd, fig, fig_title)
        # fig_name = my_chart_path + 'MedCrackChart' + col + '.png'
        # fig.savefig(fig_name, format = 'png') 
        
        # # 2.3 Plot Crack Curve
        # fig_title = 'Med ' + col + ' Crack Curve($/BBL)'
        # fig = plot_crack_curve(df_prod_fwd, df_brt_fwd, cf, fig, fig_title)
        # fig_name = my_chart_path + 'MedCrackCurve' + col + '.png'
        # fig.savefig(fig_name, format = 'png') 

def main():
    plot_all_crack()        
    
        
 
if __name__ == "__main__":
    print("Example")
    try:
        start = time.time()
        main()
        end = time.time()
        print('Task runs %0.2f seconds.' %(end - start))
    except KeyboardInterrupt:
        print("Ctrl+C pressed. Stopping...")        