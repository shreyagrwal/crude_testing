import os
import datetime
import shutil
import win32com.client as win32


def generate_pdf():
    cmd = 'xelatex -output-directory=./MarginPDF -aux-directory=./MarginPDF/logfiles EuroMargin.tex'
    os.system(cmd)

    today_date = datetime.date.today()
    pdf_name = "./MarginPDF/EuropeanMargin-" + today_date.strftime("%Y-%m-%d") + ".pdf"
    shutil.copy("./MarginPDF/EuroMargin.pdf", pdf_name)

def send_email():
    today_date = datetime.date.today()
    outlook = win32.Dispatch('outlook.application')
    email = outlook.CreateItem(0)
    email.To = 'report-admin@petrochina.com.sg; report.pcanalyst00@petrochina-usa.com;'
    email.CC = 'Wenqiang.liu@petroineos.com; judith-tan@petrochina.com.sg'
    email.Subject = 'European Benchmark margin report-' + today_date.strftime("%Y-%m-%d")
    # email.Body = 'Message body'
    email.HTMLBody = 'This is an automated email, please contract <a href="mailto:wenqiang.liu@petroineos.com?subject=Feedback on European Margin Report PDF">Wenqiang Liu</a> if there is any question or feedback' #this field is optional

    # To attach a file to the email (optional):
    pdf_name = "C:/Users/wenqiangliu/AT/Margin/MarginPDF/EuropeanMargin-" + today_date.strftime("%Y-%m-%d") + ".pdf"
    my_attachment  = pdf_name
    email.Attachments.Add(my_attachment)

    email.Send()    
    
def main():
    generate_pdf()
    send_email()

    

if __name__ == '__main__':
    main()