import SaveMarginData as smd
import CalcMargin as cm
import CalcCrack as cc
import PlotMargin as pm
import PlotCrack as pcrk
import PlotCrude as pcrd
import SendMargin as sm
import time
from datetime import date, datetime
from dateutil.relativedelta import relativedelta

def main(): 
    from_date = date(2018, 1, 2)
    to_date = date.today() - relativedelta(days=+1)
    
    # 1. Save Margin Data
    print('Save Margin Data')
    smd.save_csv_data(from_date, to_date)
    
    # 2. Calculate Margin and Crack
    print('='*20)
    # Margin
    print('Calcatue Margin')
    cm.calc_margin()    
    # Crack
    print('Calcatue Crack')
    cc.calc_cracks()
    cc.calc_med_cracks()
   
    # 3. Plot Margin, Crack and Crude
    print('='*20)
    # Margin
    print('Plot Margin')
    pm.plot_nwe_margin()
    pm.plot_med_margin()
    # Crack
    print('Plot Crack')
    pcrk.plot_all_crack()
    # Crude
    print('Plot Crude')
    pcrd.plot_all_crude()
    
    # 4. Send Margin
    print('='*20)
    print('Send Margin')
    sm.send_margin()
    print('='*20)


if __name__ == "__main__":
    print("European Margin Report")
    try:
        start = time.time()
        main()
        end = time.time()
        print('Task runs %0.2f seconds.' %(end - start))
    except KeyboardInterrupt:
        print("Ctrl+C pressed. Stopping...")