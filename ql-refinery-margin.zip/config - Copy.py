import datetime
    
# Global Varible   
my_path_margin = 'I:/Crude Oil Department/Analytics/wq/DG_Data/European Margin/'
my_path_margin_fwd = 'I:/Crude Oil Department/Analytics/wq/DG_Data/European Margin/Forward/'
my_path_margin_hani = 'I:/Analysis Department/Projects/Europe Refinery Run/European Margins/'
my_path_margin_ali = 'S:/~Refined Products Department/Ali/Margins/'
my_chart_path = 'I:/Crude Oil Department/Analytics/wq/DG_Data/European Margin/Chart/'


mgw_bbl = -0.0342
# mgw_bbl = -0.0675

conversion_factor = {
    'Propane': 12.41,
    'Butane': 10.7,
    'Naphtha': 8.9,
    'Gasoline': 8.33,
    'Jet': 7.88,
    'ULSD': 7.45,
    'Gasoil': 7.45,
    'VLSFO': 6.77,  #6.77 in old version; 6.35 in platts
    'LSFO':	6.353,
    'HSFO': 6.353,
    'LSVGO': 6.95,
    'HSVGO': 6.95,
    'LSSR': 6.77,
    'HSSR': 6.77,
    # 'NWEFreight': 7.5,
    'Other' : 6.95
    }

nwe_crud_basket = {
    # 'Strip': {'NSStrip': -1},# 'Dated': 1,'NSStrip': 1,
    'Strip': {'Dated': -1},# 'Dated': 1,'NSStrip': 1,
    'Slate': {'Oseberg': -0.25,
            'Forties': -0.25,
            'Ekofisk': -0.25,
            'Urals': -0.25,
            },
    'Freight': {'NWEFreight': -1 / 7.5 * 0.75},
    'GasCost': {'GasCost': mgw_bbl},
    }
                    
nwe_crud_basket_new = {
    'Date': datetime.date(2022, 2, 22),
    # 'Strip': {'NSStrip': -1},# 'Dated': 1,'NSStrip': 1,
    'Strip': {'Dated': -1},# 'Dated': 1,'NSStrip': 1,   
    'Slate': {'Oseberg': -0.25,
            'Forties': -0.25,
            'Ekofisk': -0.25,
            'Johan': -0.25,
            },
    'Freight': {'NWEFreight': -1 / 7.5},
    'GasCost': {'GasCost': mgw_bbl},
    }                  

        
med_crud_basket = {
    'Strip': {'MedStrip': -1},# 'Dated': 1,'NSStrip': 1,
    # 'Strip': {'Dated': -1},# 'Dated': 1,'NSStrip': 1,
    'Slate': {
            'Urals': -0.25, # CIF 
            'CPC': -0.25, # CIF
            'Saharan': -0.25, # FOB
            'Azeri': -0.25, # CIF
            },
    'Freight': {'MedFreight': -1 / 7.5 * 0.25},
    'GasCost': {'GasCost': mgw_bbl},
    }  

med_crud_basket_new = {
    'Date': datetime.date(2022, 2, 22),
    'Strip': {'MedStrip': -1},# 'Dated': 1,'NSStrip': 1,
    # 'Strip': {'Dated': -1},# 'Dated': 1,'NSStrip': 1,
    'Slate': {
            'Sider': -0.33, # FOB
            'Saharan': -0.33, # FOB
            'Azeri': -0.34, # CIF
            },
    'Freight': {'MedFreight': -1 / 7.5 * 0.66},
    'GasCost': {'GasCost': mgw_bbl},
    }   
  


nwe_com_yield = {
    'Propane': 0.025,
    'Butane': 0.025,
    'Naphtha': 0.06,
    'Gasoline': 0.25,
    'Jet': 0.08,
    'ULSD': 0.26,
    'Gasoil': 0.11,
    'LSFO':	0.04,
    'HSFO': 0.06,
    'LSVGO': 0.02,
    # 'HSVGO': 0,
    'LSSR': 0.02,
    'HSSR': 0.01,
    'Other' : 0.03,
    }
                
nwe_com_yield_fwd = {
    'Propane': 0.05,
    'Naphtha': 0.06,
    'Gasoline': 0.25,
    'Jet': 0.08,
    'ULSD': 0.26,
    'Gasoil': 0.11,
    'LSFO':	0.04,
    'HSFO': 0.06,
    }

decay_factor = {
    0 : 1,
    1 : 1,
    2 : 0.8,
    3 : 0.5,
    4 : 0.2,
    }
                
nwe_sim_yield = {'Propane': 0.01,
                'Butane': 0.01,
                # 'Naphtha': 0.06,
                'Gasoline': 0.17,
                'Jet': 0.06,
                'ULSD': 0.30,
                'Gasoil': 0.07,
                # 'LSFO': 0,
                # 'HSFO': 0,
                # 'LSVGO': 0,
                # 'HSVGO': 0,
                'LSSR': 0.33,
                # 'HSSR': 0,
                # 'Other' : 0,
                } 

med_com_yield = {
    'Propane': 0.02,
    'Butane': 0.02,
    'Naphtha': 0.06,
    'Gasoline': 0.23,
    'Jet': 0.06,
    'ULSD': 0.31,
    'Gasoil': 0.08,
    'LSFO':	0.04,
    'HSFO': 0.08,
    # 'LSVGO': 0,
    # 'HSVGO': 0,
    # 'LSSR': 0.02,
    'HSSR': 0.01,
    'Other' : 0.07
    }

med_com_yield_fwd = {
    'Propane': 0.04,
    'Naphtha': 0.06,
    'Gasoline': 0.23,
    'Jet': 0.06,
    'ULSD': 0.31,
    'Gasoil': 0.08,
    'LSFO':	0.04,
    'HSFO': 0.08,
    }
                
med_sim_yield = {'Propane': 0.0118,
                'Butane': 0.0118,
                'Naphtha': 0.0121,
                'Gasoline': 0.1755,
                'Jet': 0.098,
                'ULSD': 0.2083,
                'Gasoil': 0.0875,
                # 'LSFO': 0,
                'HSFO': 0.2503,
                'LSVGO': 0.0272,
                'HSVGO': 0.0634,
                # 'LSSR': 0,
                # 'HSSR': 0,
                'Other' : 0.0276,
                }   