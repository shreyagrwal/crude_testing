import datetime
import os
import pandas as pd

import config
import MarginSup as ms
import sys
from ag_datagenic_rest_client import DataGenic
import warnings
warnings.filterwarnings("ignore")

path = config.path_margin
path_ttf = config.path_margin + 'GasCost/'
path_fwd = config.path_margin_fwd
path_hani = config.path_margin_hani 

# Summarise Raw Data
def save_spot_data(df_model, name_pre, start_date, end_date):
    
    pkl_raw = path + name_pre + '.pickle'
    csv_raw = path + name_pre + '.csv'
    brentexp = './BrentExp.csv'

    dg = DataGenic.create_from_environment()
    
    df_exp = pd.read_csv(brentexp, index_col=0)
    exp_list = [datetime.datetime.strptime(ind, '%m/%d/%Y').date() for ind in df_exp.index]

    #Summarise raw data
    if not os.path.exists(pkl_raw):
        df_data = pd.DataFrame([])
    else:
        df_data = pd.read_pickle(pkl_raw)
    
    #Spot
    modle_lmm2 = 'model://ICE_BRT_MM/EU.OIL.NTHSEA.ICE.AFT1MIN.BRENT.IND.M02/PRICE/ALL'
    df_lmm2 = dg.get_time_series(model_url=modle_lmm2,from_date=start_date, to_date=end_date)
    df_lmm2 = df_lmm2.reset_index()
    df_lmm2.rename(columns={'Time':'date','PRICE':'LMMM2'}, inplace=True)
    df_lmm2['date'] = df_lmm2['date'].dt.date
    df_lmm2.set_index('date', inplace=True)

    for ind, row in df_model.iterrows():
        print(ind,' ->> ', row['Name'],' ->> ', row['Model'])
        prod_name = row['Name']

        if prod_name == 'LMMM2':
            continue
            
        model = row['Model']
        df = dg.get_time_series(model_url=model,from_date=start_date, to_date=end_date)
        df = df.reset_index()
        df.rename(columns={'Time':'date','PRICE':row['Name']}, inplace=True)
        df['date'] = df['date'].dt.date
        df.set_index('date', inplace=True)
        if not os.path.exists(csv_raw):
            df_data = pd.concat([df_data, df[prod_name]], axis=1, sort = False)
        else:   
            for ind, row in df.iterrows():
                df_data.loc[ind, prod_name] = row[prod_name]
                if prod_name == 'LMM' and ind in exp_list:
                    df_data.loc[ind, 'LMM'] = df_lmm2.loc[ind, 'LMMM2']

    df_data = df_data.drop_duplicates(keep='last')                    
    df_data = df_data.dropna(subset = ['Gasoline'], how='all', axis=0)
    df_data.to_pickle(pkl_raw)
    try:
        df_data.to_csv(csv_raw)
    except:
        print(f'Data is saved as pickle but couldnt save {csv_raw}.csv file as it might be open or crashed')
        pass
    print(df_data)

def save_fwd_data_by_day(df_model_fwd, name_pre):
    
    dg = DataGenic.create_from_environment()

    #NWE Forward
    deciding_date = datetime.date.today()
    if ms.is_bank_holiday(deciding_date):
        deciding_date = ms.get_previous_trading_day(deciding_date)

    # Every day summary
    pub_date = datetime.date(2022, 9, 1)
    #pub_date = datetime.date(2023, 6, 1)
    while pub_date < deciding_date:
        path_fwd_daily = path_fwd + str(pub_date.year) + "/" + pub_date.strftime('%Y-%m-%d') + "/"
        pkl_fwd = path_fwd_daily + name_pre + ".pkl"
        csv_fwd = path_fwd_daily + name_pre + ".csv"
        
        if os.path.exists(pkl_fwd):
            pub_date = ms.get_next_trading_day(pub_date)
            continue
        
        df_data_fwd = pd.DataFrame([])
        for ind, row in df_model_fwd.iterrows():
            print(ind,' ->> ', row['Name'],' ->> ', row['Model'])
            prod_name = row['Name']  
            model = row['Model']
            df = dg.get_curve(model_url=model)
            df = df.reset_index()
            df['DATE'] = df['DATE'].dt.date
            df.set_index('DATE', inplace=True)
            ser_value = df['PRICE']
            ser_value.name = prod_name
            df_data_fwd = pd.concat([df_data_fwd, ser_value], axis=1, sort = False)
        if not df_data_fwd.empty:
            print(df_data_fwd)
            if not os.path.exists(path_fwd_daily):
                os.makedirs(path_fwd_daily)
            df_data_fwd.to_pickle(pkl_fwd)
            df_data_fwd.to_csv(csv_fwd)
        
        pub_date = ms.get_next_trading_day(pub_date)

def save_fwd_data_by_product(df_model_fwd):

    dg = DataGenic.create_from_environment()
    
    # Every Product summary
    for ind, row in df_model_fwd.iterrows():   

        pkl_abs = path_fwd + ind + "-abs.pkl"
        csv_abs = path_fwd + ind + "-abs.csv"        
        
        pkl_roll = path_fwd + ind + "-rolling.pkl"
        csv_roll = path_fwd + ind + "-rolling.csv"
                
        if os.path.exists(pkl_abs):
            df_fwd_abs = pd.read_pickle(pkl_abs)
            df_fwd_roll = pd.read_pickle(pkl_roll)
            pub_date = df_fwd_abs.columns[-1]
            # pub_date = get_next_trading_day(pub_date)
        else:
            df_fwd_abs = pd.DataFrame([])
            df_fwd_roll = pd.DataFrame([])
            pub_date = datetime.date(2015, 1, 2)
            #pub_date = datetime.date(2023, 7, 25)

        deciding_date = datetime.date.today()
        if ms.is_bank_holiday(deciding_date):
            deciding_date = ms.get_previous_trading_day(deciding_date)               
        while pub_date < deciding_date:
            path_fwd_daily = path_fwd + str(pub_date.year) + "/" + pub_date.strftime('%Y-%m-%d') + "/"
            csv_name = path_fwd_daily + ind +".csv"
            # if not os.path.exists(csv_name):
            #     pub_date = ms.get_next_trading_day(pub_date)
            #     continue
            model = row['Model']
            df_raw = dg.get_curve(model_url=model)
            df_raw = df_raw.reset_index()
            df_raw['DATE'] = df_raw['DATE'].dt.date
            df_raw.set_index('DATE', inplace=True)
            tmp_date = df_raw.index[0]
            
            #Absolute Month Tenor
            df = df_raw.rename(index = {tmp_date : datetime.date(1, 1, 1)})           
            ser_value = df['PRICE']
            ser_value.name = pub_date
            if pub_date not in df_fwd_abs.columns:
                df_fwd_abs = pd.concat([df_fwd_abs, ser_value], axis=1, sort = False)

            
            #Rolling Month Tenor           
            ser_value = df_raw['PRICE']
            ser_value.name = pub_date
            if pub_date not in df_fwd_roll.columns:
                df_fwd_roll = pd.concat([df_fwd_roll, ser_value], axis=1, sort = False)
            
            print(ind, pub_date)
            pub_date = ms.get_next_trading_day(pub_date)    

        if not df_fwd_abs.empty:
            df_fwd_abs = df_fwd_abs.round(2)
            df_fwd_abs = df_fwd_abs.sort_index(axis=1)
            df_fwd_abs = df_fwd_abs.loc[:,~df_fwd_abs.columns.duplicated()]
            
            df_fwd_abs.to_pickle(pkl_abs)
            df_fwd_abs.to_csv(csv_abs)        
        
        if not df_fwd_roll.empty:
            df_fwd_roll = df_fwd_roll.round(2)
            df_fwd_roll = df_fwd_roll.sort_index(axis=1)
            df_fwd_roll = df_fwd_roll.loc[:,~df_fwd_roll.columns.duplicated()]
            
            df_fwd_roll.to_pickle(pkl_roll)
            df_fwd_roll.to_csv(csv_roll)        

def save_ttf_data(df_ttf, start_date, end_date):

    dg = DataGenic.create_from_environment()
    
    # 1. TTF Expiry list
    pkl_name = path_ttf + 'TTF_EXP.pkl'  
    if not os.path.exists(pkl_name):
        csv_name = path_ttf + 'TTF_EXP.csv'
        df_exp = pd.read_csv(csv_name, index_col=0)
        ser_exp = df_exp.iloc[:, 0]
        ser_exp.index = [datetime.datetime.strptime(i_date, '%Y-%m-%d').date() for i_date in ser_exp.index]
        for ind, value in ser_exp.iteritems():
            ser_exp.loc[ind] = datetime.datetime.strptime(value, '%Y-%m-%d').date()
        ser_exp.to_pickle(pkl_name)
    else:
        ser_exp = pd.read_pickle(pkl_name)

    # 2. Save as Rolling Data        
    # 2.1 Read Existing File  
    # Rolling
    pkl_name = path_ttf + 'TTF-Rolling.pkl' 
    pkl_name_usd = path_ttf + 'TTF-USD-Rolling.pkl' 
    if os.path.exists(pkl_name): 
        df_roll = pd.read_pickle(pkl_name)
        df_roll_usd = pd.read_pickle(pkl_name_usd)
    else:
        df_cols = []
        for i in range(24):
            df_cols.append('M'+str(i+1).zfill(2))
        df_roll = pd.DataFrame([], columns=df_cols)    
        df_roll_usd = pd.DataFrame([], columns=df_cols)    
    
    # Absolute
    pkl_name = path_ttf + 'TTF-Abs.pkl' 
    pkl_name_usd = path_ttf + 'TTF-USD-Abs.pkl' 
    if os.path.exists(pkl_name): 
        df_abs = pd.read_pickle(pkl_name)
        df_abs_usd = pd.read_pickle(pkl_name_usd)
    else:
        df_cols = []
        for i in range(2014, 2031):
            for j in range(1, 13):
                df_cols.append(datetime.date(i, j, 1))    
        df_abs = pd.DataFrame([], columns=df_cols)   
        df_abs_usd = pd.DataFrame([], columns=df_cols)   
    
    # Currency
    modle_EURUSD = 'model://ECB_FX/EU.FX.SPOT.ECB.CET.USD.EUR/MID'
    ser_curncy = dg.get_time_series(model_url=modle_EURUSD,from_date=start_date, to_date=end_date)
    ser_curncy = ser_curncy.reset_index()
    ser_curncy.rename(columns={'Time':'date','PRICE':'LMMM2'}, inplace=True)
    ser_curncy['date'] = ser_curncy['date'].dt.date
    ser_curncy.set_index('date', inplace=True)
  
    # 2.2 Append New Data          
    i=0
    for ind, row in df_ttf.iterrows():
        print(ind,' ->> ', row['Name'],' ->> ', row['Model'])
        model = row['Model']
        #try:
        df = dg.get_time_series(model_url=model,from_date=start_date, to_date=end_date)
        df = df.reset_index()
        df.rename(columns={'Time':'date','PRICE':row['Name']}, inplace=True)
        df['date'] = df['date'].dt.date
        df.set_index('date', inplace=True)
        df_col = 'M' + str(i+1).zfill(2)
        i+=1
        for ind_cur, row_df in df.iterrows():          
            if ind_cur not in ser_curncy.index:
                ind_cur = ser_curncy.index[0]
            i_curncy = ser_curncy.loc[ind_cur]
            #Rolling
            df_roll.loc[ind_cur, df_col] = row_df[0]
            df_roll_usd.loc[ind_cur, df_col] = round(row_df[0]*i_curncy[0], 2)
            #Absolute
            ctct_month = ms.get_next_month(ind_cur)
            if ctct_month >= df_abs.columns[0] and ctct_month <= df_abs.columns[-1]:
                if ind_cur > ser_exp.loc[ctct_month]:
                    ctct_month = ms.get_next_month(ctct_month)
                for j in range(i):
                    ctct_month = ms.get_next_month(ctct_month)
                df_abs.loc[ind_cur, ctct_month] = row_df[0]
                df_abs_usd.loc[ind_cur, ctct_month] = round(row_df[0]*i_curncy[0], 2)
    
    # 3. Save Data
    # 3.1 Rolling
    # EURO
    pkl_name = path_ttf + 'TTF-Rolling.pkl'  
    csv_name = path_ttf + 'TTF-Rolling.csv'  
    df_roll.to_pickle(pkl_name)
    df_roll.to_csv(csv_name)    
    # USD
    pkl_name = path_ttf + 'TTF-USD-Rolling.pkl'  
    csv_name = path_ttf + 'TTF-USD-Rolling.csv'  
    df_roll_usd.to_pickle(pkl_name)
    df_roll_usd.to_csv(csv_name)
    
    # 3.2 Absolute
    # Euro
    pkl_name = path_ttf + 'TTF-Abs.pkl'  
    csv_name = path_ttf + 'TTF-Abs.csv'  
    df_abs.to_pickle(pkl_name)
    df_abs.to_csv(csv_name)    
    # USD
    pkl_name = path_ttf + 'TTF-USD-Abs.pkl'  
    csv_name = path_ttf + 'TTF-USD-Abs.csv'  
    df_abs_usd.to_pickle(pkl_name)
    df_abs_usd.to_csv(csv_name)


def save_gas_cost():
    # 1. Constant
    ton2mmmbtu = 47.646
    mgw2mmmbtu = 3.413
    ton2mgw = 47.646 / 3.413
    # mgw_bbl = 0.0675
    # mgw_bbl = 0.06

    pkl_name = path_ttf + 'TTF-USD-Rolling.pkl'  
    df_ttf = pd.read_pickle(pkl_name)
    
    pkl_name = path + 'NWERawData.pickle'  
    df_prop_spot = pd.read_pickle(pkl_name)  
    ser_prop_spot = df_prop_spot['Propane'] 
    
    pkl_name = path_fwd + 'NWEForwardPropane-rolling.pkl'  
    df_prop_fwd = pd.read_pickle(pkl_name)     
    
    df_prop_fwd = df_prop_fwd.T
    df_ttf = df_ttf.loc[df_prop_fwd.index[0]:]
    
    # 2. Spot
    ser_ttf_spot = df_ttf['M01']
    ser_prop_spot = ser_prop_spot.loc[df_prop_fwd.index[0]:]
    
    df_gas_spot = pd.DataFrame([], columns = ['NatGas', '40-60', '75-25'])
    df_gas_spot['NatGas'] = ser_ttf_spot
    ser_gascost = ser_prop_spot / ton2mgw * 0.4 + ser_ttf_spot * 0.6
    df_gas_spot['40-60'] = ser_gascost
    ser_gascost = ser_prop_spot / ton2mgw * 0.75 + ser_ttf_spot * 0.25
    df_gas_spot['75-25'] = ser_gascost
    df_gas_spot = df_gas_spot.round(2)    
    pkl_name = path_ttf + 'GasCost.pkl'  
    csv_name = path_ttf + 'GasCost.csv'  
    df_gas_spot.to_pickle(pkl_name)
    df_gas_spot.to_csv(csv_name)
    
    # 3. Forward
    # 3.1 Read Data
    # Propane
    pkl_name = path_fwd + 'NWEForwardPropane-Abs.pkl'  
    df_prop_fwd = pd.read_pickle(pkl_name)    
    df_prop_fwd = df_prop_fwd.T 
    # TTF
    pkl_name = path_ttf + 'TTF-USD-Abs.pkl'  
    df_ttf = pd.read_pickle(pkl_name) 
    df_ttf = df_ttf.loc[df_prop_fwd.index[0]:] 
    df_ttf = df_ttf.dropna(how='all', axis=1)
    # 3.2 Calculation    
    df_natgas = pd.DataFrame([])
    df_40 = pd.DataFrame([])
    df_75 = pd.DataFrame([])
    df_best40 = pd.DataFrame([])
    df_best75 = pd.DataFrame([])
    for i_col in df_ttf.columns:
        i_ttf = df_ttf[i_col]
        if i_col in df_prop_fwd.columns:
            i_prop = df_prop_fwd[i_col].copy()
        else:
            i_prop = df_prop_fwd.iloc[:, -1].copy()
        # 100% Natgas    
        ser_natgas = i_ttf
        ser_natgas.name = i_col
        df_natgas = pd.concat([df_natgas, ser_natgas], axis=1)
        # 60% Natgas
        ser_40 = i_prop / ton2mgw * 0.4 + i_ttf * 0.6
        ser_40.name = i_col
        df_40 = pd.concat([df_40, ser_40], axis=1)
        # 25% Natgas
        ser_75 = i_prop / ton2mgw * 0.75 + i_ttf * 0.25
        ser_75.name = i_col
        df_75 = pd.concat([df_75, ser_75], axis=1)
        # 60% Best
        ser_best_40 = pd.concat([ser_natgas, ser_40], axis=1).min(axis=1)
        ser_best_40.name = i_col
        df_best40 = pd.concat([df_best40, ser_best_40], axis=1)
        # 25% Best
        ser_best_75 = pd.concat([ser_natgas, ser_75], axis=1).min(axis=1)
        ser_best_75.name = i_col
        df_best75 = pd.concat([df_best75, ser_best_75], axis=1)
    df_40 = df_40.round(2)
    df_75 = df_75.round(2)
    df_best40 = df_best40.round(2)
    df_best75 = df_best75.round(2)
    
    # 3.3 Save Data
    # 100% Gas
    pkl_name = path_ttf + 'GasCost-NatGas.pkl' 
    csv_name = path_ttf + 'GasCost-NatGas.csv' 
    df_natgas.to_pickle(pkl_name)
    df_natgas.to_pickle(csv_name)
    # 60% Gas
    pkl_name = path_ttf + 'GasCost-40LPG.pkl' 
    csv_name = path_ttf + 'GasCost-40LPG.csv' 
    df_40.to_pickle(pkl_name)
    df_40.to_pickle(csv_name)
    # 25% Gas
    pkl_name = path_ttf + 'GasCost-75LPG.pkl' 
    csv_name = path_ttf + 'GasCost-75LPG.csv' 
    df_75.to_pickle(pkl_name)  
    df_75.to_pickle(csv_name)  
    # 60% Best    
    pkl_name = path_ttf + 'GasCost-40best.pkl' 
    csv_name = path_ttf + 'GasCost-40best.csv' 
    df_best40.to_pickle(pkl_name) 
    df_best40.to_pickle(csv_name) 
    # 25% Best
    pkl_name = path_ttf + 'GasCost-75best.pkl' 
    csv_name = path_ttf + 'GasCost-75best.csv' 
    df_best75.to_pickle(pkl_name)  
    df_best75.to_pickle(csv_name)  